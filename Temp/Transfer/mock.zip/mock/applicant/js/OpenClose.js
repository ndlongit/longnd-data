// JavaScript Document
<!-- 折り畳みJS（新）-->

var folder=''
var image=''
var hd="img/minus.png"
var sw="img/plus.png"

function showFolder(subobj, imgobj) {
	folder=document.all(subobj).style
	image=document.all(imgobj)
	if (folder.display=="none") {
		folder.display=""
		image.src=hd
	} else {
		folder.display="none"
		image.src=sw
	}
}

/*絞りこみ条件のパネルを開閉する*/
function closeCondition(targetID,openImg,closeImg){
	var target = $("#"+targetID);
	var isClose = target.hasClass("closeCondition");
	if(!isClose){	
		target.hide();
		$("#leftPane").width(0);
		$("#closeIcon").css("left","-30px");
		$("#closeIcon").attr("top",top + "px");
		target.addClass("closeCondition");
		//グリッド部分の幅を伸ばす
		$("#rightPane").width("95%");
		
	} else{
		target.show();
		$("#leftPane").width("250px");
		$("#closeIcon").css("left","220px");
		target.removeClass("closeCondition");
		$("#rightPane").width("75%");
	}
}