$(document).ready(function(){
	showDatePicker($(".date"),"../img/ico_datepicker.png");
});