var prePageX = 0;
//応募者管理画面
var app_gridData =[
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"21","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"未入力","message":"<p class='label_NG'>自動NG</p><br /><a href='#'>14/07/11(金)</a>","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在",	"epmloyeesNum":"1000",	"listNonlist":"非上場"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":true},
	{"route":" ","offerName":"AssistUI改善PJT１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０","name":"山田花子<br/>（10001000）","age":"20","gender":"女","jobs":"企画/事務","income":"410","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_gMail'>受信</p><br />14/07/12(土)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田次郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"データに改行を含む場合\nAssistUI改善PJT１\nAssistUI改善PJT１２\nAssistUI改善PJT１２	３","name":"山田三郎<br/>（10001001）","age":"25","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/13(日)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田四朗","appNo":"10000002","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"405","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田花子","appNo":"10000003","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/15(火)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田花子","appNo":"10000004","isUnread":true},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"24","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/16(水)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"あいかわ","appNo":"10000005","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"27","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_coordination'>日程調整</p><br />14/07/17(木)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"いとう","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"21","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/18(金)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"うえだ","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_coordination'>日程調整</p><br />14/07/19(土)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"えとう","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"405","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"おがわ","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/21(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"かつやま","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/22(火)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"25","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/23(水)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":true},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"21","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_coordination'>日程調整</p><br />14/07/24(木)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"27","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p><br />14/07/11(金)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"410","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_gMail'>受信</p><br />14/07/12(土)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"23","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/13(日)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"405","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/15(火)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"24","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/16(水)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"24","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/17(木)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":true,"isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"25","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/18(金)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"405","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"30","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/20(日)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"27","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/21(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/22(火)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"405","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"21","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/24(木)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p><br />14/07/11(金)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":true},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"410","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_gMail'>受信</p><br />14/07/12(土)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/13(日)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"25","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/15(火)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_thanks'>サンクス</p><br />14/07/16(水)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"21","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/17(木)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"27","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/18(金)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/19(土)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":true},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"405","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"23","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/21(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"25","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/22(火)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"21","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/23(水)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"24","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/24(木)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p><br />14/07/11(金)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_gMail'>受信</p><br />14/07/12(土)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"21","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/13(日)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":true},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"27","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/15(火)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"405","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/17(木)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"24","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/18(金)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"27","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/19(土)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"23","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p><br />14/07/20(日)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/21(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":true},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"20","gender":"女","jobs":"企画/事務","income":"405","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p><br />14/07/14(月)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"24","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/23(水)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"800","routeA":"求人広告媒体","routeB":"直接応募","nameSub":"山田太郎","appNo":"10000001","isUnread":false},
	{"route":" ","offerName":"AssistUI改善PJT123456789","name":" ","age":"24","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p><br />14/07/23(水)","time":"14/07/12"	,"address":"東京都千代田区"	,"phoneNum":"000-0000-0000"	,"lastSchool":"大学"	,"faculty":"工学部"	,"graduateDiv":"卒業見込み"	,"graduationYear":"16/07/12"	,"incumResign":"現職中"	,"employmentStatus":"正社員"	,"jobChangeNum":"0"	,"jobContent":"最大2000文字入ります。あああああああああああああああああああああああああああああああああああああああああ"	,"officeName":"株式会社インテリジェンス"	,"workPeriod":"1999/01～現在"	,"business":"IT／通信  -  システムインテグレータ"	,"qualification":"普通自動車免許 第一種","englishSkill":"会話力：外国語で打ち合わせや交渉ができる読解力：資料・報告書などの読解には支障が無い作文力：報告書やレターを正しく書ける"	,"toeic":"300"	,"tofelI":"400"	,"tofelP":"500"	,"anoLang":"語学： 韓国語（ハングル）会話力：流暢ではないが、ある程度の日常会話ができる読解力：学校で外国語を学び、外国語に対してある程度抵抗が無い作文力：学校で外国語を学び、外国語に対してある程度抵抗が無い"	,"place":"最大150文字入ります。あああああああああ"	,"tofelP":"503"	,"person":"採用太郎"	,"languRemarks":"最大1000文字入ります。語学あああああ"	,"jobChangeHope":"18/04/01"	,"incomeHope":"1000","routeA":"最後の","routeB":"レコード","nameSub":"山田太郎","appNo":"10000001","isUnread":false}
];

var isItemDragging = false;
var prevID = "";
var idName;
var isDrop = false;
var isHeaderDragging = false;
var daraggingThID = "";
var isSameHeader = false;
var gridHeaderSize = {}
var rowSelectorWidth = 50;
var isSameTH=false;
var inHeader=false;
/*グリッドヘッダ内部のサイズを計算して当て直す*/
function calcHeaderTextWidth(columnKey){
	var spanWidth = $("#grid_"+columnKey).children("a").children(".ui-iggrid-headertext").width();
	var thWidth = $("#grid_"+columnKey).width();
	var containerWidth = $("#grid_"+columnKey).children(".ui-iggrid-indicatorcontainer").width();
	if( spanWidth + containerWidth >= thWidth) {
		var columnTextWidth = $("#grid_"+columnKey).width() - $("#grid_"+columnKey).children(".ui-iggrid-indicatorcontainer").width();
		$("#grid_"+columnKey).children("a").children(".ui-iggrid-headertext").width(columnTextWidth);
	} else {
		$("#grid_"+columnKey).children("a").children(".ui-iggrid-headertext").css("width","");
	}
}
/*追加した列にドラッグイベントを登録する*/
function addDragAddedElement(ui){
	var columnID =ui.draggable.attr("id").replace("_cloumn", "");
	var columnKey = columnID.replace("grid_","");
	//追加要素にイベント登録する
	addGridHeaderDrag("#"+columnID);
	//列を表示したらその時の幅を保存する
	gridHeaderSize[columnKey] = $("#"+columnID).width();
	calcHeaderTextWidth(columnKey);
	extendContents();
}
/*グリッドヘッダにドラッグ＆ドロップイベントを登録する*/
function addGridHeaderDrag(targetSelector){
	//グリッドのヘッダに項目をドロップしたとき
	$(targetSelector).on("drop",function(e,ui){
		if(isItemDragging || isHeaderDragging) {
			//ドロップされた要素は非活性にする
			$(".cloumn_selected").draggable({disabled:true});
			//挿入位置を示す線を削除
			$("#insertBorder").remove();
			//所定の位置にドロップされたとき
			isDrop = true;
			//ドラッグ要素のIDを取得
			var dragElemID = ui.draggable.attr("id").replace("grid_", "").replace("_cloumn", "");
			//ドロップされた列のIDを取得
			var dropElemID = $(this).attr("id").replace("grid_", "");
			//ドラッグされた列が非表示かどうか調べる、非表示なら先に表示しておく
			var isHidding;
			var cols = $("#grid").igGrid("option", "columns");
			for(var i =0; i < cols.length; i++) {
				if(cols[i].key == dragElemID) {
					isHidding = cols[i].hidden;
				}
			}
			if(isHidding){
				//列を表示する
				$("#grid").igGrid("showColumn", dragElemID);
				extendContents();
			}
			if(dropElemID == "autoGenerated" && prevID != "autoGenerated"){
				//チェックボックス列にドロップしたとき
				var wkID = $("#"+dropElemID).next().attr("id");
				//列を移動
				$("#grid").igGrid("moveColumn", dragElemID, wkID.replace("grid_", ""), false, true);
				//列を非表示にする
				if(!isHidding) $("#grid").igGrid("hideColumn", dragElemID);
				//列を表示する
				$("#grid").igGrid("showColumn", dragElemID);
				setTimeout(function(){addDragAddedElement(ui);},500);
				
			} else if((dropElemID == "autoGenerated" && prevID == "autoGenerated") || prevID.replace("grid_","") == dropElemID) {
				//左隣にドロップしたときはなにもしない
			} else {
				//列をドロップした位置に移動
				$("#grid").igGrid("moveColumn", dragElemID, dropElemID, true, true);
				//列を非表示にする
				if(!isHidding) $("#grid").igGrid("hideColumn", dragElemID);
				//列を表示する
				$("#grid").igGrid("showColumn", dragElemID);
				setTimeout(function(){addDragAddedElement(ui);},500);
			}
			isHidding = false;
			if(isItemDragging) isItemDragging=false;
			if(isHeaderDragging) isHeaderDragging = false;
			prevID = "";
		}
	}).on("dropover", function(e,ui){
		var borderX = $(this).position().left + $(this).outerWidth();
		var borderY = $(this).position().top;
		$("#insertBorder").remove();
		//挿入位置を示す線を表示
		$(this).append("<div id=\"insertBorder\" style=\"width:2px;height:"+$("#grid").outerHeight()+"px;background-color:#92D050;position:absolute;top:"+borderY + "px;left:"+borderX+"px;\"></div>");
		if(isItemDragging){
			ui.helper.children("img").attr("src","../img/show.png");
		}
	}).on("dropout",function(e,ui){
		//挿入位置を示す線を削除
		if(isItemDragging){
			ui.helper.children("img").attr("src","../img/noDrop.png");
		}
	}).droppable().on("dragstart",function(e,ui){ /*ドラッグしたとき*/
		daraggingThID = $(this).attr("id");
		isHeaderDragging = true;
		idName = $(this).attr("id");
		//ドラッグしたヘッダの範囲を取得する
		prevID = $(this).prev().attr("id");
	}).on("drag",function(e,ui){
		if( ($(this).offset().left <= e.pageX) && (e.pageX <= ($(this).offset().left + $(this).outerWidth()))
					&& ( ($(this).offset().top <= e.pageY) && (e.pageY <= ($(this).offset().top + $(this).outerHeight())))){
					$("#insertBorder").css("display","none");
		} else {
			$("#insertBorder").css("display","block");
		}
	
		if(
			($("thead").offset().left <= e.pageX) && (e.pageX <= ($("thead").offset().left + $("thead").width()))
			&& ( $(this).offset().top <= e.pageY &&  e.pageY <= ($(this).offset().top + $(this).outerHeight() ))
		){
			//ヘッダ内にカーソルがあるとき(チェックボックス行は除く）
			ui.helper.children("img").attr("src","../img/show.png");
			inHeader = true;
		} else if( ($("thead").offset().left <= e.pageX) && (e.pageX <= ($("thead").offset().left + $("thead").width()))
			&& ( ($(this).offset().top + $(this).outerHeight() <= e.pageY))){
			//グリッド内にカーソルがあるとき
			inHeader = false;
			ui.helper.children("img").attr("src","../img/noDrop.png");
			//挿入位置を示す線を削除
			$("#insertBorder").remove();
		} else {
			inHeader = false;
			ui.helper.children("img").attr("src","../img/gomi.png");
			//挿入位置を示す線を削除
			$("#insertBorder").remove();
		}
	}).draggable({
		helper:function(e,ui){
			var target = $(this).attr("id");
			var returnElement = $('[id^='+target+'_cloumn]').clone(true).append("<img style='width:20px;position:absolute;top:-5px;' src='../img/gomi.png'/>").css("opacity","1.0").css("background-color","#eee");
			return returnElement;
		},
		cursor:"url(../img/grabbing.png), url(../img/grabbing.cur),auto",
		zIndex:990,
	});
}
$(document).ready(function(){
	//応募者管理画面
	$("#grid").igGrid({
		autoGenerateColumns: true,
		columns: [
			{ headerText: "応募経路", key: "route", dataType: "string" ,width:100,template: "${routeA}<br/>(${routeB})"},
			{ headerText: "求人名称", key: "offerName", dataType: "string" ,width:100, template: "<a href=\"#\">${offerName}</a>"},
			{ headerText: "氏名", key: "name", dataType: "string" ,width:80, template: "<a href=\"#\">${nameSub}<br/>(${appNo})</a>"},
			{ headerText: "年齢", key: "age", dataType: "string" ,width:55, template: "${age}才"},
			{ headerText: "性別", key: "gender", dataType: "string" ,width:55},
			{ headerText: "経験職種", key: "jobs", dataType: "string" ,width:80},
			{ headerText: "現年収", key: "income", dataType: "string" ,width:100,template: "${income}万円"},
			{ headerText: "最終学歴学校", key: "education", dataType: "string" ,width:80},
			{ headerText: "選考フェーズ", key: "phase", dataType: "string" ,width:100,template:"<a href=\"#\">${phase}</a>"},
			{ headerText: "進捗メモ", key: "progress", dataType: "string" ,width:80,template:"<a href=\"#\">${progress}</a>"},
			{ headerText: "最新メッセージ", key: "message", dataType: "string",width:100},
			{ headerText: "応募日時", key: "time", dataType: "string",width:100,hidden: true},
			{ headerText: "現住所", key: "address", dataType: "string",width:100,hidden: true},
			{ headerText: "自宅/携帯TEL", key: "phoneNum", dataType: "string",width:100,hidden: true},
			{ headerText: "最終学歴区分", key: "lastSchool", dataType: "string",width:100,hidden: true},
			{ headerText: "最終学部", key: "faculty", dataType: "string",width:100,hidden: true},
			{ headerText: "卒業区分", key: "graduateDiv", dataType: "string",width:100,hidden: true},
			{ headerText: "卒業年月", key: "graduationYear", dataType: "string",width:100,hidden: true},
			{ headerText: "勤務状況", key: "incumResign", dataType: "string",width:100,hidden: true},
			{ headerText: "雇用形態", key: "employmentStatus", dataType: "string",width:100,hidden: true},
			{ headerText: "転職回数", key: "jobChangeNum", dataType: "string",width:100,hidden: true},
			{ headerText: "職務内容", key: "jobContent", dataType: "string",width:100,hidden: true},
			{ headerText: "勤務先会社", key: "officeName", dataType: "string",width:100,hidden: true},
			{ headerText: "勤務期間", key: "workPeriod", dataType: "string",width:100,hidden: true},
			{ headerText: "従業員数", key: "epmloyeesNum", dataType: "string",width:100,hidden: true},
			{ headerText: "上場・非上場", key: "listNonlist", dataType: "string",width:100,hidden: true},
			{ headerText: "業種", key: "business", dataType: "string",width:100,hidden: true},
			{ headerText: "資格名", key: "qualification", dataType: "string",width:100,hidden: true},
			{ headerText: "英語力", key: "englishSkill", dataType: "string",width:100,hidden: true},
			{ headerText: "TOEIC", key: "toeic", dataType: "string",width:100,hidden: true},
			{ headerText: "TOEFL(i)", key: "tofelI", dataType: "string",width:100,hidden: true},
			{ headerText: "TOEFL(P)", key: "tofelP", dataType: "string",width:100,hidden: true},
			{ headerText: "その他語学", key: "anoLang", dataType: "string",width:100,hidden: true},
			{ headerText: "選考場所", key: "place", dataType: "string",width:100,hidden: true},
			{ headerText: "選考担当者名", key: "person", dataType: "string",width:100,hidden: true},
			{ headerText: "語学備考", key: "languRemarks", dataType: "string",width:100,hidden: true},
			{ headerText: "転職希望時期", key: "jobChangeHope", dataType: "string",width:100,hidden: true},
			{ headerText: "希望最低年収", key: "incomeHope", dataType: "string" ,width:100,hidden: true,template: "${income}万円"},
			//ここから下はデータとして持つが、表示はしない連結用のデータ
			{ headerText: "応募経路（大分類）", key: "routeA", dataType: "string" ,width:100,hidden: true},
			{ headerText: "応募経路（中分類）", key: "routeB", dataType: "string" ,width:100,hidden: true},
			{ headerText: "氏名サブ", key: "nameSub", dataType: "string" ,width:100,hidden: true},
			{ headerText: "応募者番号", key: "appNo", dataType: "string" ,width:100,hidden: true},
			{ headerText: "未読フラグ", key: "isUnread", dataType: "bool" ,width:100,hidden: true}
		],
		rendered:function(e,ui){
			var cols = $("#grid").igGrid("option", "columns");
			for(var i=0; i<cols.length;i++){
				if(cols[i].hidden == false){
					calcHeaderTextWidth(cols[i].key);
				}
			}
		},
	    columnsCollectionModified: function(evt, ui) {
			//headerのwidthを取得する。
			var headerW = $("#header").width();
			//左ペインのwidthを取得する。
			var leftW = $("#leftPane").width();
			//windowのwidthを取得する。
			var winW = $(window).width();
			
			var childW = $("#grid").width();
			//要素幅に290(コンテンツのmargin-left分＋左の固定分)を足す。
			var liquidW = childW + 290;
			//要素幅に40(コンテンツのmargin-left分)を足す。
			var marginW = childW + 40;
			if(liquidW <= winW ){
				$("body").css("width","100%");
				$("#header").css("width","100%");
				$("#footer").css("width","100%");
			} else {
				$("body").width(liquidW);
				$("#header").width(liquidW);
				$("#footer").width(liquidW);
			}
	    },
		features: [
				{
					name: "Tooltips",
					visibility: "always",
					style: "popover",
					showDelay: 1000,
					hideDelay: 500,
					tooltipShowing : function(evt, args) {
						//データを結合しているセルはツールチップの表示内容を整形する
						if(args.columnKey == "route") {
							args.tooltip=args.element.childNodes[0].data + "</br>" +args.element.childNodes[2].data;
						} else if(args.columnKey == "name"){
							args.tooltip = args.element.innerText.replace(/(\n|\r)/g, "<br/>");
						} else if(args.columnKey == "age") {
							args.tooltip += "才";
						} else if(args.columnKey == "income") {
							args.tooltip += "万円";
						} else {
							args.tooltip=args.tooltip;
						}
					}
				},
				{
					name: "Sorting",
					type: "local",
					applySortedColumnCss : false,
					columnSorted:function(e,ui){
						var addClass = "ui-icon";
						var target = $("#grid_"+ui.columnKey).children(".ui-iggrid-indicatorcontainer").children("span");
						if(ui.direction == "ascending"){
							addClass += " ui-iggrid-colindicator-asc ui-icon-arrowthick-1-n";
							target.addClass(addClass).removeClass("ui-icon-arrowthick-1-s");
						} else if(ui.direction == "descending"){
							addClass += " ui-iggrid-colindicator-desc ui-icon-arrowthick-1-s";
							target.addClass(addClass).removeClass("ui-icon-arrowthick-1-n");
						}
						//ヘッダーテキストの幅を変更
						calcHeaderTextWidth(ui.columnKey);
					}
				},
				{
					name: "RowSelectors",
					enableCheckBoxes: true,
					enableRowNumbering: true,
					rowSelectorColumnWidth: rowSelectorWidth
				},
				{
					name:"Selection",
					multipleSelection: true,
				},
				{	name: "Resizing",
					deferredResizing: false,
					columnResized: function(e, ui){
						var padding = parseInt($("#grid_"+ui.columnKey).css("padding-left").replace("px")) + parseInt($("#grid_"+ui.columnKey).css("padding-right").replace("padding-right"));
						$("#grid_"+ui.columnKey).width(ui.newWidth-padding);
						//リサイズしたらリサイズしたヘッダのサイズを保存しておく
						gridHeaderSize[ui.columnKey]=ui.newWidth-padding;
						prePageX = e.pageX;
						//ヘッダーテキストの幅を変更
						calcHeaderTextWidth(ui.columnKey);
					},
					columnSettings: [
						{columnKey: "route", minimumWidth: 55},
						{columnKey: "offerName", minimumWidth: 55},
						{columnKey: "name", minimumWidth: 55},
						{columnKey: "age", minimumWidth: 55},
						{columnKey: "gender", minimumWidth: 55},
						{columnKey: "jobs", minimumWidth: 55},
						{columnKey: "income", minimumWidth: 55},
						{columnKey: "education", minimumWidth: 55},
						{columnKey: "phase", minimumWidth: 55},
						{columnKey: "progress", minimumWidth: 55},
						{columnKey: "message", minimumWidth: 55},
						{columnKey: "time", minimumWidth: 55},
						{columnKey: "phoneNum", minimumWidth: 55},
						{columnKey: "lastSchool", minimumWidth: 55},
						{columnKey: "faculty", minimumWidth: 55},
						{columnKey: "graduateDiv", minimumWidth: 55},
						{columnKey: "graduationYear", minimumWidth: 55},
						{columnKey: "incumResign", minimumWidth: 55},
						{columnKey: "employmentStatus", minimumWidth: 55},
						{columnKey: "jobChangeNum", minimumWidth: 55},
						{columnKey: "officeName", minimumWidth: 55},
						{columnKey: "workPeriod", minimumWidth: 55},
						{columnKey: "listNonlist", minimumWidth: 55},
						{columnKey: "epmloyeesNum", minimumWidth: 55},
						{columnKey: "business", minimumWidth: 55},
						{columnKey: "qualification", minimumWidth: 55},
						{columnKey: "englishSkill", minimumWidth: 55},
						{columnKey: "toeic", minimumWidth: 55},
						{columnKey: "tofelI", minimumWidth: 55},
						{columnKey: "tofelP", minimumWidth: 55},
						{columnKey: "anoLang", minimumWidth: 55},
						{columnKey: "place", minimumWidth: 55},
						{columnKey: "person", minimumWidth: 55},
						{columnKey: "languRemarks", minimumWidth: 55},
						{columnKey: "jobChangeHope", minimumWidth: 55},
						{columnKey: "incomeHope", minimumWidth: 55}
					]
				},
				{
					name: "Filtering",
					type: "local",
					mode: "advanced",
					filterDialogContainment: "window",
					filterDialogWidth : 360,
					filterDialogOpened: function (e, ui) {
						var currentColumn = ui.owner._dialogCurrentColumn;
						var top = $("#grid_"+currentColumn).offset().top;
						var left = $("#grid_"+currentColumn).offset().left;
						var rleft = $("#grid_"+currentColumn).position().left;
						if(scrollY - initHeaderTop > 0) {
							$("#grid_container_dialog").css("top",(scrollY - initHeaderTop + $("thead").height())+"px");
						} else {
							$("#grid_container_dialog").css("top",$("thead").height());
						}
						if($("body").width() <= (left+$("#grid_container_dialog").width())){
							var diff = (left+$("#grid_container_dialog").width()) - $("body").width();
							rleft -= diff;
						}
						$("#grid_container_dialog").css("left",rleft);
						
					},
					filterDialogMaxFilterCount : 38,
					columnSettings : [
						{columnKey: "routeA", allowFiltering: false},
						{columnKey: "routeB", allowFiltering: false},
						{columnKey: "nameSub", allowFiltering: false},
						{columnKey: "appNo", allowFiltering: false},
						{columnKey: "isUnread", allowFiltering: false}
					]
				}
			],
			dataSource: app_gridData //JSON Array defined above
	});
	//ヘッダのドラッグ＆ドロップイベントを登録
	addGridHeaderDrag(".ui-iggrid-header");
	//初期表示でgrid内に存在する要素は非活性にする
	$(".cloumn_selected").draggable({disabled:true}).addClass("ui-state-disabled");
	$(".draggable").on("dragstart",function(e,ui){
		idName = $(this).attr("id");
		isDrop = false;
		isItemDragging = true
		$(this).addClass("cloumn_selected").addClass("ui-state-disabled");
	}).on("dragstop",function(e,ui){
		//挿入位置を示す線を削除
		$("#insertBorder").remove();
		//ドラッグ終了時の動作(所定の位置にドロップされなかったとき)
		if(!isDrop){
			$(this).removeClass("cloumn_selected").removeClass("ui-state-disabled");
		}
		if(isItemDragging) isItemDragging=false;
		if(isHeaderDragging) isHeaderDragging = false;
	});
	$(".draggable").draggable({
		helper:function(e,ui){
			return $(this).clone(true).append("<img style='width:20px;position:absolute;top:-10px;' src='../img/noDrop.png'/>").css("opacity","1.0").css("background-color","#eee");
		},
		cursor:"url(../img/grabbing.png), url(../img/grabbing.cur),auto",
		zIndex:990,
	});
	
	//表示項目のブロックの上をドラッグ中のときはドロップ状態を示すアイコンを出さない
	$("#draggableArea").droppable({
		over:function(e,ui){
			if(isItemDragging){
				ui.helper.children("img").attr("src","");
			}
		},
		out:function(e,ui){
			if(isItemDragging){
				ui.helper.children("img").attr("src","../img/noDrop.png");
			}
		},
		stop:function(e,ui){
			if(isItemDragging) isItemDragging=false;
			if(isHeaderDragging) isHeaderDragging = false;
		}
	});
	
	//ヘッダをグリッド外へ出したら列を非表示にする
	$("body").droppable({
		greedy:true,
		drop:function(e,ui){
			isSameTH = false;
			if( ($("#"+idName).offset().left <= e.pageX) && (e.pageX <= ($("#"+idName).offset().left + $("#"+idName).outerWidth()))
				&& ( ($("#"+idName).offset().top <= e.pageY) && (e.pageY <= ($("#"+idName).offset().top + $("tbody").outerHeight())))){
				isSameTH = true;
			}
			if(isHeaderDragging && !isSameTH && !inHeader){
				isHeaderDragging = false;
				//ドラッグしたidを含む項目がドロップされたら活性に戻す。
				$('[id^='+idName+'_]').draggable({disabled:false}).removeClass("cloumn_selected").removeClass("ui-state-disabled");
				
				//ドラッグ要素のIDを取得
				var dragElemID = ui.draggable.attr("id").replace("grid_", "");
				//列を非表示にする
				$("#grid").igGrid("hideColumn", dragElemID);
			}
			//挿入位置を示す線を削除
			$("#insertBorder").remove();
			inHeader=false;
		}
	});
	var initHeaderTop = $("thead").offset().top;
	var htop = $("thead").offset().top;
	var hleft = $("thead").offset().left;
	var hwidth = $("th").width();	//ヘッダーの幅
	var hheight = $("th").height();	//ヘッダーの高さ
	var gridHeight = $("#grid").height();
	var arrayThSize = new Array();
	var idx = 0;
	var scrollY = 0;
	var theadWidth = $("thead").width();
	var isFixedTop = false;
	var thPadding = parseInt($(".ui-iggrid-header").css("padding-left").replace("px")) + parseInt($(".ui-iggrid-header").css("padding-right").replace("padding-right"));
	//theadサイズを取得と初期設定
	//ヘッダをページ固定するためにposition:absoluteを使う
	//absolute指定をした時はthにサイズを明示的に当てないと幅が合わない
	$(".ui-iggrid-header").each(function(){
		if($(this).attr("id") == undefined){
			$(this).attr("id","autoGenerated");
			gridHeaderSize["autoGenerated"] = rowSelectorWidth;
			
			$(this).width(rowSelectorWidth-thPadding);
		} else {
			gridHeaderSize[$(this).attr("id").replace("grid_","")] = $(this).width();
			$(this).width($(this).width());
		}

	});
	
	/*スクロールイベント*/
	$(window).scroll(function () {
		if(scrollY != $(window).scrollTop()){
			//左のパネルが折りたたまれると右パネルの要素が横に伸びて
			//グリッドのヘッダー位置が変わるためスクロール中かつヘッダ固定にしていないときの位置を毎回取得する
			if($("thead").css("position") != "absolute"){
				htop = $("thead").offset().top;
			}
			if( (htop < $(window).scrollTop())){
				//グリッドの範囲内をスクロールしているときはヘッダを固定する
				//リサイズしているかもしれないのでthにサイズを設定
				//固定中はドラッグイベントを切る
				for(var key in gridHeaderSize){
					$("#grid_"+key).width(gridHeaderSize[key]);
					$("#grid_"+key).draggable("option", "disabled", true);
					$("#grid_"+key).css("opacity","1.0");
				}
				$("thead").css("position","absolute");
				$("thead").css("top",$(window).scrollTop()-htop + "px");
				$("thead").addClass("shadow");
				isFixedTop = true;
			} else if(htop > $(window).scrollTop()){
				//グリッドの範囲外になったらヘッダーをもとの位置に戻す
				$("thead").css("position","relative");
				$("thead").css("top",htop);
				$("thead").removeClass("shadow");
				isFixedTop = false;
				//ドラッグOKにする
				$(".ui-iggrid-header").draggable("option", "disabled", false);
			}
		} else {
			var nowY = $("thead").offset().top;
			if( (htop < $(window).scrollTop()) ){
				$("thead").css("position","absolute");
				$("thead").css("top",  $(window).scrollTop()-htop + "px");
			}
		}
		scrollY = $(window).scrollTop();
	});
	
	var initChangeAllTop = $("#changeAllDiv").offset().top;
	var isVisible = false;
	var changeAllDivHeight = $("#changeAllDiv").height();
	var initChangeAllMarginTop = $("#changeAllDiv").css("margin-top").replace("px","");
	function toggleChangeAllDiv(){
		if(($("#grid").offset().top + $("#grid").height()) > $(window).scrollTop() + initChangeAllTop && $(window).scrollTop() + initChangeAllTop > $("#grid").offset().top + $("thead tr th").outerHeight() * 2){
				
			//グリッ2行分までスクロールしたら一括変更をフェードインする
				$("#changeAllDiv").addClass("shadow");
				$("#changeAllDiv").height(changeAllDivHeight);
				//$("#changeAllDiv").css("position","fixed");
				$("#changeAllDiv").css("position","absolute");
				$("#changeAllDiv").css("top", ($(window).scrollTop()+initChangeAllTop -initChangeAllMarginTop) + "px");
				if(!isVisible){
					$("#changeAllDiv").fadeIn();
					isVisible = true;
				}
				
		} else if( ($(window).scrollTop() + initChangeAllTop) > ($("#grid").offset().top + $("#grid").height())) {
			//グリッド下部までスクロールしたらフッター上部に固定する。
			$("#changeAllDiv").removeClass("shadow");
			$("#changeAllDiv").width($("#changeAllDiv").width())
			$("#changeAllDiv").css("position","static");
			isVisible = false;
		} else {
			//他は非表示
			$("#changeAllDiv").fadeOut();
			isVisible = false;
			$("#changeAllDiv").css("position","static");
		}
	}
	$("#changeAllDiv").hide();
	//一括操作のフェードイン、固定
	$(window).scroll(function () {
		toggleChangeAllDiv()
	});
});


