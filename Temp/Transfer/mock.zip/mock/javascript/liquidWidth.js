/*コンテンツ幅が伸びたときにページ全体を伸ばす*/
function extendContents(){
	//headerのwidthを取得する。
	var headerW = $("#header").width();
	//左ペインのwidthを取得する。
	var leftW = $("#leftPane").width();
		//windowのwidthを取得する。
	var winW = $(window).width();
	
	var childW = $("#grid").width();
	//要素幅に290(コンテンツのmargin-left分＋左の固定分)を足す。
	var liquidW = childW + 290;
	//要素幅に40(コンテンツのmargin-left分)を足す。
	var marginW = childW + 40;
	
	//左ペインが250pxのとき
	if(leftW == 250 ){
		//要素幅がheader/footerより大きくなったときに、それに伴いheader/footerの幅を伸ばす。
		if(liquidW > headerW ){
			$("#header").width(liquidW);
			$("#footer").width(liquidW);
		} else {
			
		}
	//左ペインが0pxのとき
	}else if(leftW == 0){
		//要素幅がheader/footerより大きくなったときに、それに伴いheader/footerの幅を伸ばす。
		if(marginW > headerW ){
			$("#header").width(marginW);
			$("#footer").width(marginW);
		}
	}

}
/*コンテンツ幅が縮んだときにページ全体を縮める*/
function contractContents(){
	//headerのwidthを取得する。
	var headerW = $("#header").width();
	//左ペインのwidthを取得する。
	var leftW = $("#leftPane").width();
	//windowのwidthを取得する。
	var winW = $(window).width(); 
	
	//要素のwidthを取得し、それに50を引く。
	var childW = $("#grid").width() - 50;
	//要素幅に290(コンテンツのmargin-left分＋左の固定分)を足す。
	var liquidW = childW + 290;
	//要素幅に40(コンテンツのmargin-left分)を足す。
	var marginW = childW + 40;
	
	//左ペインが250pxのとき
	if(leftW == 250 ){
		//gridのmin-width:869pxより大きいとき
		if(childW >= 869 ){
			//クリックするたびに要素の幅を50減らしていく。
			$("#grid").width(childW)
		}
		//要素幅がwindow幅より大きいときに、それに伴いheader/footerの幅を縮める。
		if(liquidW > winW){
			$("#header").width(liquidW);
			$("#footer").width(liquidW);
		//要素幅がwindow幅以下のときに、それに伴いheader/footerの幅を100%にする。
		}else if(liquidW <= winW ){
			$("#header").css("width","100%");
			$("#footer").css("width","100%");
		}
	//左ペインが0pxのとき
	}else if(leftW == 0){
		//gridのmin-width:1065pxより大きいとき
		if(childW >= 1065 ){
			//クリックするたびに要素の幅を50減らしていく。
			$("#grid").width(childW)
		}
		//要素幅がwindow幅より大きいときに、それに伴いheader/footerの幅を縮める。
		if(marginW >= winW){
			$("#header").width(marginW);
			$("#footer").width(marginW);
		//要素幅がwindow幅以下のときに、それに伴いheader/footerの幅を100%にする。
		}else if(marginW <= winW ){
			$("#header").css("width","100%");
			$("#footer").css("width","100%");
		}
	}
}


/*初回読み込み時にコンテンツ幅を合わせる*/
//$(window).load(function () {
//	//headerのwidthを取得する。
//	var headerW = $("#header").width();
//	//要素のwidthを取得する。
//	var childW = $("#grid").width();
//	//要素幅に282(コンテンツのmargin-left分＋左の固定分)を足す。
//	var liquidW = childW + 290;
//	if(liquidW > headerW ){
//		$("#header").width(liquidW);
//		$("#footer").width(liquidW);
//	}
//});