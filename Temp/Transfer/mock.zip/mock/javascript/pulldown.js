﻿// JavaScript Document
$(function () {
	var over_flg;
	//spanをclickしたときの処理
	$('span.pull_span').click(function() {
		$('.pull_span').each(function(){
			//すべて非表示
		 	$(this).next('ul').hide()
		 });
		 //clickしたspan下にあるulを表示する。
		 	$(this).next('ul').slideToggle('fast');
	});
	//マウスカーソルの位置
	$('.pull_span, pull_ul').hover(function(){//pulldown上
		over_flg = true;
	}, function(){
		over_flg = false;//pulldown外
	});
	//pulldown外だったら非表示にする
	$('body').click(function() {
		if (over_flg == false) {
			$('.pull_ul').hide();
		}
	});
	//pulldown内の<a>をclickしたら非表示にする
	$('.pull_contents').click(function() {
			$('.pull_ul').hide();
	});
});