//datePicker_style
// JavaScript Document
		$(function() {

			$(function() { $(".date").datepicker(); 
			$(".date").datepicker("option", "showOn", 'button'); 
			$(".date").datepicker("option", "buttonImageOnly", true); 
			$(".date").datepicker("option", "buttonImage", '../../img/ico_datepicker.png');
			$(".date_limitMin").datepicker("option", 'minDate', 1);	//今日を含む過去の選択不可
			$(".date_limitMax").datepicker("option", 'maxDate', "+1m");	//今日から1カ月以降選択不可
			});

			$( ".date" ).datepicker({
				beforeShowDay: function(date) {
					//日曜日
					if(date.getDay() == 0) {
						return [true,"ui-datepicker-sunday"];
					//土曜日
					} else if(date.getDay() == 6){
						return [true,"ui-datepicker-saturday"];
					//平日
					} else {
						return [true];
					}
				}
			});
		});