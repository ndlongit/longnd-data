$(document).ready(function(){
	$(function() {
		$('input[type=radio]').change(function() {
			$('.tr1, .tr2').removeClass('invisible');
			if ($("input:radio[name='candidateDay']:checked").val() == "1") {
				$('.tr2').addClass('invisible');
			} else if($("input:radio[name='candidateDay']:checked").val() == "2") {
				$('.tr1').addClass('invisible');
			}
		}).trigger('change');
	});
});