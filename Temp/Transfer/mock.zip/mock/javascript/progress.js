﻿$(document).ready(function(){
	$("#selectPhase").change(function(){
		getProgressContents($(this).val());
	});
});
function textCount(target,zeroFormat,max){
	var num = String(max).length;
	var thisValueLength = target.val().length;
	if(zeroFormat){
		thisValueLength = (Array(num).join('0') + thisValueLength).slice(-num);
	}
	return thisValueLength;
}
function addTextCountEvent(targetObj,countObj){
	MaxLength500 = 500;
	targetObj.on('keyup',function(){
		var count = textCount($(this),true,MaxLength500);
		if(parseInt(count,10) > MaxLength500){
			countObj.css("color","red");
		} else {
			countObj.css("color","#000");
		}
		countObj.html(count);
	});
}

//Ajax処理はモック用のダミー本番環境はWebServiceにリクエストを送る
function getProgressContents(selectValue){
	html = getHTMLContents(selectValue)
	$.ajax({
		type:"GET",
		url:html,
		dataType:"html",
		cache:false,
	}).done(function(data){
			$("#contentBody").html(data);
			showPlaceHolder();
			addTextCountEvent($("#screeningMemo"),$("#count1"));
			showDatePicker($(".date"),"../img/ico_datepicker.png");
	}).fail(function(data){
			$("#contentBody").html("通信に失敗しました");
	});
}

//モック用のメソッド
//実際はWebサービスにリクエストパラメータを投げてどの内容を取得するか判断させるが
//モックはバックエンドがないので疑似的に取得するhtmlを変えている
function getHTMLContents(selectValue){
	if(selectValue == "systemPhase1") {
		$("#selectRating").attr("disabled","disabled");
		return "progress_entries.html";
	} else if(selectValue == "systemPhase2") {
		$("#selectRating").attr("disabled","disabled");
		return "paper_screening.html";
	} else if(selectValue == "systemPhase3") {
		$("#selectRating").removeAttr("disabled");
		return "paper_screening_ok.html";
	} else if(selectValue == "systemPhase4") {
		$("#selectRating").removeAttr("disabled");
		return "paper_screening_ng.html";
	} else {
		return "dummy.html";
	}
}