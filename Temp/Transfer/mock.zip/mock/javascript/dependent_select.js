//連動するテキストボックス
// JavaScript Document
$(document).ready( function() {
			var Names = [
				{ types: 'all', names: '--all--' },
				{ types: 'all', names: 'sunflower' },
				{ types: 'all', names: 'rose' },
				{ types: 'all', names: 'cat' },
				{ types: 'all', names: 'dog' },
				{ types: 'all', names: 'rabbit' },
				{ types: 'flowers', names: 'sunflower' },
				{ types: 'flowers', names: 'rose' },
				{ types: 'animals', names: 'cat' },
				{ types: 'animals', names: 'dog' },
				{ types: 'animals', names: 'rabbit' }
			];
			
			$('#eachType').change(function(){
				setEachName($(this).val());
			});
			
			function setEachName(Types){
				$('#eachName').find('option').remove();
				$(Names).each(function(i){
					if(Names[i].types == Types){
						$('#eachName').append($('<option></option>')
							.attr('types', Names[i].types)
							.val(Names[i].names)
							.text(Names[i].names));
					}
				});
			}
			setEachName('all');
		});