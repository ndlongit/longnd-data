// JavaScript Document
function textCount(target,zeroFormat,max){
	var num = String(max).length;
	var thisValueLength = target.val().length;
	if(zeroFormat){
		thisValueLength = (Array(num).join('0') + thisValueLength).slice(-num);
	}
	return thisValueLength;
}

$(function(){
	MaxLength500 = 500;
	$('#comment1').bind('keyup',function(){
		var count = textCount($(this),true,MaxLength500);
		if(parseInt(count,10) > MaxLength500){
			$('#count1').css("color","red");
		} else {
			$('#count1').css("color","#000");
		}
		$('#count1').html(count);
	});
});
