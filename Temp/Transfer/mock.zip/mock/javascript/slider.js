//slider
// JavaScript Document
		/*あとでちゃんとクロージャーにする*/
		var currentPage = 1; //現在表示しているページ数 1orign
		var maxPage = 4;	//表示するページの最大数
		$(document).ready(function(){
			$(".slideContents").parent("div").height($(".slideContents").height());
			$(".slideOuter").width($(".slideContents").width());
			/*ロード時の前へ、次へボタンの位置を決める 上下位置は画面中央に固定*/
			var posArray = getSlideButtonPos();
			setSlideButtonPos(posArray);
			
			/*画面がリサイズされたときに前へ、次へボタンの位置を計算する*/
			$(window).resize(function(){
				var posArray = getSlideButtonPos();
				setSlideButtonPos(posArray);
			});

			/*次へボタンのイベントをバインド*/
			$("#slideNext").bind("click",slideNext);
			
		});
		function initNextPageGrid(idx){
			var url = window.location;
			var path = url.href.split("/");
			var fileName = path.pop();
			if(fileName == "management.html"){
				$("#msg_grid"+idx).igGrid({
					autoGenerateColumns: true,
					height : "250px",
					columns: [
						{ headerText: "件名", key: "title", dataType: "string",width : 440},
						{ headerText: "添付", key: "annex", dataType: "string" ,width : 40},
						{ headerText: "送信者名", key: "sendName", dataType: "string" ,width : 195},
						{ headerText: "送受信日時", key: "sendDate", dataType: "string" ,width : 160},
						{ headerText: "マイページでの閲覧状況", key: "readCondition", dataType: "string" ,width : 110}
					],
					features: [
						{
							name: "Sorting",
							type: "local"
						},
					],
					dataSource: msg_gridData 
				});
			} else if(fileName == "send.html"){
				//カレンダーを表示する
				showDatePicker($(".date"),"../img/ico_datepicker.png");
			}
		}
		/*次へボタンを押したときの動作*/
		function slideNext(){
			currentPage++;
			if(currentPage == maxPage){
				/*最後まできたら次へボタンは非アクティブにする*/
				$("#slideNext").removeClass("enableSlideButton");
				$("#slideNext").addClass("disableSlideButton");
				$("#slideNext").unbind("click");
			} else {
				//前へボタンのをアクティブにする
				if($("#slidePrev").hasClass("disableSlideButton")){
					$("#slidePrev").removeClass("disableSlideButton");
					$("#slidePrev").addClass("enableSlideButton");
					$("#slidePrev").bind("click",slidePrev);
				}
			}
			/*Ajaxで次のページを取得する*/
			$.ajax({
				type:"GET",
				url:"nextPage_" + currentPage +".html",
				dataType:"html",
				cache:false,
				success:function(data){
					$(".slidable").width($(".slidable").width() + $(".slideContents").width());
					$(".slidable").append(data);
					$(".slidable").animate({
						marginLeft: '-=' + $('.slideContents').width() + 'px',
					});
					//スライドした際に画面上部に移動する(htmlも指定しないとIEやFireFoxでは動作しなくなる)
					$("body, html").scrollTop(0);
				},
				error:function(data){
					$("#contents").html("通信に失敗しました");
				},
				complete:function(data){
					initNextPageGrid(currentPage);
					$(window).scrollTop(0);
				}
			});
			return false;
		}
		/*前へボタンを押したときの動作*/
		function slidePrev(){
			currentPage--;
			if(currentPage == 1){
				/*最初まできたら前へボタンは非アクティブにする*/
				$("#slidePrev").removeClass("enableSlideButton");
				$("#slidePrev").addClass("disableSlideButton");
				$("#slidePrev").unbind("click");
			} else {
				//次へボタンをアクティブにする
				if($("#slideNext").hasClass("disableSlideButton")){
					$("#slideNext").removeClass("disableSlideButton");
					$("#slideNext").addClass("enableSlideButton");
					$("#slideNext").bind("click",slideNext);
				}
			}
			$(".slidable").animate({
				marginLeft: '+=' + $('.slideContents').eq(0).width() + 'px',
			});
			//スライドした際に画面上部に移動する(htmlも指定しないとIEやFireFoxでは動作しなくなる)
			$("body, html").scrollTop(0);
			//setTimeout(function(){$("body, html").scrollTop(0);},500);
		}
		
		/*ボタン位置を計算して返す*/
		function getSlideButtonPos(){
			buttonTop =  ($(window).height() - $(".slideButton").height() ) / 2;
			prevLeft = $("#contents").offset().left - 10 - $(".slideButton").outerWidth();
			nextLeft = $("#contents").offset().left + 10 + $("#contents").outerWidth();
			return [buttonTop,prevLeft,nextLeft];
			//$("#slidePrev").css("position","fixed").css("top",prevY).css("left",prevX);
			//$("#slideNext").css("position","fixed").css("top",nextY).css("left",nextX);
		}
		/*計算したボタン位置をDOMにセットする*/
		function setSlideButtonPos(posArray){
			$("#slidePrev").css("position","fixed").css("top",posArray[0]).css("left",posArray[1]);
			$("#slideNext").css("position","fixed").css("top",posArray[0]).css("left",posArray[2]);
		}
		
		