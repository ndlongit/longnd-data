$(function () {
	var index = 1;
	$("tbody").on("click",".delete",function(){
		//trを消す
		$(this).parent("th").parent("tr").remove();
		//番号を振り直す
		index = 2;
		$(".addRow").each(function(){
			$(this).children("th").children("span").text("候補日時"+index);
			$(this).children("td").children("input").attr("name","candidate"+index);
			index++;
		});
		index = index - 1;
		if(index < 10){
			//ここで追加ボタンを表示する。
			$("#add").css("display","block");
		}
		console.log("deleteのときのindexは"+index);
	});
	 $("#add").click(function () {
		++index;
		console.log("addのときのindexは"+index);
		$("#target").append(
		"<tr class='tr1 addRow'>"
		+"<th style='border-top:1px solid #ccc; border-bottom:none;'><span>候補日時"+ index +"</span><img src='../img/icon_btn_cancel.png' class='delete'/></th>"
		+"<td style='border-top:1px solid #ccc; border-bottom:none;'>"
		+"<input type='text' class='date date_limitMin verticalMiddle radius_5' name='candidate"+ index +"' style='width:105px;' title='' />"
		+"<select name='timeHour' class='m_left10'>"
		+"<option>00</option>"
		+"<option>01</option>"
		+"<option>02</option>"
		+"<option>03</option>"
		+"<option>04</option>"
		+"<option>05</option>"
		+"<option>06</option>"
		+"<option>07</option>"
		+"<option>08</option>"
		+"<option>09</option>"
		+"<option>10</option>"
		+"<option>11</option>"
		+"<option>12</option>"
		+"<option>13</option>"
		+"<option>14</option>"
		+"<option>15</option>"
		+"<option>16</option>"
		+"<option>17</option>"
		+"<option>18</option>"
		+"<option>19</option>"
		+"<option>20</option>"
		+"<option>21</option>"
		+"<option>22</option>"
		+"<option>23</option>"
		+"<option>24</option>"
		+"</select><span class='m_right10'>時</span>"
		+"<select name='timeMinutes'>"
		+"<option>00</option>"
		+"<option>05</option>"
		+"<option>10</option>"
		+"<option>15</option>"
		+"<option>20</option>"
		+"<option>25</option>"
		+"<option>30</option>"
		+"<option>35</option>"
		+"<option>40</option>"
		+"<option>45</option>"
		+"<option>50</option>"
		+"<option>55</option>"
		+"</select><span class='m_right10'>分</span>"
		+"<span class='m_right10'>～</span>"
		+"<select name='timeHour'>"
		+"<option>00</option>"
		+"<option>01</option>"
		+"<option>02</option>"
		+"<option>03</option>"
		+"<option>04</option>"
		+"<option>05</option>"
		+"<option>06</option>"
		+"<option>07</option>"
		+"<option>08</option>"
		+"<option>09</option>"
		+"<option>10</option>"
		+"<option>11</option>"
		+"<option>12</option>"
		+"<option>13</option>"
		+"<option>14</option>"
		+"<option>15</option>"
		+"<option>16</option>"
		+"<option>17</option>"
		+"<option>18</option>"
		+"<option>19</option>"
		+"<option>20</option>"
		+"<option>21</option>"
		+"<option>22</option>"
		+"<option>23</option>"
		+"<option>24</option>"
		+"</select><span class='m_right10'>時</span>"
		+"<select name='timeMinutes'>"
		+"<option>00</option>"
		+"<option>05</option>"
		+"<option>10</option>"
		+"<option>15</option>"
		+"<option>20</option>"
		+"<option>25</option>"
		+"<option>30</option>"
		+"<option>35</option>"
		+"<option>40</option>"
		+"<option>45</option>"
		+"<option>50</option>"
		+"<option>55</option>"
		+"</select><span class='m_right10'>分</span>"
		+"</td>"
		+"</tr>"
		);
		if(index == 10){
			//ここで追加ボタンを非表示にする。
			$(this).css("display","none");
		}
		showDatePicker($(".date"),"../img/ico_datepicker.png");
	});
});