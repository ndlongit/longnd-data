//igGrid
// JavaScript Document
		//ホーム画面
		var offer_gridData =[
			{"offerType":"営業職(経験者)","mssName":"ライフパートナー［東京本店］","apply":"<a href='#'>20</a>","document":"<a href='#'>3</a>","selection":"<a href='#'>0</a>","briefing":"<a href='#'>2</a>","interview1":"<a href='#'>0</a>","interview2":"<a href='#'>0</a>","interview3":"<a href='#'>0</a>","reserve1":"<a href='#'>0</a>","reserve2":"<a href='#'>0</a>","informalDecision":"<a href='#'>0</a>","beforeEnter":"<a href='#'>0</a>","adjustDay":"<a href='#'>0</a>","waitResult":"<a href='#'>1</a>","all":"<a href='#'>1</a>"},
			{"offerType":"<span class='nonRead'>営業職(ポテンシャル)</span>","mssName":"<span class='nonRead'>新規開拓営業職(Employee Health&Benefits)</span>","apply":"<a href='#'><span class='nonRead'>100</span></a>","document":"<a href='#'><span class='nonRead'>15</span></a>","selection":"<a href='#'><span class='nonRead'>1</span></a>","briefing":"<a href='#'><span class='nonRead'>4</span></a>","interview1":"<a href='#'><span class='nonRead'>1</span></a>","interview2":"<a href='#'><span class='nonRead'>0</span></a>","interview3":"<span class='nonRead'>0</span>","reserve1":"<a href='#'><span class='nonRead'>0</span></a>","reserve2":"<a href='#'><span class='nonRead'>0</span></a>","informalDecision":"<a href='#'><span class='nonRead'>0</span></a>","beforeEnter":"<a href='#'><span class='nonRead'>0</span></a>","adjustDay":"<a href='#'><span class='nonRead'>1</span></a>","waitResult":"<a href='#'><span class='nonRead'>0</span></a>","all":"<a href='#'><span class='nonRead'>1</span></a>"},
			{"offerType":"営業企画職(ポテンシャル)","mssName":"営業アシスタント［東京本店］","apply":"<a href='#'>300</a>","document":"<a href='#'>30</a>","selection":"<a href='#'>58</a>","briefing":"<a href='#'>4</a>","interview1":"<a href='#'>1</a>","interview2":"<a href='#'>0</a>","interview3":"<a href='#'>0</a>","reserve1":"<a href='#'>0</a>","reserve2":"<a href='#'>0</a>","informalDecision":"<a href='#'>0</a>","beforeEnter":"<a href='#'>0</a>","adjustDay":"<a href='#'>1</a>","waitResult":"<a href='#'>0</a>","all":"<a href='#'>1</a>"},
			{"offerType":"<span class='nonRead'>技術職(経験者)</span>","mssName":"<span class='nonRead'>【埼玉】金属研磨・研削加工※国内シェア60%歯科用製品</span>","apply":"<a href='#'><span class='nonRead'>3</span></a>","document":"<a href='#'><span class='nonRead'>0</span></a>","selection":"<a href='#'><span class='nonRead'>0</span></a>","briefing":"<a href='#'><span class='nonRead'>0</span></a>","interview1":"<a href='#'><span class='nonRead'>0</span></a>","interview2":"<a href='#'><span class='nonRead'>0</span></a>","interview3":"<a href='#'><span class='nonRead'>0</span></a>","reserve1":"<a href='#'><span class='nonRead'>0</span></a>","reserve2":"<a href='#'><span class='nonRead'>0</span></a>","informalDecision":"<a href='#'><span class='nonRead'>0</span></a>","beforeEnter":"<a href='#'><span class='nonRead'>0</span></a>","adjustDay":"<a href='#'><span class='nonRead'>0</span></a>","waitResult":"<a href='#'><span class='nonRead'>0</span></a>","all":"<a href='#'><span class='nonRead'>1</span></a>"},
			{"offerType":"経理職(経験者)","mssName":"経理サポート［福岡支社］","apply":"<a href='#'>68</a>","document":"<a href='#'>20</a>","selection":"<a href='#'>1</a>","briefing":"<a href='#'>4</a>","interview1":"<a href='#'>1</a>","interview2":"<a href='#'>0</a>","interview3":"<a href='#'>0</a>","reserve1":"<a href='#'>0</a>","reserve2":"<a href='#'>0</a>","informalDecision":"<a href='#'>0</a>","beforeEnter":"<a href='#'>3</a>","adjustDay":"<a href='#'>1</a>","waitResult":"<a href='#'>0</a>","all":"<a href='#'>1</a>"}
		];
		//ホーム画面
		var mss_gridData =[
			{"offerName":"システムの側から会社のビジネスを支える社内SE","mssType":"求人原稿","appearanceTerm":"2014/7/28～2014/8/30","todayApply":"<p class='label_waiting'>掲載待ち</p>","nonRead":"<p class='label_waiting'>掲載待ち</p>","appSum":"<p class='label_waiting'>掲載待ち</p>"},
			{"offerName":"<a href='#'><span class='nonRead'>タイヤや自動車部品などの提案営業／未経験者歓迎</span></a>","mssType":"<span class='nonRead'>求人原稿</span>","appearanceTerm":"<span class='nonRead'>2014/7/1～2014/7/20</span>","todayApply":"<a href='#'><span class='nonRead'>17</span></a>","nonRead":"<a href='#'><span class='nonRead'>5</span></a>","appSum":"<a href='#'><span class='nonRead'>30</span></a>"},
			{"offerName":"<a href='#'>プロマネスキルがつくシステムエンジニア(プロマネ候補、プロマネ未経験歓迎</a>","mssType":"求人原稿","appearanceTerm":"2014/1/1～2014/1/31","todayApply":"－","nonRead":"<a href='#'>0</a>","appSum":"<a href='#'>12</a>"},
			{"offerName":"<a href='#'>プラントエンジニア(計画・設計)</a>","mssType":"求人原稿","appearanceTerm":"2014/1/1～2014/1/31","todayApply":"－","nonRead":"<a href='#'>0</a>","appSum":"<a href='#'>24</a>"},
			{"offerName":"<a href='#'>施工管理</a>","mssType":"求人原稿","appearanceTerm":"2014/1/1～2014/1/31","todayApply":"－","nonRead":"<a href='#'>0</a>","appSum":"<a href='#'>28</a>"}
		];
		//メッセージ管理画面
		var msg_gridData =[
			{"title":"<p class='label_normal'>通常</p><span class='nonRead'>Re:選考結果のお知らせ【株式会社てすと】</span>","annex":"<span class='annex'><img src='img/icon_con_clip_min.png' /></span>","sendName":"<span class='nonRead'>株式会社てすと</span>","sendDate":"<span class='nonRead'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_nonRead'><img src='img/icon_con_nonReadmsg.png' />未読</p>"},
			{"title":"<p class='label_gMail'>受信</p><span class='read'>Re:選考結果のお知らせ【株式会社てすと】</span>","sendName":"<span class='read'>株式会社てすと</span>","sendDate":"<span class='read'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_read'><img src='img/icon_con_Readmsg.png' />既読</p>"},
			{"title":"<p class='label_sMail'>送信</p><span class='read'>Re:選考結果のお知らせ【株式会社てすと】</span>","annex":"<span class='annex'><img src='img/icon_con_clip_min.png' /></span>","sendName":"<span class='read'>株式会社てすと</span>","sendDate":"<span class='read'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_read'><img src='img/icon_con_Readmsg.png' />既読</p>"},
			{"title":"<p class='label_NG'>NG</p><span class='nonRead'>Re:選考結果のお知らせ【株式会社てすと】</span>","sendName":"<span class='nonRead'>株式会社てすと","sendDate":"<span class='nonRead'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_nonRead'><img src='img/icon_con_nonReadmsg.png' />未読</p>"},
			{"title":"<p class='label_thanks'>サンクス</p><span class='read'>Re:選考結果のお知らせ【株式会社てすと】</span>","annex":"<span class='annex'><img src='img/icon_con_clip_min.png' /></span>","sendName":"<span class='read'>株式会社てすと</span>","sendDate":"<span class='read'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_read'><img src='img/icon_con_Readmsg.png' />既読</p>"},
			{"title":"<p class='label_coordination'>日程調整</p><span class='read'>Re:選考結果のお知らせ【株式会社てすと】</span>","sendName":"<span class='read'>株式会社てすと</span>","sendDate":"<span class='read'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_read'><img src='img/icon_con_Readmsg.png' />既読</p>"},
			{"title":"<p class='label_normal'>通常</p><span class='nonRead'>Re:選考結果のお知らせ【株式会社てすと】</span>","annex":"<span class='annex'><img src='img/icon_con_clip_min.png' /></span>","sendName":"<span class='nonRead'>株式会社てすと</span>","sendDate":"<span class='nonRead'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_nonRead'><img src='img/icon_con_nonReadmsg.png' />未読</p>"},
			{"title":"<p class='label_gMail'>受信</p><span class='read'>Re:選考結果のお知らせ【株式会社てすと】</span>","sendName":"<span class='read'>株式会社てすと</span>","sendDate":"<span class='read'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_read'><img src='img/icon_con_Readmsg.png' />既読</p>"},
			{"title":"<p class='label_sMail'>送信</p><span class='read'>Re:選考結果のお知らせ【株式会社てすと】</span>","annex":"<span class='annex'><img src='img/icon_con_clip_min.png' /></span>","sendName":"<span class='read'>株式会社てすと</span>","sendDate":"<span class='read'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_read'><img src='img/icon_con_Readmsg.png' />既読</p>"},
			{"title":"<p class='label_NG'>NG</p><span class='nonRead'>Re:選考結果のお知らせ【株式会社てすと】</span>","sendName":"<span class='nonRead'>株式会社てすと","sendDate":"<span class='nonRead'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_nonRead'><img src='img/icon_con_nonReadmsg.png' />未読</p>"},
			{"title":"<p class='label_thanks'>サンクス</p><span class='read'>Re:選考結果のお知らせ【株式会社てすと】</span>","annex":"<span class='annex'><img src='img/icon_con_clip_min.png' /></span>","sendName":"<span class='read'>株式会社てすと</span>","sendDate":"<span class='read'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_read'><img src='img/icon_con_Readmsg.png' />既読</p>"},
			{"title":"<p class='label_coordination'>日程調整</p><span class='read'>Re:選考結果のお知らせ【株式会社てすと】</span>","sendName":"<span class='read'>株式会社てすと</span>","sendDate":"<span class='read'>2014/01/23 15:10:05</span>","readCondition":"<p class='label_read'><img src='img/icon_con_Readmsg.png' />既読</p>"}
		];
		//応募者管理画面
		var app_gridData =[
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"<a href='#'>AssistUI改善PJT123456789</a>","name":"<a href='#'>山田太郎<br/>（10000999）</a>","age":"21","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"<a href='#'>応募</a>","progress":"<a id='progressLink1' href='#'>未入力</a>","message":"<a href='#'><p class='label_NG'>自動NG</p>14/07/11(金)</a>"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０１２３４５６７８９０</span>","name":"<span class='nonRead'>山田花子<br/>（10001000）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>410</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>一次選考結果待ち</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_gMail'>受信</p><span class='nonRead'>14/07/12(土)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"データに改行を含む場合\nAssistUI改善PJT１\nAssistUI改善PJT１２\nAssistUI改善PJT１２	３","name":"山田太郎<br/>（10001001）","age":"25","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/13(日)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001002）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>405</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>応募</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_thanks'>サンクス</p><span class='nonRead'>14/07/14(月)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎<br/>（10001003）","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/15(火)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子<br/>（10001004）","age":"24","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/16(水)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"27","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/17(木)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"21","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/18(金)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/19(土)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001002）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>405</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>応募</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_thanks'>サンクス</p><span class='nonRead'>14/07/14(月)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/21(月)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/22(火)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"25","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/23(水)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"21","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/24(木)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"27","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p>14/07/11(金)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001000）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>410</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>一次選考結果待ち</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_gMail'>受信</p><span class='nonRead'>14/07/12(土)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"23","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/13(日)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001002）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>405</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>応募</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_thanks'>サンクス</p><span class='nonRead'>14/07/14(月)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/15(火)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"24","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/16(水)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"24","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/17(木)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"25","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/18(金)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001002）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>405</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>応募</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_thanks'>サンクス</p><span class='nonRead'>14/07/14(月)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"30","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/20(日)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"27","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/21(月)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/22(火)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001002）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>405</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>応募</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_thanks'>サンクス</p><span class='nonRead'>14/07/14(月)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"21","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/24(木)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p>14/07/11(金)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001000）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>410</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>一次選考結果待ち</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_gMail'>受信</p><span class='nonRead'>14/07/12(土)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/13(日)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/14(月)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"25","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/15(火)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_thanks'>サンクス</p>14/07/16(水)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"21","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/17(木)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"27","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/18(金)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/19(土)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001002）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>405</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>応募</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_thanks'>サンクス</p><span class='nonRead'>14/07/14(月)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"23","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/21(月)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"25","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/22(火)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"21","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/23(水)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"24","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/24(木)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p>14/07/11(金)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_gMail'>受信</p>14/07/12(土)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"21","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/13(日)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"27","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/14(月)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/15(火)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001002）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>405</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>応募</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_thanks'>サンクス</p><span class='nonRead'>14/07/14(月)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"30","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/17(木)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"24","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/18(金)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"27","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/19(土)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"23","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/20(日)"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/21(月)"},
				{"route":"<span class='nonRead'>求人広告媒体DODA<br/>（直接応募）</span>","offerName":"<span class='nonRead'>AssistUI改善PJT123456789</span>","name":"<span class='nonRead'>山田花子<br/>（10001002）</span>","age":"<span class='nonRead'>20</span>","gender":"<span class='nonRead'>女</span>","jobs":"<span class='nonRead'>企画/事務</span>","income":"<span class='nonRead'>405</span>","education":"<span class='nonRead'>○○大学</span>","phase":"<span class='nonRead'>応募</span>","progress":"<span class='nonRead'>未入力</span>","message":"<p class='label_thanks'>サンクス</p><span class='nonRead'>14/07/14(月)</span>"},
				{"route":"求人広告媒体DODA<br/>（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"24","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/23(水)"},
				{"route":"最後","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/24(木)"}
			];
		//応募者管理画面innerScroll
		var appSc_gridData =[
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎（10000999）","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p>14/07/11(金)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子（10001000）","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_gMail'>受信</p>14/07/12(土)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎（10001001）","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/13(日)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子（10001002）","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p>14/07/14(月)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎（10001003）","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/15(火)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子（10001004）","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/16(水)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎（10001005）","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/17(木)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_thanks'>サンクス</p>14/07/18(金)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/19(土)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/20(日)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/21(月)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/22(火)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_thanks'>サンクス</p>14/07/23(水)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/24(木)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p>14/07/11(金)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_gMail'>受信</p>14/07/12(土)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/13(日)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/14(月)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/15(火)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_thanks'>サンクス</p>14/07/16(水)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/17(木)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/18(金)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/19(土)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p>14/07/20(日)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/21(月)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/22(火)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/23(水)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_thanks'>サンクス</p>14/07/24(木)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p>14/07/11(金)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_gMail'>受信</p>14/07/12(土)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/13(日)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/14(月)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_thanks'>サンクス</p>14/07/15(火)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/16(水)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/17(木)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/18(金)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_thanks'>サンクス</p>14/07/19(土)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/20(日)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/21(月)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/22(火)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_thanks'>サンクス</p>14/07/23(水)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/24(木)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_NG'>自動NG</p>14/07/11(金)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_gMail'>受信</p>14/07/12(土)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/13(日)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/14(月)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/15(火)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_thanks'>サンクス</p>14/07/16(水)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/17(木)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/18(金)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"削除","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/19(土)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"応募","progress":"未入力","message":"<p class='label_thanks'>サンクス</p>14/07/20(日)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"一次選考結果待ち","progress":"ぜひ採用したい","message":"<p class='label_sMail'>送信</p>14/07/21(月)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"削除","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/22(火)"},
				{"route":"求人広告媒体DODA（直接応募）","offerName":"AssistUI改善PJT123456789","name":"山田太郎","age":"20","gender":"男","jobs":"営業・IT系","income":"400","education":"××大学","phase":"応募","progress":"ぜひ採用したい","message":"<p class='label_thanks'>サンクス</p>14/07/23(水)"},
				{"route":"最後","offerName":"AssistUI改善PJT123456789","name":"山田花子","age":"20","gender":"女","jobs":"企画/事務","income":"400","education":"○○大学","phase":"一次選考結果待ち","progress":"未入力","message":"<p class='label_sMail'>送信</p>14/07/24(木)"}
			];
		
		$(document).ready(function() {
			//ホーム画面
			$("#offer_grid").igGrid({
				autoGenerateColumns: true,
				columns: [
					{ headerText: "求人分類", key: "offerType", dataType: "string",width : 95},
					{ headerText: "求人名称", key: "mssName", dataType: "string" ,width : 195},
					{ headerText: "応募", key: "apply", dataType: "string" ,width : 47},
					{ headerText: "書類", key: "document", dataType: "string" ,width : 47},
					{ headerText: "選考", key: "selection", dataType: "string" ,width : 47},
					{ headerText: "説明会", key: "briefing", dataType: "string" ,width : 47},
					{ headerText: "1次面接", key: "interview1", dataType: "string" ,width : 47},
					{ headerText: "2次面接", key: "interview2", dataType: "string" ,width : 47},
					{ headerText: "3次面接", key: "interview3", dataType: "string" ,width : 47},
					{ headerText: "予備1", key: "reserve1", dataType: "string" ,width : 47},
					{ headerText: "予備2", key: "reserve2", dataType: "string" ,width : 47},
					{ headerText: "内定", key: "informalDecision", dataType: "string" ,width : 47},
					{ headerText: "入社前", key: "beforeEnter", dataType: "string" ,width : 47},
					{ headerText: "日程調整中", key: "adjustDay", dataType: "string" ,width : 47},
					{ headerText: "結果待ち", key: "waitResult", dataType: "string" ,width : 47},
					{ headerText: "ALL", key: "all", dataType: "string" ,width : 47}
				],
				features: [
						{
							name: "Tooltips",
							visibility: "always",
							style: "popover",
							showDelay: 1000,
							hideDelay: 500,
							tooltipShowing : function(evt, args) {
								var val = args.tooltip;
								val = val.replace(/(\n|\r)/g, "<br/>");
								args.tooltip=val;
							}
						},
						{
							name: "Sorting",
							type: "local"
						}
					],
					dataSource: offer_gridData //JSON Array defined above
			});
			//ホーム画面
			$("#mss_grid").igGrid({
				autoGenerateColumns: true,
				columns: [
					{ headerText: "DODA 求人名称", key: "offerName", dataType: "string",width : 510},
					{ headerText: "原稿タイプ", key: "mssType", dataType: "string" ,width : 78},
					{ headerText: "掲載期間", key: "appearanceTerm", dataType: "string" ,width : 150},
					{ headerText: "本日応募", key: "todayApply", dataType: "string" ,width : 70},
					{ headerText: "未読", key: "nonRead", dataType: "string" ,width : 70},
					{ headerText: "応募総計", key: "appSum", dataType: "string" ,width : 70}
				],
				features: [
						{
							name: "Tooltips",
							visibility: "always",
							style: "popover",
							showDelay: 1000,
							hideDelay: 500,
							tooltipShowing : function(evt, args) {
								var val = args.tooltip;
								val = val.replace(/(\n|\r)/g, "<br/>");
								args.tooltip=val;
							}
						},
						{
							name: "Sorting",
							type: "local"
						}
					],
					dataSource: mss_gridData //JSON Array defined above
			});
			//メッセージ管理画面
			$("#msg_grid").igGrid({
				autoGenerateColumns: true,
				height : "250px",
				columns: [
					{ headerText: "件名", key: "title", dataType: "string",width : 440},
					{ headerText: "添付", key: "annex", dataType: "string" ,width : 40},
					{ headerText: "送信者名", key: "sendName", dataType: "string" ,width : 190},
					{ headerText: "送受信日時", key: "sendDate", dataType: "string" ,width : 160},
					{ headerText: "マイページでの閲覧状況", key: "readCondition", dataType: "string" ,width : 110}
				],
				features: [
						{
							name: "Sorting",
							type: "local"
						},
					],
					dataSource: msg_gridData //JSON Array defined above                    
			});
			//応募者管理画面
			$("#grid").igGrid({
				autoGenerateColumns: true,
				columns: [
					{ headerText: "応募経路", key: "route", dataType: "string" },
					{ headerText: "求人名称", key: "offerName", dataType: "string" },
					{ headerText: "氏名", key: "name", dataType: "string" },
					{ headerText: "年齢", key: "age", dataType: "string" },
					{ headerText: "性別", key: "gender", dataType: "string" },
					{ headerText: "経験職種", key: "jobs", dataType: "string" },
					{ headerText: "現年収（万円）", key: "income", dataType: "string" },
					{ headerText: "最終学歴学校", key: "education", dataType: "string" },
					{ headerText: "選考フェーズ", key: "phase", dataType: "string" },
					{ headerText: "進捗メモ", key: "progress", dataType: "string" },
					{ headerText: "最新メッセージ", key: "message", dataType: "string" }
				],
				features: [
						{
							name: "Tooltips",
							visibility: "always",
							style: "popover",
							showDelay: 1000,
							hideDelay: 500,
							tooltipShowing : function(evt, args) {
								var val = args.tooltip;
								val = val.replace(/(\n|\r)/g, "<br/>");
								args.tooltip=val;
								
							}
						},
						{
							name: "Sorting",
							type: "local"
						},
						{
							name: "RowSelectors",
							enableCheckBoxes: true,
							enableRowNumbering: true,
						},
						{
							name:"Selection",
							multipleSelection: true,
						},
						{	name: "Resizing",
							deferredResizing: false
						},
						{
							name: "Filtering",
							type: "local",
							mode: "advanced",
							filterDialogContainment: "window",
							filterDialogWidth : 360
						}
					],
					dataSource: app_gridData //JSON Array defined above
			});
			
			//応募者管理画面innerScroll
			$("#appSc_grid").igGrid({
				fixedHeaders : true,
				fixedFooters : true,
				height : "500px",
				autoGenerateColumns: true,
				columns: [
					{ headerText: "応募経路", key: "route", dataType: "string" },
					{ headerText: "求人名称", key: "offerName", dataType: "string" },
					{ headerText: "氏名", key: "name", dataType: "string" },
					{ headerText: "年齢", key: "age", dataType: "number" },
					{ headerText: "性別", key: "gender", dataType: "string" },
					{ headerText: "経験職種", key: "jobs", dataType: "string" },
					{ headerText: "現年収（万円）", key: "income", dataType: "number" },
					{ headerText: "最終学歴学校", key: "education", dataType: "string" },
					{ headerText: "選考フェーズ", key: "phase", dataType: "string" },
					{ headerText: "進捗メモ", key: "progress", dataType: "string" },
					{ headerText: "最新メッセージ", key: "message", dataType: "string" }
				],
				features: [
						{
							name: "Sorting",
							type: "local"
						},
						{
							name: "RowSelectors",
							enableCheckBoxes: true,
							enableRowNumbering: false,
						},
						{
							name:"Selection",
							multipleSelection: true,
							mode:"cell"
						},
						{	name: "Resizing",
							deferredResizing: false
						},
						{
							name: "Paging",
							type: "local",
							pageSize: 50,
							pageSizeDropDownLocation : "inpager",
							pageSizeDropDownLabel : "表示件数",
							pageSizeDropDownTrailingLabel : "",
							pageSizeList : [20, 30, 50],
							prevPageLabelText : "< 前へ",
							nextPageLabelText : "次へ >",
							pagerRecordsLabelTemplate : "${recordCount}件中${startRecord}～${endRecord}件の応募者を表示しています。 "
						},
						{
							name: "Filtering",
							type: "local",
							mode: "advanced",
							filterDialogContainment: "window",
						}
					],
					dataSource: appSc_gridData //JSON Array defined above
			});
		});