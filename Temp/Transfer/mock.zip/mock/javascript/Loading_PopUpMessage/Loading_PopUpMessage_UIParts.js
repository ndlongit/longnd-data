var MAXHEIGHT = 530;
$(document).ready(function() {
	$('#dialogSample').click(function(){
		$.blockUI({
			message: $('#dialog'),
			css: {top: "25%", left:"25%", width: "665px",height:"", padding:"10px 10px 30px 10px" }
		});
		//���[�_���|�b�v�A�b�v��max-height�̎w��(top:5%�ɂ��邱�ƑO��)
		$("#dialog").parent("div").css("max-height",MAXHEIGHT+"px");
	});
	$('#cancel').click(function() {
		$.unblockUI();
		return false;
	});
	$('#OKButton').click(function() {
		$.unblockUI();
		return false;
	});
	$('#CancelButton').click(function() {
		$.unblockUI();
		return false;
	});
	
});