// JavaScript Document
    $(document).ready(function() { 
        $('#dialogSample').click(function() {
        	  $.blockUI({ message: $('#dialog'), css: {top: '25%', left:'25%', width: '665px',height:'330px', padding:'10px 10px 10px 10px' } }); 
           // $.blockUI({ message: $('#dialog'), css: { width: '665px',height:'330px', padding:'10px 10px 10px 10px' , margin:'0 auto'} }); 
        }); 
        //$('#ok').click(function() { 
            // update the block message 
            //$.blockUI({ message: "<h1>Remote call in progress...</h1>" }); 
            //$.ajax({ 
            //    url: 'wait.php', 
            //    cache: false, 
            //    complete: function() { 
                    // unblock when remote call returns 
            //        $.unblockUI(); 
            //    } 
            //}); 
        //}); 
 
        $('#cancel').click(function() { 
            $.unblockUI(); 
            return false; 
        }); 

        $('#loadingSample').click(function() { //ローディング画面
            $.blockUI({ message: $('#loadingImage'), css: { width: '85px', height: '85px', padding: '0', top: '38%', left: '47%', color: '#666666',
	 } }); 
			setTimeout($.unblockUI, 2000);//2秒でブロック解除 
        }); 
 
    }); 
