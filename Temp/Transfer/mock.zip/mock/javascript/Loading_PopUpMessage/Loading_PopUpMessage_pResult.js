// JavaScript Document
    $(document).ready(function() { 
        $('#dialogSample').click(function() {
            $.blockUI({ message: $('#dialog'), css: { width: '665px',height:'', top:'25%', left:'25%', padding:'10px 10px 10px 10px' } }); 
        }); 
        $('#cancel').click(function() { 
            $.unblockUI(); 
            return false; 
        }); 
        $('#loadingSample').click(function() { //ローディング画面
            $.blockUI({ message: $('#loadingImage'), css: { width: '85px', height: '85px', padding: '0', top: '38%', left: '47%', color: '#666666',
	 } }); 
			setTimeout($.unblockUI, 2000);//2秒でブロック解除 
        }); 
    }); 
