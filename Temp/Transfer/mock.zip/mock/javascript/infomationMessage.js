function showInfomationMessage(id,text,waitTime){
	var target = $('#'+id);
	target.fadeIn().queue(function() {
	  setTimeout(function(){target.dequeue();
	  }, waitTime);
	});
	target.fadeOut();
};