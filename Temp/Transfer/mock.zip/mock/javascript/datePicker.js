function showDatePicker(targetObj,iconPath){
	targetObj.datepicker({
		showOn:"button",
		buttonImageOnly:true,
		buttonImage:iconPath,
		minDate:1,
		//maxDate:"+1m",
		beforeShowDay: function(date) {
			//日曜日
			if(date.getDay() == 0) {
				return [true,"ui-datepicker-sunday"];
			//土曜日
			} else if(date.getDay() == 6){
				return [true,"ui-datepicker-saturday"];
			//平日
			} else {
				return [true];
			}
		}
	});
}