$(function() {

	//load Tabs
	$("#tabsContentArea").load("./commonTabs.html  #tabsContentInner");
});