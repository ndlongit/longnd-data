package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlLienElementMapper;
import com.structis.shared.model.MdlLienElement;

@Service
public class LienElementServiceImpl implements LienElementService {

	@Autowired
	MdlLienElementMapper mdlLienElementMapper;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public MdlLienElement findLienElementByElement(int idModeleVersion, int idElment) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idElement", idElment);
		return mdlLienElementMapper.findByElement(mapParameter);
	}

	@Override
	public int insert(MdlLienElement record) {
		return mdlLienElementMapper.insert(record);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<MdlLienElement> findWithElementByIdLienCommuns(Integer idModeleVersion, List<Integer> idLienCommuns) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommuns", idLienCommuns);
		return mdlLienElementMapper.findWithElementByIdLienCommuns(mapParameter);
	}

}
