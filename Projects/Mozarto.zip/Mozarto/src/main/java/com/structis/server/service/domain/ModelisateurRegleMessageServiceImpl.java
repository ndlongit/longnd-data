package com.structis.server.service.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.core.ConstantError;
import com.structis.shared.comparator.TreeNodeRegleModelComparator;
import com.structis.shared.constant.CodeRegle;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.constant.Niveau;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.model.MdlAttributEtenduReference;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlLienCommun;
import com.structis.shared.model.MdlMessage;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.MdlReferenceElementKey;
import com.structis.shared.model.MdlRegle;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;
import com.structis.shared.model.reference.TreeNodeModel;
import com.structis.shared.model.reference.TreeNodeRegleModel;
import com.structis.shared.model.reference.ValuePlaceHolder;

@Service
public class ModelisateurRegleMessageServiceImpl implements ModelisateurRegleMessageService {
	
	@Autowired
	LienCommunService lienCommunService;
	
	@Autowired
	RegleService regleService;
	
	@Autowired
	TypeRegleService typeRegleService;

	@Autowired
	MessageService messageService;
	
	@Autowired
	ModeleService modeleService;
	
	@Autowired
	ReferenceElementService referenceElementService;
	
	@Autowired
	CaracteristiqueService caracteristiqueService;
	
	@Autowired
	ReferenceService referenceService;
	
	@Autowired
	LienReferenceService lienReferenceService;
	
	@Autowired
	LiencaracteristiqueService liencaracteristiqueService;
	
	@Autowired
	CarateristiqueReferenceService carateristiqueReferenceService;
	
	@Autowired
	AttributEtenduReferenceService attributEtenduReferenceService;
	
	@Override
	public List<ModelisateurRegleMessageListModel> findRegleMessageList(TreeNodeModel sourceNode,boolean findRegle, boolean findMessage) {
		List<ModelisateurRegleMessageListModel> finalListRegleMessage = new ArrayList<ModelisateurRegleMessageListModel>();
		if(sourceNode.getIdModeleVersion() != null){
			int idModeleVersion = sourceNode.getIdModeleVersion();
			int sourceId = sourceNode.getId();
			String typeSourceLien = sourceNode.getModelType().getLabel();
	
			int idSourceLienCommun = lienCommunService.getIdLienCommmun(idModeleVersion, sourceId, typeSourceLien, false);
			List<Integer> idLienCommunList = new ArrayList<Integer>();
			if( idSourceLienCommun > 0 ) {
				idLienCommunList.add(idSourceLienCommun);
			}
			idLienCommunList.addAll(regleService.findLienCommunsHierarchyUp(sourceNode, idModeleVersion));
			
			List<MdlRegle> regleList = new ArrayList<MdlRegle>();
			List<MdlMessage> messageList = new ArrayList<MdlMessage>();
			
			if( idLienCommunList.size() > 0 ) {
				if(findRegle){
					regleList = regleService.findRegleListExcludeAnnuler(idModeleVersion, idLienCommunList);
				}
				if(!sourceNode.getModelType().equals(ModelNodeType.ELEMENT))
					if(findMessage){
						messageList = messageService.findMessageExludeAnnulerByLienCommun(idModeleVersion, idLienCommunList);
					}
			}
			if(regleList.size() > 0 ) {
				for( MdlRegle regle : regleList ) {
					ModelisateurRegleMessageListModel model = new ModelisateurRegleMessageListModel();
					boolean heritage = false;
					int quantite = (int) regle.getNQuantite();
					String regeleType = ModelisateurRegleMessageListModel.REGLE_TYPE;
					int relation = (int) regle.getNPriorite();
					TreeNodeModel parentNode = null;
					if( regle.getIdSourceLienCommun() != idSourceLienCommun ) {
						heritage = true;
						//TODO:query performance
						parentNode = regleService.findNodeByIdLienCommun(regle.getIdModeleVersion(), regle.getIdSourceLienCommun());
					}
					//TODO:query performance
					TreeNodeModel targetNode = regleService.findNodeByIdLienCommun(regle.getIdModeleVersion(), regle.getIdCibleLienCommun());
					
					String cibleLabel = "";
					if( targetNode != null ) {
						cibleLabel = targetNode.getLibelle();
						
					}
					model = createModelisateurRegleMessageListModel(
							regle.getIdRegle(), heritage, parentNode, targetNode, idModeleVersion, cibleLabel, quantite,
							regeleType, relation);
					finalListRegleMessage.add(model);
				}
			}
			if(messageList.size() > 0 ){
				for(MdlMessage message:messageList){
					ModelisateurRegleMessageListModel model = new ModelisateurRegleMessageListModel();
					boolean heritage = false;
					int quantite = 0;
					String regeleType = ModelisateurRegleMessageListModel.MESSAGE_TYPE;
					int relation = (int) message.getNPriorite();
					TreeNodeModel parentNode = null;
					if( Integer.valueOf(message.getIdSourceLienCommun()) != idSourceLienCommun ) {
						heritage = true;
						//TODO:query performance
						parentNode = regleService.findNodeByIdLienCommun(message.getIdModeleVersion(), message.getIdSourceLienCommun());
					}
					//TODO:query performance
					TreeNodeModel targetNode = null;
					model = createModelisateurRegleMessageListModel(
							message.getIdMessage(), heritage, parentNode, targetNode, idModeleVersion, message.getLLibelleLong(), quantite,
							regeleType, relation);
					finalListRegleMessage.add(model);
				}	
			}
		}
		return finalListRegleMessage;
	}
	@Override
	public List<TreeNodeRegleModel> findElementRegleList(TreeNodeModel sourceNode) {
		List<TreeNodeRegleModel> finalListRegle = new ArrayList<TreeNodeRegleModel>();

		int idModeleVersion = sourceNode.getIdModeleVersion();
		int sourceId = sourceNode.getId();
		String typeSourceLien = sourceNode.getModelType().getLabel();

		int idSourceLienCommun = lienCommunService.getIdLienCommmun(idModeleVersion, sourceId, typeSourceLien, false);
		List<Integer> idLienCommunList = new ArrayList<Integer>();
		if( idSourceLienCommun > 0 ) {
			idLienCommunList.add(idSourceLienCommun);
		}
		
		idLienCommunList.addAll(regleService.findLienCommunsHierarchyUp(sourceNode, idModeleVersion));
		
		List<MdlRegle> regleList = new ArrayList<MdlRegle>();
		
		if( idLienCommunList.size() > 0 ) {
			regleList = regleService.findRegleListExcludeAnnuler(idModeleVersion, idLienCommunList);
		}
		if(regleList.size() > 0 ) {
			for( MdlRegle regle : regleList ) {
				if( (CodeRegle.REFERENCE_VS_ELEMENT.getLabel().equals(regle.getCTypeRegle()) && regle.getIdSourceLienCommun().intValue() == idSourceLienCommun)
						|| (CodeRegle.CARACTERISTIQUE_VS_ELEMENT.getLabel().equals(regle.getCTypeRegle()) && regle.getIdSourceLienCommun() != idSourceLienCommun) ){
					boolean heritage = false;
					if( regle.getIdSourceLienCommun() != idSourceLienCommun ) {
						heritage = true;
					}
					//TODO:query performance
					TreeNodeModel targetNode = regleService.findNodeByIdLienCommun(regle.getIdModeleVersion(), regle.getIdCibleLienCommun());
					TreeNodeRegleModel regleModel = new TreeNodeRegleModel(targetNode);
					regleModel.setInherited(heritage);
					regleModel.setRelation((int) regle.getNPriorite());
					finalListRegle.add(regleModel);
				}
			}
		}
		Collections.sort(finalListRegle,new TreeNodeRegleModelComparator());
		return finalListRegle;
	}
	@Override
	@Transactional
	public ModelisateurRegleMessageListModel insertRegle(Integer idUser,TreeNodeModel sourceNode, TreeNodeModel targetNode,
			int priorite, int quantite) {

		//check whether exists in mdl_lien_caracteristique -> if not insert to mz_mdl_lien_commun, mz_mdl_lien_caracteristique
		if( sourceNode != null && targetNode != null ) {
			int idModeleVersion = sourceNode.getIdModeleVersion();
			int sourceId = sourceNode.getId();
			int cibleId = targetNode.getId();
			int idSourceLienCommun;
			int idCibleLienCommun;
			String typeSourceLien = sourceNode.getModelType().getLabel();
			String typeCibledLien = targetNode.getModelType().getLabel();
			idSourceLienCommun = lienCommunService.getIdLienCommmun(idModeleVersion, sourceId, typeSourceLien, true);
			idCibleLienCommun = lienCommunService.getIdLienCommmun(idModeleVersion, cibleId, typeCibledLien, true);

			String codeTypeRegle = typeRegleService.findTypeRegle(typeSourceLien, typeCibledLien);

			// insert into mz_mdl_regle
			MdlRegle regle = new MdlRegle();
			regle.setIdModeleVersion(idModeleVersion);
			regle.setIdSourceLienCommun(idSourceLienCommun);
			regle.setIdCibleLienCommun(idCibleLienCommun);
			regle.setCTypeRegle(codeTypeRegle);
			regle.setNQuantite((short) quantite);
			regle.setNPriorite((short) priorite);
			regleService.insert(regle);
			ModelisateurRegleMessageListModel model = createModelisateurRegleMessageListModel(
					regle.getIdRegle(), false, null, targetNode, idModeleVersion, targetNode.getLibelle(), quantite,
					ModelisateurRegleMessageListModel.REGLE_TYPE, priorite);
			
			//update modele version
			modeleService.updateModifiedBy(idUser,idModeleVersion);
			return model;
		}
		return null;
	}
	@Override
	public ModelisateurRegleMessageListModel updateRegle(Integer idUser,int idRegle, TreeNodeModel target,
			int priorite, int quantite) {
		MdlRegle regle = regleService.findById(idRegle);
		int idCibleLienCommun = lienCommunService.getIdLienCommmun(regle.getIdModeleVersion().intValue(), target.getId(), target.getModelType().getLabel(), true);
		if(regle.getIdCibleLienCommun().intValue() !=  idCibleLienCommun){
			regle.setIdCibleLienCommun(idCibleLienCommun);
		}
		regle.setNPriorite((short)priorite);
		regle.setNQuantite((short)quantite);
		regleService.update(regle);
		ModelisateurRegleMessageListModel model = createModelisateurRegleMessageListModel(
				regle.getIdRegle(), false, null, target, regle.getIdModeleVersion(), target.getLibelle(), quantite,
				ModelisateurRegleMessageListModel.REGLE_TYPE, priorite);
		modeleService.updateModifiedBy(idUser,regle.getIdModeleVersion());
		return model;
	}
	private ModelisateurRegleMessageListModel createModelisateurRegleMessageListModel(int id, boolean heritage,
			TreeNodeModel parentNode, TreeNodeModel targetNode, int idModeleVersion, String cibleLabel, int quantite,
			String regeleType, int relation) {
		ModelisateurRegleMessageListModel model = new ModelisateurRegleMessageListModel();
		model.setId(id);
		model.setParentNode(parentNode);
		model.setTargetNode(targetNode);
		model.setHeritage(heritage);
		model.setIdModeleVersion(idModeleVersion);
		model.setCibleLibelle(cibleLabel);
		model.setQuantite(quantite);
		model.setType(regeleType);
		model.setRelation(relation);
		return model;
	}
	
	@Override
	public boolean checkSatisfyRules(TreeNodeModel source, Integer idTarget) {
		if( source.getId() != null ) {
			List<ModelisateurRegleMessageListModel> result = findRegleMessageList(source, true, false);
			if (result != null) {
				for (ModelisateurRegleMessageListModel rule: result) {
					if (rule.getTargetNode().getId().intValue() == idTarget.intValue()) {
						if (rule.getRelation().intValue() == Niveau.INTERDITE.getIndex()) {
							return false;
						}
					}
				}
			}
		}	
		return true;
	}
	
	@Override
	public boolean checkSatisfyRules(TreeNodeModel source, Integer idTarget, Integer idVersion, String type ) {
		if( source.getId() != null ) {
			List<ModelisateurRegleMessageListModel> result = findRegleMessageList(source, true, false);
			if ("E".equals(type)) {
				return (!isElementExistInRules(result, idTarget));
			} else if ("R".equals(type)) {
				List <MdlReferenceElement> list = referenceElementService.findByModeleVersionAndReference(idVersion, idTarget);
				for (MdlReferenceElement r: list) {
					if (isElementExistInRules(result, r.getIdElement())) {
						return false;
					}
				}
				return true;
			}
		}	
		return true;
	}
	private boolean isElementExistInRules(List<ModelisateurRegleMessageListModel> result, Integer elementId) {
		if (result != null) {
			for (ModelisateurRegleMessageListModel rule: result) {
				if (rule.getTargetNode().getId().intValue() == elementId.intValue()) {
					if (rule.getRelation().intValue() == Niveau.INTERDITE.getIndex()) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public String validateToDelete(TreeNodeModel sourceNode, boolean isDeleteRegle, boolean isDeleteMessage, boolean isDeleteAll){
		String warnning = "";
		int idModeleVersion = sourceNode.getIdModeleVersion();
		List<Integer> idCarateristiques = new ArrayList<Integer>();
		List<Integer> idReferenceChildrens = new ArrayList<Integer>();
		if( sourceNode.getModelType() == ModelNodeType.CARACTERISTIQUE ) {
			//get all carateristque children 
			idCarateristiques = caracteristiqueService.findIdChidrensHierarchy(sourceNode.getId());
			
			// get all reference of caracteristique
			if(idCarateristiques.size()>0){
				idReferenceChildrens = 	referenceService.findReferenceIdListByModeleVersionAndCaracteristiqueList(idModeleVersion, idCarateristiques);		
				if(idReferenceChildrens != null && idReferenceChildrens.size()>0){
					if(isDeleteAll){
						// check if each reference is orphan then delete reference
						List<ValuePlaceHolder> numberCarateristiqueParents = referenceService.findParentNumberByidReferencesNotInIdCarateristiques(
								idModeleVersion, idReferenceChildrens);
						for(ValuePlaceHolder value:numberCarateristiqueParents){
							if(value.valueId != null && value.valueId == 1 ){
								warnning = "delete orphan";
								break;
							}
						}
					}
				}
				
			}
			
		}else if( sourceNode.getModelType() == ModelNodeType.REFERENCE ){
			//check if this reference have sous modele
			int countSousModele = referenceService.coundSousModeleByIdReference(idModeleVersion, sourceNode.getId());
			if(countSousModele > 0){
				warnning = "delete sous";
			}
		}
		return warnning;
	}
	
	@Override
	@Transactional
	public void deleteModelisateurNode(TreeNodeModel sourceNode, boolean isDeleteRegle, boolean isDeleteMessage, boolean isDeleteAll) {
		//face with reference
		int idModeleVersion = sourceNode.getIdModeleVersion();
		List<Integer> idCarateristiques = new ArrayList<Integer>();
		List<Integer> idReferenceChildrens = new ArrayList<Integer>();
		List<Integer> idReferenceToDeletes = new ArrayList<Integer>();
		//List<Integer> idReferenceToUnlinks = new ArrayList<Integer>();
		if( sourceNode.getModelType() == ModelNodeType.CARACTERISTIQUE ) {
			//get all carateristque children 
			idCarateristiques = caracteristiqueService.findIdChidrensHierarchy(sourceNode.getId());
			
			// get all reference of caracteristique
			if(idCarateristiques.size()>0){
				//delete all references of this carateristique
				idReferenceChildrens = 	referenceService.findReferenceIdListByModeleVersionAndCaracteristiqueList(idModeleVersion, idCarateristiques);		
				if(idReferenceChildrens != null && idReferenceChildrens.size()>0){
					if(isDeleteAll){
						// check if each reference is orphan then delete reference
						List<ValuePlaceHolder> numberCarateristiqueParents = referenceService.findParentNumberByidReferencesNotInIdCarateristiques(
								idModeleVersion, idReferenceChildrens);
						for(ValuePlaceHolder value:numberCarateristiqueParents){
							if(value.valueId != null && value.valueId == 1 ){
								idReferenceToDeletes.add(value.elementId);
							}/*else{
								idReferenceToUnlinks.add(value.elementId);
							}*/
						}
						unlinkReferences(idModeleVersion,idCarateristiques);
						if( idReferenceToDeletes.size() > 0){
							deleteRefereces(idModeleVersion,idReferenceToDeletes,isDeleteRegle, isDeleteMessage, isDeleteAll);
						}
						//if( idReferenceToUnlinks.size() > 0 ){
							//deleteRefereces(idModeleVersion,idReferenceToUnlinks,isDeleteRegle, isDeleteMessage, false);
							
						//}
					}else{
						deleteRefereces(idModeleVersion,idReferenceChildrens,isDeleteRegle, isDeleteMessage, isDeleteAll);
					}
				}
				List<Integer> idLienCommunCarateristiques = liencaracteristiqueService.findLienCaracteristiqueIdsByCaracteristiqueList(idModeleVersion, idCarateristiques);
				if(idLienCommunCarateristiques != null && idLienCommunCarateristiques.size() >0){
					// delete all message of this carateristique
					if(isDeleteMessage){
						messageService.deleteMessageByidLienCommuns(idModeleVersion, idLienCommunCarateristiques);
					}
					// delete all regle of this carateristique
					// delele all regle that this carateristique is tartget
					if(isDeleteRegle){
						regleService.deleteByIdLienCommun(idModeleVersion, idLienCommunCarateristiques);
					}
					if(isDeleteAll){
						//delete all liencommun of this carateristique
						liencaracteristiqueService.deleteByIdlienCoummuns(idModeleVersion, idLienCommunCarateristiques);
						lienCommunService.deleteByIdLienCoummuns(idModeleVersion, idLienCommunCarateristiques);
					}
				}
				if(isDeleteAll){
					//delete carateristique it'self
					if(idReferenceChildrens != null && idReferenceChildrens.size() > 0){
						carateristiqueReferenceService.deleteByModeleVersionIdCarateristiquesAndIdReferences(idModeleVersion, idCarateristiques ,null);
					}
					caracteristiqueService.deleteByIds(idCarateristiques);
					//idReferenceChildrens = 	referenceService.findReferenceListByModeleVersionAndCaracteristiqueList(idModeleVersion, idCarateristiques);
				}
			}
			
		}else if( sourceNode.getModelType() == ModelNodeType.REFERENCE ){
			idReferenceToDeletes.add(sourceNode.getId());
			deleteRefereces(idModeleVersion,idReferenceToDeletes,isDeleteRegle, isDeleteMessage, isDeleteAll);
			
		}else if(sourceNode.getModelType() == ModelNodeType.ELEMENT){
			if(sourceNode.getParentId() != null && sourceNode.getParentId() != 0){
				referenceElementService.deleteSousElementsByIdElementAndIdReferences(idModeleVersion, sourceNode.getId(), sourceNode.getParentId());
				MdlReferenceElementKey refEleKey = new MdlReferenceElementKey();
				refEleKey.setIdElement(sourceNode.getId());
				refEleKey.setIdModeleVersion(idModeleVersion);
				refEleKey.setIdReference(sourceNode.getParentId());
				referenceElementService.deleteById(refEleKey);
			}
		}
	}
	@Transactional
	public void unlinkReferences(Integer idModeleVersion,List<Integer> idCaracteristiques){
		carateristiqueReferenceService.deleteByModeleVersionIdCarateristiquesAndIdReferences(idModeleVersion,idCaracteristiques,null);
	}
	@Transactional
	public void deleteRefereces(Integer idModeleVersion, List<Integer> idReferences,boolean isDeleteRegle, boolean isDeleteMessage, boolean isDeleteAll){
		List<Integer> idLienCommunReferences = lienReferenceService.findByIdReferences(idModeleVersion, idReferences);
		idLienCommunReferences.add(0);
		if(idLienCommunReferences != null && idLienCommunReferences.size() > 0){
			// delete all message of this reference
			if(isDeleteMessage){
				messageService.deleteMessageByidLienCommuns(idModeleVersion, idLienCommunReferences);
			}
			// delete all regle of this reference
			// delele all regle that this reference is tartget
			if(isDeleteRegle){
				regleService.deleteByIdLienCommun(idModeleVersion, idLienCommunReferences);
			}
			if(isDeleteAll){
				//delete all liencommun of this reference
				lienReferenceService.deleteByIdLienCommuns(idModeleVersion, idLienCommunReferences);
				lienCommunService.deleteByIdLienCoummuns(idModeleVersion, idLienCommunReferences);
			}
		}
		if(isDeleteAll){
			// delete all element of this reference
			referenceElementService.deleteByIdModeleVersionAndIdReferences(idModeleVersion, idReferences);
			/**
			 *delete all element sous reference
			 * --> find all the sous reference have id_sous_modele = id_reference
			 * --> set id_reference_parent = null
			 */
			referenceService.deleteSousModele(idModeleVersion, idReferences);
			//delete all attribut etendu of this reference
			attributEtenduReferenceService.deleteByIdReferences(idModeleVersion, idReferences);
			//delete carateristique_reference
			carateristiqueReferenceService.deleteByModeleVersionIdCarateristiquesAndIdReferences(idModeleVersion,null,idReferences);			
			//delete refrence itself
			referenceService.deleteById(idReferences);
		}
	}
	@Override
	public ModelisateurRegleMessageListModel insertMessage(Integer idUser, TreeNodeModel source, int priorite, String libelle) {
		if( source != null ) {
			int idModeleVersion = source.getIdModeleVersion();
			int sourceId = source.getId();
			MdlLienCommun lienCommun;
			String typeSourceLien = source.getModelType().getLabel();
			lienCommun = lienCommunService.getLienCommmun(idModeleVersion, sourceId, typeSourceLien, true);
			

			// insert into mz_mdl_regle
			MdlMessage message = new MdlMessage();
			message.setIdModeleVersion(idModeleVersion);
			message.setIdSourceLienCommun(lienCommun.getIdLienCommun());
			message.setCTypeLien(lienCommun.getCTypeLien());
			message.setLLibelleLong(libelle);
			message.setNPriorite((short) priorite);
			messageService.insert(message);
			ModelisateurRegleMessageListModel model = createModelisateurRegleMessageListModel(
					message.getIdMessage(), false, null, null, idModeleVersion, libelle, -1,
					ModelisateurRegleMessageListModel.MESSAGE_TYPE, priorite);
			
			//update modele version
			modeleService.updateModifiedBy(idUser,idModeleVersion);
			return model;
		}
		return null;
	}
	@Override
	public ModelisateurRegleMessageListModel updateMessage(Integer idUser, Integer idMessage, String libelle,
			int priorite) {
		MdlMessage message = messageService.findById(idMessage);
		message.setLLibelleLong(libelle);
		message.setNPriorite((short) priorite);
		messageService.update(message);
		ModelisateurRegleMessageListModel model = createModelisateurRegleMessageListModel(
				message.getIdMessage(), false, null, null, message.getIdModeleVersion(), libelle, -1,
				ModelisateurRegleMessageListModel.MESSAGE_TYPE, priorite);
		
		//update modele version
		modeleService.updateModifiedBy(idUser,message.getIdModeleVersion());
		return model;
	}
	@Override
	public List<ModelisateurRegleMessageListModel> findReglePointToElement(TreeNodeModel elementNode) {
		int idModeleVersion = elementNode.getIdModeleVersion();
		int sourceId = elementNode.getId();
		String typeSourceLien = elementNode.getModelType().getLabel();
		List<ModelisateurRegleMessageListModel> regleResult = new ArrayList<ModelisateurRegleMessageListModel>();
		int idLienCommunElement = lienCommunService.getIdLienCommmun(idModeleVersion, sourceId, typeSourceLien, false);
		if(idLienCommunElement != 0){
			List<MdlRegle> regles = regleService.findRegleByIdCibleLienCommun(idModeleVersion, idLienCommunElement);
			if(regles != null && regles.size() > 0){
				for(MdlRegle regle:regles){
					int quantite = (int) regle.getNQuantite();
					String regeleType = ModelisateurRegleMessageListModel.REGLE_TYPE;
					int relation = (int) regle.getNPriorite();
					TreeNodeModel parentNode = null;
					parentNode = regleService.findNodeByIdLienCommun(regle.getIdModeleVersion(), regle.getIdSourceLienCommun());
					ModelisateurRegleMessageListModel model = createModelisateurRegleMessageListModel(
						regle.getIdRegle(), true, parentNode, null, idModeleVersion, "", quantite,
						regeleType, relation);
					regleResult.add(model);
				}
			}
		}
		return regleResult;
	}
	

	public TreeNodeModel copyCaracteristique (MdlCaracteristique caract, Integer idParent, boolean isCopyRegle,
			boolean isCopyMessage, boolean isCopyChildren, Integer idUtilisateur, Integer idMetier){
		TreeNodeModel treeNodeModel = new TreeNodeModel();
		List<MdlCaracteristique> caracteristiqueChildren = caracteristiqueService.findCaracteristiqueChildrenHierarchy(caract.getIdCaracteristique());	

		List<String> duplicatedLibelles = caracteristiqueCheckCopyExist(caracteristiqueChildren, caract.getIdModeleVersion());
		String duplicatedLibellesStr = "";
		if(duplicatedLibelles.size() > 0){
			duplicatedLibellesStr += duplicatedLibelles.get(0); 
			if(isCopyChildren){
				if(duplicatedLibelles.size() > 1)
					for(int i = 1; i < duplicatedLibelles.size(); i++){
						duplicatedLibellesStr += "," + duplicatedLibelles.get(i); 
					}
			}
		}
		List<MdlReference> references = new ArrayList<MdlReference>();
		if(isCopyChildren){
			List<Integer> idCaract = new ArrayList<Integer>();
			idCaract.add(caract.getIdCaracteristique());
			references = referenceService.findReferencesByModeleVersionAndCaracteristiqueList(caract.getIdModeleVersion(), idCaract);
			List<String> duplicatedLibellesRef = referenceCheckCopyExist(references, caract.getIdModeleVersion());
			if(duplicatedLibellesRef.size() > 0){
				duplicatedLibellesStr += duplicatedLibellesRef.get(0); 
				if(duplicatedLibellesRef.size() > 1)
					for(int i = 1; i < duplicatedLibellesRef.size(); i++){
						duplicatedLibellesStr += "," + duplicatedLibellesRef.get(i); 
					}
			}
		}
		
		if(!"".equals(duplicatedLibellesStr))
			throw new FunctionalException(ConstantError.ERR_EXISTED + " " + duplicatedLibellesStr);
		
		MdlCaracteristique caracteristique = new MdlCaracteristique();
		String lLibelleLong = "Copie de " + caract.getLLibelleLong();
		lLibelleLong = lLibelleLong.length() > 50 ? lLibelleLong.substring(0, 49) : lLibelleLong;
		caracteristique.setLLibelleLong(lLibelleLong);
/*		int libelleLength = lLibelleLong.length();
		while(caracteristiqueService.findByBaseCriteria(caracteristique).size() > 0){
			lLibelleLong = caracteristique.getLLibelleLong();
			if(caracteristique.getLLibelleLong().length() == 50){
				libelleLength--;
				lLibelleLong = lLibelleLong.substring(0, libelleLength - 1);
			}

			lLibelleLong = lLibelleLong.length() > 50 ? lLibelleLong.substring(0, libelleLength - 1) : lLibelleLong;
			caracteristique.setLLibelleLong(lLibelleLong + "1");
		}*/
		caracteristique.setIdCaracteristiqueParent(idParent);
		caracteristique.setIdModeleVersion(caract.getIdModeleVersion());
		caracteristique.setLCommentaire(caract.getLCommentaire());
		caracteristique.setLevel(caract.getLevel());
		caracteristique.setNRang(caract.getNRang());
		caracteristiqueService.findByBaseCriteria(caracteristique);
		caracteristiqueService.insert(caracteristique);
		if(isCopyChildren){
			if(caracteristiqueChildren != null && caracteristiqueChildren.size() > 1){
				treeNodeModel.setHasChildren(true);
				caracteristiqueChildren.remove(0);
				for(MdlCaracteristique child : caracteristiqueChildren){
						copyCaracteristique(child, caracteristique.getIdCaracteristique(), isCopyRegle, isCopyMessage, isCopyChildren, idUtilisateur, idMetier);
				}
			}
			for(MdlReference ref : references){
				copyReference(ref, caracteristique.getIdCaracteristique(), isCopyRegle, isCopyMessage, isCopyChildren, idUtilisateur, idMetier, false);
			}
		}
		treeNodeModel.setId(caracteristique.getIdCaracteristique());
		treeNodeModel.setIdModeleVersion(caracteristique.getIdModeleVersion());
		treeNodeModel.setLibelle(caracteristique.getLLibelleLong());
		treeNodeModel.setModelType(ModelNodeType.CARACTERISTIQUE);
		treeNodeModel.setParentId(idParent);
		return treeNodeModel;
	}
	
	public TreeNodeModel copyReference(MdlReference ref, Integer idCaracteristique, boolean isCopyRegle,
			boolean isCopyMessage, boolean isCopyChildren, Integer idUtilisateur, Integer idMetier, boolean check){
		
			List<MdlReference> refs = new ArrayList<MdlReference>();
			refs.add(ref);
			List<String> duplicatedLibelles = referenceCheckCopyExist(refs, ref.getIdModeleVersion());
			String duplicatedLibellesStr = "";
			if(duplicatedLibelles.size() > 0){
				duplicatedLibellesStr += duplicatedLibelles.get(0); 
				if(duplicatedLibelles.size() > 1)
					for(int i = 1; i < duplicatedLibelles.size(); i++){
						duplicatedLibellesStr += "," + duplicatedLibelles.get(i); 
					}
				throw new FunctionalException(ConstantError.ERR_EXISTED + " " + duplicatedLibellesStr);
			}

		MdlReference reference = new MdlReference();
		String lLibelleLong = "Copie de " + ref.getLLibelleLong();
		lLibelleLong = lLibelleLong.length() > 500 ? lLibelleLong.substring(0, 500) : lLibelleLong;
		reference.setLLibelleLong(lLibelleLong);
/*		int libelleLength = lLibelleLong.length();
		while(referenceService.findByBaseCriteria(reference).size() > 0){
			lLibelleLong = reference.getLLibelleLong();
			if(reference.getLLibelleLong().length() == 500){
				libelleLength--;
				lLibelleLong = lLibelleLong.substring(0, libelleLength - 1);
			}

			lLibelleLong = lLibelleLong.length() > 500 ? lLibelleLong.substring(0, libelleLength - 1) : lLibelleLong;
			reference.setLLibelleLong(lLibelleLong + "1");
		}*/
		reference.setIdModeleVersion(ref.getIdModeleVersion());
		reference.setLCommentaire(ref.getLCommentaire());
		reference.setNRang(ref.getNRang());
		referenceService.insert(reference);
		MdlCarateristiqueReference mdlCarateristiqueReference = new MdlCarateristiqueReference();
		mdlCarateristiqueReference.setIdCaracteristique(idCaracteristique);
		mdlCarateristiqueReference.setIdReference(reference.getIdReference());
		mdlCarateristiqueReference.setIdModeleVersion(ref.getIdModeleVersion());
		carateristiqueReferenceService.insert(mdlCarateristiqueReference);
		List<MdlReferenceElement> listElementSortie = referenceElementService.findByModeleVersionAndReference(
				ref.getIdModeleVersion(), ref.getIdReference());
		for(MdlReferenceElement refelts : listElementSortie){
			refelts.setIdReference(reference.getIdReference());
		}
		referenceElementService.insertList(listElementSortie);
		MdlAttributEtenduReference criteria = new MdlAttributEtenduReference();
		criteria.setIdModeleVersion(ref.getIdModeleVersion());
		criteria.setIdReference(ref.getIdReference());
		List<MdlAttributEtenduReference> attributEtendus = attributEtenduReferenceService.findByBaseCriteria(criteria);
		for(MdlAttributEtenduReference att : attributEtendus){
			att.setIdReference(reference.getIdReference());
			
		}
		attributEtenduReferenceService.insertList(attributEtendus);

		TreeNodeModel treeNodeModel = new TreeNodeModel();
		if(listElementSortie.size() > 0)
			treeNodeModel.setHasChildren(true);
		treeNodeModel.setId(reference.getIdReference());
		treeNodeModel.setIdModeleVersion(reference.getIdModeleVersion());
		treeNodeModel.setLibelle(reference.getLLibelleLong());
		treeNodeModel.setModelType(ModelNodeType.REFERENCE);
		treeNodeModel.setParentId(idCaracteristique);
		Integer coundSousModeleByIdReference = referenceService.coundSousModeleByIdReference(ref.getIdModeleVersion(), ref.getIdReference());
		if(coundSousModeleByIdReference > 0)
			treeNodeModel.setSousRef(true);
//		referenceService.insertOrUpdate(idUtilisateur, reference, attributEtendus, listElementEntree, listElementSortie);
		return treeNodeModel;
	}
	
	private List<String> caracteristiqueCheckCopyExist(List<MdlCaracteristique> list, Integer idModeleVersion){
		if(list != null && list.size() > 0){
			List<String> libelles = new ArrayList<String>();
			for(MdlCaracteristique car : list){
				String lib = "Copie de " + car.getLLibelleLong();
				lib = lib.length() > 50 ? lib.substring(0, 50) : lib;
				libelles.add(lib);
			}
			return caracteristiqueService.findLibelleInList(libelles, idModeleVersion);
		}
		return new ArrayList<String>();
	}
	
	private List<String> referenceCheckCopyExist(List<MdlReference> list, Integer idModeleVersion){
		if(list != null && list.size() > 0){
			List<String> libelles = new ArrayList<String>();
			for(MdlReference car : list){
				String lib = "Copie de " + car.getLLibelleLong();
				lib = lib.length() > 500 ? lib.substring(0, 499) : lib;
				libelles.add(lib);
			}
			return referenceService.findLibelleInList(libelles, idModeleVersion);
		}
		return new ArrayList<String>();
	}
	
	
}
