package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.data.shared.TreeStore;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.menu.Menu;
import com.sencha.gxt.widget.core.client.treegrid.TreeGrid;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.service.ClientModelisateurServiceAsync;
import com.structis.shared.model.reference.TreeNodeModel;

public class CopierMenu extends Menu {

	private HTML cancelButton;

	private TextButton confirmButton;

	private CheckBox regles;

	private CheckBox messagesCheckbox;

	private CheckBox descendance;

	private TreeGrid<TreeNodeModel> treeGrid;

	private TreeStore<TreeNodeModel> treeStore;

	protected Messages messages = GWT.create(Messages.class);

	private SimpleEventBus bus;

	private Menu menuParent;

	public CopierMenu(final TreeGrid<TreeNodeModel> tree, String title, SimpleEventBus bus, Menu parent) {
		final Dialog simple = new Dialog();
		this.treeGrid = tree;
		this.bus = bus;
		menuParent = parent;
		treeStore = (TreeStore<TreeNodeModel>) tree.getTreeStore();
		simple.getElement().getStyle().setBackgroundColor("#FFFFFF");
		//		simple.setBodyStyle("background:white");
		//		simple.getButtonBar().setStyleName("whiteBackGround");
		simple.setHeadingText(title);
		simple.setButtonAlign(BoxLayoutPack.END);
		confirmButton = new TextButton(PredefinedButton.OK.name());
		cancelButton = new HTML("Annuler");
		cancelButton.setStyleName("htmlLink");
		simple.getButtonBar().add(cancelButton);
		simple.getButtonBar().add(confirmButton);
		simple.getButtonById(PredefinedButton.OK.name()).hide();
		VerticalLayoutContainer container = new VerticalLayoutContainer();
		regles = new CheckBox();
		messagesCheckbox = new CheckBox();
		descendance = new CheckBox();
		regles.setValue(true);
		messagesCheckbox.setValue(true);
		descendance.setValue(true);
		regles.setEnabled(false);
		messagesCheckbox.setEnabled(false);
		container.add(regles);
		container.add(messagesCheckbox);
		container.add(descendance);
		regles.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
			@Override
			public void onValueChange(ValueChangeEvent<Boolean> arg0) {

				checkValidateEnable();
			}
		});
		messagesCheckbox.addValueChangeHandler(new ValueChangeHandler<Boolean>() {

			@Override
			public void onValueChange(ValueChangeEvent<Boolean> arg0) {

				checkValidateEnable();
			}
		});
		descendance.addValueChangeHandler(new ValueChangeHandler<Boolean>() {

			@Override
			public void onValueChange(ValueChangeEvent<Boolean> arg0) {

				if( descendance.getValue() ) {
					regles.disable();
					messagesCheckbox.disable();
				}
				else {
					regles.enable();
					messagesCheckbox.enable();
				}
				checkValidateEnable();
			}
		});
		cancelButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				hide();
			}
		});
		confirmButton.addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				hide();
				menuParent.hide();
				final TreeNodeModel sourceNodeModel = treeGrid.getSelectionModel().getSelectedItem();
				if( treeGrid != null ) {
					ClientModelisateurServiceAsync.Util.getInstance().validateToDelete(
							sourceNodeModel, regles.getValue(), messagesCheckbox.getValue(), descendance.getValue(),
							new AsyncCallbackWithErrorResolution<String>() {

								@Override
								public void onSuccess(String result) {
									copierNode(
											sourceNodeModel, regles.getValue(), messagesCheckbox.getValue(),
											descendance.getValue());
								}
							});

				}

			}
		});
		simple.setHideOnButtonClick(true);
		simple.add(container);
		simple.setResizable(false);
		simple.setDraggable(false);
		simple.setWidth(300);
		simple.setHeight(130);
		simple.setPosition(0, 0);
		add(simple);
		//	    setWidth(300);
		//	    setHeight(100);

	}

	private void copierNode(final TreeNodeModel sourceNodeModel, final boolean isDeleteRegle, final boolean isDeleteMessage,
			final boolean isDeleteChildren) {
		
	}

	public HTML getCancelButton() {
		return cancelButton;
	}

	public void setCancelButton(HTML cancelButton) {
		this.cancelButton = cancelButton;
	}

	public TextButton getConfirmButton() {
		return confirmButton;
	}

	public void setConfirmButton(TextButton confirmButton) {
		this.confirmButton = confirmButton;
	}

	public CheckBox getRegles() {
		return regles;
	}

	public void setRegles(CheckBox regles) {
		this.regles = regles;
	}

	public CheckBox getMessages() {
		return messagesCheckbox;
	}

	public void setMessages(CheckBox messages) {
		this.messagesCheckbox = messages;
	}

	public CheckBox getDescendance() {
		return descendance;
	}

	public void setDesendance(CheckBox descendance) {
		this.descendance = descendance;
	}

	private void checkValidateEnable() {
		if( !regles.getValue() && !messagesCheckbox.getValue() && !descendance.getValue() )
			confirmButton.disable();
		else
			confirmButton.enable();
	}
}
