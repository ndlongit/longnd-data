package com.structis.client.panel.admin;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.text.shared.AbstractSafeHtmlRenderer;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.sencha.gxt.cell.core.client.form.ComboBoxCell.TriggerAction;
import com.sencha.gxt.core.client.XTemplates;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.FramedPanel;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.AbstractHtmlLayoutContainer.HtmlData;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.HtmlLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.BeforeSelectEvent;
import com.sencha.gxt.widget.core.client.event.BeforeSelectEvent.BeforeSelectHandler;
import com.sencha.gxt.widget.core.client.event.BlurEvent;
import com.sencha.gxt.widget.core.client.event.BlurEvent.BlurHandler;
import com.sencha.gxt.widget.core.client.event.CompleteEditEvent;
import com.sencha.gxt.widget.core.client.event.CompleteEditEvent.CompleteEditHandler;
import com.sencha.gxt.widget.core.client.event.FocusEvent;
import com.sencha.gxt.widget.core.client.event.FocusEvent.FocusHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.form.ComboBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.CellSelectionModel;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.grid.editing.GridEditing;
import com.sencha.gxt.widget.core.client.grid.editing.GridInlineEditing;
import com.structis.client.event.ElementCompositionGridEvent;
import com.structis.client.event.GestionElementCompositionCloseTabEvent;
import com.structis.client.event.GestionElementCompositionRenameElementEvent;
import com.structis.client.event.ModifyEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.AttributEtenduMetierERValueModelProperties;
import com.structis.client.properties.FamilleProperties;
import com.structis.client.properties.TypeElementProperties;
import com.structis.client.service.ClientElementServiceAsync;
import com.structis.client.service.ClientGestionElementCompositionServiceAsync;
import com.structis.client.widget.HtmlButton;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.Element;
import com.structis.shared.model.Famille;
import com.structis.shared.model.TypeElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.GestionElementCompositionReference;

public class GestionDesElementDeCompositionForm extends VerticalLayoutContainer {

	private static final int NOMENCLATUREFOURNISSEUR_MAX_LENGTH = 50;

	private static final int CODE_MAX_LENGTH = 10;

	private static final int LIBELLE_MAX_LENGTH = 500;

	private SimpleEventBus bus;
	
	private String label;

	private final Messages messages = GWT.create(Messages.class);

	private NavigationService navigation = NavigationFactory.getNavigation();

	private ComboBox<TypeElement> type;

	private CheckBox actif;

	private TextField code;

	private TextField libelle;

	private TextField nomenclatureFournisseur;

	private ComboBox<Famille> famille;

	private ComboBox<Famille> sousfamille;

	private ComboBox<Famille> groupe;

	private ComboBox<Famille> sousgroupe;

	private ComboBox<Famille> typeprestation;

	private Grid<AttributEtenduMetierERValueModel> attributEtenduGrid;

	private HtmlButton cancelBtn;

	private TextButton validBtn;

	private FramedPanel panel;

	private Element element;

	private List<Famille> familles;

	private List<TypeElement> types;

	private List<AttributEtenduMetierERValueModel> attributEtendus;

	private HtmlLayoutContainer con2;

	private FieldLabel labelfamille;

	private FieldLabel labelsousfamille;

	private FieldLabel labelgroupe;

	private FieldLabel labelsousgroupe;

	private FieldLabel labeltypeprestation;

	private ClickHandler cancelBtnHandler;

	private Integer idMetier = navigation.getContext().getMetier().getIdMetier();

	private Integer idElement;

	private boolean typeVide = false;

	private boolean codeVide = false;

	private boolean codeExist = false;

	private boolean libelleVide = false;

	private List<Element> allElements;

	private String codeInitial = "";

	private Object nFournisseurInitial = "";

	private String codeActuel = "";

	private String libelleActuel = "";

	private Object nFournisseurActuel = "";

	private boolean nFournisseurExist = false;

	private int codeSize;

	private int libelleSize;

	private int nfournisseurSize;

	private int typeSize;
	
	private boolean isChanged;
	
	private boolean create = true;
	
	private String texttmp = "";

	private ListStore<AttributEtenduMetierERValueModel> attributEtenduStore;

	private final AttributEtenduMetierERValueModelProperties attprops;
	interface ComboBoxTemplates extends XTemplates {
		
	    @XTemplate("<div  style = \"height:11px;\" >&nbsp;{lLibelle}</div>")
	    SafeHtml state(String lLibelle);
	 
	  }
	public GestionDesElementDeCompositionForm(Integer idElement, SimpleEventBus b, String label) {
		this.idElement = idElement;
		this.bus = b;
		this.label = label;
		setStyleName("whiteBackGround");
		panel = new FramedPanel();
		panel.setHeaderVisible(false);
		panel.setStyleName("whiteBackGround");
		panel.getButtonBar().setStyleName("whiteBackGround");
		add(panel, new VerticalLayoutData(1, 1));

		VerticalLayoutContainer vp = new VerticalLayoutContainer();
				vp.setStyleName("whiteBackGround");
		panel.add(vp);
		vp.setAdjustForScroll(true);

		FieldSet fieldSet1 = new FieldSet();
		vp.add(fieldSet1);
		fieldSet1.setBorders(false);

		HtmlLayoutContainer con1 = new HtmlLayoutContainer(getTableMarkup());
		fieldSet1.add(con1);

		TypeElementProperties props = GWT.create(TypeElementProperties.class);
		ListStore<TypeElement> typeselt = new ListStore<TypeElement>(props.cTypeElement());

		type = new ComboBox<TypeElement>(typeselt, props.lLibelle());
		con1.add(new FieldLabel(type, messages.gestionelemcompoRightType()), new HtmlData(".f1"));
		type.setTypeAhead(true);
		type.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationType(type, props.lLibelle());

		actif = new CheckBox();
		actif.setValue(true);
		HorizontalPanel hp = new HorizontalPanel();
		hp.add(actif);
		//		actif.setPosition(0, 0);
		con1.add(new FieldLabel(hp, messages.gestionelemcompoRightActif()), new HtmlData(".f2"));

		code = new TextField();
		code.setValidateOnBlur(false);
		con1.add(new FieldLabel(code, messages.gestionelemcompoRightCode()), new HtmlData(".f3"));

		libelle = new TextField();
		con1.add(new FieldLabel(libelle, messages.gestionelemcompoRightLibelle()), new HtmlData(".f4"));

		nomenclatureFournisseur = new TextField();
		con1.add(
				new FieldLabel(nomenclatureFournisseur, messages.gestionelemcompoRightNomclematureFournisseur()),
				new HtmlData(".f5"));

		// Famille

		FieldSet fieldSet = new FieldSet();
		fieldSet.setHeadingText(messages.gestionelemcompoRightFamille());
		vp.add(fieldSet);

		con2 = new HtmlLayoutContainer(getTableMarkup());
		fieldSet.add(con2);

		FamilleProperties fprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> fam = new ListStore<Famille>(fprops.idFamille());
		famille = new ComboBox<Famille>(fam, fprops.lLibelle(), new AbstractSafeHtmlRenderer<Famille>() {

			@Override
			public SafeHtml render(Famille item) {
				final ComboBoxTemplates comboBoxTemplates = GWT.create(ComboBoxTemplates.class);
		         return comboBoxTemplates.state(item.getLLibelle());
			}
		});
		labelfamille = new FieldLabel(famille, messages.gestionelemcompoRightFamilleFamille());

		FamilleProperties sfprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> sfam = new ListStore<Famille>(sfprops.idFamille());
		sousfamille = new ComboBox<Famille>(sfam, sfprops.lLibelle());
		labelsousfamille = new FieldLabel(sousfamille, messages.gestionelemcompoRightFamilleSousFamille());

		FamilleProperties gprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> gpe = new ListStore<Famille>(gprops.idFamille());
		groupe = new ComboBox<Famille>(gpe, gprops.lLibelle());
		labelgroupe = new FieldLabel(groupe, messages.gestionelemcompoRightFamilleGroupe());

		FamilleProperties sgprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> sgpe = new ListStore<Famille>(sgprops.idFamille());
		sousgroupe = new ComboBox<Famille>(sgpe, sgprops.lLibelle());
		labelsousgroupe = new FieldLabel(sousgroupe, messages.gestionelemcompoRightFamilleSousGroupe());

		FamilleProperties pprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> prest = new ListStore<Famille>(pprops.idFamille());
		typeprestation = new ComboBox<Famille>(prest, pprops.lLibelle(), new AbstractSafeHtmlRenderer<Famille>() {

			@Override
			public SafeHtml render(Famille item) {
				final ComboBoxTemplates comboBoxTemplates = GWT.create(ComboBoxTemplates.class);
		         return comboBoxTemplates.state(item.getLLibelle());
			}
		});
		labeltypeprestation = new FieldLabel(typeprestation, messages.gestionelemcompoRightFamilleTypePrestation());

		famille.setTypeAhead(true);
		famille.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(famille, fprops.lLibelle(), Constant.TYPE_FAMILLE_FAMILLE);

		sousfamille.setTypeAhead(true);
		sousfamille.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(sousfamille, sfprops.lLibelle(), Constant.TYPE_FAMILLE_SOUSFAMILLE);

		groupe.setTypeAhead(true);
		groupe.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(groupe, gprops.lLibelle(), Constant.TYPE_FAMILLE_GROUPE);
		sousgroupe.setTypeAhead(true);
		sousgroupe.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(sousgroupe, sgprops.lLibelle(), Constant.TYPE_FAMILLE_SOUSGROUPE);

		typeprestation.setTypeAhead(true);
		typeprestation.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(typeprestation, pprops.lLibelle(), Constant.TYPE_FAMILLE_TYPEPRESTATION);

		// Attributs

		FieldSet fieldSet2 = new FieldSet();
		fieldSet2.setHeadingText(messages.gestionelemcompoRightAttributs());
		vp.add(fieldSet2);

		VerticalLayoutContainer con3 = new VerticalLayoutContainer();

		attprops = GWT.create(AttributEtenduMetierERValueModelProperties.class);
		ColumnConfig<AttributEtenduMetierERValueModel, String> libAttr = new ColumnConfig<AttributEtenduMetierERValueModel, String>(
				attprops.attributEtenduLibelle());
		libAttr.setHeader(messages.modelisateurFormLibelle());

		ColumnConfig<AttributEtenduMetierERValueModel, String> valAttr = new ColumnConfig<AttributEtenduMetierERValueModel, String>(
				attprops.valeur());
		valAttr.setHeader(messages.modelisateurFormValeur());
		List<ColumnConfig<AttributEtenduMetierERValueModel, ?>> l = new ArrayList<ColumnConfig<AttributEtenduMetierERValueModel, ?>>();
		libAttr.setMenuDisabled(true);
		valAttr.setMenuDisabled(true);
		l.add(libAttr);
		l.add(valAttr);
		ColumnModel<AttributEtenduMetierERValueModel> cm = new ColumnModel<AttributEtenduMetierERValueModel>(l);
		attributEtenduStore = new ListStore<AttributEtenduMetierERValueModel>(
				attprops.getIdER());
		attributEtenduGrid = new Grid<AttributEtenduMetierERValueModel>(attributEtenduStore, cm);
		attributEtenduGrid.getView().setAutoExpandColumn(valAttr);
		
		attributEtenduGrid.setHeight(100);
		attributEtenduGrid.setBorders(true);
		attributEtenduGrid.getView().setAutoFill(true);

		final GridEditing<AttributEtenduMetierERValueModel> editorAttr = new GridInlineEditing<AttributEtenduMetierERValueModel>(
				attributEtenduGrid);
		attributEtenduGrid.setSelectionModel(new CellSelectionModel<AttributEtenduMetierERValueModel>());
		editorAttr.addCompleteEditHandler(new CompleteEditHandler<AttributEtenduMetierERValueModel>() {

			@Override
			public void onCompleteEdit(CompleteEditEvent<AttributEtenduMetierERValueModel> event) {
				enableButtons(true);
				isChanged = true;
			}
		});
		
		editorAttr.addEditor(valAttr, new TextField());
		con3.add(attributEtenduGrid, new VerticalLayoutData(1, 1));
		fieldSet2.add(con3);
		// Button

		panel.setButtonAlign(BoxLayoutPack.CENTER);
		panel.getBody().setBorders(false);
		cancelBtn = new HtmlButton(messages.commonAnnulerButton());
		cancelBtn.setStyleName("htmlLink");
		panel.addButton(cancelBtn);
		validBtn = new TextButton(messages.commonValiderButton(), new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				if( actif.getValue() == false ) {
					final ConfirmMessageBox box = new ConfirmMessageBox(
							messages.commonConfirmDesactiver(), messages.gestionelemcompoLeftDesactivermesage());
					box.setWidth(400);
					box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
					box.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {

						@Override
						public void onSelect(SelectEvent event) {
							box.hide();
							attributEtenduStore.commitChanges();
							insertOrUpdate();
							isChanged = false;
						}
					});
					box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
					box.getButtonById(PredefinedButton.NO.name()).addSelectHandler(new SelectHandler() {

						@Override
						public void onSelect(SelectEvent event) {
							box.hide();
//							actif.setValue(true);
						}
					});

					box.show();
				}
				else {
					attributEtenduStore.commitChanges();
					insertOrUpdate();
				}
			}
		});

		panel.addButton(validBtn);

		addHandler();
		
		enableButtons(false);
		disableFamilles();
	}
	
	private void addHandler(){
		code.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				codeActuel = code.getText();
			}
		});
		code.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if (code.getText().length() > CODE_MAX_LENGTH){
					code.reset();
					code.setText(code.getText().substring(0, CODE_MAX_LENGTH));
				}
				else {
					if(!codeActuel.equals(code.getText())){
						toggleChange(true);
					}
				}
			}
		});
		
		libelle.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				libelleActuel = libelle.getText();
			}
		});
		
		libelle.addKeyDownHandler(new KeyDownHandler() {
			
			@Override
			public void onKeyDown(KeyDownEvent arg0) {
				texttmp = libelle.getCurrentValue();
			}
		});
		
		libelle.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if (libelle.getText().length() > LIBELLE_MAX_LENGTH){
					libelle.reset();
					libelle.setText(libelle.getText().substring(0, LIBELLE_MAX_LENGTH));
				}
				else {
					if (!libelleActuel.equals(libelle.getText())){
						toggleChange(true);
					}
				}
			}
		});
		
		nomenclatureFournisseur.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				nFournisseurActuel = nomenclatureFournisseur.getText();
			}
		});
		nomenclatureFournisseur.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if (nomenclatureFournisseur.getText().length() > NOMENCLATUREFOURNISSEUR_MAX_LENGTH){
					nomenclatureFournisseur.reset();
					nomenclatureFournisseur.setText(nomenclatureFournisseur.getText().substring(0, NOMENCLATUREFOURNISSEUR_MAX_LENGTH));
				}
				else {
					if(!nFournisseurActuel.equals(nomenclatureFournisseur.getText())){
						toggleChange(true);
					}
				}
			}
		});
		
		type.addBlurHandler(new BlurHandler() {

			@Override
			public void onBlur(BlurEvent event) {
				// to fix bug code object appears on blur 
				if( type.getValue() == null ) {
					type.setText("");
				}
				else {
					type.setText(type.getValue().getLLibelle());
				}
			}
		});
		type.addValueChangeHandler(new ValueChangeHandler<TypeElement>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<TypeElement> arg0) {

				type.clearInvalid();
				typeVide = false;
			}
		});
		code.addValueChangeHandler(new ValueChangeHandler<String>() {

			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				toggleChange(true);
				code.clearInvalid();
				codeExist = false;
				codeVide = false;
			}
		});
		actif.addValueChangeHandler(new ValueChangeHandler<Boolean>() {

			@Override
			public void onValueChange(ValueChangeEvent<Boolean> arg0) {
				
				isChanged = true;
				enableButtons(true);

			}
		});
		libelle.addValueChangeHandler(new ValueChangeHandler<String>() {

			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				toggleChange(true);
				libelle.clearInvalid();
				libelleVide = false;
			}
		});
		nomenclatureFournisseur.addValueChangeHandler(new ValueChangeHandler<String>() {

			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				toggleChange(true);
				nomenclatureFournisseur.clearInvalid();
				nFournisseurExist = false;

			}
		});
		famille.addBlurHandler(new BlurHandler() {

			@Override
			public void onBlur(BlurEvent event) {
				if( famille.getValue() == null ) {
					famille.setText("");
				}
				else {
					famille.setText(famille.getValue().getLLibelle());
				}
			}
		});
		typeprestation.addBlurHandler(new BlurHandler() {

			@Override
			public void onBlur(BlurEvent event) {
				if( typeprestation.getValue() == null ) {
					typeprestation.setText("");
				}
				else {
					typeprestation.setText(typeprestation.getValue().getLLibelle());
				}
			}
		});
		sousfamille.addBlurHandler(new BlurHandler() {

			@Override
			public void onBlur(BlurEvent event) {
				if( sousfamille.getValue() != null )
					sousfamille.setText(sousfamille.getValue().getLLibelle());
				else
					sousfamille.setText("");
			}
		});
		groupe.addBlurHandler(new BlurHandler() {

			@Override
			public void onBlur(BlurEvent event) {
				if( groupe.getValue() != null )
					groupe.setText(groupe.getValue().getLLibelle());

			}
		});

		sousgroupe.addBlurHandler(new BlurHandler() {

			@Override
			public void onBlur(BlurEvent event) {
				if( sousgroupe.getValue() != null )
					sousgroupe.setText(sousgroupe.getValue().getLLibelle());
			}
		});
		
		cancelBtnHandler = new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				if (isChanged){
					final ConfirmMessageBox box = new ConfirmMessageBox(
							messages.gestionelemcompoRightAnnulerTitre(), messages.gestionelemcompoRightAnnulerMessage());
					box.setWidth(400);
					box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
					box.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {
	
						@Override
						public void onSelect(SelectEvent event) {
							box.hide();
							reset();
							if( !create ) {
								fillFieldsForUpdate(element);
							}
							else {
								bus.fireEvent(new GestionElementCompositionCloseTabEvent());
							}
							isChanged = false;
						}
					});
					box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
					box.getButtonById(PredefinedButton.NO.name()).addSelectHandler(new SelectHandler() {
	
						@Override
						public void onSelect(SelectEvent event) {
							box.hide();
						}
					});
	
					box.show();
				}
			}

		};
		cancelBtn.addClickHandler(cancelBtnHandler);
		validBtn.addBeforeSelectHandler(new BeforeSelectHandler() {

			@Override
			public void onBeforeSelect(BeforeSelectEvent event) {
				codeSize = code.getElement().getWidth(false);
				typeSize = type.getElement().getWidth(false);
				libelleSize = libelle.getElement().getWidth(false);
				nfournisseurSize = nomenclatureFournisseur.getElement().getWidth(false);
				code.clearInvalid();
				codeVide = false;
				codeExist = false;
				type.clearInvalid();
				typeVide = false;
				nomenclatureFournisseur.clearInvalid();
				nFournisseurExist = false;
				libelle.clearInvalid();
				libelleVide = false;
			}
		});

		panel.addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent event) {
				if (event.getWidth() > 0){
					type.clearInvalid();
					code.clearInvalid();
					libelle.clearInvalid();
					nomenclatureFournisseur.clearInvalid();
					int fieldwidth = event.getWidth() / 3;
					code.setWidth(fieldwidth);
					type.setWidth(fieldwidth);
					libelle.setWidth(fieldwidth);
					nomenclatureFournisseur.setWidth(fieldwidth);
					famille.setWidth(fieldwidth);
					sousfamille.setWidth(fieldwidth);
					groupe.setWidth(fieldwidth);
					sousgroupe.setWidth(fieldwidth);
					typeprestation.setWidth(fieldwidth);
					if( typeVide ) {
						type.markInvalid(messages.gestionelemcompoRightChampvide());
					}
					if( codeVide ) {
						code.markInvalid(messages.gestionelemcompoRightChampvide());
					}
					if( codeExist ) {
						code.markInvalid(messages.gestionelemcompoRightCodeUnique());
					}
					if( libelleVide ) {
						libelle.markInvalid(messages.gestionelemcompoRightChampvide());
					}
					if( nFournisseurExist ) {
						nomenclatureFournisseur.markInvalid(messages.gestionelemcompoRightNomenclatureUnique());
					}
					attributEtenduGrid.setWidth(panel.getElement().getWidth(false) - 35);
					attributEtenduGrid.setHeight(panel.getElement().getHeight(false) / 3);
				}
			}
		});
		
		addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent event) {
				panel.setHeight(event.getHeight());
				panel.setWidth(event.getWidth());
			}
		});
		
	}

	private void addHandlersForEventObservationFamille(final ComboBox<Famille> combo,
			final LabelProvider<Famille> labelProvider, final String typeFam) {
		combo.addSelectionHandler(new SelectionHandler<Famille>() {
			@Override
			public void onSelection(SelectionEvent<Famille> event) {
				toggleChange(true);
				if( Constant.TYPE_FAMILLE_FAMILLE.equals(typeFam) ) {
					sousfamille.getStore().replaceAll(
							listFamille(false, event.getSelectedItem().getIdFamille(), Constant.TYPE_FAMILLE_SOUSFAMILLE));
					sousfamille.reset();
					sousfamille.enable();
					groupe.reset();
					groupe.disable();
					sousgroupe.reset();
					sousgroupe.disable();
				}
				else {
					if( Constant.TYPE_FAMILLE_SOUSFAMILLE.equals(typeFam) ) {
						groupe.getStore().replaceAll(
								listFamille(false, event.getSelectedItem().getIdFamille(), Constant.TYPE_FAMILLE_GROUPE));
						groupe.reset();
						groupe.enable();
						sousgroupe.reset();
						sousgroupe.disable();
					}
					else {
						if( Constant.TYPE_FAMILLE_GROUPE.equals(typeFam) ) {
							sousgroupe.getStore().replaceAll(
									listFamille(
											false, event.getSelectedItem().getIdFamille(), Constant.TYPE_FAMILLE_SOUSGROUPE));
							sousgroupe.reset();
							sousgroupe.enable();
						}
					}
				}

			}
		});
		combo.addValueChangeHandler(new ValueChangeHandler<Famille>() {

			@Override
			public void onValueChange(ValueChangeEvent<Famille> arg0) {
				isChanged = true;
				enableButtons(true);

			}
		});
	}

	private void addHandlersForEventObservationType(ComboBox<TypeElement> combo,
			final LabelProvider<TypeElement> labelProvider) {

		combo.addSelectionHandler(new SelectionHandler<TypeElement>() {
			@Override
			public void onSelection(SelectionEvent<TypeElement> event) {
				if( Constant.TYPE_ARTICLE.equals(event.getSelectedItem().getLLibelle()) ) {
					con2.remove(labeltypeprestation);
					con2.add(labelfamille, new HtmlData(".f1"));
					con2.add(labelsousfamille, new HtmlData(".f2"));
					con2.add(labelgroupe, new HtmlData(".f3"));
					con2.add(labelsousgroupe, new HtmlData(".f4"));
					disableFamilles();
					famille.getStore().replaceAll(listFamille(false, null, Constant.TYPE_FAMILLE_FAMILLE));
					famille.enable();
				}
				else {
					if( Constant.TYPE_PRESTATION.equals(event.getSelectedItem().getLLibelle()) ) {
						con2.remove(labelfamille);
						con2.remove(labelsousfamille);
						con2.remove(labelgroupe);
						con2.remove(labelsousgroupe);
						con2.add(labeltypeprestation, new HtmlData(".f1"));
						disableFamilles();
						typeprestation.getStore().replaceAll(listFamille(true, null, Constant.TYPE_FAMILLE_TYPEPRESTATION));
						typeprestation.enable();
					}
				}
			}
		});
		combo.addValueChangeHandler(new ValueChangeHandler<TypeElement>() {

			@Override
			public void onValueChange(ValueChangeEvent<TypeElement> arg0) {
				isChanged = true;
				enableButtons(true);

			}
		});
	}

	private native String getTableMarkup() /*-{
		return [
				'<table width=100% cellpadding=0 cellspacing=0>',
				'<tr><td class=f1 width=50%></td><td class=f2 width=50%></td></tr>',
				'<tr><td class=f3></td><td class=f4></td></tr>',
				'<tr><td class=f5></td></tr>', '</table>'

		].join("");
	}-*/;

	private void insertOrUpdate() {
		final MessageBox messageBox = new MessageBox(messages.commonInfoHeader());
		messageBox.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
		if( element == null ) {
			element = new Element();
		}
		if( type.getValue() == null ) {
			type.markInvalid(messages.gestionelemcompoRightChampvide());
			typeVide = true;
			messageBox.setMessage(messages.gestionelemcompoRightObligatoire(messages.gestionelemcompoRightType()));
			messageBox.show();
//			type.setWidth(typeSize);
			return;
		}
		if( code.getText().equals("") ) {
			code.markInvalid(messages.gestionelemcompoRightChampvide());
			codeVide = true;
			messageBox.setMessage(messages.gestionelemcompoRightObligatoire(messages.gestionelemcompoRightCode()));
			messageBox.show();
//			code.setWidth(codeSize);
			return;
		}
		if( libelle.getText().equals("") ) {
			libelle.markInvalid(messages.gestionelemcompoRightChampvide());
			libelleVide = true;
			messageBox.setMessage(messages.gestionelemcompoRightObligatoire(messages.gestionelemcompoRightLibelle()));
			messageBox.show();
//			libelle.setWidth(libelleSize);
			return;
		}
		if(nomenclatureFournisseur.getText().length() > NOMENCLATUREFOURNISSEUR_MAX_LENGTH){
			nomenclatureFournisseur.markInvalid(messages.commonLimit(messages.gestionelemcompoRightNomclematureFournisseur(), NOMENCLATUREFOURNISSEUR_MAX_LENGTH));
			nFournisseurExist = true;
			messageBox.setMessage(messages.commonLimit(messages.gestionelemcompoRightNomclematureFournisseur(), NOMENCLATUREFOURNISSEUR_MAX_LENGTH));
			messageBox.show();
			return;
		}
		if(code.getText().length() > CODE_MAX_LENGTH){
			code.markInvalid(messages.commonLimit(messages.gestionelemcompoRightCode(), CODE_MAX_LENGTH));
			codeVide = true;
			messageBox.setMessage(messages.commonLimit(messages.gestionelemcompoRightCode(), CODE_MAX_LENGTH));
			messageBox.show();
			return;
		}
		if(libelle.getText().length() > LIBELLE_MAX_LENGTH){
			libelle.markInvalid(messages.commonLimit(messages.gestionelemcompoRightLibelle(), LIBELLE_MAX_LENGTH));
			libelleVide = true;
			messageBox.setMessage(messages.commonLimit(messages.gestionelemcompoRightLibelle(), LIBELLE_MAX_LENGTH));
			messageBox.show();
			return;
		}

		element.setLLibelleLong(libelle.getText());
		element.setInActif(actif.getValue());
		element.setLNomenclatureFournisseur(nomenclatureFournisseur.getText());
		if( Constant.TYPE_ARTICLE.equals(type.getValue().getLLibelle()) )
			element.setCTypeElement(Constant.TYPE_ELEMENT_ARTICLE);
		else
			element.setCTypeElement(Constant.TYPE_ELEMENT_PRESTATION);

		element.setCElement(code.getText());
		if( typeprestation.getValue() != null ) {
			element.setIdFamille(typeprestation.getValue().getIdFamille());
		}
		else {
			if( type.getValue().getLLibelle().equals(Constant.TYPE_PRESTATION) )
				element.setIdFamille(findPrestationVide());
			else {
				if( famille.getValue() == null ) {
					element.setIdFamille(findFamilleVide());
				}
				else {
					if( sousgroupe.getValue() != null ) {
						element.setIdFamille(sousgroupe.getValue().getIdFamille());
					}
					else {
						if( groupe.getValue() != null ) {
							element.setIdFamille(groupe.getValue().getIdFamille());
						}
						else {
							if( sousfamille.getValue() != null ) {
								element.setIdFamille(sousfamille.getValue().getIdFamille());
							}
							else {
								element.setIdFamille(famille.getValue().getIdFamille());

							}
						}
					}
				}
			}
		}

		element.setIdMetier(idMetier);

		ClientElementServiceAsync.Util.getInstance().insert(
				element, attributEtendus, idElement != null, new AsyncCallbackWithErrorResolution<Element>() {

					@Override
					public void onSuccess(Element elt) {
						bus.fireEvent(new ElementCompositionGridEvent());
						if(idElement == null){
							navigation.getBus().fireEvent(new ModifyEvent(true));
						}
						idElement = elt.getIdElement();
						element.setIdElement(idElement);
						toggleChange(false);
						label = code.getText();
						bus.fireEvent(new GestionElementCompositionRenameElementEvent(getId(), code.getText()));
						code.clearInvalid();
						codeExist = false;
						codeVide = false;
						libelle.clearInvalid();
						libelleVide = false;
						nomenclatureFournisseur.clearInvalid();
						nFournisseurExist = false;
						type.clearInvalid();
						typeVide = false;
						create = false;
					}

					@Override
					public void onFailure(Throwable caught) {
						if( caught.getMessage().equals("500 f009") ) {
							code.clearInvalid();
							code.markInvalid(messages.gestionelemcompoRightCodeUnique());
							codeExist = true;
							messageBox.setMessage(messages.gestionelemcompoRightUnique(messages.gestionelemcompoRightCode()));
							messageBox.show();
						}
						else if( caught.getMessage().equals("500 f014") ) {
							code.clearInvalid();
							nomenclatureFournisseur.markInvalid(messages.gestionelemcompoRightNomenclatureUnique());
							nFournisseurExist = true;
							messageBox.setMessage(messages.gestionelemcompoRightUnique(messages.gestionelemcompoRightNomclematureFournisseur()));
							messageBox.show();
						}

//						code.setWidth(codeSize);
//						type.setWidth(typeSize);
//						libelle.setWidth(libelleSize);
//						nomenclatureFournisseur.setWidth(nfournisseurSize);
						enableButtons(false);
					}

				});

	}

	public void enableButtons(boolean enable) {
		if(!validBtn.isEnabled() && enable){
			navigation.getBus().fireEvent(new ModifyEvent(false));
		}else if(validBtn.isEnabled() && !enable){
			navigation.getBus().fireEvent(new ModifyEvent(true));
		}
		validBtn.setEnabled(enable);
		cancelBtn.setEnable(enable);
	}

	protected List<Famille> listFamille(boolean isPrestation, Integer parent, String typeFam) {
		List<Famille> results = null;
		if( familles != null && familles.size() > 0 ) {
			if( isPrestation ) { //prestation
				results = new LinkedList<Famille>();
				for( int i = 0 ; i < familles.size() ; i++ ) {
					Famille tmp = familles.get(i);
					if( Constant.TYPE_ELEMENT_PRESTATION.equals(tmp.getCTypeElement()) && typeFam.equals(tmp.getCTypeFamille()) ){
						if(tmp
								.getLLibelle().equals(""))
							results.add(0, tmp);
						else
							results.add(tmp);
					}
				}
			}
			else { //article
				results = new LinkedList<Famille>();
				for( int i = 0 ; i < familles.size() ; i++ ) {
					Famille tmp = familles.get(i);
					if( Constant.TYPE_ELEMENT_ARTICLE.equals(tmp.getCTypeElement()) && tmp.getIdFamilleParent() == parent && typeFam.equals(tmp.getCTypeFamille()) ) {
						if(tmp.getLLibelle().equals(""))
							results.add(0, tmp);
						else
							results.add(tmp);
					}
				}
			}
		}
		return results;
	}

	private void disableFamilles() {
		typeprestation.reset();
		typeprestation.disable();
		famille.reset();
		famille.disable();
		sousfamille.reset();
		sousfamille.disable();
		groupe.reset();
		groupe.disable();
		sousgroupe.reset();
		sousgroupe.disable();
	}

	public void onLoad() {
		ClientGestionElementCompositionServiceAsync.Util.getInstance().getGestionElementCompositionReference(
				idElement, idMetier, new AsyncCallbackWithErrorResolution<GestionElementCompositionReference>() {

					@Override
					public void onSuccess(GestionElementCompositionReference result) {
						//create
						type.getStore().replaceAll(result.getTypeElements());
//						if (attributEtenduStore.getAll() != null && attributEtenduStore.getAll().size() > 0)
//							for(int i = 0; i < attributEtenduStore.getAll().size(); i++)
//								attributEtenduStore.remove(i);
						attributEtenduStore.clear();
						attributEtenduStore.addAll(result.getAttributEtendus());
						
						//						attributEtenduGrid.setHeight(100);
						familles = result.getFamilles();
						attributEtendus = result.getAttributEtendus();
						element = result.getElement();
						//update
						if( result.getElement() != null ) {
							fillFieldsForUpdate(result.getElement());
							create = false;
							codeInitial = result.getElement().getCElement();
							nFournisseurInitial = result.getElement().getLNomenclatureFournisseur();
						}

					}
				});
		forceLayout();
	}

	public void reset() {
		//create
		code.reset();
		code.setText("");
		libelle.reset();
		libelle.setText("");
		nomenclatureFournisseur.reset();
		nomenclatureFournisseur.setText("");
		type.reset();
		actif.setValue(true);
		famille.reset();
		sousfamille.reset();
		groupe.reset();
		sousgroupe.reset();
		typeprestation.reset();
		attributEtenduStore.replaceAll(attributEtendus);
		con2.remove(labeltypeprestation);
		con2.remove(labelfamille);
		con2.remove(labelsousfamille);
		con2.remove(labelgroupe);
		con2.remove(labelsousgroupe);
		disableFamilles();
		enableButtons(false);
	}

	public void fillFieldsForUpdate(Element elt) {
		//fill type field
		List<TypeElement> typestore = type.getStore().getAll();
		TypeElement typetmp = null;
		for( int i = 0 ; i < typestore.size() ; i++ ) {
			if( elt.getCTypeElement().equals(typestore.get(i).getCTypeElement()) ) {
				typetmp = typestore.get(i);
			}
		}
		type.setValue(typetmp);

		//fill code field
		code.setText(elt.getCElement());

		//fill libelle field
		libelle.setText(elt.getLLibelleLong());

		//fill actif checkbox
		actif.setValue(elt.getInActif());

		//fill nomenclature fournisseur field
		nomenclatureFournisseur.setText(elt.getLNomenclatureFournisseur());

		//fill famille fields
		if( Constant.TYPE_ELEMENT_PRESTATION.equals(elt.getCTypeElement()) ) { //Prestation
			con2.add(labeltypeprestation, new HtmlData(".f1"));
			typeprestation.enable();
			Famille typeprestationtmp = findFamille(elt.getIdFamille());
			typeprestation.setValue(typeprestationtmp);
			typeprestation.getStore().replaceAll(listFamille(true, null, Constant.TYPE_FAMILLE_TYPEPRESTATION));
		}
		else { //Article
			con2.add(labelfamille, new HtmlData(".f1"));
			con2.add(labelsousfamille, new HtmlData(".f2"));
			con2.add(labelgroupe, new HtmlData(".f3"));
			con2.add(labelsousgroupe, new HtmlData(".f4"));
			Famille f = findFamille(elt.getIdFamille());
			if (f != null){
				if( f.getCTypeFamille().equals(Constant.TYPE_FAMILLE_FAMILLE) ) {
					famille.enable();
					sousfamille.enable();
					famille.setValue(f);
					famille.getStore().replaceAll(listFamille(false, null, Constant.TYPE_FAMILLE_FAMILLE));
					sousfamille.getStore().replaceAll(
							listFamille(false, f.getIdFamille(), Constant.TYPE_FAMILLE_SOUSFAMILLE));
				}
				else {
					if( f.getCTypeFamille().equals(Constant.TYPE_FAMILLE_SOUSFAMILLE) ) {
						famille.enable();
						sousfamille.enable();
						groupe.enable();
						sousfamille.setValue(f);
						famille.setValue(findFamille(f.getIdFamilleParent()));
						famille.getStore().replaceAll(listFamille(false, null, Constant.TYPE_FAMILLE_FAMILLE));
						sousfamille.getStore().replaceAll(
								listFamille(false, f.getIdFamilleParent(), Constant.TYPE_FAMILLE_SOUSFAMILLE));
						groupe.getStore().replaceAll(
								listFamille(false, f.getIdFamille(), Constant.TYPE_FAMILLE_GROUPE));
					}
					else {
						if( f.getCTypeFamille().equals(Constant.TYPE_FAMILLE_GROUPE) ) {
							famille.enable();
							sousfamille.enable();
							groupe.enable();
							sousgroupe.enable();
							groupe.setValue(f);
							Famille sousfamilleilletmp = findFamille(f.getIdFamilleParent());
							sousfamille.setValue(sousfamilleilletmp);
							famille.setValue(findFamille(sousfamilleilletmp.getIdFamilleParent()));
							famille.getStore().replaceAll(listFamille(false, null, Constant.TYPE_FAMILLE_FAMILLE));
							sousfamille.getStore().replaceAll(
									listFamille(
											false, sousfamilleilletmp.getIdFamilleParent(), Constant.TYPE_FAMILLE_SOUSFAMILLE));
							groupe.getStore().replaceAll(
									listFamille(false, f.getIdFamilleParent(), Constant.TYPE_FAMILLE_GROUPE));
							sousgroupe.getStore().replaceAll(
									listFamille(false, f.getIdFamille(), Constant.TYPE_FAMILLE_SOUSGROUPE));
						}
						else {
							famille.enable();
							sousfamille.enable();
							groupe.enable();
							sousgroupe.enable();
							sousgroupe.setValue(f);
							Famille groupetmp = findFamille(f.getIdFamilleParent());
							groupe.setValue(groupetmp);
							Famille sousfamilletmp = findFamille(groupetmp.getIdFamilleParent());
							sousfamille.setValue(sousfamilletmp);
							famille.setValue(findFamille(sousfamilletmp.getIdFamilleParent()));
							famille.getStore().replaceAll(listFamille(false, null, Constant.TYPE_FAMILLE_FAMILLE));
							sousfamille.getStore().replaceAll(
									listFamille(false, sousfamilletmp.getIdFamilleParent(), Constant.TYPE_FAMILLE_SOUSFAMILLE));
							groupe.getStore().replaceAll(
									listFamille(false, groupetmp.getIdFamilleParent(), Constant.TYPE_FAMILLE_GROUPE));
							sousgroupe.getStore().replaceAll(
									listFamille(false, f.getIdFamilleParent(), Constant.TYPE_FAMILLE_SOUSGROUPE));
						}
					}
				}
			}

		}
	}

	public Integer findFamilleVide() {
		for( Famille fam : familles ) {
			if( fam.getLLibelle().equals("") && fam.getCTypeFamille().equals(Constant.TYPE_FAMILLE_FAMILLE) )
				return fam.getIdFamille();
		}
		return null;
	}

	public Integer findPrestationVide() {
		for( Famille fam : familles ) {
			if( fam.getLLibelle().equals("") && fam.getCTypeFamille().equals(Constant.TYPE_FAMILLE_TYPEPRESTATION) )
				return fam.getIdFamille();
		}
		return null;
	}

	public Famille findFamille(Integer idFamille) {
		Famille f = null;
		if( familles != null )
			for( int i = 0 ; i < familles.size() ; i++ ) {
				if( familles.get(i).getIdFamille() == idFamille )
					return familles.get(i);
			}
		return f;
	}

	public Integer getIdElement() {
		return idElement;
	}

	public void setIdElement(Integer idElement) {
		this.idElement = idElement;
	}

	public boolean isChanged() {
		return isChanged;
	}

	public void setChanged(boolean isChanged) {
		this.isChanged = isChanged;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public ComboBox<TypeElement> getType() {
		return type;
	}

	public void setType(ComboBox<TypeElement> type) {
		this.type = type;
	}

	public CheckBox getActif() {
		return actif;
	}

	public void setActif(CheckBox actif) {
		this.actif = actif;
	}

	public TextField getCode() {
		return code;
	}

	public void setCode(TextField code) {
		this.code = code;
	}

	public TextField getLibelle() {
		return libelle;
	}

	public void setLibelle(TextField libelle) {
		this.libelle = libelle;
	}

	public TextField getNomenclatureFournisseur() {
		return nomenclatureFournisseur;
	}

	public void setNomenclatureFournisseur(TextField nomenclatureFournisseur) {
		this.nomenclatureFournisseur = nomenclatureFournisseur;
	}

	public ComboBox<Famille> getFamille() {
		return famille;
	}

	public void setFamille(ComboBox<Famille> famille) {
		this.famille = famille;
	}

	public ComboBox<Famille> getSousfamille() {
		return sousfamille;
	}

	public void setSousfamille(ComboBox<Famille> sousfamille) {
		this.sousfamille = sousfamille;
	}

	public ComboBox<Famille> getGroupe() {
		return groupe;
	}

	public void setGroupe(ComboBox<Famille> groupe) {
		this.groupe = groupe;
	}

	public ComboBox<Famille> getSousgroupe() {
		return sousgroupe;
	}

	public void setSousgroupe(ComboBox<Famille> sousgroupe) {
		this.sousgroupe = sousgroupe;
	}

	public ComboBox<Famille> getTypeprestation() {
		return typeprestation;
	}

	public void setTypeprestation(ComboBox<Famille> typeprestation) {
		this.typeprestation = typeprestation;
	}

	public Grid<AttributEtenduMetierERValueModel> getAttributEtenduGrid() {
		return attributEtenduGrid;
	}

	public void setAttributEtenduGrid(Grid<AttributEtenduMetierERValueModel> attributEtenduGrid) {
		this.attributEtenduGrid = attributEtenduGrid;
	}

	public HtmlButton getCancelBtn() {
		return cancelBtn;
	}

	public void setCancelBtn(HtmlButton cancelBtn) {
		this.cancelBtn = cancelBtn;
	}

	public TextButton getValidBtn() {
		return validBtn;
	}

	public void setValidBtn(TextButton validBtn) {
		this.validBtn = validBtn;
	}

	protected void toggleChange(boolean changed) {
		enableButtons(changed);
		if(isChanged != changed){
			bus.fireEvent(new ModifyEvent(!changed));
		}
		isChanged = changed;
	}
}
