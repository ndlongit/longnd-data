package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GestionElementCompositionEvent  extends GwtEvent<GestionElementCompositionHandler>{

	private static Type<GestionElementCompositionHandler> TYPE = new Type<GestionElementCompositionHandler>();
	public static Type<GestionElementCompositionHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionElementCompositionHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionElementCompositionHandler handler) {
		handler.onLoad(this);
	}
	
	private Integer idElement;
	
	public GestionElementCompositionEvent(Integer idElement) {
		this.idElement = idElement;
	}

	public Integer getIdElement() {
		return idElement;
	}

	public void setIdElement(Integer idElement) {
		this.idElement = idElement;
	}
}
