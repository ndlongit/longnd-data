package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlReferenceSousModele;

public interface ReferenceSousModeleService {

	public static final String SERVICE_NAME = "referenceSousModeleService";

	int deleteById(Integer idSousModele);

	int delete(MdlReferenceSousModele record);

	int insert(MdlReferenceSousModele record);

	int insertSelective(MdlReferenceSousModele record);

	MdlReferenceSousModele findById(Integer idSousModele);

	List<MdlReferenceSousModele> findAll();

	int updateSelective(MdlReferenceSousModele record);

	int update(MdlReferenceSousModele record);

	List<MdlReferenceSousModele> findByBaseCriteria(MdlReferenceSousModele criteria);
}
