package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.ImportElementError;

public interface ImportElementErrorService {

	public static final String SERVIECE_NAME = "importElementErrorService";

	public ImportElementError findById(Integer id);

	public Integer insert(ImportElementError record);

	public Integer update(ImportElementError record);

	public Integer delete(ImportElementError record);

	public Integer deleteById(Integer id);

	public List<ImportElementError> findAll();

	public void deleteByImportElementIds(List<Integer> importElementIds);
	
	public List<ImportElementError> findByImportedId(Integer importedId);
}
