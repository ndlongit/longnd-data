package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class ModelisateurExecuterModeleEvent  extends GwtEvent<ModelisateurExecuterModeleHandler>{
	
	private static Type<ModelisateurExecuterModeleHandler> TYPE = new Type<ModelisateurExecuterModeleHandler>();
	
	private Integer idModeleVersion;
	
	public static Type<ModelisateurExecuterModeleHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModelisateurExecuterModeleHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModelisateurExecuterModeleHandler handler) {
		handler.onLoad(this);
	}
	
	public ModelisateurExecuterModeleEvent(Integer idModeleVersion) {
		this.idModeleVersion = idModeleVersion;
	}

	public void setIdModeleVersion(Integer idModeleVersion) {
		this.idModeleVersion = idModeleVersion;
	}

	public Integer getIdModeleVersion() {
		return idModeleVersion;
	}

}
