package com.structis.client.widget;

import com.google.gwt.dom.client.Style.Cursor;
import com.google.gwt.user.client.ui.Image;
import com.structis.client.image.Images;

public class TreeMenuIcon extends Image{
	private int status = 0;
	public TreeMenuIcon(){
		setResource(Images.RESOURCES.treeMenuIconClose());
		getElement().getStyle().setCursor(Cursor.POINTER);
	}
	
	public void toogleDisplayMenu(){
		if(status == 0){
			status = 1;
			setResource(Images.RESOURCES.treeMenuIconOpen());
		}else{
			setResource(Images.RESOURCES.treeMenuIconClose());
			status = 0;
		}
	}
	public void resetMenu(){
		status = 0;
		setResource(Images.RESOURCES.treeMenuIconClose());
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
}
