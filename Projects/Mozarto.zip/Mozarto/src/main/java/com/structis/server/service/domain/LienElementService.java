package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlLienElement;

public interface LienElementService {
	MdlLienElement findLienElementByElement(int idModeleVersion, int idElment);

	List<MdlLienElement> findWithElementByIdLienCommuns(Integer idModeleVersion, List<Integer> idLienCommuns);

	int insert(MdlLienElement record);
}
