package com.structis.client.panel.composition;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.structis.client.message.Messages;
import com.structis.client.widget.CustomizeBorderlayoutContainer;

public class CompositionAccueilPanel extends SimpleContainer {

	private SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private CompositionAccueilLeftPanel accueilLeftPanel;
	
	private CompositionAccueilCompoGrid accueilCompoGrid;
	
	
	public CompositionAccueilPanel(SimpleEventBus bus) {
		this.bus = bus;
		setBorders(true);
		buildPanel();
//		addHandler();s
	}

	private void buildPanel() {
		final CustomizeBorderlayoutContainer mainContainer = new CustomizeBorderlayoutContainer();
		mainContainer.setBorders(false);

		accueilLeftPanel = new CompositionAccueilLeftPanel(bus);

		accueilCompoGrid = new CompositionAccueilCompoGrid(bus);

		final BorderLayoutData westData = new BorderLayoutData(0.40);
		westData.setCollapsible(true);
		westData.setSplit(true);
		westData.setCollapseMini(true);
		westData.setMargins(new Margins(0, 5, 0, 0));
//		westData.setMinSize(ScreenSize.MINLEFT);

		final BorderLayoutData centerData = new BorderLayoutData(0.55);
//		centerData.setMinSize(ScreenSize.MINCENTER);

		//con.setNorthWidget(north, northData);
		ContentPanel leftPanel = new ContentPanel();
		leftPanel.setHeaderVisible(false);
		leftPanel.setBorders(false);
		leftPanel.setBodyBorder(false);
		leftPanel.add(accueilLeftPanel);
		
		mainContainer.setLeftTitle(messages.commonPanneauAction());
		mainContainer.setWestWidget(leftPanel, westData);
		mainContainer.setCenterWidget(accueilCompoGrid, centerData);
		mainContainer.addResizeHandler(new ResizeHandler() {
			@Override
			public void onResize(ResizeEvent event) {
				///Window.alert(event.getWidth()+"");
				//eastData.setSize(200);
				int totalWith = event.getWidth();
				int unitWith = totalWith / 8;
				westData.setSize(unitWith * 2);
			}
		});
		add(mainContainer);
	}

	/*private void addHandler() {
		accueilCompoGrid.getGrid().getLoader().load();
	}

	public CompositionAccueilCompoGrid getAccueilModeleGrid() {
		return accueilCompoGrid;
	}
*/
	public void setAccueilModeleGrid(CompositionAccueilCompoGrid accueilModeleGrid) {
		this.accueilCompoGrid = accueilModeleGrid;
	}

}
