package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ModelisateurExecuterModeleHandler extends EventHandler {
	void onLoad(ModelisateurExecuterModeleEvent modifierModeleEvent);
}
