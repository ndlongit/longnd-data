package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface CompositionLoadComposModeleHandler extends EventHandler {
	void onLoad(CompositionLoadComposModeleEvent event);
}
