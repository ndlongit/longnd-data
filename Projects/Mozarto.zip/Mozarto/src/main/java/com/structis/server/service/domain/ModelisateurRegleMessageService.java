package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;
import com.structis.shared.model.reference.TreeNodeModel;
import com.structis.shared.model.reference.TreeNodeRegleModel;

public interface ModelisateurRegleMessageService {
	/**
	 * 
	 * @param source
	 * @param target
	 * @param priorite
	 * @param quantite
	 * @return
	 */
	ModelisateurRegleMessageListModel insertRegle(Integer idUser,TreeNodeModel source, TreeNodeModel target, int priorite, int quantite);
	
	/**
	 * 
	 * @param idRegle
	 * @param target
	 * @param priorite
	 * @param quantite
	 * @return
	 */
	ModelisateurRegleMessageListModel updateRegle(Integer idUser,int idRegle, TreeNodeModel target, int priorite, int quantite);

	/**
	 * 
	 * @param sourceNode
	 * @return
	 */
	List<ModelisateurRegleMessageListModel> findRegleMessageList(TreeNodeModel sourceNode,boolean findRegle, boolean findMessage);
	
	List<ModelisateurRegleMessageListModel> findReglePointToElement(TreeNodeModel elementNode);
	
	List<TreeNodeRegleModel> findElementRegleList(TreeNodeModel sourceNode);
	
	boolean checkSatisfyRules(TreeNodeModel parentNode, Integer idElement);

	boolean checkSatisfyRules(TreeNodeModel source, Integer idTargetElementOrReference, Integer idVersion, String typeReferenceOrElement);
	
	/**
	 * delete an node in the modelisateur tree
	 * @param sourceNode
	 * @param regles
	 * @param message
	 * @param recursive
	 */
	void deleteModelisateurNode(TreeNodeModel sourceNode,boolean isDeleteRegle, boolean isDeleteMessage, boolean isDeleteAll);

	ModelisateurRegleMessageListModel insertMessage(Integer idUser, TreeNodeModel source, int priorite, String libelle);
	
	String validateToDelete(TreeNodeModel sourceNode, boolean isDeleteRegle, boolean isDeleteMessage, boolean isDeleteAll);

	ModelisateurRegleMessageListModel updateMessage(Integer idUser, Integer idMessage, String libelle, int priorite);
	
	public TreeNodeModel copyCaracteristique (MdlCaracteristique caract, Integer idParent, boolean isCopyRegle,
			boolean isCopyMessage, boolean isCopyChildren, Integer idUtilisateur, Integer idMetier);
	
	public TreeNodeModel copyReference(MdlReference ref, Integer idCaracteristique, boolean isCopyRegle,
			boolean isCopyMessage, boolean isCopyChildren, Integer idUtilisateur, Integer idMetier, boolean check);
}
