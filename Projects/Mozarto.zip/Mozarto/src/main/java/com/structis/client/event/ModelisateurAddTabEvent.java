package com.structis.client.event;

import java.util.Stack;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurAddTabEvent extends GwtEvent<ModelisateurAddTabHandler> {

	private static Type<ModelisateurAddTabHandler> TYPE = new Type<ModelisateurAddTabHandler>();

	public static Type<ModelisateurAddTabHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModelisateurAddTabHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModelisateurAddTabHandler handler) {
		handler.onLoad(this);
	}

	private TreeNodeModel treeNode;	
	private TreeNodeModel parentNode;

	Stack<TreeNodeModel> itemsPath;
	private Integer idParent; 
	private String labelParent;
	private boolean createModele = false;
	private boolean create = false;
	private boolean openRegleView = false;

	public ModelisateurAddTabEvent(TreeNodeModel treeNode, Stack<TreeNodeModel> itemsPath, boolean createModele, boolean create, boolean openRegleView) {
		this.treeNode = treeNode;
		this.itemsPath = itemsPath;
		this.createModele = createModele;
		this.create = create;
		this.setOpenRegleView(openRegleView);
	}

	public TreeNodeModel getTreeNode() {
		return treeNode;
	}

	public void setTreeNode(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}

	public Stack<TreeNodeModel> getItemsPath() {
		return itemsPath;
	}

	public void setItemsPath(Stack<TreeNodeModel> itemsPath) {
		this.itemsPath = itemsPath;
	}

	public Integer getIdParent() {
		return idParent;
	}

	public void setIdParent(Integer idParent) {
		this.idParent = idParent;
	}

	public String getLabelParent() {
		return labelParent;
	}

	public void setLabelParent(String labelParent) {
		this.labelParent = labelParent;
	}

	public TreeNodeModel getParentNode() {
		return parentNode;
	}

	public void setParentNode(TreeNodeModel parentNode) {
		this.parentNode = parentNode;
	}

	public boolean isCreateModele() {
		return createModele;
	}

	public void setCreateModele(boolean createModele) {
		this.createModele = createModele;
	}

	public void setCreate(boolean create) {
		this.create = create;
	}

	public boolean isCreate() {
		return create;
	}

	public void setOpenRegleView(boolean openRegleView) {
		this.openRegleView = openRegleView;
	}

	public boolean isOpenRegleView() {
		return openRegleView;
	}
	

	
}
