package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.CmpReferenceElement;

public interface CompositionReferenceElementService {
	void insertList(List<CmpReferenceElement> cmpReferenceElements);
	
	void deleteByIdComposition(Integer idComposition);
}
