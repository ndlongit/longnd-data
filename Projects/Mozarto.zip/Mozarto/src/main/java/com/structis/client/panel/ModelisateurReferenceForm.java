package com.structis.client.panel;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.StatusCodeException;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.cell.core.client.form.SpinnerFieldCell;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.loader.LoadEvent;
import com.sencha.gxt.data.shared.loader.LoadHandler;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer.HorizontalLayoutData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.FocusEvent;
import com.sencha.gxt.widget.core.client.event.FocusEvent.FocusHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FormPanel.LabelAlign;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor.ShortPropertyEditor;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.form.Validator;
import com.sencha.gxt.widget.core.client.form.validator.MaxLengthValidator;
import com.sencha.gxt.widget.core.client.form.validator.MaxLengthValidator.MaxLengthMessages;
import com.sencha.gxt.widget.core.client.form.validator.MinLengthValidator;
import com.sencha.gxt.widget.core.client.form.validator.MinLengthValidator.MinLengthMessages;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.grid.editing.GridEditing;
import com.sencha.gxt.widget.core.client.grid.editing.GridInlineEditing;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.MaskEvent;
import com.structis.client.event.RenameTreeNodeEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.panel.validator.DupplicateValidator;
import com.structis.client.properties.AttributEtenduMetierERValueModelProperties;
import com.structis.client.properties.CarateristiqueReferenceProperties;
import com.structis.client.properties.ReferenceElementProperties;
import com.structis.client.service.ClientCaracteristiqueServiceAsync;
import com.structis.client.service.ClientReferenceServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.client.widget.CustomizeGridDropTarget;
import com.structis.client.widget.ImagesCell;
import com.structis.client.widget.PagingToolBarWithoutDisplayText;
import com.structis.server.core.ConstantError;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ReferenceFormModel;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurReferenceForm extends AbstractModelisateurEditForm {

	private TextField libele;

	private TextArea commentaires;

	private MdlReference referenceModel;

	private Grid<AttributEtenduMetierERValueModel> attrReferenceGrid;

	private ListStore<AttributEtenduMetierERValueModel> attrReferenceStore;

	private Grid<MdlCarateristiqueReference> gridEde;

	private ListStore<MdlCarateristiqueReference> storeEde;

	private Grid<MdlReferenceElement> gridEds;

	private ListStore<MdlReferenceElement> storeEds;

	private CustomizeGridDropTarget<MdlCarateristiqueReference> relationDropTarget = null;

	private VerticalLayoutContainer labelCommentContainer;
	
	private NavigationModelisateurForm navigationModelisateurForm;
	
	private ModelisateurRegleMessageList modelisateurRegleMessageList;
	
	private String libelleActuel = "";
	
	private String commentaireActuel = "";
	
	private VerticalLayoutContainer gridEdeContainer;
	
	private VerticalLayoutContainer gridEdsContainer;
	//private NavigationService navigation = NavigationFactory.getNavigation();
	
	@SuppressWarnings("unchecked")
	Validator<String> dupplicateValidation = new DupplicateValidator();

	public ModelisateurReferenceForm(SimpleEventBus bus, TreeNodeModel item, TreeNodeModel nodeParent) {
		super(bus, item, nodeParent);		
	}
	public ModelisateurReferenceForm(SimpleEventBus bus, TreeNodeModel item) {
		super(bus, item);
	}

	@Override
	protected VerticalLayoutContainer buildPanel() {
		Label titleLable = new Label(messages.modelisateurReference());
		titleLable.addStyleName("editFormTitle");

		VerticalLayoutContainer mainContainer = new VerticalLayoutContainer();
		labelCommentContainer = new VerticalLayoutContainer();
		labelCommentContainer.add(titleLable);
		labelCommentContainer.add(new HTML("<hr/>"));
//		mainContainer.add(titleLable);
//		mainContainer.add(new HTML("<hr/>"));

		libele = new TextField();
		libele.setValidateOnBlur(true);
		libele.setAutoValidate(true);
		
		MaxLengthValidator validatorMax = new MaxLengthValidator(500);
		validatorMax.setMessages(new MaxLengthMessages() {

			@Override
			public String maxLengthText(int length) {
				return messages.commonLongeurMaxError(500);
			}
		});

		MinLengthValidator validatorMin = new MinLengthValidator(1);
		validatorMin.setMessages(new MinLengthMessages() {

			@Override
			public String minLengthText(int length) {
				return messages.commonObligatoire();
			}
		});
		libele.addValidator(validatorMax);
		libele.addValidator(validatorMin);

		commentaires = new TextArea();
		commentaires.setHeight(50);

		FieldLabel libeleFieldLabel = new FieldLabel(libele, messages.modelisateurFormLibelle());
		libeleFieldLabel.setLabelSeparator("");
		libeleFieldLabel.setLabelWidth(40);
		libeleFieldLabel.setLabelAlign(LabelAlign.LEFT);
		FieldLabel commentairesFieldLabel = new FieldLabel(commentaires, messages.modelisateurFormCommentaires());
		commentairesFieldLabel.setLabelSeparator("");
		commentairesFieldLabel.setLabelAlign(LabelAlign.TOP);

		//attribute grid
		buildAttrReferenceGrid();
		

		//relations grid
		buildGridEde();
		buildGridEds();
		
		labelCommentContainer.add(libeleFieldLabel, new VerticalLayoutData(1, -1));
		labelCommentContainer.add(commentairesFieldLabel, new VerticalLayoutData(1, -1));
		
		HorizontalLayoutContainer relationContainer = new HorizontalLayoutContainer();
		relationContainer.add(gridEdeContainer, new HorizontalLayoutData(.4, 1, new Margins(0, 5, 0, 0)));
		
		/*final CustomizePagingToolbar gridEdsToolBar = new CustomizePagingToolbar();
		gridEdsToolBar.getElement().getStyle().setProperty("borderBottom", "none");
		gridEds.setBorders(false);
		gridEdsContainer = AppUtil.createGridWidthPagingContainer(gridEds, gridEdsToolBar);*/
		relationContainer.add(gridEdsContainer, new HorizontalLayoutData(.6, 1, new Margins(0, 0, 0, 0)));
		
		labelCommentContainer.add(new Label(messages.modelisateurFormAttributsReference()));
		mainContainer.add(labelCommentContainer, new VerticalLayoutData(.98, -1));
		
//		mainContainer.add(libeleFieldLabel, new VerticalLayoutData(.98, -1));
//		mainContainer.add(commentairesFieldLabel, new VerticalLayoutData(.98, -1));
//		mainContainer.add(new Label(messages.modelisateurFormAttributsReference()));
		mainContainer.add(attrReferenceGrid, new VerticalLayoutData(.98, 80));		
		mainContainer.add(new Label(messages.modelisateurFormRelations()));
		mainContainer.add(relationContainer, new VerticalLayoutData(.98, .98));

		return mainContainer;
	}

	@Override
	protected void addHandler() {
		addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent paramResizeEvent) {
				libele.clearInvalid();
			}
		});
/*		libele.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent paramChangeEvent) {
				libele.removeValidator(dupplicateValidation);
				toggleSaveCancel(true);
			}
		});*/
		libele.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				libelleActuel = libele.getText();
			}
		});
		libele.addKeyUpHandler(new KeyUpHandler() {			
			@Override
			public void onKeyUp(KeyUpEvent paramKeyUpEvent) {
				if(!libelleActuel.equals(libele.getText())){
					toggleSaveCancel(true);
				}
			}
		});
		libele.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				toggleSaveCancel(true);
			}
		});
		commentaires.addKeyUpHandler(new KeyUpHandler() {			
			@Override
			public void onKeyUp(KeyUpEvent paramKeyUpEvent) {
				if(!commentaireActuel.equals(commentaires.getText())){
					toggleSaveCancel(true);
				}
			}
		});
		commentaires.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				toggleSaveCancel(true);
			}
		});
		commentaires.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				commentaireActuel = commentaires.getText();
			}
		});
/*		commentaires.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
				toggleSaveCancel(true);
			}
		});*/
		validerButton.addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				if( libele.isValid() ) {
					if (referenceModel.getIdReference() == null) {
						referenceModel.setIdModeleVersion(parentNode.getIdModeleVersion());										
					}
					referenceModel.setLLibelleLong(libele.getValue());
					referenceModel.setLCommentaire(commentaires.getValue());

					attrReferenceStore.commitChanges();
					storeEde.commitChanges();
					storeEds.commitChanges();

					final ReferenceFormModel referenceForm = new ReferenceFormModel();
					referenceForm.setReference(referenceModel);
					List<AttributEtenduMetierERValueModel> attrReferences = new ArrayList<AttributEtenduMetierERValueModel>();					
					for( AttributEtenduMetierERValueModel attr : attrReferenceStore.getAll() ) {
						attrReferences.add(attr);
					}
					referenceForm.setListAttributEtendu(attrReferences);
					List<MdlCarateristiqueReference> caracteristiqueReferencez = new ArrayList<MdlCarateristiqueReference>();
					caracteristiqueReferencez.addAll(storeEde.getAll());
					referenceForm.setListElementEntree(caracteristiqueReferencez);
					List<MdlReferenceElement> referenceElements = new ArrayList<MdlReferenceElement>();
					referenceElements.addAll(storeEds.getAll());
					referenceForm.setListElementSortie(referenceElements);
					
					Integer parentId = null;
					if (parentNode != null) {
						parentId = parentNode.getId() != null ? parentNode.getId() : parentNode.getTempId();
					}		
					final Integer iParentId = parentId; 
					if (referenceModel.getInSousReference() != null && referenceModel.getInSousReference().equals(true)) {
						AppUtil.showConfirmMessageBox(
								messages.modelisateurReferenceSousReferenceChange(referenceModel.getLLibelleLong()), new SelectHandler() {
									@Override
									public void onSelect(SelectEvent event) {
										updateReference(navigation.getContext().getUtilisateur().getIdUtilisateur(), iParentId, 
												referenceForm);
									}
								}, null);
					} else {
						updateReference(navigation.getContext().getUtilisateur().getIdUtilisateur(), iParentId, 
								referenceForm);						
					}
				}
			}
		});
		annulerButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				showConfirmCloseMessage(messages.modelisateurReferenceLabel());				
			}
		});
		
//		bus.addHandler(NewRowHolderEvent.getType(), new NewRowHolderHandler() {
//			@Override
//			public void onLoad(NewRowHolderEvent e) {
//				MdlCarateristiqueReference newRecord = getNewCaracteristiqueReferenceHolder();
//				storeEde.add(storeEde.size(), newRecord);				
//				gridEde.getSelectionModel().select(newRecord, true);
//			}
//		});
		
	}

	protected void updateReference(Integer utilisateurId, Integer parentId,
			ReferenceFormModel referenceForm) {
		ClientReferenceServiceAsync.Util.getInstance().insertOrUpdate( utilisateurId, parentId, 
				referenceForm, new AsyncCallbackWithErrorResolution<Integer>() {

			@Override
			public void onSuccess(Integer paramT) {		
				treeNode.setId(paramT);
				treeNode.setLibelle(referenceModel.getLLibelleLong());
				if(referenceModel.getIdReference() == null){
					getNavigationModelisateurForm().toggleDetailButton(false);
					getModelisateurRegleMessageList().loadListRelgeAndMessage();
				}
				referenceModel.setIdReference(paramT);
				RenameTreeNodeEvent renameTreeNodeEvent = new RenameTreeNodeEvent(getTabId(), referenceModel.getLLibelleLong());
				renameTreeNodeEvent.setNewId(referenceModel.getIdReference());
				renameTreeNodeEvent.setNewVersionId(referenceModel.getIdModeleVersion());
				bus.fireEvent(renameTreeNodeEvent);									
				toggleSaveCancel(false);
				libele.removeValidator(dupplicateValidation);HorizontalPanel navigationPanel = getNavigationModelisateurForm().getNavigationPanel();
				if (navigationPanel.getWidgetCount() > 0)
					navigationPanel.remove(navigationPanel.getWidgetCount() - 1);
				final HTML label = new HTML(referenceModel.getLLibelleLong());
				label.setStylePrimaryName("htmlLink");
				navigationPanel.add(label);
			}
			@Override
			public void onFailure(Throwable caught){
				if (caught instanceof StatusCodeException) {
					StatusCodeException fe = (StatusCodeException) caught;
					if (fe.getEncodedResponse().equals(ConstantError.ERR_DUPLICATED)) {										
						MessageBox box = new MessageBox(messages.commonInfoHeader(),messages.commonDuplicateLibelle(libele.getText()));
						box.show();
						libele.addValidator(dupplicateValidation);
						libele.validate();
					}
				} else {
					AppUtil.showMessageBox(caught.getMessage());
				}
			}
		});
		
	}
	@Override
	protected void resetForm() {
		loadForm();
		toggleSaveCancel(false);
	}

	@Override
	protected void loadForm() {		
		
		if (treeNode.getId() != null ||  treeNode.getTempId() != null  ) {
			Integer id = treeNode.getId() != null ? treeNode.getId() : treeNode.getTempId();
			ClientReferenceServiceAsync.Util.getInstance().findReferenceFormModelById(
					treeNode.getIdModeleVersion(), id, navigation.getContext().getMetier().getIdMetier(),
					new AsyncCallbackWithErrorResolution<ReferenceFormModel>() {
						@Override
						public void onSuccess(ReferenceFormModel result) {
							if( result != null ) {
								referenceModel = result.getReference();
								libele.setValue(referenceModel.getLLibelleLong());
								commentaires.setValue(referenceModel.getLCommentaire());
								attrReferenceStore.clear();
								if( result.getListAttributEtendu() != null ) {
									attrReferenceStore.addAll(result.getListAttributEtendu());
								}
								/*storeEde.clear();
								if( result.getListElementEntree() != null ) {
									storeEde.addAll(result.getListElementEntree());
								}
								storeEde.add(getNewCaracteristiqueReferenceHolder());*/
								gridEde.getLoader().load();
								
								/*storeEds.clear();
								if( result.getListElementSortie() != null ) {
									storeEds.addAll(result.getListElementSortie());
								}*/
								gridEds.getLoader().load();
							}
						}
					});
		} else {
			referenceModel = new MdlReference();				
			libele.clear();
			libele.setValue(treeNode.getLibelle());
			if(libele.getText().trim().equals(messages.commontreenewnode())){
				libele.reset();
				libele.setEmptyText(messages.commontreenewnode());
			}
			commentaires.clear();
			storeEde.clear();
			storeEde.add(getNewRelationRecord());			
			storeEde.add(getNewCaracteristiqueReferenceHolder());
			attrReferenceStore.clear();
			ClientReferenceServiceAsync.Util.getInstance().getListAttributEtenduByModelVersion(parentNode.getIdModeleVersion(),
					new AsyncCallbackWithErrorResolution<List<AttributEtenduMetierERValueModel>>() {
						@Override
						public void onSuccess(List<AttributEtenduMetierERValueModel> result) {							
							attrReferenceStore.addAll(result);							
						}
					});
		}
		
	}

	private MdlCarateristiqueReference getNewRelationRecord() {
		MdlCarateristiqueReference ref = new MdlCarateristiqueReference();		
		ref.setIdReference(-1);
		ref.setIdModeleVersion(parentNode.getIdModeleVersion());
		ref.setIdCaracteristique(parentNode.getId());
		ref.setCaracteristiqueLibelle(parentNode.getLibelle());
		return ref;
	}
	private MdlCarateristiqueReference getNewCaracteristiqueReferenceHolder() {		
		MdlCarateristiqueReference ref = new MdlCarateristiqueReference();
		ref.setStatus(ImagesCell.EMPTY_NEW);
		//ref.setIdReference(-1);
		ref.setIdModeleVersion(referenceModel.getIdModeleVersion());
		//ref.setIdCaracteristique(-1);		
		return ref;
	}
	
	private void buildAttrReferenceGrid() {
		AttributEtenduMetierERValueModelProperties attprops = GWT.create(AttributEtenduMetierERValueModelProperties.class);
		ColumnConfig<AttributEtenduMetierERValueModel, String> libAttr = new ColumnConfig<AttributEtenduMetierERValueModel, String>(
				attprops.attributEtenduLibelle());
		libAttr.setHeader(messages.modelisateurFormLibelle());

		ColumnConfig<AttributEtenduMetierERValueModel, String> valAttr = new ColumnConfig<AttributEtenduMetierERValueModel, String>(
				attprops.valeur());
		valAttr.setHeader(messages.modelisateurFormValeur());
		List<ColumnConfig<AttributEtenduMetierERValueModel, ?>> l = new ArrayList<ColumnConfig<AttributEtenduMetierERValueModel, ?>>();
		libAttr.setMenuDisabled(true);
		valAttr.setMenuDisabled(true);
		l.add(libAttr);
		l.add(valAttr);
		ColumnModel<AttributEtenduMetierERValueModel> cm = new ColumnModel<AttributEtenduMetierERValueModel>(l);
		attrReferenceStore = new ListStore<AttributEtenduMetierERValueModel>(attprops.getIdER());
		attrReferenceGrid = new Grid<AttributEtenduMetierERValueModel>(attrReferenceStore, cm);
		attrReferenceGrid.getView().setAutoExpandColumn(libAttr);
		attrReferenceGrid.setHeight(100);
		attrReferenceGrid.setBorders(true);
		attrReferenceGrid.getView().setForceFit(true);
		attrReferenceGrid.getView().setAdjustForHScroll(true);
		final GridEditing<AttributEtenduMetierERValueModel> editorAttr = new GridInlineEditing<AttributEtenduMetierERValueModel>(
				attrReferenceGrid);
		TextField text = new TextField();
		text.addValueChangeHandler(new ValueChangeHandler<String>() {

			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				editorAttr.getEditableGrid().getStore().commitChanges();
				changed = true;
				toggleSaveCancel(true);
			}
		});
		editorAttr.addEditor(valAttr, text);
	}

	private void buildGridEde() {
		CarateristiqueReferenceProperties carateristiqueReferenceProperties = GWT.create(CarateristiqueReferenceProperties.class);

		//storeEde = new ListStore<MdlCarateristiqueReference>(carateristiqueReferenceProperties.ge);
		RpcProxy<PagingLoadConfig, PagingLoadResult<MdlCarateristiqueReference>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<MdlCarateristiqueReference>>() {
			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<MdlCarateristiqueReference>> callback) {
				ClientReferenceServiceAsync.Util.getInstance().loadCaracteristiquePaging(treeNode.getIdModeleVersion(), treeNode.getId(), loadConfig, callback);
			}
	    };
		storeEde = new ListStore<MdlCarateristiqueReference>(new ReferenceElementKeyProvider());		
		PagingLoader<PagingLoadConfig, PagingLoadResult<MdlCarateristiqueReference>> loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<MdlCarateristiqueReference>>(proxy);
		loader.setRemoteSort(true);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, MdlCarateristiqueReference, PagingLoadResult<MdlCarateristiqueReference>>(
				storeEde));
		
		ColumnConfig<MdlCarateristiqueReference, String> ccEdeLibelle = new ColumnConfig<MdlCarateristiqueReference, String>(
				carateristiqueReferenceProperties.caracteristiqueLibelle());
		ccEdeLibelle.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRelationElementEntree()));
		ccEdeLibelle.setSortable(false);
		ccEdeLibelle.setMenuDisabled(true);

		ColumnConfig<MdlCarateristiqueReference, MdlCarateristiqueReference> ccAction = new ColumnConfig<MdlCarateristiqueReference, MdlCarateristiqueReference>(
				new IdentityValueProvider<MdlCarateristiqueReference>());
		ccAction.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRelationAct()));
		ccAction.setSortable(false);
		ccAction.setMenuDisabled(true);
		ccAction.setWidth(50);
		Integer directId = (treeNode == null) ? null : treeNode.getParentId();
		ImagesCell image = new ImagesCell(directId) {

			@Override
			public void onDelete(final MdlCarateristiqueReference node) {					
					ClientCaracteristiqueServiceAsync.Util.getInstance().findById(node.getIdCaracteristique(), new AsyncCallbackWithErrorResolution<MdlCaracteristique>() {					
						@Override
						public void onSuccess(MdlCaracteristique arg0) {							
							AppUtil.showConfirmMessageBox(messages.modelisateurRightDeleteCaracteristiqueReference(arg0.getLLibelleLong(),referenceModel.getLLibelleLong()), new SelectHandler() {							
								@Override
								public void onSelect(SelectEvent event) {								
									storeEde.remove(node);
									toggleSaveCancel(true);
								}							
							}, null);
						}						
					});				
					
					//storeEde.add(getNewCaracteristiqueReferenceHolder());
			}
			@Override
			public void onAdd(MdlCarateristiqueReference node) {
				
				//node.setIdReference(referenceModel.getIdReference());
				MdlCarateristiqueReference newNode = storeEde.findModelWithKey(""+node.hashCode());
				newNode.setStatus(ImagesCell.WAITING_SELECT);
				storeEde.update(newNode);
				storeEde.commitChanges();
				toggleDragDropCaracteristique(true);
			}
			@Override
			public void onValidate(MdlCarateristiqueReference node) {
//				node.setIdReference(-1);
//				node.setIdModeleVersion(-1);
				MdlCarateristiqueReference newNode = storeEde.findModelWithKey(""+node.hashCode());
				newNode.setStatus(ImagesCell.VALIDATED);
				
				storeEde.update(newNode);
				storeEde.commitChanges();
				toggleSaveCancel(true);
				toggleDragDropCaracteristique(false);				
//				bus.fireEvent(new NewRowHolderEvent());
				MdlCarateristiqueReference newRecord = getNewCaracteristiqueReferenceHolder();				
				storeEde.add(newRecord);
				storeEde.commitChanges();
				//storeEde.commitChanges();
//				gridEde.getSelectionModel().select(newRecord, true);
			}
			@Override
			public void onCancel(MdlCarateristiqueReference node) {
				MdlCarateristiqueReference newNode = storeEde.findModelWithKey(""+node.hashCode());				
				storeEde.remove(newNode);									
				storeEde.add(getNewCaracteristiqueReferenceHolder());
				storeEde.commitChanges();
				toggleDragDropCaracteristique(false);
			}
		};
		ccAction.setCell(image);

		List<ColumnConfig<MdlCarateristiqueReference, ?>> lEde = new ArrayList<ColumnConfig<MdlCarateristiqueReference, ?>>();
		lEde.add(ccEdeLibelle);
		lEde.add(ccAction);

		gridEde = new Grid<MdlCarateristiqueReference>(storeEde, new ColumnModel<MdlCarateristiqueReference>(lEde));
		gridEde.setLoadMask(true);
		gridEde.setLoader(loader);
		loader.addLoadHandler(new LoadHandler<PagingLoadConfig, PagingLoadResult<MdlCarateristiqueReference>>() {
			@Override
			public void onLoad(LoadEvent<PagingLoadConfig, PagingLoadResult<MdlCarateristiqueReference>> event) {
				storeEde.add(getNewCaracteristiqueReferenceHolder());
			}
		});
		gridEde.setBorders(false);
		//gridEde.getView().setForceFit(true);
		gridEde.getView().setAutoExpandColumn(ccEdeLibelle);
		gridEde.getView().setForceFit(true);
		gridEde.getView().setAdjustForHScroll(true);
		PagingToolBarWithoutDisplayText gridEdeToolBar = new PagingToolBarWithoutDisplayText(ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
		gridEdeToolBar.bind(loader);
		gridEdeToolBar.getElement().getStyle().setProperty("borderBottom", "none");
		
		gridEdeContainer = AppUtil.createGridWidthPagingContainer(gridEde, gridEdeToolBar);
	}

	private void toggleDragDropCaracteristique(boolean flag) {
		MaskEvent maskEvent = new MaskEvent(flag, getTabId());													
		bus.fireEvent(maskEvent);
		if (flag) {
			buttonContainer.mask();
			labelCommentContainer.mask();
			gridEds.mask();
			attrReferenceGrid.mask();
			if (relationDropTarget == null) {
				relationDropTarget = new CustomizeGridDropTarget<MdlCarateristiqueReference>(gridEde, bus, referenceModel.getIdReference());
			} else {
				relationDropTarget.enable();
			}
		} else {
			buttonContainer.unmask();
			labelCommentContainer.unmask();
			attrReferenceGrid.unmask();
			gridEds.unmask();
			relationDropTarget.disable();			
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void buildGridEds() {
		RpcProxy<PagingLoadConfig, PagingLoadResult<MdlReferenceElement>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<MdlReferenceElement>>() {
			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<MdlReferenceElement>> callback) {
				ClientReferenceServiceAsync.Util.getInstance().loadElementPaging(treeNode.getIdModeleVersion(), treeNode.getId(), loadConfig, callback);
			}
	     
	    };
		ReferenceElementProperties elementValueProperties = GWT.create(ReferenceElementProperties.class);
		storeEds = new ListStore<MdlReferenceElement>(elementValueProperties.getIdElement());
		PagingLoader<PagingLoadConfig, PagingLoadResult<MdlReferenceElement>> loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<MdlReferenceElement>>(proxy);
		loader.setRemoteSort(true);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, MdlReferenceElement, PagingLoadResult<MdlReferenceElement>>(
				storeEds));
		ColumnConfig<MdlReferenceElement, String> ccEdeLibelle = new ColumnConfig<MdlReferenceElement, String>(
				elementValueProperties.elementLibelle());
		ccEdeLibelle.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRelationElementSortieComposition()));
		ccEdeLibelle.setSortable(false);
		ccEdeLibelle.setMenuDisabled(true);

		ColumnConfig<MdlReferenceElement, Short> ccQuantite = new ColumnConfig<MdlReferenceElement, Short>(
				elementValueProperties.nQuantite());

		SpinnerFieldCell<Short> quantiteCell = new SpinnerFieldCell<Short>(new ShortPropertyEditor());
		quantiteCell.addSelectionHandler(new SelectionHandler() {

			@Override
			public void onSelection(SelectionEvent paramSelectionEvent) {
				toggleSaveCancel(true);				
			}
			
		});
		quantiteCell.setAllowBlank(false);
		quantiteCell.setAllowNegative(false);
		quantiteCell.setMinValue(1);
		quantiteCell.setEditable(null,false);
		quantiteCell.setWidth(70);
		ccQuantite.setCell(quantiteCell);
		ccQuantite.setHeader(messages.modelisateurFormRelationQte());
		ccQuantite.setWidth(70);

		List<ColumnConfig<MdlReferenceElement, ?>> lEds = new ArrayList<ColumnConfig<MdlReferenceElement, ?>>();
		lEds.add(ccEdeLibelle);
		lEds.add(ccQuantite);
		gridEds = new Grid<MdlReferenceElement>(storeEds, new ColumnModel<MdlReferenceElement>(lEds));
		gridEds.getView().setForceFit(true);
		gridEds.setBorders(false);
		gridEds.setLoadMask(true);
		gridEds.setLoader(loader);
		gridEds.getView().setAutoExpandColumn(ccEdeLibelle);
		gridEds.getView().setAdjustForHScroll(true);
		PagingToolBarWithoutDisplayText gridEdsToolBar = new PagingToolBarWithoutDisplayText(ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
		gridEdsToolBar.bind(loader);
		gridEdsToolBar.getElement().getStyle().setProperty("borderBottom", "none");
		
		gridEdsContainer = AppUtil.createGridWidthPagingContainer(gridEds, gridEdsToolBar);
		
	}

	class ReferenceElementKeyProvider implements ModelKeyProvider<MdlCarateristiqueReference> {
		@Override
		public String getKey(MdlCarateristiqueReference item) {
			return ""+item.hashCode();
		}
	}

	public NavigationModelisateurForm getNavigationModelisateurForm() {
		return navigationModelisateurForm;
	}
	
	public void setNavigationModelisateurForm(NavigationModelisateurForm navigationModelisateurForm) {
		this.navigationModelisateurForm = navigationModelisateurForm;
	}
	public ModelisateurRegleMessageList getModelisateurRegleMessageList() {
		return modelisateurRegleMessageList;
	}
	public void setModelisateurRegleMessageList(ModelisateurRegleMessageList modelisateurRegleMessageList) {
		this.modelisateurRegleMessageList = modelisateurRegleMessageList;
	}
}
