package com.structis.server.aop;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class SystemArchitecture {

	@Pointcut("execution(* com.structis.server.mapper.ModelBeanMapperDozerImpl.*(..))")
	public void inMapperLayer() {}
	
	@Pointcut("execution(* com.structis.server.service.domain.*.*(..))")
	public void inManagerLayer() {}
	
	@Pointcut("execution(* com.structis.server.dao.*.*(..))")
	public void inDaoLayer(){}
	
	
	@Pointcut("execution(* com.structis.server.service.client.*.*(..))")
	public void inCallerLayer() {}

}
