package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class ModifierModeleEvent  extends GwtEvent<ModifierModeleHandler>{
	
	private static Type<ModifierModeleHandler> TYPE = new Type<ModifierModeleHandler>();
	
	private Integer idModeleVersion;
	
	public static Type<ModifierModeleHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModifierModeleHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModifierModeleHandler handler) {
		handler.onLoad(this);
	}
	
	public ModifierModeleEvent(Integer idModeleVersion) {
		this.idModeleVersion = idModeleVersion;
	}

	public void setIdModeleVersion(Integer idModeleVersion) {
		this.idModeleVersion = idModeleVersion;
	}

	public Integer getIdModeleVersion() {
		return idModeleVersion;
	}

}
