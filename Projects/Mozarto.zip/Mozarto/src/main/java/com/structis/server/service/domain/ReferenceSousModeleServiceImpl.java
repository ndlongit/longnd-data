package com.structis.server.service.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlReferenceSousModeleMapper;
import com.structis.shared.model.MdlReferenceSousModele;

@Service(ReferenceSousModeleService.SERVICE_NAME)
public class ReferenceSousModeleServiceImpl implements ReferenceSousModeleService {

	@Autowired
	private MdlReferenceSousModeleMapper mapper;

	@Override
	public int deleteById(Integer idSousModele) {
		return mapper.deleteById(idSousModele);
	}

	@Override
	public int delete(MdlReferenceSousModele record) {
		return mapper.delete(record);
	}

	@Override
	public int insert(MdlReferenceSousModele record) {
		return mapper.insert(record);
	}

	@Override
	public int insertSelective(MdlReferenceSousModele record) {
		return mapper.insertSelective(record);
	}

	@Override
	public MdlReferenceSousModele findById(Integer idSousModele) {
		return mapper.findById(idSousModele);
	}

	@Override
	public List<MdlReferenceSousModele> findAll() {
		return mapper.findAll();
	}

	@Override
	public int updateSelective(MdlReferenceSousModele record) {
		return mapper.updateSelective(record);
	}

	@Override
	public int update(MdlReferenceSousModele record) {
		return mapper.update(record);
	}

	@Override
	public List<MdlReferenceSousModele> findByBaseCriteria(MdlReferenceSousModele criteria) {
		return mapper.findByBaseCriteria(criteria);
	}
}
