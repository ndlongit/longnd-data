package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.HabilitationUtilisateurMapper;
import com.structis.shared.model.HabilitationUtilisateur;
import com.structis.shared.model.HabilitationUtilisateurKey;
import com.structis.shared.model.reference.UtilisateurMetierRoleModel;

@Service
public class HabilitationUtilisateurServiceImpl implements HabilitationUtilisateurService {
	
	@Autowired
	HabilitationUtilisateurMapper habilitationUtilisateurMapper;
	
	@Override
	public HabilitationUtilisateur findByIdUtilisateurAndIdMetier(Integer idUtilisateur, Integer idMetier) {
		HabilitationUtilisateurKey key = new HabilitationUtilisateurKey();
		key.setIdMetier(idMetier);
		key.setIdUtilisateur(idUtilisateur);
		return habilitationUtilisateurMapper.findById(key);
	}

	@Override
	public int update(Integer idUtilisateur, Integer idMetier, String cRole) {
		HabilitationUtilisateur record = findByIdUtilisateurAndIdMetier(idUtilisateur, idMetier);
		record.setIdMetier(idMetier);
		record.setIdUtilisateur(idUtilisateur);
		record.setCRole(cRole);
		return habilitationUtilisateurMapper.update(record);
	}

	@Override
	public List<UtilisateurMetierRoleModel> getAllMetier(Integer idUtilisateur) {
		return habilitationUtilisateurMapper.findMetierByUtilisateur(idUtilisateur);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public int insertList(List<HabilitationUtilisateur> list) {
		Map map = new HashMap();
		map.put("habilitationUtilisateurList", list);
		return habilitationUtilisateurMapper.insertList(map);
	}

	@Override
	public int deleteByIdUtilisateur(Integer idUtilisateur) {
		return habilitationUtilisateurMapper.deleteByIdUtilisateur(idUtilisateur);
	}

}
