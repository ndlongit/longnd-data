package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.CompositionCarateristiqueModel;

public interface CompositionCaracteristiqueProperties extends PropertyAccess<CompositionCarateristiqueModel> {
	
	ModelKeyProvider<CompositionCarateristiqueModel> idCaracteristique();	
	LabelProvider<CompositionCarateristiqueModel> lLibelleLong();
	
	ValueProvider<CompositionCarateristiqueModel, Short> nRang();

	ValueProvider<CompositionCarateristiqueModel, Integer> idModeleVersion();		
}