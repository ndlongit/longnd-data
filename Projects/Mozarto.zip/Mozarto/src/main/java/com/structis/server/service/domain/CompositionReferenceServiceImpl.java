package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.CmpReferenceMapper;
import com.structis.shared.model.CmpReference;

@Service
public class CompositionReferenceServiceImpl implements CompositionReferenceService {

	@Autowired
	CmpReferenceMapper cmpReferenceMapper;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void insertList(List<CmpReference> cmpReferences) {
		Map parameters = new HashMap();
		parameters.put("cmpReferences", cmpReferences);
		cmpReferenceMapper.insertList(parameters);
	}

	@Override
	public List<CmpReference> findByIdComposition(Integer idComposition) {
		return cmpReferenceMapper.findByIdComposition(idComposition);
	}

	@Override
	public void deleteByIdComposition(Integer idComposition) {
		cmpReferenceMapper.deleteByIdComposition(idComposition);
	}
}
