package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoadResultBean;
import com.structis.client.service.ClientGestionUtilisateursService;
import com.structis.server.core.ConstantError;
import com.structis.server.service.domain.HabilitationUtilisateurService;
import com.structis.server.service.domain.MetierService;
import com.structis.server.service.domain.PzUtilisateurService;
import com.structis.server.service.domain.RoleUtilisateurService;
import com.structis.server.service.domain.UtilisateurLienPegazService;
import com.structis.server.service.domain.UtilisateurService;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.model.HabilitationUtilisateur;
import com.structis.shared.model.PzUtilisateur;
import com.structis.shared.model.RoleUtilisateur;
import com.structis.shared.model.Utilisateur;
import com.structis.shared.model.UtilisateurLienPegaz;
import com.structis.shared.model.reference.UtilisateurMetierRoleModel;

@Service("gestionUtilisateursServiceImpl")
public class ClientGestionUtilisateursServiceImpl implements ClientGestionUtilisateursService {

	@Autowired
	MetierService metierService;
	
	@Autowired
	UtilisateurService utilisateurService;
	
	@Autowired
	PzUtilisateurService pzUtilisateurService;
	
	@Autowired
	RoleUtilisateurService roleUtilisateurService;
	
	@Autowired
	HabilitationUtilisateurService habilitationUtilisateurService;
	
	@Autowired
	UtilisateurLienPegazService utilisateurLienPegazService;

	@Override
	public PagingLoadResult<Utilisateur> findAllByMetier(Integer idMetier, PagingLoadConfig loadConfig) {
		List<Utilisateur> listUtilisateurs = new ArrayList<Utilisateur>();
		if(idMetier != null)
			listUtilisateurs = utilisateurService.findAllByMetier(idMetier);
		else
			listUtilisateurs = utilisateurService.findAllPegaz();
		List<Utilisateur> sublist = new ArrayList<Utilisateur>();
		int start = loadConfig.getOffset();
	    int limit = listUtilisateurs.size();
	    if (loadConfig.getLimit() > 0) {
		      limit = Math.min(start + loadConfig.getLimit(), limit);
		}
	    for (int i = loadConfig.getOffset(); i < limit; i++) {
	    	Utilisateur m = listUtilisateurs.get(i);
	    	sublist.add(m);
	    }
		return new PagingLoadResultBean<Utilisateur>(sublist, listUtilisateurs.size(), loadConfig.getOffset());
	}

	@Override
	public List<RoleUtilisateur> findAllRole() {
		return roleUtilisateurService.findAll();
	}

	@Override
	public RoleUtilisateur findRoleByUtilisateurAndMetier(Integer idUtilisateur, Integer idMetier) {
		return roleUtilisateurService.findByUtilisateurAndMetier(idUtilisateur, idMetier);
	}

	@Override
	public Integer updateRoleUtilisateur(Integer idUtilisateur, Integer idMetier, String cRole) {
		return habilitationUtilisateurService.update(idUtilisateur, idMetier, cRole);
	}

	@Override
	public List<UtilisateurMetierRoleModel> getAllMetier(Integer idUtilisateur) {
		return habilitationUtilisateurService.getAllMetier(idUtilisateur);
	}

	@Override
	public Utilisateur insertOrUpdate(Utilisateur utilisateur, List<UtilisateurMetierRoleModel> list) {
		Integer idUtilisateur = utilisateur.getIdUtilisateur();
		Integer idPegaz = utilisateur.getIdPegaz();
		Utilisateur findByCUtilisateur = utilisateurService.findUtilisateurByAccount(utilisateur.getCUtilisateur());
		if (findByCUtilisateur != null && !findByCUtilisateur.getIdUtilisateur().equals(idUtilisateur)){
			throw new FunctionalException(ConstantError.ERR_DUPLICATED);
		}
		String codePegaz = utilisateur.getCodePegaz();
		if (codePegaz != null && !"".equals(codePegaz)){
			PzUtilisateur findByCodePegaz = pzUtilisateurService.findByCode(codePegaz);
			if (findByCodePegaz != null && !findByCodePegaz.getIdUtilisateurpegaz().equals(idPegaz)){
				throw new FunctionalException(ConstantError.ERR_EXISTED);
			}
		}
		if (idUtilisateur != null){
			habilitationUtilisateurService.deleteByIdUtilisateur(idUtilisateur);
			utilisateurService.update(utilisateur);
			if(idPegaz != null){
				PzUtilisateur pzUtilisateur = pzUtilisateurService.findById(idPegaz);
				pzUtilisateurService.update(pzUtilisateur);
			}
		}
		else{
			utilisateurService.insert(utilisateur);
			if(codePegaz != null && !"".equals(codePegaz)){
				PzUtilisateur pzu = new PzUtilisateur();
				pzu.setCUtilisateurPegaz(codePegaz);
				pzUtilisateurService.insert(pzu);
				UtilisateurLienPegaz upz = new UtilisateurLienPegaz();
				upz.setIdUtilisateur(utilisateur.getIdUtilisateur());
				upz.setIdUtilisateurpegaz(pzu.getIdUtilisateurpegaz());
				utilisateurLienPegazService.insert(upz);
			}
		}
		List<HabilitationUtilisateur> habilitationUtilisateurs = new ArrayList<HabilitationUtilisateur>();
		if(list != null && list.size() > 0){
			for (UtilisateurMetierRoleModel u : list){
				if(u.getCRole() != null){
					HabilitationUtilisateur h = new HabilitationUtilisateur();
					h.setIdMetier(u.getIdMetier());
					h.setIdUtilisateur(utilisateur.getIdUtilisateur());
					h.setCRole(u.getCRole());
					h.setInDefaut(u.getInDefaut() == null ? false : u.getInDefaut());
					habilitationUtilisateurs.add(h);
				}
			}
			habilitationUtilisateurService.insertList(habilitationUtilisateurs);
		}
		return utilisateur;
	}

	
}
