package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlMessage;
import com.structis.shared.model.reference.TreeNodeModel;

public interface MessageService {
	List<MdlMessage> findMessageByLienCommun(Integer idModeleVersion, List<Integer> idLienCommunList);
	
	void deleteMessageByidLienCommuns(Integer idModeleVersion,List<Integer> idLienCommuns);

	void insert(MdlMessage message);
	
	void update(MdlMessage message);
	
	MdlMessage findById(Integer idMessage);
	
	void delete(Integer idUser,TreeNodeModel sourceNode,int idMessage);

	List<MdlMessage> findAnnulerMessageByLienCommun(Integer idModeleVersion, List<Integer> idLienCommunList);

	void deleteList(int idModeleVersion, List<Integer> idMessage);

	void cancelInheritage(Integer idUser, TreeNodeModel sourceNode, int idMessage);
	
	List<MdlMessage> findMessageExludeAnnulerByLienCommun(Integer idModeleVersion, List<Integer> idLienCommunList);

}
