package com.structis.client.event.application;

import com.google.gwt.event.shared.EventHandler;

public interface LoadDataHandler extends EventHandler {
	
	void onLoad(LoadDataEvent event);

}
