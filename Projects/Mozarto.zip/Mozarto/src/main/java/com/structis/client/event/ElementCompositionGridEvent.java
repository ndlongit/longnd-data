package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class ElementCompositionGridEvent  extends GwtEvent<ElementCompositionGridHandler>{

	private static Type<ElementCompositionGridHandler> TYPE = new Type<ElementCompositionGridHandler>();
	public static Type<ElementCompositionGridHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ElementCompositionGridHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ElementCompositionGridHandler handler) {
		handler.onLoad(this);
	}
	
	public ElementCompositionGridEvent() {
	}

}
