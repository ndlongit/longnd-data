package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.resources.client.CssResource;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.sencha.gxt.widget.core.client.grid.GroupingView;

public class CustomizeGroupingView<M> extends GroupingView<M> {
	public interface GroupingViewStyle extends CssResource, GridDataTableStyles {

		String gridGroup();

		String gridGroupBody();

		String gridGroupCollapsed();

		String gridGroupHead();

		String gridGroupHeadInner();
	}

	@Override
	protected void renderGroup(SafeHtmlBuilder buf, GroupingData<M> g, SafeHtml renderedRows) {
		GroupingViewAppearance groupAppearance = GWT.<GroupingViewAppearance> create(GroupingViewAppearance.class);
		String groupClass = "gridGroupTitle"/*groupAppearance.style().gridGroup()*/;
		String headClass = groupAppearance.style().gridGroupHead();
		//
		buf.append(tpls.tr(
				groupClass,
				tpls.tdWrap(cm.getColumnCount(), headClass + " " + styles.cell(), styles.cellInner(), renderGroupHeader(g))));
		buf.append(tpls.tr("", tpls.tdWrap(cm.getColumnCount(), "", "", renderedRows)));
	}
	@Override
	protected void toggleGroup(Element group, boolean expanded) {

	}

}
