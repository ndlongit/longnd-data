package com.structis.client.panel.composition;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Image;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.TreeStore;
import com.sencha.gxt.widget.core.client.event.CollapseItemEvent;
import com.sencha.gxt.widget.core.client.event.CollapseItemEvent.CollapseItemHandler;
import com.sencha.gxt.widget.core.client.event.ExpandItemEvent;
import com.sencha.gxt.widget.core.client.event.ExpandItemEvent.ExpandItemHandler;
import com.sencha.gxt.widget.core.client.tree.Tree;
import com.structis.client.event.CompositionTreeLoadCompleteEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.panel.AbstractPanel;
import com.structis.client.service.ClientCompositionServiceAsync;
import com.structis.shared.model.reference.CompositionTreeComboboxModel;
import com.structis.shared.model.reference.TreeNodeCompositionModel;
import com.structis.shared.model.reference.TreeNodeModel;

public class CompositionTreePanel extends AbstractPanel {
	private TreeStore<TreeNodeModel> treeStore;

	Tree<TreeNodeModel, String> tree;

	private NavigationService navigation = NavigationFactory.getNavigation();

	private Integer idModeleVersion = 0;

	private HTML collapseButton;

	private HTML stateChangeButton;

	private TreeNodeCompositionModel rootNode;

	private int stateNum = 1;
	
	//private int firstLoad = 0;
	private CompositionCaracteristiqueListForm compositionCaracteristiqueListForm;
	
	public CompositionTreePanel(SimpleEventBus bus) {
		super(bus);
	}

	class KeyProvider implements ModelKeyProvider<TreeNodeModel> {
		@Override
		public String getKey(TreeNodeModel item) {
			return item.hashCode() + "";
		}
	}

	@Override
	public void buildPanel() {

		stateChangeButton = new HTML();

		Image stateChangeIcon = new Image();
		stateChangeIcon.setPixelSize(16, 16);
		stateChangeIcon.setResource(images.treeMenu());
		stateChangeButton.setHTML(stateChangeIcon + "");
		stateChangeButton.setStyleName("searchButton");
		stateChangeButton.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		add(stateChangeButton);

		treeStore = new TreeStore<TreeNodeModel>(new KeyProvider());

		tree = new Tree<TreeNodeModel, String>(treeStore, new ValueProvider<TreeNodeModel, String>() {

			@Override
			public String getValue(TreeNodeModel object) {
				return object.getLibelle();
			}

			@Override
			public void setValue(TreeNodeModel object, String value) {
			}

			@Override
			public String getPath() {
				return "name";
			}
			
		});
		
		add(tree, new VerticalLayoutData(1, 1));

		collapseButton = new HTML();

		Image collapseIcon = new Image();
		collapseIcon.setPixelSize(16, 16);
		collapseIcon.setResource(images.collapseLeft());
		collapseButton.setHTML(collapseIcon + "");
		collapseButton.setStyleName("searchButton");
		collapseButton.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		add(collapseButton);
	}

	@Override
	public void addHandler() {
		stateChangeButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				changeState();
			}
		});
		tree.addCollapseHandler(new CollapseItemHandler<TreeNodeModel>() {

			@Override
			public void onCollapse(CollapseItemEvent<TreeNodeModel> event) {
				stateNum = 0;
				stateChangeButton.setTitle(messages.compositionLeftTreeButtonState1());
			}
		});
		tree.addExpandHandler(new ExpandItemHandler<TreeNodeModel>() {

			@Override
			public void onExpand(ExpandItemEvent<TreeNodeModel> event) {
				stateNum = 0;
				stateChangeButton.setTitle(messages.compositionLeftTreeButtonState1());
			}
		});
		
	}

	@Override
	protected void onAfterFirstAttach() {
		if( navigation.getContext().getIdModeleVersionComposition() != 0 ) {
			idModeleVersion = navigation.getContext().getIdModeleVersionComposition();
			if(treeStore.getAll().size() == 0){
				loadComposition(idModeleVersion);
			}
		}
		/*navigation.getBus().addHandler(LoadCompositionEvent.getType(), new LoadCompositionHandler() {
			@Override
			public void onLoad(LoadCompositionEvent loadCompositionEvent) {
				
			}
		});*/

	}

	public void loadComposition(int idModeleVersionParameter) {
		this.idModeleVersion = idModeleVersionParameter /* loadCompositionEvent.getIdModeleVersion() */;
		treeStore.clear();
		ClientCompositionServiceAsync.Util.getInstance().getCompositionTreeAndComboboxBeforeLastNode(
				idModeleVersion, new AsyncCallbackWithErrorResolution<CompositionTreeComboboxModel>() {

					@Override
					public void onSuccess(CompositionTreeComboboxModel result) {
						treeStore.clear();
						if( result != null ) {
							rootNode = result.getTreeNodeCompositionModel();
							treeStore.add((TreeNodeModel) rootNode);
							processFolder(treeStore, rootNode);
							if( rootNode.getChildren() != null ) {
								expandNodeBeforeLastNode(rootNode);
							}
							getCompositionCaracteristiqueListForm().loadCombobox(
									idModeleVersion, result.getNodeBeforeLastNodesResults());
							bus.fireEvent(new CompositionTreeLoadCompleteEvent(rootNode.getLibelle()));
						}
					}
				});
	}
	public void reLoadComposition() {
		treeStore.clear(); 
		treeStore.add((TreeNodeModel) rootNode);
		processFolder(treeStore, rootNode);
		if( rootNode.getChildren() != null ) {
			expandNodeBeforeLastNode(rootNode);
		}
	}
	private void processFolder(TreeStore<TreeNodeModel> store, TreeNodeCompositionModel folder) {
		if( folder.getChildren() != null ) {
			for( TreeNodeCompositionModel child : folder.getChildren() ) {
				store.add(folder, (TreeNodeModel) child);
				if( child.isHasChildren() ) {
					processFolder(store, child);
				}
			}
		}
	}

	private void expandNodeBeforeLastNode(TreeNodeCompositionModel node) {
		if( !node.isNodeBeforeLastNode() ) {
			tree.setExpanded(node, true);
			if( node.isHasChildren() ) {
				for( TreeNodeCompositionModel child : node.getChildren() ) {
					if( child != null ) {
						expandNodeBeforeLastNode(child);
					}
				}
			}
		}
		else {
			if( node.isHasChildren() ) {
				for( TreeNodeCompositionModel child : node.getChildren() ) {
					if( child.isHasChildren() ) {
						tree.setExpanded(node, true);
						for( TreeNodeCompositionModel child1 : node.getChildren() ) {
							if( child1 != null ) {
								expandNodeBeforeLastNode(child1);
							}
						}
						break;
					}
				}

			}
		}
		stateNum = 1;
		stateChangeButton.setTitle(messages.compositionLeftTreeButtonState2());
		forceLayout();
	}

	private void changeState() {

		switch( stateNum ) {
			case 1 :
				tree.expandAll();
				stateNum = 2;
				stateChangeButton.setTitle(messages.compositionLeftTreeButtonState3());
				break;
			case 2 :
				tree.collapseAll();
				stateNum = 3;
				stateChangeButton.setTitle(messages.compositionLeftTreeButtonState1());
				break;
			case 3 :
				expandNodeBeforeLastNode(rootNode);
				break;
			default :
				tree.collapseAll();
				expandNodeBeforeLastNode(rootNode);
				break;
		}
	
	}

	public HTML getCollapseButton() {
		return collapseButton;
	}

	public void setCollapseButton(HTML collapseButton) {
		this.collapseButton = collapseButton;
	}

	public CompositionCaracteristiqueListForm getCompositionCaracteristiqueListForm() {
		return compositionCaracteristiqueListForm;
	}

	public void setCompositionCaracteristiqueListForm(CompositionCaracteristiqueListForm compositionCaracteristiqueListForm) {
		this.compositionCaracteristiqueListForm = compositionCaracteristiqueListForm;
	}

}
