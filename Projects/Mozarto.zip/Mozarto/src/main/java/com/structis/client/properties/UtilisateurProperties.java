package com.structis.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.Utilisateur;

public interface UtilisateurProperties extends PropertyAccess<Utilisateur> {
	@Path("idUtilisateur")
	ModelKeyProvider<Utilisateur> idUtilisateur();

	ValueProvider<Utilisateur, String> cUtilisateur();

	ValueProvider<Utilisateur, String> lNom();

	ValueProvider<Utilisateur, String> lPrenom();

	ValueProvider<Utilisateur, String> lMail();

	ValueProvider<Utilisateur, Boolean> inActif();

	ValueProvider<Utilisateur, String> lMotdepasse();

	ValueProvider<Utilisateur, String> nomComplet();
}
