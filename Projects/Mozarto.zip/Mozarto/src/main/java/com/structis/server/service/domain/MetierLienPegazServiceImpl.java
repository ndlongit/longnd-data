package com.structis.server.service.domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MetierLienPegazMapper;
import com.structis.shared.model.MetierLienPegaz;

@Service("metierLienPegazService")
public class MetierLienPegazServiceImpl implements MetierLienPegazService {

	@Autowired
	MetierLienPegazMapper metierLienPegazMapper;
	
	@Override
	public void insert(MetierLienPegaz metierLienPegaz) {
		metierLienPegazMapper.insert(metierLienPegaz);
	}

}
