package com.structis.client.panel;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HasValue;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.sencha.gxt.core.client.util.ToggleGroup;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.FocusEvent;
import com.sencha.gxt.widget.core.client.event.FocusEvent.FocusHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.Radio;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.service.ClientRegleMessageServiceAsync;
import com.structis.shared.constant.Niveau;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurMessageForm extends AbstractFieldsetEditForm {

	//	private final Messages messages = GWT.create(Messages.class);

	private ModelisateurRegleMessageList parent;

	private Radio information;

	private Radio avertissement;

	private Radio alerte;

	private ToggleGroup toggle;

	private TextArea messageLibelle;
	
	private String messageLibelleActuel = "";

	private NavigationService navigation = NavigationFactory.getNavigation();

	private TreeNodeModel source;

	private HorizontalPanel importance;

	private FieldLabel importanceLabel;

	private Integer idMessage;
	
	private boolean changed = false;

	public ModelisateurMessageForm(SimpleEventBus bus, ModelisateurRegleMessageList parent) {
		super(bus);

		this.parent = parent;
		annulerButton.setEnable(true);
		validerButton.setEnabled(true);
	}

	@Override
	protected VerticalLayoutContainer buildPanel() {
		setHeadingHtml(messages.modelisateurFormMessage());
		VerticalLayoutContainer form = new VerticalLayoutContainer();
		information = new Radio();
		information.setBoxLabel(messages.modelisateurFormMessageImportanceInformation());

		avertissement = new Radio();
		avertissement.setBoxLabel(messages.modelisateurFormMessageImportanceAvertissement());
		avertissement.setValue(true);

		alerte = new Radio();
		alerte.setBoxLabel(messages.modelisateurFormMessageImportanceAlerte());

		toggle = new ToggleGroup();
		toggle.add(information);
		toggle.add(avertissement);
		toggle.add(alerte);
		toggle.setValue(avertissement);

		importance = new HorizontalPanel();
		importance.add(information);
		importance.add(avertissement);
		importance.add(alerte);

		importance.setWidth("auto");

		importanceLabel = new FieldLabel(importance, messages.modelisateurFormMessageImportance());
		importanceLabel.setLabelWidth(200);

		form.add(importanceLabel, new VerticalLayoutData(1, 0.15));

		messageLibelle = new TextArea();
//		messageLibelle.getElement().setAttribute("maxlength", "500");
		form.add(messageLibelle, new VerticalLayoutData(1, 0.70));
		messageLibelle.setPreventScrollbars(true);
		return form;
	}

	@Override
	protected void addHandler() {
		annulerButton.getHtml().addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				parent.unDisplayRegleForm();
				parent.getReglesMessagesGrid().enable();
				//				resetForm();
			}
		});
		validerButton.addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				if(messageLibelle.getText().length() <= 500)
					insertOrUpdate();
				else
					messageLibelle.markInvalid(messages.commonMaxlength(500));
			}
		});
		toggle.addValueChangeHandler(new ValueChangeHandler<HasValue<Boolean>>() {

			@Override
			public void onValueChange(ValueChangeEvent<HasValue<Boolean>> event) {
				toggleSaveCancel(true);
			}
		});
		messageLibelle.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				messageLibelleActuel = messageLibelle.getText();				
			}
		});
		messageLibelle.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
				toggleSaveCancel(true);
			}
		});
		messageLibelle.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if(!messageLibelleActuel.equals(messageLibelle.getText()))
					toggleSaveCancel(true);
			}
		});
	}

	protected void insertOrUpdate() {

		if( messageLibelle.getValue() != null && messageLibelle.getValue().length() > 0 ) {
			int idUtilisateur = navigation.getContext().getUtilisateur().getIdUtilisateur();
			if( idMessage == null)
				ClientRegleMessageServiceAsync.Util.getInstance().insertMessage(
						idUtilisateur, source, messageLibelle.getValue(), getPriorite(),
						new AsyncCallbackWithErrorResolution<ModelisateurRegleMessageListModel>() {

							@Override
							public void onSuccess(ModelisateurRegleMessageListModel result) {
								parent.getReglesMessagesStore().add(result);
								parent.setRowUpdateIndex(parent.getReglesMessagesStore().indexOf(result));
								List<ModelisateurRegleMessageListModel> select = new ArrayList<ModelisateurRegleMessageListModel>();
								select.add(result);
								parent.getReglesMessagesGrid().getSelectionModel().setSelection(select);
								toggleSaveCancel(false);
								idMessage = result.getId();
							}
						});
			else
				ClientRegleMessageServiceAsync.Util.getInstance().updateMessage(
						idUtilisateur, idMessage, messageLibelle.getValue(), getPriorite(),
						new AsyncCallbackWithErrorResolution<ModelisateurRegleMessageListModel>() {
							@Override
							public void onSuccess(ModelisateurRegleMessageListModel result) {
								if( result != null ) {
									String key = "" + result.getType() + result.getId();
									ModelisateurRegleMessageListModel record = parent.getReglesMessagesStore().findModelWithKey(
											key);
									if( record != null ) {
										parent.getReglesMessagesStore().update(result);
										List<ModelisateurRegleMessageListModel> select = new ArrayList<ModelisateurRegleMessageListModel>();
										select.add(result);
										parent.getReglesMessagesGrid().getSelectionModel().setSelection(select);
									}

									toggleSaveCancel(false);
								}
							}
						});
		}
		else {
			messageLibelle.markInvalid(messages.commonChampObligatoire());
		}
	}

	@Override
	protected void loadForm(TreeNodeModel item) {
		this.source = item;

	}

	private int getPriorite() {
		int priorite = 0;
		Radio radio = (Radio) toggle.getValue();
		if( radio != null ) {

			if( radio.getBoxLabel().equals(messages.modelisateurFormMessageImportanceInformation()) ) {
				priorite = Niveau.INFORMATION.getIndex();
			}
			else if( radio.getBoxLabel().equals(messages.modelisateurFormMessageImportanceAvertissement()) ) {
				priorite = Niveau.AVERTISSEMENT.getIndex();
			}
			else if( radio.getBoxLabel().equals(messages.modelisateurFormMessageImportanceAlerte()) ) {
				priorite = Niveau.ALERTE.getIndex();
			}
		}
		return priorite;
	}

	public void loadMessage(ModelisateurRegleMessageListModel message) {
		resetForm();
		parent.getCreateMessage().setEnable(true);
		parent.getCreateRegle().setEnable(true);
		validerButton.setEnabled(false);
		annulerButton.setEnable(false);
		this.idMessage = message.getId();
		messageLibelle.setValue(message.getCibleLibelle());
		messageLibelle.setText(message.getCibleLibelle());
		if( message.getRelation().intValue() == Niveau.INFORMATION.getIndex() ) {
			information.setValue(true);
			toggle.setValue(information);
		}
		else if( message.getRelation().intValue() == Niveau.AVERTISSEMENT.getIndex() ) {
			avertissement.setValue(true);
			toggle.setValue(avertissement);
		}
		else {
			alerte.setValue(true);
			toggle.setValue(alerte);
		}
	}

	public void resetForm() {
		changed = false;
		idMessage = null;
		information.reset();
		avertissement.reset();
		alerte.reset();
		avertissement.setValue(true);
		toggle.setValue(avertissement);
		messageLibelle.reset();
		messageLibelle.clearInvalid();

	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	public boolean isChanged() {
		return changed;
	}

	protected void toggleSaveCancel(boolean enable) {
		changed = enable;
		parent.getCreateMessage().setEnable(!enable);
		parent.getCreateRegle().setEnable(!enable);
		validerButton.setEnabled(enable);
		annulerButton.setEnable(enable);
		if(enable)
			parent.getReglesMessagesGrid().disable();
		else
			parent.getReglesMessagesGrid().enable();
	}
}
