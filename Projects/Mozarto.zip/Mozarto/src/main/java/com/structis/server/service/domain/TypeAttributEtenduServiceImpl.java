package com.structis.server.service.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.persistence.TypeAttributEtenduMapper;
import com.structis.shared.model.TypeAttributEtendu;

/**
 * 
 * @author vu.dang
 *
 */
@Service("typeAttributEtenduService")
public class TypeAttributEtenduServiceImpl implements  TypeAttributEtenduService{
	@Autowired
	private TypeAttributEtenduMapper mapper;
	
	public TypeAttributEtendu findById(String id) {
		return mapper.findById(id);	
	}
	
	@Transactional
	public Integer insert(TypeAttributEtendu record) {
		 return mapper.insert(record);	
	}
	
	@Transactional
	public Integer update(TypeAttributEtendu record) {
		return mapper.update(record);	
	}
		
	@Transactional
	public Integer delete(TypeAttributEtendu record) {
		return mapper.delete(record);	
	}
	
	@Transactional
	public Integer deleteById(String id) {
		return mapper.deleteById(id);	
	}
	public List<TypeAttributEtendu> findAll() {
		return mapper.findAll();		
	}
}
