package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GestionUtilisateurDisableUtilisateurEvent extends GwtEvent<GestionUtilisateurDisableUtilisateurHandler> {

	private static Type<GestionUtilisateurDisableUtilisateurHandler> TYPE = new Type<GestionUtilisateurDisableUtilisateurHandler>();
	private String tabLabel;
	private Integer idUtilisateur;

	public static Type<GestionUtilisateurDisableUtilisateurHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionUtilisateurDisableUtilisateurHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionUtilisateurDisableUtilisateurHandler handler) {
		handler.onLoad(this);
	}	

	public GestionUtilisateurDisableUtilisateurEvent(String tabLabel) {
		this.tabLabel = tabLabel;
	}

	public GestionUtilisateurDisableUtilisateurEvent(Integer idUtilisateur) {
		this.idUtilisateur = idUtilisateur;
	}

	public String getTabLabel() {
		return tabLabel;
	}

	public void setTabLabel(String newLabel) {
		this.tabLabel = newLabel;
	}

	public Integer getIdUtilisateur() {
		return idUtilisateur;
	}

	public void setIdUtilisateur(Integer idUtilisateur) {
		this.idUtilisateur = idUtilisateur;
	}

}
