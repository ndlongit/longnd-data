package com.structis.client.widget;

import com.sencha.gxt.widget.core.client.container.Viewport;
import com.structis.client.constant.ConstantClient;

public class SizeLimitViewPort extends Viewport {
	public SizeLimitViewPort(){
		setEnableScroll(true);
		//getElement().getStyle().setProperty("overflow", "scroll");
	}
	@Override
	protected void onWindowResize(int width, int height) {
		if( width < ConstantClient.ScreenSize.MINWIDTH ) {
			width = ConstantClient.ScreenSize.MINWIDTH;
		}
		if(height < ConstantClient.ScreenSize.MINHEIGHT){
			height = ConstantClient.ScreenSize.MINHEIGHT;
		}
		setPixelSize(width, height);
	}
}
