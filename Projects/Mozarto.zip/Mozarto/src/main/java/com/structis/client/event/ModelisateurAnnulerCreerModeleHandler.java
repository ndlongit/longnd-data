package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ModelisateurAnnulerCreerModeleHandler extends EventHandler {
	void onLoad(ModelisateurAnnulerCreerModeleEvent annulerCreerModeleEvent);
}
