package com.structis.server.service.domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.PzUtilisateurMapper;
import com.structis.shared.model.PzUtilisateur;


@Service("pzUtilisateurService")
public class PzUtilisateurServiceImpl implements PzUtilisateurService {

	@Autowired
	PzUtilisateurMapper pzUtilisateurMapper;
	
	@Override
	public Integer insert(PzUtilisateur utilisateur) {
		return pzUtilisateurMapper.insert(utilisateur);
	}

	@Override
	public Integer update(PzUtilisateur utilisateur) {
		return pzUtilisateurMapper.update(utilisateur);
	}

	@Override
	public PzUtilisateur findByCode(String code) {
		return pzUtilisateurMapper.findByCode(code);
	}

	@Override
	public PzUtilisateur findById(Integer id) {
		return pzUtilisateurMapper.findById(id);
	}

}
