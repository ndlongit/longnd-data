package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.CompositionReferenceGridModel;

public interface CompositionReferenceProperties extends PropertyAccess<CompositionReferenceGridModel> {
	
	
	ModelKeyProvider<CompositionReferenceGridModel> idReference();	
	ValueProvider<CompositionReferenceGridModel, String> lLibelleLong();
	
	ValueProvider<CompositionReferenceGridModel, Boolean> isInherited();

	ValueProvider<CompositionReferenceGridModel, Integer> quantite();		
	ValueProvider<CompositionReferenceGridModel, Integer> status();
	ValueProvider<CompositionReferenceGridModel, Integer> relation();
	/*ValueProvider<CompositionReferenceGridModel, Boolean> select();*/
}