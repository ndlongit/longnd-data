package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GestionElementCompositionDisableElementEvent extends GwtEvent<GestionElementCompositionDisableElementHandler> {

	private static Type<GestionElementCompositionDisableElementHandler> TYPE = new Type<GestionElementCompositionDisableElementHandler>();
	private String tabLabel;
	private Integer idElement;

	public static Type<GestionElementCompositionDisableElementHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionElementCompositionDisableElementHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionElementCompositionDisableElementHandler handler) {
		handler.onLoad(this);
	}	

	public GestionElementCompositionDisableElementEvent(String tabLabel) {
		this.tabLabel = tabLabel;
	}

	public GestionElementCompositionDisableElementEvent(Integer idElement) {
		this.idElement = idElement;
	}

	public String getTabLabel() {
		return tabLabel;
	}

	public void setTabLabel(String newLabel) {
		this.tabLabel = newLabel;
	}

	public void setIdElement(Integer idElement) {
		this.idElement = idElement;
	}

	public Integer getIdElement() {
		return idElement;
	}

}
