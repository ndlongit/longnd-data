package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlLienCaracteristiqueMapper;
import com.structis.shared.model.MdlLienCaracteristique;

@Service
public class LiencaracteristiqueServiceImpl implements LiencaracteristiqueService {
	
	@Autowired
	MdlLienCaracteristiqueMapper mdlLienCaracteristiqueMapper;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public MdlLienCaracteristique findLienCaracteristiqueByCaracteristique(int idModeleVersion, int idCaracteristique) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idCaracteristique", idCaracteristique);
		
		return mdlLienCaracteristiqueMapper.findByCaracteristique(mapParameter);
	}

	@Override
	public int insert(MdlLienCaracteristique record) {
		return mdlLienCaracteristiqueMapper.insert(record);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Integer> findLienCaracteristiqueIdsByCaracteristiqueList(int idModeleVersion,
			List<Integer> idCaracteristiques) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("list", idCaracteristiques);
		return mdlLienCaracteristiqueMapper.findListIdByIdCaracteristiqueList(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteByIdlienCoummuns(int idModeleVersion,List<Integer> idLienCoummuns) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommuns", idLienCoummuns);
		mdlLienCaracteristiqueMapper.deleteByIds(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<MdlLienCaracteristique> findLienCaracteristiqueByCaracteristiqueList(int idModeleVersion,
			List<Integer> idCaracteristiques) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idCaracteristiques", idCaracteristiques);
		return mdlLienCaracteristiqueMapper.findByIdCaracteristiqueList(mapParameter);
	}
	
}
