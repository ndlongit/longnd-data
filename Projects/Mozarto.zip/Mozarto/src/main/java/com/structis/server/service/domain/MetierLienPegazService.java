package com.structis.server.service.domain;

import com.structis.shared.model.MetierLienPegaz;

public interface MetierLienPegazService {
	public void insert(MetierLienPegaz metierLienPegaz);
}
