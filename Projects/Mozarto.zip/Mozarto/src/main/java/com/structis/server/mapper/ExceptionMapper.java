package com.structis.server.mapper;


import javax.validation.ConstraintViolationException;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.TransactionException;

import com.structis.server.core.ConstantError;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.exception.ServiceException;
import com.structis.shared.exception.TechnicalException;

public class ExceptionMapper {
	@SuppressWarnings("unused")
	private static Logger logger = Logger.getLogger(ExceptionMapper.class);
	public static ServiceException map(Throwable ex){
		ServiceException result = null;
		/* 
		 * Si l'erreur est d�j� sous forme TechnicalException ou Functional Exception
		 * On l'aisse passer
		 */
		if (ex instanceof TechnicalException 
				|| ex instanceof FunctionalException) {
			
			result = (ServiceException) ex;
		}
		
		/* Probl�me de cr�ation de transaction comme :
		 *  - r�seau
		 *  - mauvaise url, username et password
		 *  - time out
		 */
		else if (ex instanceof TransactionException) {
			result = new TechnicalException(ex, ConstantError.ERR_TRANSACTION);
		}
		
		
		/* Probl�me de donn�es non conforme :
		 *  - violation des constraint
		 */
		else if (ex instanceof DataIntegrityViolationException
				|| ex instanceof ConstraintViolationException) {
			result = new TechnicalException(ConstantError.ERR_DONNES_INCORRECT);
		}
		
		/* Probl�me de data access comme :
		 * 	- la base n'est pas correct
		 */
		else if (ex instanceof DataAccessException) {
			result = new TechnicalException(ex, ConstantError.ERR_DATA_ACCESS);
		}
		/*
		 * Session expire
		 * 
		 */
		/*else if (ex instanceof AuthenticationCredentialsNotFoundException){
			result = new TechnicalException(ex, ConstantError.ERR_SESSION_EXPIRE);
		}*/
		/*
		 * Access refuse
		 */
		/*else if (ex instanceof AccessDeniedException){
			result = new FunctionalException(ex, ConstantError.ERR_ACCES_REFUSE);
		}*/
		
		/*
		 * Autre erreurs : erreur inconnu 
		 */
		else {
			result = new TechnicalException(ex, ConstantError.ERR_INCONNU);
		}
		
		return result;
	}

}
