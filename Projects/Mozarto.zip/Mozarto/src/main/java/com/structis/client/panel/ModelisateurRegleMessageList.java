package com.structis.client.panel;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.SimplePanel;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutData;
import com.sencha.gxt.widget.core.client.container.CardLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.CellClickEvent;
import com.sencha.gxt.widget.core.client.event.CellClickEvent.CellClickHandler;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.event.RowDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.RowDoubleClickEvent.RowDoubleClickHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.ModelisateurAddTabEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.ConstantMessages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.ModelisateurRegleListModelProperties;
import com.structis.client.service.ClientRegleMessageServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.client.widget.CustomizeConfirmMessageBox;
import com.structis.client.widget.HtmlButton;
import com.structis.client.widget.PagingToolBarWithoutDisplayText;
import com.structis.client.widget.RegleMessageActionCell;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurRegleMessageList extends AbstractPanel {

	private HtmlButton createMessage;

	private HtmlButton createRegle;

	private CardLayoutContainer editFormContainer;

	private ModelisateurRegleForm regleForm;

	private ModelisateurMessageForm messageForm;

	private Label titleLable;

	private Label regleMessageListLabel;

	private Grid<ModelisateurRegleMessageListModel> reglesMessagesGrid;

	private ListStore<ModelisateurRegleMessageListModel> reglesMessagesStore;

	private ConstantMessages constantMessages = GWT.create(ConstantMessages.class);

	private static final SafeHtml ICON_UNCHECK = AppUtil.makeImage(Images.RESOURCES.uncheckIcon());

	private static final SafeHtml ICON_CHECK = AppUtil.makeImage(Images.RESOURCES.checkIcon());

	SimplePanel emptyPanel;

	protected TreeNodeModel sourceNode;

	private VerticalLayoutData data1;

	private VerticalLayoutData data2;

	private NavigationService navigation = NavigationFactory.getNavigation();
	
	private int rowUpdateIndex = -1;
	
	private boolean changed = false;
	
	private PagingLoader<PagingLoadConfig, PagingLoadResult<ModelisateurRegleMessageListModel>> loader;
	
	public ModelisateurRegleMessageList(SimpleEventBus bus) {
		super(bus);
	}

	public ModelisateurRegleMessageList(SimpleEventBus bus, TreeNodeModel treeNode) {
		super(bus);
		this.sourceNode = treeNode;
		loadPanel(treeNode);
	}

	@Override
	public void buildPanel() {

		titleLable = new Label("");
		titleLable.addStyleName("editFormTitle");

		HBoxLayoutContainer titlePanel = new HBoxLayoutContainer();
		BoxLayoutData flex = new BoxLayoutData(new Margins(0, 5, 0, 0));
		flex.setFlex(1);
		createMessage = new HtmlButton("> " + messages.modelisateurFormRegleCreemessage());
		createRegle = new HtmlButton("> " + messages.modelisateurFormRegleCreeregle());
		createMessage.setEnable(false);
		createRegle.setEnable(false);
		
		titlePanel.add(titleLable);
		titlePanel.add(new Label(), flex);
		titlePanel.add(createMessage, new BoxLayoutData(new Margins(0, 8, 0, 4)));
		titlePanel.add(createRegle);
		add(titlePanel,new VerticalLayoutData(1,-1));
		add(new HTML("<hr/>"));

		regleMessageListLabel = new Label();
		buildReglesMessagesGrid();

		regleForm = new ModelisateurRegleForm(bus, this);
		emptyPanel = new SimplePanel();
		editFormContainer = new CardLayoutContainer();
		editFormContainer.add(emptyPanel);

		messageForm = new ModelisateurMessageForm(bus, this);
		add(regleMessageListLabel);
		data1 = new VerticalLayoutData(1, .9);
		data2 = new VerticalLayoutData(1, .1);
		PagingToolBarWithoutDisplayText gridEdsToolBar = new PagingToolBarWithoutDisplayText(ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
		gridEdsToolBar.bind(loader);
		gridEdsToolBar.getElement().getStyle().setProperty("borderBottom", "none");
		VerticalLayoutContainer gridEdsContainer = AppUtil.createGridWidthPagingContainer(reglesMessagesGrid, gridEdsToolBar);
		add(gridEdsContainer, data1);
		add(editFormContainer, data2);
	}

	@Override
	public void addHandler() {
		createMessage.getHtml().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				if(createMessage.isEnnabled()){
					displayMessageForm();
					messageForm.getAnnulerButton().setEnable(true);
					messageForm.getValiderButton().setEnabled(true);
				}
			}
		});
		createRegle.getHtml().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				if(createRegle.isEnnabled()){
					displayRegleForm();
					regleForm.getAnnulerButton().setEnable(true);
					regleForm.getValiderButton().setEnabled(true);
				}
			}
		});
		reglesMessagesGrid.addRowDoubleClickHandler(new RowDoubleClickHandler() {
			@Override
			public void onRowDoubleClick(RowDoubleClickEvent event) {
				ModelisateurRegleMessageListModel node = reglesMessagesStore.get(event.getRowIndex());
				if(!node.isHeritage()){
					if( node.getType().equals(ModelisateurRegleMessageListModel.REGLE_TYPE) ) {
						if( isModifyAllow(node) ) {
							displayRegleForm();
							regleForm.loadRegle(node);
							rowUpdateIndex = reglesMessagesStore.getAll().indexOf(node);
						}
					}
					if( node.getType().equals(ModelisateurRegleMessageListModel.MESSAGE_TYPE) ) {
						displayMessageForm();
						messageForm.loadMessage(node);
						rowUpdateIndex = reglesMessagesStore.getAll().indexOf(node);
					}
				
					/*regleForm.getAnnulerButton().setEnable(false);
					regleForm.getValiderButton().setEnabled(false);
					messageForm.getAnnulerButton().setEnable(false);
					messageForm.getValiderButton().setEnabled(false);
					createMessage.setEnable(true);
					createRegle.setEnable(true);*/
				}
			}
//			}
		});
		reglesMessagesGrid.addCellClickHandler(new CellClickHandler() {
			
			@Override
			public void onCellClick(CellClickEvent event) {
				if(event.getCellIndex() != 5){
					ModelisateurRegleMessageListModel node = reglesMessagesStore.get(event.getRowIndex());
					if(!node.isHeritage()){
						if( node.getType().equals(ModelisateurRegleMessageListModel.MESSAGE_TYPE) ) {
							if( isModifyAllow(node) ) {
								displayMessageForm();
								messageForm.loadMessage(node);
								rowUpdateIndex = reglesMessagesStore.getAll().indexOf(node);
							}
							/*if(node.isHeritage()){
								messageForm.getAnnulerButton().setEnable(false);
								messageForm.getValiderButton().setEnabled(false);
								createMessage.setEnable(true);
								createRegle.setEnable(true);
							}*/
						}
						else if( node.getType().equals(ModelisateurRegleMessageListModel.REGLE_TYPE) ) {
							if( isModifyAllow(node) ) {
								displayRegleForm();
								regleForm.loadRegle(node);
								rowUpdateIndex = reglesMessagesStore.getAll().indexOf(node);
							}
							/*if(node.isHeritage()){
								regleForm.getAnnulerButton().setEnable(false);
								regleForm.getValiderButton().setEnabled(false);
								createMessage.setEnable(true);
								createRegle.setEnable(true);
							}*/
						}
						
					}
				}
			}
		});
	}

	public void loadPanel(TreeNodeModel treeNode) {
		regleForm.loadForm(treeNode);
		messageForm.loadForm(treeNode);
		String title = "";
		if( treeNode.getModelType().equals(ModelNodeType.CARACTERISTIQUE) ) {
			reglesMessagesGrid.getColumnModel().setHidden(0, false);
			reglesMessagesGrid.getColumnModel().setHidden(1, true);
			reglesMessagesGrid.getColumnModel().setHidden(4, false);
			title = messages.modelisateurCaracteristique();
		}
		else if( treeNode.getModelType().equals(ModelNodeType.REFERENCE) ) {
			reglesMessagesGrid.getColumnModel().setHidden(0, false);
			reglesMessagesGrid.getColumnModel().setHidden(1, true);
			reglesMessagesGrid.getColumnModel().setHidden(4, false);
			title = messages.modelisateurReference();
		}else {
			reglesMessagesGrid.getColumnModel().setHidden(0, true);
			reglesMessagesGrid.getColumnModel().setHidden(1, false);
			reglesMessagesGrid.getColumnModel().setHidden(4, true);
			title = messages.modelisateurElementDeComposition();
		}
		titleLable.setText(title);
		regleMessageListLabel.setText(messages.modelisateurFormRegleGridtitle()+ " " + treeNode.getLibelle());

	}

	private void buildReglesMessagesGrid() {
		class KeyProvider implements ModelKeyProvider<ModelisateurRegleMessageListModel> {
			@Override
			public String getKey(ModelisateurRegleMessageListModel item) {
				return "" + item.getType() + item.getId();
			}
		}
		ModelisateurRegleListModelProperties properties = GWT.create(ModelisateurRegleListModelProperties.class);
		reglesMessagesStore = new ListStore<ModelisateurRegleMessageListModel>(new KeyProvider());
		
		RpcProxy<PagingLoadConfig, PagingLoadResult<ModelisateurRegleMessageListModel>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<ModelisateurRegleMessageListModel>>() {
			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<ModelisateurRegleMessageListModel>> callback) {
				if(sourceNode.getModelType().equals(ModelNodeType.ELEMENT)){
					ClientRegleMessageServiceAsync.Util.getInstance().findReglePointToElementPaging(sourceNode, loadConfig, callback);
				}else{
					ClientRegleMessageServiceAsync.Util.getInstance().findMessageRegleListPaging(sourceNode, loadConfig, callback);
				}
			}
	    };
	    loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<ModelisateurRegleMessageListModel>>(proxy);
		loader.setRemoteSort(true);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, ModelisateurRegleMessageListModel, PagingLoadResult<ModelisateurRegleMessageListModel>>(
				reglesMessagesStore));
		
		ColumnConfig<ModelisateurRegleMessageListModel, ModelisateurRegleMessageListModel> cclibelle = new ColumnConfig<ModelisateurRegleMessageListModel, ModelisateurRegleMessageListModel>(
				new IdentityValueProvider<ModelisateurRegleMessageListModel>());
		cclibelle.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRegleGridelementcible()));
		cclibelle.setSortable(false);
		cclibelle.setMenuDisabled(true);
		cclibelle.setCell(new AbstractCell<ModelisateurRegleMessageListModel>() {
			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, ModelisateurRegleMessageListModel value,
					SafeHtmlBuilder sb) {
				if( value.getType().equals(ModelisateurRegleMessageListModel.MESSAGE_TYPE) ) {
					String label;
					if (value.getCibleLibelle().length() > 10){
						label = value.getCibleLibelle()/*.substring(0, 10)*/;
						sb.appendHtmlConstant("<span class='htmlLink'>" + messages.modelisateurFormMessage() + "</span> (" + label + ")");
					}
					else{
						label = value.getCibleLibelle();
						sb.appendHtmlConstant("<span class='htmlLink'>" + messages.modelisateurFormMessage() + "</span> (" + label + ")");
					}
				}
				else {
					sb.appendHtmlConstant(value.getCibleLibelle());
				}
			}
		});
		ColumnConfig<ModelisateurRegleMessageListModel, ModelisateurRegleMessageListModel> cSourceLibelle = new ColumnConfig<ModelisateurRegleMessageListModel, ModelisateurRegleMessageListModel>(
				new IdentityValueProvider<ModelisateurRegleMessageListModel>());
		cSourceLibelle.setHeader(messages.modelisateurFormRegleGridElementSource());
		cSourceLibelle.setSortable(false);
		cSourceLibelle.setMenuDisabled(true);
		cSourceLibelle.setCell(new AbstractCell<ModelisateurRegleMessageListModel>() {
			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, ModelisateurRegleMessageListModel value,
					SafeHtmlBuilder sb) {
				if( value.getParentNode() != null ) {
					sb.appendHtmlConstant(value.getParentNode().getLibelle());
				}
			}
		});
		ColumnConfig<ModelisateurRegleMessageListModel, Integer> ccrelation = new ColumnConfig<ModelisateurRegleMessageListModel, Integer>(
				properties.relation());
		ccrelation.setCell(new AbstractCell<Integer>() {

			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, Integer value, SafeHtmlBuilder sb) {
				if(value != null && value != 0){
					String relationConstant = "relation" + value;
					sb.appendHtmlConstant(constantMessages.getString(relationConstant));
				}else{
					sb.appendHtmlConstant("");
				}
			}
		});
		ccrelation.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRegleGridrelation()));
		ccrelation.setSortable(false);
		ccrelation.setMenuDisabled(true);

		ColumnConfig<ModelisateurRegleMessageListModel, Integer> ccquantite = new ColumnConfig<ModelisateurRegleMessageListModel, Integer>(
				properties.quantite());
		ccquantite.setHeader(messages.modelisateurFormRegleGridquantite());
		ccquantite.setSortable(false);
		ccquantite.setMenuDisabled(true);
		ccquantite.setWidth(60);
		ccquantite.setAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		ccquantite.setCell(new AbstractCell<Integer>() {

			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, Integer value, SafeHtmlBuilder sb) {
				if( value > 0 ) {
					sb.appendHtmlConstant("" + value);
				}
			}
		});

		ColumnConfig<ModelisateurRegleMessageListModel, ModelisateurRegleMessageListModel> ccIsHerritage = new ColumnConfig<ModelisateurRegleMessageListModel, ModelisateurRegleMessageListModel>(
				new IdentityValueProvider<ModelisateurRegleMessageListModel>());
		ccIsHerritage.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRegleGridheritage()));
		ccIsHerritage.setSortable(false);
		ccIsHerritage.setMenuDisabled(true);
		ccIsHerritage.setWidth(50);
		ccIsHerritage.setAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		ccIsHerritage.setCell(new AbstractCell<ModelisateurRegleMessageListModel>() {
			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, ModelisateurRegleMessageListModel value,
					SafeHtmlBuilder sb) {
				if( value.isHeritage() ) {
					sb.append(ICON_CHECK);

				}
				else {
					sb.append(ICON_UNCHECK);
				}
			}
		});

		ColumnConfig<ModelisateurRegleMessageListModel, ModelisateurRegleMessageListModel> ccAction = new ColumnConfig<ModelisateurRegleMessageListModel, ModelisateurRegleMessageListModel>(
				new IdentityValueProvider<ModelisateurRegleMessageListModel>());
		ccAction.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRegleGridaction()));
		ccAction.setSortable(false);
		ccAction.setMenuDisabled(true);
		ccAction.setWidth(70);
		ccAction.setAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		RegleMessageActionCell cellAction = new RegleMessageActionCell() {

			@Override
			public void onEdit(ModelisateurRegleMessageListModel node) {
				
					if( node.getType().equals(ModelisateurRegleMessageListModel.REGLE_TYPE) ) {
						if(isModifyAllow(node)){
							displayRegleForm();
							regleForm.loadRegle(node);
							rowUpdateIndex = reglesMessagesStore.getAll().indexOf(node);
						}
					}
					if( node.getType().equals(ModelisateurRegleMessageListModel.MESSAGE_TYPE) ) {
						displayMessageForm();
						messageForm.loadMessage(node);
						rowUpdateIndex = reglesMessagesStore.getAll().indexOf(node);
					}
			}

			@Override
			public void onDelete(ModelisateurRegleMessageListModel record) {
				if( record.getType().equals(ModelisateurRegleMessageListModel.REGLE_TYPE) ) {
					if(isModifyAllow(record)){
						deleteRegle(sourceNode, record);
					}
				}
				if( record.getType().equals(ModelisateurRegleMessageListModel.MESSAGE_TYPE) ) {
					deleteMessage(sourceNode, record);
				}
			}

			@Override
			public void onUnlink(ModelisateurRegleMessageListModel record) {
				if( record.getType().equals(ModelisateurRegleMessageListModel.REGLE_TYPE) ) {
					if(isModifyAllow(record)){
						cancelInheritageRegle(sourceNode, record);
					}
				}
				if( record.getType().equals(ModelisateurRegleMessageListModel.MESSAGE_TYPE) ) {
					cancelInheritageMessage(sourceNode, record);
				}
			}

			@Override
			public void onGoto(ModelisateurRegleMessageListModel record) {
				//if( record.getType().equals(ModelisateurRegleMessageListModel.REGLE_TYPE) ) {
					bus.fireEvent(new ModelisateurAddTabEvent(record.getParentNode(), null, false, false, true));
				//}
			}
		};
		ccAction.setCell(cellAction);

		List<ColumnConfig<ModelisateurRegleMessageListModel, ?>> listColunm = new ArrayList<ColumnConfig<ModelisateurRegleMessageListModel, ?>>();
		listColunm.add(cclibelle);
		listColunm.add(cSourceLibelle);
		listColunm.add(ccrelation);
		listColunm.add(ccquantite);
		listColunm.add(ccIsHerritage);
		listColunm.add(ccAction);
		
		reglesMessagesGrid = new Grid<ModelisateurRegleMessageListModel>(
				reglesMessagesStore, new ColumnModel<ModelisateurRegleMessageListModel>(listColunm));
		//reglesMessagesGrid.setBorders(true);
		reglesMessagesGrid.setLoadMask(true);
		reglesMessagesGrid.setLoader(loader);
		reglesMessagesGrid.setBorders(false);
		
		reglesMessagesGrid.getView().setForceFit(true);

		reglesMessagesGrid.getView().setAutoExpandColumn(cclibelle);
		reglesMessagesGrid.setHeight(100);
		reglesMessagesGrid.getView().setAdjustForHScroll(true);
	}
	private boolean isModifyAllow(ModelisateurRegleMessageListModel node){
		int rowIndex = reglesMessagesStore.getAll().indexOf(node);
		boolean allow = true;
		if(rowUpdateIndex != -1 && rowUpdateIndex == rowIndex){
			allow = false;
		}
		return allow;
	}
	public void toggleCreateLink(boolean enable) {
//		createMessage.setEnable(enable);
//		createRegle.setEnable(enable);
		//reglesMessagesGrid.setEnabled(enable);
		if( enable ) {
			editFormContainer.setActiveWidget(emptyPanel);
			rowUpdateIndex = -1;
		}
	}

	public void displayRegleForm() {
		data1.setHeight(.3);
		data2.setHeight(.68);
		enableButtons(false);
		toggleCreateLink(false);
		regleForm.resetForm();
		editFormContainer.add(regleForm);
		editFormContainer.setActiveWidget(regleForm);
		doLayout();
	}

	public void unDisplayRegleForm() {
		data1.setHeight(.98);
		data2.setHeight(0);
		enableButtons(true);
		toggleCreateLink(true);
		regleForm.resetForm();
		editFormContainer.remove(regleForm);
		doLayout();
	}

	public void displayMessageForm() {
		data1.setHeight(.3);
		data2.setHeight(.68);
		enableButtons(false);
		toggleCreateLink(false);		
		editFormContainer.add(messageForm, new VerticalLayoutData(1,1));
		messageForm.resetForm();
		editFormContainer.setActiveWidget(messageForm);
		doLayout();
	}

	public void unDisplayMessageForm() {
		data1.setHeight(.98);
		data2.setHeight(0);
		enableButtons(true);
		toggleCreateLink(true);
		messageForm.resetForm();
		editFormContainer.remove(messageForm);
		doLayout();
	}

	public void loadListRelgeAndMessage() {
		regleMessageListLabel.setText(messages.modelisateurFormRegleGridtitle()+ " " + sourceNode.getLibelle());
		reglesMessagesStore.clear();
		//toggleCreateLink(true);
		if( sourceNode.getId() != null ) {
			loader.load();
			/*if(sourceNode.getModelType().equals(ModelNodeType.ELEMENT)){
				ClientRegleMessageServiceAsync.Util.getInstance().findReglePointToElement(sourceNode, new AsyncCallbackWithErrorResolution<List<ModelisateurRegleMessageListModel>>() {
					@Override
					public void onSuccess(List<ModelisateurRegleMessageListModel> result) {
						if( result != null ) {
							reglesMessagesStore.addAll(result);
						}
					}
				});
			}else{
				ClientRegleMessageServiceAsync.Util.getInstance().findMessageRegleList(
						sourceNode, new AsyncCallbackWithErrorResolution<List<ModelisateurRegleMessageListModel>>() {
							@Override
							public void onSuccess(List<ModelisateurRegleMessageListModel> result) {
								if( result != null ) {
									reglesMessagesStore.addAll(result);
								}
							}
						});
			}*/
		}
	}

	private void cancelInheritageRegle(final TreeNodeModel sourceNode, final ModelisateurRegleMessageListModel record) {
		String contentMessage = "<table><tr><td style='line-height:100%' >"+messages.modelisateurFormRegleConfirmUnlink()+"</td></tr></table>";
		final CustomizeConfirmMessageBox confirmBox = new CustomizeConfirmMessageBox(
				messages.commonConfirmation(), contentMessage);
		final int idUser = navigation.getContext().getUtilisateur().getIdUtilisateur();
		confirmBox.addHideHandler(new HideHandler() {
			public void onHide(HideEvent event) {
				if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
					ClientRegleMessageServiceAsync.Util.getInstance().cancelInheritageRegle(
							idUser,sourceNode, record.getId(), new AsyncCallbackWithErrorResolution<Void>() {

								@Override
								public void onSuccess(Void result) {
									reglesMessagesStore.remove(record);
								}
							});
				}
				
				else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {

				}
			}
		});
		confirmBox.show();
	}

	private void cancelInheritageMessage(final TreeNodeModel sourceNode, final ModelisateurRegleMessageListModel record) {
		String contentMessage = "<table><tr><td style='line-height:100%' >"+messages.modelisateurFormMessageConfirmUnlink()+"</td></tr></table>";
		final CustomizeConfirmMessageBox confirmBox = new CustomizeConfirmMessageBox(
				messages.commonConfirmation(), contentMessage);
		final int idUser = navigation.getContext().getUtilisateur().getIdUtilisateur();
		confirmBox.addHideHandler(new HideHandler() {
			public void onHide(HideEvent event) {
				if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
					ClientRegleMessageServiceAsync.Util.getInstance().cancelInheritageMessage(
							idUser,sourceNode, record.getId(), new AsyncCallbackWithErrorResolution<Void>() {

								@Override
								public void onSuccess(Void result) {
									reglesMessagesStore.remove(record);
								}
							});
				}
				
				else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {

				}
			}
		});
		confirmBox.show();
	}

	private void deleteRegle(final TreeNodeModel sourceNode, final ModelisateurRegleMessageListModel record) {
		String contentMessage = "<table><tr><td style='line-height:100%' >"+messages.modelisateurFormRegleConfirmDelete()+"</td></tr></table>";
		final CustomizeConfirmMessageBox confirmBox = new CustomizeConfirmMessageBox(
				messages.commonConfirmation(), contentMessage);
		final int idUser = navigation.getContext().getUtilisateur().getIdUtilisateur();
		confirmBox.addHideHandler(new HideHandler() {
			public void onHide(HideEvent event) {
				if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
					ClientRegleMessageServiceAsync.Util.getInstance().deleteRegle(
							idUser,sourceNode, record.getId(), new AsyncCallbackWithErrorResolution<Void>() {
								@Override
								public void onSuccess(Void result) {
									reglesMessagesStore.remove(record);
								}
							});
				}
				else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {

				}

			}
		});
		confirmBox.show();
	}

	private void deleteMessage(final TreeNodeModel sourceNode, final ModelisateurRegleMessageListModel record) {
		String contentMessage = "<table><tr><td style='line-height:100%' >"+messages.modelisateurFormMessageConfirmDelete()+"</td></tr></table>";
		final CustomizeConfirmMessageBox confirmBox = new CustomizeConfirmMessageBox(
				messages.commonConfirmation(), contentMessage);
		final int idUser = navigation.getContext().getUtilisateur().getIdUtilisateur();
		confirmBox.addHideHandler(new HideHandler() {
			public void onHide(HideEvent event) {
				if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
					ClientRegleMessageServiceAsync.Util.getInstance().deleteMessage(
							idUser,sourceNode, record.getId(), new AsyncCallbackWithErrorResolution<Void>() {
								@Override
								public void onSuccess(Void result) {
									reglesMessagesStore.remove(record);
								}
							});
				}
				else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {

				}

			}
		});
		confirmBox.show();
	}
	
	public void enableButtons (boolean enable){
		createMessage.setEnable(enable);
		createRegle.setEnable(enable);
	}

	public CardLayoutContainer getEditFormContainer() {
		return editFormContainer;
	}

	public void setEditFormContainer(CardLayoutContainer editFormContainer) {
		this.editFormContainer = editFormContainer;
	}

	public ListStore<ModelisateurRegleMessageListModel> getReglesMessagesStore() {
		return reglesMessagesStore;
	}

	public void setReglesMessagesStore(ListStore<ModelisateurRegleMessageListModel> reglesMessagesStore) {
		this.reglesMessagesStore = reglesMessagesStore;
	}

	public Grid<ModelisateurRegleMessageListModel> getReglesMessagesGrid() {
		return reglesMessagesGrid;
	}

	public void setReglesMessagesGrid(Grid<ModelisateurRegleMessageListModel> reglesMessagesGrid) {
		this.reglesMessagesGrid = reglesMessagesGrid;
	}

	public int getRowUpdateIndex() {
		return rowUpdateIndex;
	}

	public void setRowUpdateIndex(int rowUpdateIndex) {
		this.rowUpdateIndex = rowUpdateIndex;
	}
	
	public void resetForm (){
		unDisplayRegleForm();
		regleForm.resetForm();
		unDisplayMessageForm();
		messageForm.resetForm();
	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	public boolean isChanged() {
		changed = regleForm.isChanged() || messageForm.isChanged();
		return changed;
	}

	public HtmlButton getCreateMessage() {
		return createMessage;
	}

	public void setCreateMessage(HtmlButton createMessage) {
		this.createMessage = createMessage;
	}

	public HtmlButton getCreateRegle() {
		return createRegle;
	}

	public void setCreateRegle(HtmlButton createRegle) {
		this.createRegle = createRegle;
	}
}
