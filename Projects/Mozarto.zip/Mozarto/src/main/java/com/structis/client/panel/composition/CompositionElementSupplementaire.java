package com.structis.client.panel.composition;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.dom.ScrollSupport.ScrollMode;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.data.shared.SortInfo;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutData;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.SortChangeEvent;
import com.sencha.gxt.widget.core.client.event.SortChangeEvent.SortChangeHandler;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.structis.client.widget.AddElementWindow;
import com.structis.client.widget.CustomizePanel;
import com.structis.client.widget.ElementAutonomeGrid;
import com.structis.client.widget.HtmlButton;

public class CompositionElementSupplementaire extends CustomizePanel {


//	private final Messages messages = GWT.create(Messages.class);

	private HtmlButton ajouterLink;
	
	private AddElementWindow addElementWindow;
	
	private ElementAutonomeGrid elementAutonomeGrid;
	
	private SortInfo sortInfo;

	private HTML collapseButtonTop;

	private HTML collapseButtonBottom;

//	private Images images = GWT.create(Images.class);

	private VerticalLayoutContainer container;

	private HBoxLayoutContainer linkcontainer;

	private Label collapseLabel;
	
	//private NavigationService navigation = NavigationFactory.getNavigation();
	
	public CompositionElementSupplementaire(SimpleEventBus bus) {
		super(bus);
	}

	@Override
	public VerticalLayoutContainer buildPanel() {
		VerticalLayoutContainer verticalLayoutContainer = new VerticalLayoutContainer();
		final FieldSet eltFieldSet = new FieldSet();
		eltFieldSet.setStyleName("fieldsetPadding");
		eltFieldSet.setHeadingText(messages.compositionRightElementgridEltsup());
		verticalLayoutContainer.add(eltFieldSet, new VerticalLayoutData(1, 1));
		 
		container = new VerticalLayoutContainer();
		eltFieldSet.add(container, new VerticalLayoutData(1, 1));

		linkcontainer = new HBoxLayoutContainer();
		collapseButtonTop = new HTML();

		Image collapseIcon = new Image();
		collapseIcon.setPixelSize(16, 16);
		collapseIcon.setResource(images.collapseBottom());
		collapseButtonTop.setHTML(collapseIcon+"");
		collapseButtonTop.setStyleName("searchButton");
		linkcontainer.add(collapseButtonTop);
		
        BoxLayoutData flex = new BoxLayoutData(new Margins(0, 5, 0, 0));
        flex.setFlex(1);
        linkcontainer.add(new Label(), flex);
		
//		linkcontainer.setStyleName("whiteBackGround");
		ajouterLink = new HtmlButton("> " + messages.compositionRightElementgridAjouterelt());
		//ajouterLink.setStyleName("htmlLink");
		ajouterLink.getHtml().setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		ajouterLink.getHtml().setWidth("auto");
		linkcontainer.add(ajouterLink);
		
		container.add(linkcontainer);
		container.setScrollMode(ScrollMode.AUTO);
		linkcontainer.setWidth("auto");
		
		
		elementAutonomeGrid = new ElementAutonomeGridWithPagingTmpData(bus);
		
	    container.add(elementAutonomeGrid, new VerticalLayoutData(1, 0.90));
	    
	    addElementWindow = new AddElementWindow(bus, this);
	    addElementWindow.setModal(true);
	    addElementWindow.setBlinkModal(true);
		collapseButtonBottom = new HTML();

		Image collapseIcon2 = new Image();
		collapseIcon2.setPixelSize(16, 16);
		collapseIcon2.setResource(images.collapseRight());
		collapseButtonBottom.setHTML(collapseIcon2+"");
		collapseButtonBottom.setStyleName("searchButton");
		container.add(collapseButtonBottom);
	
		container.addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent arg0) {
				linkcontainer.setWidth("auto");
			}
		});
		container.setBorders(false);
		return verticalLayoutContainer;
		
	}

	@Override
	public void addHandler() {
		ajouterLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				addElementWindow.show();
				
			}
		});
		elementAutonomeGrid.getGrid().addSortChangeHandler(new SortChangeHandler() {

			@Override
			public void onSortChange(SortChangeEvent event) {
				setSortInfo(event.getSortInfo());
				
			}
		});
		addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent arg0) {
				collapsePanel.setHeight(arg0.getHeight());
				if (arg0.getWidth() > 50)
					ajouterLink.setWidth(arg0.getWidth() - 50);
			}
		});
		
	}

	@Override
	public HorizontalLayoutContainer buildCollapsePanel() {
		HorizontalLayoutContainer container = new HorizontalLayoutContainer();
		return container;
	}

	public ElementAutonomeGrid getElementAutonomeGrid() {
		return elementAutonomeGrid;
	}

	public void setElementAutonomeGrid(ElementAutonomeGrid elementAutonomeGrid) {
		this.elementAutonomeGrid = elementAutonomeGrid;
	}

	public void setSortInfo(SortInfo sortInfo) {
		this.sortInfo = sortInfo;
	}

	public SortInfo getSortInfo() {
		return sortInfo;
	}

	public HTML getCollapseButtonTop() {
		return collapseButtonTop;
	}

	public void setCollapseButtonTop(HTML collapseButton) {
		this.collapseButtonTop = collapseButton;
	}

	public HTML getCollapseButtonBottom() {
		return collapseButtonBottom;
	}

	public void setCollapseButtonBottom(HTML collapseButtonBottom) {
		this.collapseButtonBottom = collapseButtonBottom;
	}

	public Label getCollapseLabel() {
		return collapseLabel;
	}

	public void setCollapseLabel(Label collapseLabel) {
		this.collapseLabel = collapseLabel;
	}
	
	public void toogleAddElementLink(boolean enable){
		if(enable){
			ajouterLink.setEnable(enable);
		}
	}
}
