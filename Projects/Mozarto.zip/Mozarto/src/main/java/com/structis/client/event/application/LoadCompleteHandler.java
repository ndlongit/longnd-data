package com.structis.client.event.application;

import com.google.gwt.event.shared.EventHandler;

public interface LoadCompleteHandler extends EventHandler {
	
	void onLoad(LoadCompleteEvent event);

}
