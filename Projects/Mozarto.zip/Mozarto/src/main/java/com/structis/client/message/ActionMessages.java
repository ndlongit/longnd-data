package com.structis.client.message;

import com.google.gwt.i18n.client.ConstantsWithLookup;
/**
 * Interface that contains the associated resource consultants ActionMessages
 * to display the wire breadcrum
 * 
 * 
 */
public interface ActionMessages extends ConstantsWithLookup {
	/* ### Les actions */
	@Key("action.acceuil")
	String actionAcceuil();
	@Key("action.login")
	String actionAdmin();
	
	@Key("action.modelisateur.modelisateur")
	String actionModelisateurModelisateur();
	@Key("action.modelisateur.accueil")
	String actionModelisateurAccueil();
	@Key("action.compositeur")
	String actionCompositeur();
	@Key("action.compositeur.accueil")
	String actionCompositeurAccueil();
	@Key("action.gestiondumetier")
	String actionGestionDuMetier();
	@Key("action.gestiondesmetiers")
	String actionGestionDesMetiers();
	@Key("action.gestiondesutilisateurs")
	String actionGestionDesUtilisateurs();
	@Key("action.gestiondesutilisateursadmin")
	String actionGestionDesUtilisateursAdminGeneral();
	@Key("action.gestiondeselementsdecomposition")
	String actionGestionDesElementsDeComposition();
	
}
