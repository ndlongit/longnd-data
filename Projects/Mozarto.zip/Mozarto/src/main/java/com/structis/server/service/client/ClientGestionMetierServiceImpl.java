package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoadResultBean;
import com.structis.client.service.ClientGestionMetierService;
import com.structis.server.core.ConstantError;
import com.structis.server.service.domain.AttributEtenduService;
import com.structis.server.service.domain.HabilitationUtilisateurService;
import com.structis.server.service.domain.MetierLienPegazService;
import com.structis.server.service.domain.MetierService;
import com.structis.server.service.domain.PzMetierService;
import com.structis.server.service.domain.UtilisateurService;
import com.structis.shared.constant.Constant;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.HabilitationUtilisateur;
import com.structis.shared.model.Metier;
import com.structis.shared.model.MetierLienPegaz;
import com.structis.shared.model.PzMetier;
import com.structis.shared.model.reference.MetierMzPzModel;
import com.structis.shared.security.Role;

@Service("gestionMetierServiceImpl")
public class ClientGestionMetierServiceImpl implements ClientGestionMetierService {

	@Autowired
	MetierService metierService;
	
	@Autowired
	AttributEtenduService attributEtenduService;
	
	@Autowired
	PzMetierService pzMetierService;
	
	@Autowired
	MetierLienPegazService metierLienPegazService;
	
	@Autowired
	UtilisateurService utilisateurService;
	
	@Autowired
	HabilitationUtilisateurService habilitationUtilisateurService;

	@Override
	public PagingLoadResult<MetierMzPzModel> findAll(PagingLoadConfig loadConfig){
		List<MetierMzPzModel> findAllPegaz = metierService.findAllPegaz();
		List<MetierMzPzModel> sublist = new ArrayList<MetierMzPzModel>();
		int start = loadConfig.getOffset();
	    int limit = findAllPegaz.size();
	    if (loadConfig.getLimit() > 0) {
		      limit = Math.min(start + loadConfig.getLimit(), limit);
		}
	    for (int i = loadConfig.getOffset(); i < limit; i++) {
	    	MetierMzPzModel m = findAllPegaz.get(i);

			if(Constant.METIER_ADMIN.equals(m.getLLibelle().trim()))
				sublist.add(0,m);
			else
				sublist.add(m);
	    }
		return new PagingLoadResultBean<MetierMzPzModel>(sublist, findAllPegaz.size(), loadConfig.getOffset());
	}

	@Override
	public Metier insertOrUpdate(MetierMzPzModel metier, List<AttributEtendu> attributEtendus) {
		List<Metier> metierByLibelle = metierService.findByLibelle(metier.getLLibelle());
		Integer idMetier = metier.getIdMetier();
		if (metierByLibelle.size() > 1 || (metierByLibelle.size() == 1 && !metierByLibelle.get(0).getIdMetier().equals(idMetier))){
			throw new FunctionalException(ConstantError.ERR_DUPLICATED);
		}
		
		Metier mzMetier = new Metier();
		mzMetier.setCMetier("");
		mzMetier.setInActif(metier.getInActif());
		mzMetier.setLLibelle(metier.getLLibelle());
		
		PzMetier pzMetier = new PzMetier();
		if(metier.getCMetierPegaz() != null)
			pzMetier.setCMetierpegaz(metier.getCMetierPegaz());
		else
			pzMetier.setCMetierpegaz("");
		if(metier.getCSocieteSm() != null)
			pzMetier.setCSocieteSm(metier.getCSocieteSm());
		else
			pzMetier.setCSocieteSm("");
		
		short findMaxRang = attributEtenduService.findMaxRang();
		int rang = findMaxRang + 1;
		
		if(idMetier != null){
			mzMetier.setIdMetier(metier.getIdMetier());
			metierService.update(mzMetier);
			
			if(metier.getIdMetierPegaz() != null){
				pzMetier.setIdMetierpegaz(metier.getIdMetierPegaz());
				pzMetierService.update(pzMetier);
				
			}
			
			List<AttributEtendu> attListToBeInserted = new ArrayList<AttributEtendu>();
	
			for(AttributEtendu attributEtendu : attributEtendus){
				if (attributEtendu.getLLibelle() != null && !attributEtendu.getLLibelle().equals("")){
					if (attributEtendu.getIdAttributEtendu() == null){
						attributEtendu.setCLabelAttributEtendu("");
						attributEtendu.setIdMetier(idMetier);
						
						attributEtendu.setNRang((short) rang);
						attListToBeInserted.add(attributEtendu);
					}
					else {
						attributEtenduService.update(attributEtendu);
					}
				}
			}
			if (attListToBeInserted.size() > 0){
				attributEtenduService.insertList(attListToBeInserted);
			}
		}
		else{
			metierService.insert(mzMetier);
//			mzMetier = metierService.findByLibelle(metier.getLLibelle()).get(0);
			idMetier = mzMetier.getIdMetier();
			if(attributEtendus != null && attributEtendus.size() > 0){
				for(AttributEtendu attributEtendu : attributEtendus){
					if (attributEtendu.getLLibelle() != null && !attributEtendu.getLLibelle().equals("")){
						attributEtendu.setCLabelAttributEtendu("");
						attributEtendu.setIdMetier(idMetier);
						
						attributEtendu.setNRang((short) rang);
					}
					else {
						attributEtendus.remove(attributEtendu);
					}
				}
				attributEtenduService.insertList(attributEtendus);
			}
			pzMetierService.insert(pzMetier);
			MetierLienPegaz lienPegaz = new MetierLienPegaz();
			lienPegaz.setIdMetier(mzMetier.getIdMetier());
			lienPegaz.setIdMetierPegaz(pzMetier.getIdMetierpegaz());
			metierLienPegazService.insert(lienPegaz);
			List<Integer> idUtilisateurList = utilisateurService.findAllIdUtilisateur();
			List<HabilitationUtilisateur> list = new ArrayList<HabilitationUtilisateur>();
			for (Integer k : idUtilisateurList){
				HabilitationUtilisateur h = new HabilitationUtilisateur();
				h.setIdUtilisateur(k);
				h.setIdMetier(idMetier);
				h.setCRole(Role.UTILISATEURINVITE.getCode());
				h.setInDefaut(false);
				list.add(h);
			}
			habilitationUtilisateurService.insertList(list);
		}
		return mzMetier;
	}
	
	
}
