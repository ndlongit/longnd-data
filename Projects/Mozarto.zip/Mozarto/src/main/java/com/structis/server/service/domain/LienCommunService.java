package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlLienCommun;

public interface LienCommunService {
	int insert(MdlLienCommun lienCommun);
	
	public int getIdLienCommmun(int idModeleVersion, int sourceId, String typeLien,boolean createOption);
	
	public MdlLienCommun findById(int idLienCommun);

	public void deleteByIdLienCoummuns(int idModeleVersion, List<Integer> idLienCommuns);
	
	public MdlLienCommun getLienCommmun(int idModeleVersion, int sourceId, String typeLien,boolean createOption);
}
