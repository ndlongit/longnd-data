package com.structis.client.widget;

import com.sencha.gxt.data.shared.loader.PagingLoadResult;

public interface CustomizePagingLoadResult<Data> extends PagingLoadResult<Data>{
	public int  getfinalTotal();
	public void setfinalTotal(int realTotal);
}
