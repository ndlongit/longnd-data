
package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.CompositionElementGridModel;
/**
 * 
 * @author vinh.tong
 *
 */
public interface CompositionElementGridModelProperties extends PropertyAccess<CompositionElementGridModel> {
  ModelKeyProvider<CompositionElementGridModel> idElement();
	
  ValueProvider<CompositionElementGridModel, String> cElement();

  ValueProvider<CompositionElementGridModel, String> lLibelleLong();

  ValueProvider<CompositionElementGridModel, String> lNomenclatureFournisseur();

  ValueProvider<CompositionElementGridModel, Integer> quantite();
  ValueProvider<CompositionElementGridModel, Integer> idReference();
  ValueProvider<CompositionElementGridModel, String> libeleReference();
  ValueProvider<CompositionElementGridModel, Integer> relation();
  ValueProvider<CompositionElementGridModel, Integer> status();
  ValueProvider<CompositionElementGridModel, Integer> order();
  //ValueProvider<CompositionElementGridModel, Void> fake();
}
