package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.Import;

public interface ImportService {
	public static final String SERVIECE_NAME = "importService";

	public Import findById(Integer id);

	public Integer insert(Import record);

	public Integer update(Import record);

	public Integer delete(Import record);

	public Integer deleteById(Integer id);

	public List<Import> findAll();

	public List<Import> findIdsByImportType(String typeImport);

	public List<Import> findByCriteria(String typeImport, List<String> statusList);

	public Import insertNewImportItem(Integer metierId, Integer userId, String importType);

	void deletePreviousImportedData(int importId);
}
