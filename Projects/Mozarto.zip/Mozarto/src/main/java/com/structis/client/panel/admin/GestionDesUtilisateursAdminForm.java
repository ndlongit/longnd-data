package com.structis.client.panel.admin;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.text.shared.AbstractSafeHtmlRenderer;
import com.sencha.gxt.cell.core.client.form.ComboBoxCell.TriggerAction;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.core.client.XTemplates;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.data.shared.Converter;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.AbstractHtmlLayoutContainer.HtmlData;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.HtmlLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.BeforeStartEditEvent;
import com.sencha.gxt.widget.core.client.event.BeforeStartEditEvent.BeforeStartEditHandler;
import com.sencha.gxt.widget.core.client.event.CompleteEditEvent;
import com.sencha.gxt.widget.core.client.event.CompleteEditEvent.CompleteEditHandler;
import com.sencha.gxt.widget.core.client.event.FocusEvent;
import com.sencha.gxt.widget.core.client.event.FocusEvent.FocusHandler;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.form.ComboBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.PasswordField;
import com.sencha.gxt.widget.core.client.form.PropertyEditor;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.grid.editing.GridEditing;
import com.sencha.gxt.widget.core.client.grid.editing.GridInlineEditing;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.GestionUtilisateurDisableUtilisateurEvent;
import com.structis.client.event.GestionUtilisateurDisableUtilisateurHandler;
import com.structis.client.event.GestionUtilisateurRenameUtilisateurEvent;
import com.structis.client.event.ModifyEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.properties.RoleUtilisateurProperties;
import com.structis.client.properties.UtilisateurMetierRoleModelProperties;
import com.structis.client.service.ClientGestionUtilisateursServiceAsync;
import com.structis.client.widget.HtmlButton;
import com.structis.client.widget.RadioCell;
import com.structis.shared.model.RoleUtilisateur;
import com.structis.shared.model.Utilisateur;
import com.structis.shared.model.reference.UtilisateurMetierRoleModel;
import com.structis.shared.security.Role;

public class GestionDesUtilisateursAdminForm extends ContentPanel {

	private static final int MDP_MAX_LENGTH = 10;

	private static final int IDPEGAZ_MAX_LENGTH = 5;

	private static final int IDMOZARTO_MAX_LENGTH = 50;

	private static final int MAIL_MAX_LENGTH = 64;

	private static final int NOM_MAX_LENGTH = 50;

	private static final int PRENOM_MAX_LENGTH = 50;

	private SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private String tabLabel = "";

	private Utilisateur utilisateur;

	private TextButton validerButton;

	private HtmlButton annulerButton;

	private ListStore<RoleUtilisateur> roleStore;

	private HtmlLayoutContainer infoContainer;

	private VerticalLayoutContainer statutContainer;

	private VerticalLayoutContainer container;

	private TextField idMozarto;

	private TextField idPegaz;

	private TextField nom;

	private TextField prenom;

	private TextField mail;

	private boolean isChanged = false;

	private Integer idMetier;

	private CheckBox actif;

	private PasswordField password;

	private FieldLabel idMozartoField;

	private FieldLabel passwordField;

	private FieldLabel idPegazField;

	private FieldLabel nomField;

	private FieldLabel prenomField;

	private FieldLabel mailField;

	private FieldSet autorisationFieldset;

	private Grid<UtilisateurMetierRoleModel> autorisationGrid;

	private ListStore<UtilisateurMetierRoleModel> store;

	private VerticalLayoutContainer autorisationContainer;

	private GridEditing<UtilisateurMetierRoleModel> editing;

	private ComboBox<RoleUtilisateur> combo;

	private ColumnConfig<UtilisateurMetierRoleModel, String> role;
	
	private List<RoleUtilisateur> roleAdmin;
	
	private List<RoleUtilisateur> roleNonAdmin;
	
	private String idMozartotmp = "";
	
	private String idPegaztmp = "";
	
	private String passwordtmp = "";
	
	private String nomtmp = "";
	
	private String prenomtmp = "";
	
	private String mailtmp = "";

	private List<UtilisateurMetierRoleModel> metiers;

	interface ComboBoxTemplates extends XTemplates {

		@XTemplate("<div  style = \"height:11px;\" >&nbsp;{lLibelle}</div>")
		SafeHtml state(String lLibelle);

	}
	
	public GestionDesUtilisateursAdminForm(SimpleEventBus bus) {
		this.bus = bus;
		buildForm();
		addHandler();
	}

	private void buildForm() {
		setHeaderVisible(false);
		container = new VerticalLayoutContainer();
		infoContainer = new HtmlLayoutContainer(getTableMarkup());

		actif = new CheckBox();
		actif.setBoxLabel(messages.metiersFormActif());
		actif.setValue(true);
		infoContainer.add(actif, new HtmlData(".actif"));
		idMozarto = new TextField();
		idMozartoField = new FieldLabel(idMozarto, messages.utilisateursIdMozarto());
		infoContainer.add(idMozartoField, new HtmlData(".idmz"));
		password = new PasswordField();
		passwordField = new FieldLabel(password, messages.utilisateursMotdepasse());
		infoContainer.add(passwordField, new HtmlData(".mdp"));
		idPegaz = new TextField();
		idPegazField = new FieldLabel(idPegaz, messages.utilisateursIdPegaz());
		infoContainer.add(idPegazField, new HtmlData(".idpz"));
		nom = new TextField();
		nomField = new FieldLabel(nom, messages.utilisateursNom());
		infoContainer.add(nomField, new HtmlData(".nom"));
		prenom = new TextField();
		prenomField = new FieldLabel(prenom, messages.utilisateursPrenom());
		infoContainer.add(prenomField, new HtmlData(".prenom"));
		mail = new TextField();
		mailField = new FieldLabel(mail, messages.utilisateursMail());
		infoContainer.add(mailField, new HtmlData(".mail"));
		infoContainer.getElement().setPadding(new Padding(10, 30, 10, 30));
		container.add(infoContainer, new VerticalLayoutData(1, -1));

		autorisationFieldset = new FieldSet();
		autorisationFieldset.setHeadingText(messages.utilisateursAutorisations());
		container.add(autorisationFieldset, new VerticalLayoutData(1, 1));

		autorisationContainer = new VerticalLayoutContainer();
		autorisationFieldset.add(autorisationContainer);

		UtilisateurMetierRoleModelProperties properties = GWT.create(UtilisateurMetierRoleModelProperties.class);
		ColumnConfig<UtilisateurMetierRoleModel, String> metier = new ColumnConfig<UtilisateurMetierRoleModel, String>(
				properties.libelleMetier(), 200, messages.utilisateursMetier());
		role = new ColumnConfig<UtilisateurMetierRoleModel, String>(properties.libelleRole(), 200, messages.utilisateursFonction());
		ColumnConfig<UtilisateurMetierRoleModel, UtilisateurMetierRoleModel> defaut = new ColumnConfig<UtilisateurMetierRoleModel, UtilisateurMetierRoleModel>(
				new IdentityValueProvider<UtilisateurMetierRoleModel>());
		defaut.setHeader(messages.utilisateursMetierpardefaut());

		List<ColumnConfig<UtilisateurMetierRoleModel, ?>> columns = new ArrayList<ColumnConfig<UtilisateurMetierRoleModel, ?>>();
		columns.add(metier);
		columns.add(role);
		columns.add(defaut);

		ColumnModel<UtilisateurMetierRoleModel> columnModel = new ColumnModel<UtilisateurMetierRoleModel>(columns);

		store = new ListStore<UtilisateurMetierRoleModel>(properties.idMetier());
		autorisationGrid = new Grid<UtilisateurMetierRoleModel>(store, columnModel);
		autorisationGrid.getView().setAutoFill(true);
		autorisationGrid.getView().setAutoExpandColumn(metier);
		autorisationContainer.add(autorisationGrid, new VerticalLayoutData(1, 0.90));

		editing = new GridInlineEditing<UtilisateurMetierRoleModel>(autorisationGrid);
//		combo = new SimpleComboBox<Roles>(new StringLabelProvider<Roles>());
		RoleUtilisateurProperties props = GWT.create(RoleUtilisateurProperties.class);
		roleStore = new ListStore<RoleUtilisateur>(props.cRole());
		combo = new ComboBox<RoleUtilisateur>(
				roleStore, props.lLibelle(), new AbstractSafeHtmlRenderer<RoleUtilisateur>() {

					@Override
					public SafeHtml render(RoleUtilisateur item) {
						final ComboBoxTemplates comboBoxTemplates = GWT.create(ComboBoxTemplates.class);
						return comboBoxTemplates.state(item.getLLibelle());
					}
				});
		
		combo.setPropertyEditor(new PropertyEditor<RoleUtilisateur>() {

			@Override
			public String render(RoleUtilisateur object) {
				return object == null ? "" : object.getLLibelle();
			}

			@Override
			public RoleUtilisateur parse(CharSequence arg0) throws ParseException {
				return findRoleByLibelle(arg0.toString(), combo.getStore().getAll());
			}
		});
		combo.setTriggerAction(TriggerAction.ALL);
		combo.setForceSelection(true);
		editing.addEditor(role, new Converter<String, RoleUtilisateur>() {

			@Override
			public String convertFieldValue(RoleUtilisateur object) {
				return object == null ? "" : object.getLLibelle();
			}

			@Override
			public RoleUtilisateur convertModelValue(String object) {
				return findRoleByLibelle(object, combo.getStore().getAll());
			}

		}, combo);

		RadioCell radio = new RadioCell() {

			@Override
			public void onUncheck(UtilisateurMetierRoleModel u) {
				if(!u.getIsReadOnlyRadio()){
					u.setInDefaut(false);
					autorisationGrid.getStore().update(u);
					toggleChange(true);
				}
			}

			@Override
			public void onCheck(UtilisateurMetierRoleModel u) {
				if(!u.getIsReadOnlyRadio()){
					u.setInDefaut(true);
					autorisationGrid.getStore().update(u);
					toggleChange(true);
				}
			}
		};

		defaut.setCell(radio);

		add(container);
		annulerButton = new HtmlButton(messages.commonAnnulerButton());
		annulerButton.setStyleName("htmlLink");
		addButton(annulerButton);

		validerButton = new TextButton(messages.commonValiderButton());
		addButton(validerButton);
		setButtonAlign(BoxLayoutPack.CENTER);
		getButtonBar().setSpacing(30);
		getBody().setBorders(false);
		enableButtons(false);

	}

	public void loadGridData() {
		final Integer id;
		if( utilisateur != null )
			id = utilisateur.getIdUtilisateur();
		else
			id = -1;
		ClientGestionUtilisateursServiceAsync.Util.getInstance().getAllMetier(
				id, new AsyncCallbackWithErrorResolution<List<UtilisateurMetierRoleModel>>() {

					@Override
					public void onSuccess(List<UtilisateurMetierRoleModel> arg0) {
						metiers = new LinkedList<UtilisateurMetierRoleModel>();
						metiers.addAll(arg0);
						ClientGestionUtilisateursServiceAsync.Util.getInstance().findAllRole(new AsyncCallbackWithErrorResolution<List<RoleUtilisateur>>() {

							@Override
							public void onSuccess(List<RoleUtilisateur> arg0) {
								RoleUtilisateur newRole = new RoleUtilisateur();
								newRole.setCRole("");
								newRole.setLLibelle("");
								roleAdmin = new ArrayList<RoleUtilisateur>();
								roleNonAdmin = new ArrayList<RoleUtilisateur>();
								roleAdmin.add(newRole);
								roleNonAdmin.add(newRole);
								
								for(RoleUtilisateur r : arg0){
									if(Role.ADMINISTRATEURGENERAL.getCode().equals(r.getCRole())){
										roleAdmin.add(r);
									}
									else{
										roleNonAdmin.add(r);
									}
								}
								List<UtilisateurMetierRoleModel> l = new LinkedList<UtilisateurMetierRoleModel>();
								for(UtilisateurMetierRoleModel m : metiers){
									if(utilisateur == null){
										m.setInDefaut(false);
										if(!ConstantClient.ADMINISTRATION_METIER.equals(m.getLibelleMetier().trim())){
											m.setCRole(Role.UTILISATEURINVITE.getCode());
											m.setLibelleRole(findRoleByCode(Role.UTILISATEURINVITE.getCode(), arg0).getLLibelle());
											m.setIsReadOnlyRadio(false);
										}
									}
									if(ConstantClient.ADMINISTRATION_METIER.equals(m.getLibelleMetier().trim()))
										l.add(0, m);
									else
										l.add(m);
								}
								store.replaceAll(l);
							}
						});
					}
				});
	}

	protected void addHandler() {
		addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent arg0) {
				container.setWidth(arg0.getWidth());
				container.setHeight(arg0.getHeight());
			}
		});
		container.addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent arg0) {
				int w = arg0.getWidth() - 150;
				infoContainer.setWidth(w);
				autorisationContainer.setHeight("auto");
				idMozartoField.setWidth(w / 2);
				passwordField.setWidth(w / 2);
				idPegazField.setWidth(w / 2);
				nomField.setWidth(w / 2);
				prenomField.setWidth(w / 2);
				mailField.setWidth(w + 45);
			}
		});
		validerButton.addSelectHandler(new SelectHandler() {
			
			@Override
			public void onSelect(SelectEvent event) {
				validerForm();
			}
		});
		annulerButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				annulerForm();
			}
		});
		editing.addBeforeStartEditHandler(new BeforeStartEditHandler<UtilisateurMetierRoleModel>() {

			@Override
			public void onBeforeStartEdit(BeforeStartEditEvent<UtilisateurMetierRoleModel> event) {
				combo.getStore().clear();
				
				if( ConstantClient.ADMINISTRATION_METIER.equals(store.get(event.getEditCell().getRow()).getLibelleMetier().trim()) ) {
					combo.getStore().replaceAll(roleAdmin);
				}
				else {
					combo.getStore().replaceAll(roleNonAdmin);
				}
			}
		});
		idMozarto.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				idMozartotmp = idMozarto.getText();
			}
		});
		idMozarto.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if (idMozarto.getText().length() > IDMOZARTO_MAX_LENGTH){
					idMozarto.reset();
					idMozarto.setText(idMozarto.getText().substring(0, IDMOZARTO_MAX_LENGTH));
				}
				else {
					if(!idMozartotmp.equals(idMozarto.getText())){
						toggleChange(true);
					}
				}
			}
		});
		idMozarto.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				enableButtons(true);
				isChanged = true;
			}
		});
		idPegaz.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				idPegaztmp = idMozarto.getText();
			}
		});
		idPegaz.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if (idPegaz.getText().length() > IDPEGAZ_MAX_LENGTH){
					idPegaz.reset();
					idPegaz.setText(idPegaz.getText().substring(0, IDPEGAZ_MAX_LENGTH));
				}
				else {
					if(!idPegaztmp.equals(idPegaz.getText())){
						toggleChange(true);
					}
				}
			}
		});
		idPegaz.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				enableButtons(true);
				isChanged = true;
			}
		});
		password.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				passwordtmp = password.getText();
			}
		});
		password.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if (password.getText().length() > MDP_MAX_LENGTH){
					password.reset();
					password.setText(password.getText().substring(0, MDP_MAX_LENGTH));
				}
				else {
					if(!passwordtmp.equals(password.getText())){
						toggleChange(true);
					}
				}
			}
		});
		password.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				enableButtons(true);
				isChanged = true;
			}
		});
		nom.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				nomtmp = nom.getText();
			}
		});
		nom.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if (nom.getText().length() > NOM_MAX_LENGTH){
					nom.reset();
					nom.setText(nom.getText().substring(0, NOM_MAX_LENGTH));
				}
				else {
					if(!nomtmp.equals(nom.getText())){
						toggleChange(true);
					}
				}
			}
		});
		nom.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				enableButtons(true);
				isChanged = true;
			}
		});
		prenom.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				prenomtmp = prenom.getText();
			}
		});
		prenom.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if (prenom.getText().length() > PRENOM_MAX_LENGTH){
					prenom.reset();
					prenom.setText(prenom.getText().substring(0, PRENOM_MAX_LENGTH));
				}
				else {
					if(!prenomtmp.equals(prenom.getText())){
						toggleChange(true);
					}
				}
			}
		});
		prenom.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				enableButtons(true);
				isChanged = true;
			}
		});
		mail.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				mailtmp = mail.getText();
			}
		});
		mail.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if (mail.getText().length() > MAIL_MAX_LENGTH){
					mail.reset();
					mail.setText(mail.getText().substring(0, MAIL_MAX_LENGTH));
				}
				else {
					if(!mailtmp.equals(mail.getText())){
						toggleChange(true);
					}
				}
			}
		});
		mail.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				enableButtons(true);
				isChanged = true;
			}
		});
		actif.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				enableButtons(true);
				isChanged = true;
			}
		});
		editing.addCompleteEditHandler(new CompleteEditHandler<UtilisateurMetierRoleModel>() {

			@Override
			public void onCompleteEdit(CompleteEditEvent<UtilisateurMetierRoleModel> event) {
				UtilisateurMetierRoleModel tmp = store.get(event.getEditCell().getRow());
				if(combo.getValue() != null){
					tmp.setCRole(combo.getValue().getCRole());
					tmp.setIsReadOnlyRadio(false);
				}
				else{
					tmp.setCRole("");
					tmp.setIsReadOnlyRadio(true);
					tmp.setInDefaut(false);
				}
				store.update(tmp);
				toggleChange(true);
			}
		});
		bus.addHandler(GestionUtilisateurDisableUtilisateurEvent.getType(), new GestionUtilisateurDisableUtilisateurHandler() {
			
			@Override
			public void onLoad(GestionUtilisateurDisableUtilisateurEvent event) {
				if(utilisateur != null && event != null && event.getIdUtilisateur().equals(utilisateur.getIdUtilisateur())){
					actif.setValue(false);
					toggleChange(true);
				}
			}
		});
	}

	public void validerForm() {
		if(idMozarto.getText().equals("")){
			showMessage(messages.utilisateursChampObligatoire(messages.utilisateursIdMozarto()));
			return;
		}
		if(password.getText().equals("")){
			showMessage(messages.utilisateursChampObligatoire(messages.utilisateursMotdepasse()));
			return;
		}
		if(nom.getText().equals("")){
			showMessage(messages.utilisateursChampObligatoire(messages.utilisateursNom()));
			return;
		}
		if(prenom.getText().equals("")){
			showMessage(messages.utilisateursChampObligatoire(messages.utilisateursPrenom()));
			return;
		}
		if(mail.getText().equals("")){
			showMessage(messages.utilisateursChampObligatoire(messages.utilisateursMail()));
			return;
		}
		if(!isValidEmailAddress(mail.getText())){
			showMessage(messages.utilisateursMailIncorrect());
			return;
		}
		if(idPegaz.getText().length() > IDPEGAZ_MAX_LENGTH){
			showMessage(messages.utilisateursLimit(messages.utilisateursIdPegaz(), IDPEGAZ_MAX_LENGTH));
			return;
		}
		if(idMozarto.getText().length() > IDMOZARTO_MAX_LENGTH){
			showMessage(messages.utilisateursLimit(messages.utilisateursIdMozarto(), IDMOZARTO_MAX_LENGTH));
			return;
		}
		if(password.getText().length() > MDP_MAX_LENGTH){
			showMessage(messages.utilisateursLimit(messages.utilisateursMotdepasse(), MDP_MAX_LENGTH));
			return;
		}
		if(mail.getText().length() > MAIL_MAX_LENGTH){
			showMessage(messages.utilisateursLimit(messages.utilisateursMail(), MAIL_MAX_LENGTH));
			return;
		}
		if(!actif.getValue()){
			final ConfirmMessageBox box = new ConfirmMessageBox(messages.commonConfirmDesactiver(), messages.utilisateursConfirmdelete());
			box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
			box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
			box.addHideHandler(new HideHandler() {
				
				@Override
				public void onHide(HideEvent event) {
					if(box.getHideButton() == box.getButtonById(PredefinedButton.YES.name())){
						insertOrUpdate();
					}
				}
			});
			box.show();
		}
		else {
			insertOrUpdate();
		}
	}

	private void insertOrUpdate() {
			
		if (utilisateur == null){
			utilisateur = new Utilisateur();
		}
		utilisateur.setCUtilisateur(idMozarto.getText());
		utilisateur.setLMotdepasse(password.getValue());
		utilisateur.setInActif(actif.getValue());
		utilisateur.setCodePegaz(idPegaz.getText());
		utilisateur.setLNom(nom.getText());
		utilisateur.setLPrenom(prenom.getText());
		utilisateur.setLMail(mail.getText());
		store.commitChanges();
		List<UtilisateurMetierRoleModel> list = store.getAll();
		List<UtilisateurMetierRoleModel> l = new ArrayList<UtilisateurMetierRoleModel>();
		for(UtilisateurMetierRoleModel u : list){
			if(u.getCRole() != null && !"".equals(u.getCRole())){
				l.add(u);
			}
		}
		
		ClientGestionUtilisateursServiceAsync.Util.getInstance().insertOrUpdate(utilisateur, l, new AsyncCallbackWithErrorResolution<Utilisateur>() {

			@Override
			public void onSuccess(Utilisateur arg0) {
				bus.fireEvent(new GestionUtilisateurRenameUtilisateurEvent(getId(), arg0.getNomComplet()));
				utilisateur = arg0;
				toggleChange(false);
			}

			@Override
			public void onFailure(Throwable caught) {
				if (caught.getMessage() != null){
					if( caught.getMessage().equals("500 f009") ) {
						showMessage(messages.utilisateursExisted(messages.utilisateursIdMozarto()));
					}
					else if( caught.getMessage().equals("500 f013") ) {
						showMessage(messages.utilisateursExisted(messages.utilisateursIdPegaz()));
					}
				}
			}
		});
	}

	private boolean isValidEmailAddress(String email) {
		   String regex = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,4})$";
		   return email.toLowerCase().matches(regex);
		   
		}
	
	public void annulerForm() {
		ConfirmMessageBox messageBox = new ConfirmMessageBox(
				messages.commonConfirmation(), messages.utilisateursAnnulermessage());
		messageBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
		messageBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
		messageBox.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				fillInfo(utilisateur);
				loadGridData();
				toggleChange(false);
			}
		});
		messageBox.show();
	}

	public void setTabLabel(String tabLabel) {
		this.tabLabel = tabLabel;
	}

	public String getTabLabel() {
		return tabLabel;
	}

	public void fillInfo(Utilisateur utilisateur) {
		nom.setText(utilisateur.getLNom() == null ? "" : utilisateur.getLNom());
		prenom.setText(utilisateur.getLPrenom() == null ? "" : utilisateur.getLPrenom());
		mail.setText(utilisateur.getLMail() == null ? "" : utilisateur.getLMail());
		idMozarto.setText(utilisateur.getCUtilisateur());
		idPegaz.setText(utilisateur.getCodePegaz() == null ? "" : String.valueOf(utilisateur.getCodePegaz()));
		actif.setValue(utilisateur.getInActif());
		password.setValue(utilisateur.getLMotdepasse());
	}

	public void enableButtons(boolean enable) {
		annulerButton.setEnable(enable);
		validerButton.setEnabled(enable);
	}

	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	public Utilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setRoleStore(ListStore<RoleUtilisateur> roleStore) {
		this.roleStore = roleStore;
	}

	public ListStore<RoleUtilisateur> getRoleStore() {
		return roleStore;
	}

	public void setChanged(boolean isChanged) {
		this.isChanged = isChanged;
	}

	public boolean isChanged() {
		return isChanged;
	}

	public Integer getIdMetier() {
		return idMetier;
	}

	public void setIdMetier(Integer idMetier) {
		this.idMetier = idMetier;
	}

	private native String getTableMarkup() /*-{
		return [
				'<table width=100% cellpadding=30 cellspacing=0>',
				'<tr><td class=idmz width=50%></td><td class=actif width=50%></td></tr>',
				'<tr><td class=mdp></td></tr>',
				'<tr><td class=idpz></td></tr>',
				'<tr><td class=nom></td><td class=prenom></td></tr>',
				'<tr><td class=mail colspan=2></td></tr>', '</table>'

		].join("");
	}-*/;
	
	private RoleUtilisateur findRoleByLibelle (String libelle, List<RoleUtilisateur> roles){
		String str = libelle == null ? "":libelle;
		if(roles != null && roles.size() > 0){
			for (RoleUtilisateur r : roles){
				if (str.equals(r.getLLibelle()))
					return r;
			}
		}
		return null;
	}
	
	private RoleUtilisateur findRoleByCode (String cRole, List<RoleUtilisateur> roles){
		String str = cRole == null ? "":cRole;
		if(roles != null && roles.size() > 0){
			for (RoleUtilisateur r : roles){
				if (str.equals(r.getCRole()))
					return r;
			}
		}
		return null;
	}
	
	private void showMessage(String content){
		MessageBox box = new MessageBox(messages.commonInfoHeader(), content);
		box.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
		box.show();
	}

	protected void toggleChange(boolean changed) {
		enableButtons(changed);
		if(isChanged != changed){
			bus.fireEvent(new ModifyEvent(!changed));
		}
		isChanged = changed;
	}
}
