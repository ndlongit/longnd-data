package com.structis.client.properties;

import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.TypeElement;

public interface TypeElementProperties extends PropertyAccess<TypeElement> {
	ModelKeyProvider<TypeElement> cTypeElement();

	LabelProvider<TypeElement> lLibelle();
}