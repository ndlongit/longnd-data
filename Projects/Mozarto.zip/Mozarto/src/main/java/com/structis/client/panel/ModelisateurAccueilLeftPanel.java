package com.structis.client.panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.structis.client.event.CreerModeleEvent;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.shared.model.Metier;

public class ModelisateurAccueilLeftPanel extends VerticalLayoutContainer {
	private SimpleEventBus bus;

	@SuppressWarnings("unused")
	private Images images = GWT.create(Images.class);

	private final Messages messages = GWT.create(Messages.class);

	private NavigationService navigation = NavigationFactory.getNavigation();

	private HTML metierLabel;
	
	@SuppressWarnings("unused")
	private Integer idMetier;
	
	private HTML creerModeleLink;

	private Metier metier;

	public ModelisateurAccueilLeftPanel(SimpleEventBus bus) {
		metier = navigation.getContext().getMetier();
		idMetier = metier.getIdMetier();
		this.bus = bus;
		setStyleName("whiteBackGround");
		
		metierLabel = new HTML();
		metierLabel.setHTML(messages.commonMetier() + ": " + metier.getLLibelle());

		add(metierLabel);
		creerModeleLink = new HTML();
		creerModeleLink.setHTML(messages.accueilCreerModele());
		creerModeleLink.setStyleName("htmlLink");
		
		add(creerModeleLink);
		addHandler();

		/*ClientAccueilModelisateurServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

			@Override
			public void onSuccess(Metier result) {
				metierLabel.setHTML(messages.commonMetier() + ": " + result.getLLibelle());
				
				add(creerModeleLink);
				addHandler();
			}
		});*/
	}

	public void addHandler() {
		creerModeleLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				bus.fireEvent(new CreerModeleEvent());
				
			}
		});
	}
}
