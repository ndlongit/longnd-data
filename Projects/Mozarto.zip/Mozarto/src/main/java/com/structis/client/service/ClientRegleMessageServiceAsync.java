package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.shared.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;
import com.structis.shared.model.reference.RuleConflictInfo;
import com.structis.shared.model.reference.TreeNodeModel;

public interface ClientRegleMessageServiceAsync {

	public static class Util {
		private static final ClientRegleMessageServiceAsync instance = GWT.create(ClientRegleMessageService.class);

		public static ClientRegleMessageServiceAsync getInstance() {
			return instance;
		}
	}

	void insertRegle(Integer idUser, TreeNodeModel source, TreeNodeModel target, Integer priorite, Integer quantite,
			AsyncCallback<ModelisateurRegleMessageListModel> callback);

	void findMessageRegleList(TreeNodeModel item, AsyncCallback<List<ModelisateurRegleMessageListModel>> callback);

	void checkConflict(TreeNodeModel sourceNode, TreeNodeModel targetNode, int priorite, int quantite, boolean isUpdate,
			AsyncCallback<RuleConflictInfo> callback);

	void updateRegle(Integer idUser, int idRegle, TreeNodeModel target, Integer priorite, Integer quantite,
			AsyncCallback<ModelisateurRegleMessageListModel> callback);

	void cancelInheritageRegle(Integer idUser, TreeNodeModel sourceNode, int idRegle, AsyncCallback<Void> callback);

	void deleteRegle(Integer idUser, TreeNodeModel sourceNode, int idRegle, AsyncCallback<Void> callback);

	void insertMessage(Integer idUser, TreeNodeModel source, String libelle, Integer priorite,
			AsyncCallback<ModelisateurRegleMessageListModel> callback);

	void updateMessage(Integer idUtilisateur, Integer idMessage, String libelle, Integer priorite,
			AsyncCallback<ModelisateurRegleMessageListModel> callback);

	void deleteMessage(Integer idUser, TreeNodeModel sourceNode, int idMessage, AsyncCallback<Void> callback);

	void cancelInheritageMessage(Integer idUser, TreeNodeModel sourceNode, int idMessage, AsyncCallback<Void> callback);

	void findReglePointToElement(TreeNodeModel item, AsyncCallback<List<ModelisateurRegleMessageListModel>> callback);

	void findMessageRegleListPaging(TreeNodeModel item, PagingLoadConfig loadConfig,
			AsyncCallback<PagingLoadResult<ModelisateurRegleMessageListModel>> callback);

	void findReglePointToElementPaging(TreeNodeModel item, PagingLoadConfig loadConfig,
			AsyncCallback<PagingLoadResult<ModelisateurRegleMessageListModel>> callback);
}
