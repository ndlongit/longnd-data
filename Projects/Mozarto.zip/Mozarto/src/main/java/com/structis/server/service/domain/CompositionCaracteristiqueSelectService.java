package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.CmpCaracteristiqueSelect;

public interface CompositionCaracteristiqueSelectService {
	void insertList(List<CmpCaracteristiqueSelect> cmpCaracteristiqueSelects);
	void deleteByIdComposition(Integer idComposition);
}
