package com.structis.client.widget;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.Timer;
import com.sencha.gxt.data.shared.TreeStore;
import com.sencha.gxt.dnd.core.client.DND.Feedback;
import com.sencha.gxt.dnd.core.client.DndDragMoveEvent;
import com.sencha.gxt.dnd.core.client.DndDropEvent;
import com.sencha.gxt.dnd.core.client.Insert;
import com.sencha.gxt.dnd.core.client.TreeGridDropTarget;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.tree.Tree.TreeNode;
import com.sencha.gxt.widget.core.client.treegrid.TreeGrid;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.ModelisateurAddTabEvent;
import com.structis.client.event.ModelisateurTreeDoubleClickEvent;
import com.structis.client.event.ModelisateurTreeReloadAddElementEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.panel.ModelisateurTreePanel;
import com.structis.client.service.ClientElementServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.Element;
import com.structis.shared.model.reference.ElementInsertResult;
import com.structis.shared.model.reference.TreeNodeModel;

public class CustomizeTreeGridDropTarget<M> extends TreeGridDropTarget<M> {

	protected final Messages messages = GWT.create(Messages.class);

	protected SimpleEventBus bus;

	private TreeStore<TreeNodeModel> treeStore;

	private TreeGrid<TreeNodeModel> tree;

	@SuppressWarnings("unchecked")
	public CustomizeTreeGridDropTarget(TreeGrid<M> tree, SimpleEventBus bus) {
		super(tree);
		treeStore = (TreeStore<TreeNodeModel>) tree.getTreeStore();
		this.tree = (TreeGrid<TreeNodeModel>) tree;
		this.bus = bus;		
	}

	@SuppressWarnings("unchecked")
	public CustomizeTreeGridDropTarget(TreeGrid<M> tree) {
		super(tree);
		treeStore = (TreeStore<TreeNodeModel>) tree.getTreeStore();		
	}

	private void updateData(TreeNode<M> item, List<TreeNodeModel> list, TreeNodeModel parentInform, Stack<TreeNodeModel> stackTrees) {
			
			if (list != null && list.size() > 0) {
					TreeNodeModel nodeModel = list.get(0);
					if ( nodeModel.getModelType().equals(ModelNodeType.CARACTERISTIQUE) ||  nodeModel.getModelType().equals(ModelNodeType.REFERENCE)) {
						addNewNode(item, list, parentInform, stackTrees);
					} else if(nodeModel.getModelType().equals(ModelNodeType.ELEMENT)){
						if (nodeModel.getId() == null) {							
							addNewNode(item, list, parentInform, stackTrees);
						} else {
							addNewElements(item, list, parentInform, stackTrees);
						}
					}					
			}			
	}
	
	private void addNewNode(TreeNode<M> item, List<TreeNodeModel> list, TreeNodeModel parentInfo, Stack<TreeNodeModel> stackTrees) {
		if (list != null && list.size() > 0) {
			TreeNodeModel nodeModel = list.get(0);						
			ModelisateurAddTabEvent event = new ModelisateurAddTabEvent(nodeModel, stackTrees, false, true, false);
			event.setParentNode(parentInfo);			
			appendTree(item, list);
			bus.fireEvent(event);
			bus.fireEvent(new ModelisateurTreeReloadAddElementEvent(parentInfo));
//			tree.getSelectionModel().select(list.get(0), true);
		}
	}
	private void addNewElements(final TreeNode<M> item, final List<TreeNodeModel> list, final TreeNodeModel parentInfo, 
			final Stack<TreeNodeModel> stackTrees) {
		
		ClientElementServiceAsync.Util.getInstance().insertReferenceElementListInRules(parentInfo, list
				, new AsyncCallbackWithErrorResolution<ElementInsertResult>() {
					@Override
					public void onSuccess(ElementInsertResult arg0) {						
						if (arg0 != null && arg0.getNodeConflictRulesList().size() > 0) {
							String codes = "";
							for (TreeNodeModel tnm: arg0.getNodeConflictRulesList()) {
								codes += ","+tnm.getLibelle();
							}
							AppUtil.showMessageBox(messages.modelisateurElementViolateRules(parentInfo.getLibelle(), codes.substring(0)));
						}
						bus.fireEvent(new ModelisateurTreeDoubleClickEvent((TreeNodeModel)item.getModel()));
						if (arg0 != null && arg0.getValidNodeList() != null ) {
							//addNewNode(item, arg0.getValidNodeList(), parentInfo, stackTrees);
							appendTree(item, arg0.getValidNodeList());
						}
					}
				});
	}
		
	protected void appendTree(TreeNode<M> item, List<TreeNodeModel> list) {
		if( item != null ) {			
			TreeNodeModel itemModel = (TreeNodeModel) item.getModel();
			itemModel.setHasChildren(true);
			treeStore.update(itemModel);
			appendModel(item.getModel(), list, getWidget().getTreeStore().getChildCount((M)item.getModel()));
		}
		else {
			appendModel(null, list, getWidget().getTreeStore().getRootItems().size());
		}		
	}

	@Override
	protected void handleAppendDrop(final DndDropEvent event, final TreeNode<M> item) {
		final TreeNodeModel parent = null;
	
		if( item != null ) {
			TreeNodeModel node = (TreeNodeModel)item.getModel();
			if (node.getModelType().equals(ModelNodeType.REFERENCE)) {
				if (node.isSousRef()) {
					AppUtil.showConfirmMessageBox(messages.modelisateurReferenceSousReferenceChange(node.getLibelle()), new SelectHandler() {							
						@Override
						public void onSelect(SelectEvent myevent) {								
							appendDrop(parent, event, item);
						}
					}, null);
				} else {
					appendDrop(parent, event, item);
				}
			} else {
				appendDrop(parent, event, item);
			}
			
			
		}else{
			insertItem(event, item, parent);
		}
	
	}
	
	protected void appendDrop(final TreeNodeModel parent, final DndDropEvent event,
			final TreeNode<M> item) {
		tree.setExpanded((TreeNodeModel) item.getModel(), true);
		
		if(!tree.isExpanded((TreeNodeModel) item.getModel())){
			ModelisateurTreePanel.expanded = false;
			Timer timer = new Timer() {
				@Override
				public void run() {
					if(item.isLeaf() || ModelisateurTreePanel.expanded){
						this.cancel();
						if( item.isLeaf() ) {
							item.setExpand(true);
							item.setChildrenRendered(true);
							item.setLeaf(false);
							item.setExpanded(true);
							tree.getView().refresh(true);
						}
						insertItem(event, item, parent);
					}
				}
			};				
			timer.scheduleRepeating(1);
		}else{
			if( item.isLeaf() ) {
				item.setExpand(true);
				item.setChildrenRendered(true);
				item.setLeaf(false);
				item.setExpanded(true);
				tree.getView().refresh(true);
			}
			insertItem(event, item, parent);
		}		
	}

	protected void appendDrop(SelectEvent event, TreeNode<M> item) {
		// TODO Auto-generated method stub
		
	}

	private void insertItem(DndDropEvent event, TreeNode<M> item, TreeNodeModel parent) {
		// prepare items for inserting
		List<TreeNodeModel> list = new ArrayList<TreeNodeModel>();
		if( event.getData() instanceof String ) {
			TreeNodeModel model = new TreeNodeModel();

			model.setLibelle(messages.commontreenewnode());
			if( ConstantClient.Action.createCaracteristique.equals(((String) event.getData())) ) {
				model.setModelType(ModelNodeType.CARACTERISTIQUE);
			}
			else if( ConstantClient.Action.createReference.equals(((String) event.getData())) ) {
				model.setModelType(ModelNodeType.REFERENCE);
			}
			else if( ConstantClient.Action.createElement.equals(((String) event.getData())) ) {
				model.setModelType(ModelNodeType.ELEMENT);
			}

			if( item != null && item.getModel() != null ) {
				parent = (TreeNodeModel) item.getModel();
				model.setIdModeleVersion(parent.getIdModeleVersion());
				model.setParentId(parent.getId());
			}
			list.add(model);
		}
		else if( event.getData() instanceof List ) { // drag elements from grid
			@SuppressWarnings("unchecked")
			List<Element> myList = (List<Element>) event.getData();
			parent = (TreeNodeModel) item.getModel();
			for( Element e : myList ) {
				TreeNodeModel model = new TreeNodeModel();
				model.setId(e.getIdElement());
				model.setLibelle(e.getCElement() + " " + e.getLLibelleLong());
				model.setModelType(ModelNodeType.ELEMENT);
				model.setIdModeleVersion(parent.getIdModeleVersion());
				model.setParentId(parent.getId());
				list.add(model);
			}
		}

		Stack<TreeNodeModel> stackTrees = new Stack<TreeNodeModel>();
		stackTrees.push(list.get(0));

		if( item != null ) {
			stackTrees.addAll(getHierarchy((TreeNodeModel) item.getModel()));
		}
		updateData(item, list, parent, stackTrees);
	}
	
	@Override
	protected void showFeedback(DndDragMoveEvent event) {
		// TODO this might not get the right element
		super.showFeedback(event);
		boolean actionStatus = true;
		final TreeNode<M> item = getWidget().findNode(
				event.getDragMoveEvent().getNativeEvent().getEventTarget().<com.google.gwt.dom.client.Element> cast());
		
		if( item == null ) {
			if (treeStore.getAllItemsCount() != 0) {
				actionStatus = false;
				Insert.get().hide();
				event.getStatusProxy().setStatus(false);
			}
			if( activeItem != null ) {
				clearStyle(activeItem);
			}
		} else {
			TreeNodeModel treeNodeParent = (TreeNodeModel) item.getModel();
			if (treeNodeParent.getId() != null || treeNodeParent.getTempId() != null) {
				if (event.getData() instanceof String) {
					if( treeNodeParent.getModelType() == ModelNodeType.CARACTERISTIQUE ) {
						if( ConstantClient.Action.createElement.equals(((String) event.getData())) || ConstantClient.Action.dragElement.equals(((String) event.getData())) ) {
							actionStatus = false;
						}
					} else if( treeNodeParent.getModelType() == ModelNodeType.REFERENCE ) {
						if( ConstantClient.Action.createCaracteristique.equals(((String) event.getData())) || ConstantClient.Action.createReference.equals(((String) event.getData())) ) {
							actionStatus = false;
						}
					} else if( treeNodeParent.getModelType() == ModelNodeType.ELEMENT ) {
						actionStatus = false;
					}		
					
				} else if (event.getData() instanceof List) {
					if( treeNodeParent.getModelType() != ModelNodeType.REFERENCE ) {
						actionStatus = false;
					}				
				}
			} else {
				actionStatus = false;
			}
		}

		if( item != null && event.getDropTarget().getWidget() == event.getDragSource().getWidget() ) {
			@SuppressWarnings("unchecked")
			TreeGrid<M> source = (TreeGrid<M>) event.getDragSource().getWidget();
			List<M> list = source.getSelectionModel().getSelection();
			M overModel = item.getModel();
			for( int i = 0 ; i < list.size() ; i++ ) {
				M sel = list.get(i);
				if( overModel == sel ) {
					Insert.get().hide();
					event.getStatusProxy().setStatus(false);
					return;
				}
				List<M> children = getWidget().getTreeStore().getAllChildren(sel);
				if( children.contains(item.getModel()) ) {
					Insert.get().hide();
					event.getStatusProxy().setStatus(false);
					return;
				}
			}
		}

		boolean append = feedback == Feedback.APPEND || feedback == Feedback.BOTH;
		boolean insert = feedback == Feedback.INSERT || feedback == Feedback.BOTH;

		if( item == null ) {
			if (actionStatus) {
				handleAppend(event, item);
			}
		}
		else if( insert && actionStatus ) {
			handleInsert(event, item);
		}
		else if( (!getWidget().isLeaf(item.getModel()) || isAllowDropOnLeaf()) && append && actionStatus ) {
			handleAppend(event, item);
		}
		else {
			if( activeItem != null ) {
				clearStyle(activeItem);
			}
			status = -1;
			activeItem = null;
			appendItem = null;
			Insert.get().hide();
			event.getStatusProxy().setStatus(false);
		}
	}

	private Stack<TreeNodeModel> getHierarchy(TreeNodeModel node) {
		Stack<TreeNodeModel> items = new Stack<TreeNodeModel>();
		items.push(node);

		TreeNodeModel p = node;
		//have parent
		while( (p = treeStore.getParent(p)) != null ) {
			items.push(p);
		}
		return items;
	}		
}
