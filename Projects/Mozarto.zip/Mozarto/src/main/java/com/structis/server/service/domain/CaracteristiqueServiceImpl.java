package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.client.navigation.NavigationFactory;
import com.structis.client.util.ImportUtil;
import com.structis.server.core.ConstantError;
import com.structis.server.persistence.MdlCaracteristiqueMapper;
import com.structis.server.persistence.MdlModeleMapper;
import com.structis.server.persistence.MdlModeleVersionMapper;
import com.structis.server.persistence.MdlVersionMapper;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.model.ImportElementError;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlModele;
import com.structis.shared.model.MdlModeleVersion;
import com.structis.shared.model.MdlVersion;
import com.structis.shared.model.reference.ModeleModel;
import com.structis.shared.model.reference.ValuePlaceHolder;

@Service
public class CaracteristiqueServiceImpl implements CaracteristiqueService {
	
	private static final String VALUE_COLUMN = "l_valeur";

	private static final String COLUMN_COLUMN = "n_colonne";

	@Autowired
	MdlCaracteristiqueMapper mdlCaracteristiqueMapper;
	
	@Autowired
	MdlModeleMapper mdlModeleMapper;
	
	@Autowired
	MdlModeleVersionMapper mdlModeleVersionMapper;

	@Autowired
	MdlVersionMapper mdlVersionMapper;
	
	@Autowired
	private ImportElementService importElementService;

	@Autowired
	private ImportElementErrorService importElementErrorService;
	
	@Autowired
	private ModeleService modeleService;
	
	private static Locale locale;

	static {
		locale = new Locale(NavigationFactory.getNavigation().getContext().getLanguageCode());
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<MdlCaracteristique> findCaracteristiqueByIdModeleVersion(Integer idModeleVersion,
			Integer idCaracteristiqueParent) {
		if( idCaracteristiqueParent != null ) {
			@SuppressWarnings("rawtypes")
			Map mapParameter = new HashMap();
			mapParameter.put("idModeleVersion", idModeleVersion);
			mapParameter.put("idCaracteristiqueParent", idCaracteristiqueParent);
			
			return mdlCaracteristiqueMapper.findCaracteristiqueByModeleVersionAndCaracteristiqueParent(mapParameter);
		}
		else {
			return mdlCaracteristiqueMapper.findLevel1CaracteristiqueByModeleVersion(idModeleVersion);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ValuePlaceHolder> findChildrenNumberCaracteristiqueByIdModeleVersion(Integer idModeleVersion,
			Integer idCaracteristiqueParent) {

		if( idCaracteristiqueParent != null ) {
			@SuppressWarnings("rawtypes")
			Map mapParameter = new HashMap();
			mapParameter.put("idModeleVersion", idModeleVersion);
			mapParameter.put("idCaracteristiqueParent", idCaracteristiqueParent);
			return mdlCaracteristiqueMapper.findChildrenNumberOfCaracteristiqueByModeleVersion(mapParameter);
		}
		else {
			return mdlCaracteristiqueMapper.findChildrenNumberOfRootCaracteristiqueByModeleVersion(idModeleVersion);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<ValuePlaceHolder> findReferenceNumberOfCaracteristiqueByModeleVersionAndCaracteristiqueParent(
			Integer idModeleVersion, Integer idCaracteristiqueParent) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idCaracteristiqueParent", idCaracteristiqueParent);
		return mdlCaracteristiqueMapper.findReferenceNumberOfCaracteristiqueByModeleVersionAndCaracteristiqueParent(mapParameter);
	}

	@Override
	public MdlCaracteristique findById(Integer idCaracteristique) {
		return mdlCaracteristiqueMapper.findById(idCaracteristique);
	}

	@Override
	public void updateCaracteristique(MdlCaracteristique record,Integer idMetier) {
		if(record.getIdCaracteristiqueParent() == null ){
			String sortField = "dDateheureCrea";
			String sortDir = "DESC";
			List<ModeleModel> findAllByMetier = modeleService.findAllByMetier(null, idMetier, sortField, sortDir);
			for(ModeleModel modele:findAllByMetier){
				if(modele.getLLibelle().equalsIgnoreCase(record.getLLibelleLong()) && modele.getIdModeleVersion() != record.getIdModeleVersion()){
					throw new FunctionalException(ConstantError.ERR_DUPLICATED);
				}
			}
			
		}
		int numberRecord = findCaracteristiqueNumberByModeleVersionCaracteristiqueParentAndLibelle(
				record.getIdModeleVersion(), record.getLLibelleLong(), record.getIdCaracteristique());
		if( numberRecord > 0 ) {
			throw new FunctionalException(ConstantError.ERR_DUPLICATED);
		}
		
		mdlCaracteristiqueMapper.update(record);
	}

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public int findCaracteristiqueNumberByModeleVersionCaracteristiqueParentAndLibelle(Integer idModeleVersion,
			String lLibelle, Integer idCaracteristique) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("lLibelle", lLibelle);
		mapParameter.put("idCaracteristique", idCaracteristique);
		return mdlCaracteristiqueMapper.findCaracteristiqueNumberByModeleVersionCaracteristiqueParentAndLibelle(mapParameter);
	}

	@Override
	public List<MdlCaracteristique> findByHierarchy(Integer idModeleVersion) {
		return mdlCaracteristiqueMapper.findChildrenHierarchy (idModeleVersion);
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<MdlCaracteristique> findCaracteristiqueByModeleVersionAndReference(Integer idModeleVersion,
			Integer idReference) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);
		return mdlCaracteristiqueMapper.findCaracteristiqueByModeleVersionAndReference(mapParameter);
	}
	
	@Override	
	public void insert(MdlCaracteristique record) {
		int numberRecord = findCaracteristiqueNumberByModeleVersionCaracteristiqueParentAndLibelle(
				record.getIdModeleVersion(), record.getLLibelleLong(), record.getIdCaracteristique());				
		if( numberRecord > 0 ) {
			throw new FunctionalException(ConstantError.ERR_DUPLICATED);
		}
		Integer maxRange = mdlCaracteristiqueMapper.findMaxRangeOfModel(record.getIdModeleVersion());
		if (maxRange == null) {
			maxRange =  0;
		}
		record.setNRang((short)(maxRange + 1));		
		mdlCaracteristiqueMapper.insert(record);		
	}

	@Override
	public List<Integer> findIdParentsHierarchy(String idChildren) {
		return mdlCaracteristiqueMapper.findIdParentsHierarchy(idChildren);
	}

	@Override
	public List<Integer> findIdChidrensHierarchy(Integer idParent) {
		return mdlCaracteristiqueMapper.findIdChildrensHierarchy(idParent);
	}

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MdlCaracteristique findByIdLienCommun(Integer idModeleVersion, Integer idLienCommun) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommun", idLienCommun);
		return mdlCaracteristiqueMapper.findCaracteristiqueByIdLienCommun(mapParameter);
	}

	@Override
	public MdlCaracteristique findByIdModele(Integer idModele) {
		MdlCaracteristique findByIdModele = mdlCaracteristiqueMapper.findByIdModele(idModele);
		return findByIdModele;
	}

	@Override
	public List<MdlCaracteristique> findByBaseCriteria(MdlCaracteristique criteria) {
		return mdlCaracteristiqueMapper.findByBaseCriteria(criteria);
	}

	@Override
	public void remove(MdlCaracteristique record) {
		mdlCaracteristiqueMapper.delete(record);
	}

	@Override
	@Transactional
	public void insert(MdlCaracteristique record, Integer idMetier, Integer idUser) {
		if (record.getIdCaracteristiqueParent() == null) {
			String sortField = "dDateheureCrea";
			String sortDir = "DESC";
			List<ModeleModel> findAllByMetier = modeleService.findAllByMetier(null, idMetier, sortField, sortDir);
			for(ModeleModel modele:findAllByMetier){
				if(modele.getLLibelle().equalsIgnoreCase(record.getLLibelleLong())){
					throw new FunctionalException(ConstantError.ERR_DUPLICATED);
				}
			}
			MdlModele modele = new MdlModele();
			modele.setIdMetier(idMetier);
			modele.setIdUtilisateurCrea(idUser);
			modele.setInActif(true);
			mdlModeleMapper.insert(modele);
			// create modelversion
			MdlModeleVersion modelVersion = new MdlModeleVersion();
			modelVersion.setIdModele(modele.getIdModele());
			modelVersion.setIdUtilisateurDmaj(idUser);
			modelVersion.setInActif(true);
			mdlModeleVersionMapper.insert(modelVersion);
			record.setIdModeleVersion(modelVersion.getIdModeleVersion());	
			
			// insert into table version
			MdlVersion version = new MdlVersion();
			version.setIdModele(modele.getIdModele());
			version.setIdModeleVersion(modelVersion.getIdModeleVersion());
			version.setNVersion((short)0);
			mdlVersionMapper.insert(version);
		} 
		int numberRecord = findCaracteristiqueNumberByModeleVersionCaracteristiqueParentAndLibelle(
				record.getIdModeleVersion(), record.getLLibelleLong(), record.getIdCaracteristique());				
		if( numberRecord > 0 ) {
			throw new FunctionalException(ConstantError.ERR_DUPLICATED);
		}
		Integer maxRange = mdlCaracteristiqueMapper.findMaxRangeOfModel(record.getIdModeleVersion());
		if (maxRange == null) {
			maxRange =  0;
		}
		record.setNRang((short)(maxRange + 1));		
		mdlCaracteristiqueMapper.insert(record);	
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<MdlCaracteristique> findByModelVersionAndLabelList(Integer modelVersionId, List<String> labelList) {
		Map params = new HashMap();
		params.put("modelVersionId", modelVersionId);
		params.put("labelList", labelList);
		return mdlCaracteristiqueMapper.findByModelVersionAndLabelList(params);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteByIds(List<Integer> idCaracteristiques) {
		Map params = new HashMap();
		params.put("idCaracteristiques", idCaracteristiques);
		mdlCaracteristiqueMapper.deleteByIds(params);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<MdlCaracteristique> findCharacteristicHierarchyByLevel(Integer modelVersion, Integer level, String label) {
		Map params = new HashMap();
		params.put("modelVersion", modelVersion);
		params.put("level", level);
		params.put("label", label);
		return mdlCaracteristiqueMapper.findCharacteristicHierarchyByLevel(params );
	}
	
	@Override
	@Transactional
	@SuppressWarnings({ "rawtypes" })
	public void importCharacteristicsToMozarto(Integer importId, Integer modelVersion, List<String[]> csvData,
			Map<Integer, List<Integer>> dataColumnIndexes, ResourceBundleMessageSource messageSource, Integer userId) throws Exception {

		List<Integer> lines = importElementService.getAllLinesByImportId(importId);
		ImportElementError elementError = null;

		List<Map> allRecords = null;
		for( Integer lineNumber : lines ) {
			String dbError = "";
			allRecords = importElementService.findByImportIdAndLineNumber(importId, lineNumber);

			List<Integer> columnIndexes = dataColumnIndexes.get(lineNumber);
			int startIndex = columnIndexes.get(0) - 1;
			int endIndex = columnIndexes.get(1) - 1;

			MdlCaracteristique parantCharacteristic = null;
			for( int i = startIndex ; i <= endIndex ; i++ ) {
				String characteristic = getValue(allRecords, i);

				if( i == startIndex ) {
					List<MdlCaracteristique> list = findCharacteristicHierarchyByLevel(modelVersion, i, characteristic);
					if( ImportUtil.isNullOrEmpty(list) ) {
						Object[] params = { characteristic };
						dbError = messageSource.getMessage(
								"import.characteristic.error.rootCharacteristicNotExistsInModel", params, locale);
						ImportUtil.addErrorToRow(csvData, lineNumber, dbError);
						int elementImportId = getElementImportId(allRecords, i);

						if( elementImportId >= 0 ) {
							elementError = new ImportElementError();
							elementError.setIdElementImport(elementImportId);
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
							throw new RuntimeException();
						}
					}
					else {
						parantCharacteristic = list.get(0);
					}
					continue;
				}

				MdlCaracteristique criteria = new MdlCaracteristique();
				criteria.setLLibelleLong(characteristic.toUpperCase());
				criteria.setIdModeleVersion(modelVersion);
				List<MdlCaracteristique> list2 = findByBaseCriteria(criteria);
				if( ImportUtil.isNullOrEmpty(list2) ) {

					// Insert new MdlCaracteristique
					MdlCaracteristique record = new MdlCaracteristique();
					record.setIdCaracteristiqueParent(parantCharacteristic.getIdCaracteristique());
					record.setIdModeleVersion(modelVersion);
					record.setLLibelleLong(characteristic);
					short rank = mdlCaracteristiqueMapper.findMaxRangeOfModel(modelVersion).shortValue();
					record.setNRang(rank);
					insert(record);
					parantCharacteristic = record;
				}
				else {

					// Update MdlCaracteristique
					MdlCaracteristique record2 = list2.get(0);

					if( record2.getIdCaracteristiqueParent() != null && record2.getIdCaracteristiqueParent().equals(
							parantCharacteristic.getIdCaracteristique()) ) {
						parantCharacteristic = record2;
					}
					else {
						Object[] params = { characteristic };
						dbError = messageSource.getMessage(
								"import.characteristic.error.characteristicIsUsedInOtherModel", params, locale);
						ImportUtil.addErrorToRow(csvData, lineNumber, dbError);

						int elementImportId = getElementImportId(allRecords, i);

						if( elementImportId >= 0 ) {
							elementError = new ImportElementError();
							elementError.setIdElementImport(elementImportId);
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
						}

						throw new RuntimeException();
					}
				}
			}
		}
		
		//Update modified date, modified by info
		modeleService.updateModifiedBy(userId, modelVersion);
	}

	@SuppressWarnings("rawtypes")
	private int getElementImportId(List<Map> allRecords, int columnIndex) {
		Map record = null;
		for( int j = 0 ; j < allRecords.size() ; j++ ) {
			record = allRecords.get(j);
			int column = Integer.parseInt(record.get(COLUMN_COLUMN).toString());
			if( column == columnIndex ) {
				return Integer.parseInt(record.get("id_element_import").toString());
			}
		}

		return -1;
	}

	@SuppressWarnings("rawtypes")
	private static String getValue(List<Map> allRecords, int columnIndex) {
		Map record = null;
		for( int j = 0 ; j < allRecords.size() ; j++ ) {
			record = allRecords.get(j);
			int column = Integer.parseInt(record.get(COLUMN_COLUMN).toString());
			if( column == columnIndex ) {
				return record.get(VALUE_COLUMN).toString();
			}
		}
		return "";
	}

	@Override
	public MdlCaracteristique getRootNode(Integer modelVersion) {
		List<MdlCaracteristique> l = mdlCaracteristiqueMapper.getRootNode(modelVersion);
		if( l != null && l.size() > 0 ) {
			return l.get(0);
		}
		else {
			return null;
		}
	}

	@Override
	public List<MdlCaracteristique> findCharacteristicHierarchy(Integer idModelVersion) {
		return mdlCaracteristiqueMapper.findCharacteristicHierarchy(idModelVersion);
	}
	
	@Override
	public List<Integer> findNodesBeforeLastNode(Integer modelVersion) {
		return mdlCaracteristiqueMapper.findNodesBeforeLastNode(modelVersion);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<String> getCharacteristicNamesOrderByLevelAndRang(Integer modelVersion, List<String> labelList) {
		Map params = new HashMap();
		params.put("modelVersion", modelVersion);
		params.put("labelList", labelList);
		return mdlCaracteristiqueMapper.getCharacteristicNamesOrderByLevelAndRang(params);
	}
	
	@Override
	public List<MdlCaracteristique> findByCompositionId(Integer compositionId) {
		return mdlCaracteristiqueMapper.findByCompositionId(compositionId);
	}

	@Override
	public List<MdlCaracteristique> findCaracteristiqueChildrenHierarchy(Integer idParent) {
		return mdlCaracteristiqueMapper.findCaracteristiqueChildrenHierarchy(idParent);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> findLibelleInList(List<String> list, Integer idModeleVersion) {
		Map map = new HashMap();
		map.put("list", list);
		map.put("idModeleVersion", idModeleVersion);
		return mdlCaracteristiqueMapper.findLibelleInList(map);
	}
}
