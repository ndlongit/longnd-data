package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface DisableElementPossibleHandler extends EventHandler {
	void onLoad(DisableElementPossibleEvent event);
}
