package com.structis.client.panel.admin;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.AbstractHtmlLayoutContainer.HtmlData;
import com.sencha.gxt.widget.core.client.container.HtmlLayoutContainer;
import com.sencha.gxt.widget.core.client.event.FocusEvent;
import com.sencha.gxt.widget.core.client.event.FocusEvent.FocusHandler;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.structis.client.event.GestionMetierCloseTabEvent;
import com.structis.client.event.GestionMetierDisableMetierEvent;
import com.structis.client.event.GestionMetierDisableMetierHandler;
import com.structis.client.event.GestionMetierRenameMetierEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.panel.AbstractGestionMetierForm;
import com.structis.client.service.ClientGestionMetierServiceAsync;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.MetierMzPzModel;

public class GestionDesMetiersForm extends AbstractGestionMetierForm {

	private static final int LIBELLE_MAX_LENGTH = 50;
	private static final int CODEPEGAZ_MAX_LENGTH = 3;
	private static final int SERVICEMAT_MAX_LENGTH = 3;
	private TextField libelle;
	private TextField codePegaz;
	private TextField serviceMat;
	private FieldLabel libelleField;
	private FieldLabel codePegazField;
	private FieldLabel serviceMatField;
	private CheckBox actif;

	private String libelleActuel = "";
	private String codeActuel = "";
	private String serviceActuel = "";
	
	private String tabLabel = "";

	public GestionDesMetiersForm(SimpleEventBus bus) {
		super(bus);
		setAdminGeneral(true);
	}

	protected void buildForm() {
		super.buildForm();
	}

	protected void addHandler() {
		addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent arg0) {
				container.setWidth(arg0.getWidth());
				container.setHeight(arg0.getHeight());
			}
		});
		container.addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent arg0) {
				resizeForm();
			}
		});
		validerButton.addSelectHandler(new SelectHandler() {
			
			@Override
			public void onSelect(SelectEvent event) {
				validerForm();
			}
		});
		annulerButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				if(editable && isChanged){
					annulerForm();
				}
			}
		});
		libelle.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				libelleActuel = libelle.getText();
			}
		});
		libelle.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if(editable){
					if (libelle.getText().length() > LIBELLE_MAX_LENGTH){
						libelle.reset();
						libelle.setText(libelle.getText().substring(0, LIBELLE_MAX_LENGTH));
					}
					else {
						if(!libelleActuel.equals(libelle.getText())){
							toggleChange(true);
						}
					}
				}
			}
		});
		libelle.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				if(editable){
					toggleChange(true);
				}
			}
		});
		codePegaz.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				codeActuel = codePegaz.getText();
			}
		});
		codePegaz.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if(editable){
					if (codePegaz.getText().length() > CODEPEGAZ_MAX_LENGTH){
						codePegaz.reset();
						codePegaz.setText(libelle.getText().substring(0, CODEPEGAZ_MAX_LENGTH));
					}
					else {
						if(!codeActuel.equals(codePegaz.getText())){
							toggleChange(true);
						}
					}
				}
			}
		});
		codePegaz.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				if(editable){
					toggleChange(true);
				}
			}
		});
		serviceMat.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				serviceActuel = serviceMat.getText();
			}
		});
		serviceMat.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if(editable){
					if (serviceMat.getText().length() > CODEPEGAZ_MAX_LENGTH){
						serviceMat.reset();
						serviceMat.setText(libelle.getText().substring(0, CODEPEGAZ_MAX_LENGTH));
					}
					else {
						if(!serviceActuel.equals(serviceMat.getText())){
							toggleChange(true);
						}
					}
				}
			}
		});
		serviceMat.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				if(editable){
					toggleChange(true);
				}
			}
		});
		actif.addValueChangeHandler(new ValueChangeHandler<Boolean>() {

			@Override
			public void onValueChange(ValueChangeEvent<Boolean> arg0) {
				if(editable){
					toggleChange(true);
				}
			}
		});
		bus.addHandler(GestionMetierDisableMetierEvent.getType(), new GestionMetierDisableMetierHandler() {
			
			@Override
			public void onLoad(GestionMetierDisableMetierEvent event) {
				if(metier != null && event != null && event.getIdMetier().equals(metier.getIdMetier())){
					actif.setValue(false);
					toggleChange(true);
				}
			}
		});
	}

	@Override
	public void buildInfoSet() {
		 
	    HtmlLayoutContainer infoContainer = new HtmlLayoutContainer(getTableMarkup());
	    
		libelle = new TextField();
	    libelleField = new FieldLabel(libelle, messages.metiersFormLibelle());
		infoContainer.add(libelleField, new HtmlData(".libelle"));
		
		actif = new CheckBox();
		actif.setBoxLabel(messages.metiersFormActif());
		actif.setValue(true);
		infoContainer.add(actif, new HtmlData(".actif"));
	    
		codePegaz = new TextField();
	    codePegazField = new FieldLabel(codePegaz, messages.metiersFormCodepegaz());
		infoContainer.add(codePegazField, new HtmlData(".code"));
	    
		serviceMat = new TextField();
	    serviceMatField = new FieldLabel(serviceMat, messages.metiersFormServmat());
		infoContainer.add(serviceMatField, new HtmlData(".service"));

	    infoSet.add(infoContainer);
	    infoSet.getElement().setPadding(new Padding(15));
	}

	@Override
	public void validerForm() {
		
		final MessageBox messageBox = new MessageBox(messages.commonInfoHeader());
		messageBox.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
		if(libelle.getText() == null || "".equals(libelle.getText())){
			messageBox.setMessage(messages.metiersFormObligatoire());
			messageBox.show();
			return;
		}
		if(codePegaz.getText() != null && codePegaz.getText().length() > CODEPEGAZ_MAX_LENGTH){
			messageBox.setMessage(messages.commonLimit(messages.metiersFormCodepegaz(), CODEPEGAZ_MAX_LENGTH));
			messageBox.show();
			return;
		}
		if(serviceMat.getText() != null && serviceMat.getText().length() > SERVICEMAT_MAX_LENGTH){
			messageBox.setMessage(messages.commonLimit(messages.metiersFormServmat(), SERVICEMAT_MAX_LENGTH));
			messageBox.show();
			return;
		}
		if(libelle.getText().length() > LIBELLE_MAX_LENGTH){
			messageBox.setMessage(messages.commonLimit(messages.metiersFormLibelle(), LIBELLE_MAX_LENGTH));
			messageBox.show();
			return;
		}
		if(!actif.getValue()){
			final ConfirmMessageBox box = new ConfirmMessageBox(messages.commonConfirmDesactiver(), messages.metiersFormDesactivermessage());
			box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
			box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
			box.addHideHandler(new HideHandler() {
				
				@Override
				public void onHide(HideEvent event) {
					if(box.getHideButton() == box.getButtonById(PredefinedButton.YES.name())){
						insertOrUpdate();
					}
				}
			});
			box.show();
		}
		else {
			insertOrUpdate();
		}
	}

	public void insertOrUpdate() {
		
		final MessageBox messageBox = new MessageBox(messages.commonInfoHeader());
		messageBox.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
		attributReferenceGrid.getGrid().getStore().commitChanges();
		attributElementGrid.getGrid().getStore().commitChanges();
		List<AttributEtendu> attributEtendus = new ArrayList<AttributEtendu>();
		addAttributs(attributReferenceGrid, attributEtendus);
		addAttributs(attributElementGrid, attributEtendus);
		if(metier == null){
			metier = new MetierMzPzModel();
		}
		metier.setLLibelle(libelle.getText());
		metier.setInActif(actif.getValue());
		metier.setCMetierPegaz(codePegaz.getText());
		metier.setCSocieteSm(serviceMat.getText());
		
		ClientGestionMetierServiceAsync.Util.getInstance().insertOrUpdate(metier, attributEtendus, new AsyncCallbackWithErrorResolution<Metier>() {

			@Override
			public void onSuccess(Metier arg0) {
				bus.fireEvent(new GestionMetierRenameMetierEvent(getId(), libelle.getText()));
				toggleChange(false);
			}
			
			@Override
			public void onFailure(Throwable caught) {
				if( caught.getMessage().equals("500 f009") ) {
					messageBox.setMessage(messages.metiersFormLibelleMetierUnique());
					messageBox.show();
					return;
				}
			}
		});
	}

	@Override
	public void annulerForm() {
		ConfirmMessageBox messageBox = new ConfirmMessageBox(
				messages.commonConfirmation(), messages.metiersFormAnnulermessage());
		messageBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
		messageBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
		messageBox.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				if(metier != null){
					fillGrids();
					fillInfo(metier);
					toggleChange(false);
				}
				else {
					bus.fireEvent(new GestionMetierCloseTabEvent());
				}
			}
		});
		messageBox.show();
	}

	@Override
	public void resizeForm() {
		libelleField.setWidth(container.getElement().getClientWidth() / 2);
		codePegazField.setWidth(container.getElement().getClientWidth() / 2);
		serviceMatField.setWidth(container.getElement().getClientWidth() / 2);
		attrefFieldSet.setHeight(container.getElement().getClientHeight() / 3);
	}

	public void fillInfo(MetierMzPzModel metier){
		libelle.setText(metier.getLLibelle());
		if(metier.getCMetierPegaz() != null)
			codePegaz.setText(metier.getCMetierPegaz());
		if(metier.getCSocieteSm() != null)
			serviceMat.setText(metier.getCSocieteSm());
		actif.setValue(metier.getInActif());
		if(GestionDesMetiersLeftPanel.METIER_ADMIN.equals(metier.getLLibelle().trim())){
			setEditable(false);
			libelle.setReadOnly(true);
			codePegaz.setReadOnly(true);
			serviceMat.setReadOnly(true);
			actif.setReadOnly(true);
		}
	}
	
	private native String getTableMarkup() /*-{
											return [ '<table width=100% cellpadding=0 cellspacing=0>',
											'<tr><td class=libelle width=60%></td><td class=actif width=40%></td></tr>',
											'<tr><td class=code></td></tr>',
											'<tr><td class=service></td><td class=user></td></tr>', '</table>'
											
											].join("");
											}-*/;

	public String getTabLabel() {
		return tabLabel;
	}

	public void setTabLabel(String tabLabel) {
		this.tabLabel = tabLabel;
	}
}
