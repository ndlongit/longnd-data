package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GestionMetierRenameMetierEvent extends GwtEvent<GestionMetierRenameMetierHandler> {

	private static Type<GestionMetierRenameMetierHandler> TYPE = new Type<GestionMetierRenameMetierHandler>();
	private String tabId;
	private String newLabel;

	public static Type<GestionMetierRenameMetierHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionMetierRenameMetierHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionMetierRenameMetierHandler handler) {
		handler.onLoad(this);
	}	

	public GestionMetierRenameMetierEvent(String tabId, String newLabel) {
		this.newLabel = newLabel;
		this.tabId = tabId;
	}

	public String getNewLabel() {
		return newLabel;
	}

	public void setNewLabel(String newLabel) {
		this.newLabel = newLabel;
	}

	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

}
