package com.structis.client.service;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ReferenceFormModel;
import com.structis.shared.model.reference.TreeNodeModel;

@RemoteServiceRelativePath("springGwtServices/clientReferenceService")
public interface ClientReferenceService extends RemoteService {
	public ReferenceFormModel findReferenceFormModelById(Integer idModeleVersion, Integer idReference, Integer idMetier);

	public void updateReference(ReferenceFormModel referenceForm);

	Integer insert(Integer idParent, ModelNodeType typeParent, MdlReference reference);

	void remove(Integer idCaracteristiqueParent, MdlReference record);

	Integer insertOrUpdate(Integer utilisateurId, Integer caracteristiqueId, ReferenceFormModel referenceForm);

	Integer insertOrUpdateInRules(TreeNodeModel parentNode, Integer utilisateurId, Integer parentId,
			ReferenceFormModel referenceForm);

	Boolean checkSatisfyRule(TreeNodeModel tnm, Integer referenceId);

	List<AttributEtenduMetierERValueModel> getListAttributEtenduByModelVersion(Integer idModeleVersion);
	
	PagingLoadResult<MdlReferenceElement> loadElementPaging(Integer idModeleVersion, Integer idReference, PagingLoadConfig loadConfig);
	
	PagingLoadResult<MdlCarateristiqueReference> loadCaracteristiquePaging(Integer idModeleVersion, Integer idReference, PagingLoadConfig loadConfig);
}
