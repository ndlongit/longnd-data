package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GestionMetierCloseTabEvent extends GwtEvent<GestionMetierCloseTabHandler> {

	private static Type<GestionMetierCloseTabHandler> TYPE = new Type<GestionMetierCloseTabHandler>();

	public static Type<GestionMetierCloseTabHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionMetierCloseTabHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionMetierCloseTabHandler handler) {
		handler.onLoad(this);
	}
	
	public GestionMetierCloseTabEvent() {
	}

}
