package com.structis.server.csvconverter;

import java.util.List;

import com.googlecode.jcsv.writer.CSVEntryConverter;
import com.structis.shared.model.MdlCaracteristique;

public class MdlCaracteristiqueEntryConverter implements CSVEntryConverter<List<MdlCaracteristique>> {

	@Override
	public String[] convertEntry(List<MdlCaracteristique> arg0) {
		String[] columns = new String [arg0.size()];
		for (int i = 0; i < arg0.size(); i++){
			columns[i] = arg0.get(i).getLLibelleLong();
		}
		return columns;
	}

}
