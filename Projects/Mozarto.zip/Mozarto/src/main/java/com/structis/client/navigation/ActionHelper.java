package com.structis.client.navigation;

import java.util.HashMap;
import java.util.Map;
/**
 * Class ActionHelper to help get action from label
 *
 */
public class ActionHelper {
	
	private static Map<String, Action> map = new HashMap<String, Action>();
	
	static {
		for(int i=0; i< Action.values().length; i++) {
			String label = Action.values()[i].getLabel();
			map.put(label, Action.values()[i]);
		}
	}
	
	public static Action getActionFromLabel(String label){
		return map.get(label);
	}
}
