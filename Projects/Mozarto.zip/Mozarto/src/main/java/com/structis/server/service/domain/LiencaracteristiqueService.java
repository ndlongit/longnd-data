package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlLienCaracteristique;

public interface LiencaracteristiqueService {
	MdlLienCaracteristique findLienCaracteristiqueByCaracteristique(int idModeleVersion, int idCaracteristique);
	/**
	 * return list idLienCommun
	 * @param idModeleVersion
	 * @param idCaracteristiques
	 * @return
	 */
	List<Integer> findLienCaracteristiqueIdsByCaracteristiqueList(int idModeleVersion, List<Integer> idCaracteristiques);
	
	List<MdlLienCaracteristique> findLienCaracteristiqueByCaracteristiqueList(int idModeleVersion, List<Integer> idCaracteristiques);

	int insert(MdlLienCaracteristique record);
	
	void deleteByIdlienCoummuns(int idModeleVersion,List<Integer> idLienCoummuns);
}
