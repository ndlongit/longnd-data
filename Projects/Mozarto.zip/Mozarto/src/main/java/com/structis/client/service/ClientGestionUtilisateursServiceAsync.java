package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.RoleUtilisateur;
import com.structis.shared.model.Utilisateur;
import com.structis.shared.model.reference.UtilisateurMetierRoleModel;

public interface ClientGestionUtilisateursServiceAsync {
	public static class Util {

		private static ClientGestionUtilisateursServiceAsync instance = GWT
				.create(ClientGestionUtilisateursService.class);
	
		public static ClientGestionUtilisateursServiceAsync getInstance() {
			return instance;
		}
		
	}
	
	public void findAllByMetier(Integer idMetier, PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<Utilisateur>> callback);
	
	public void findAllRole(AsyncCallback<List<RoleUtilisateur>> callback);
	
	public void findRoleByUtilisateurAndMetier(Integer idUtilisateur, Integer idMetier, AsyncCallback<RoleUtilisateur> callback);
	
	public void updateRoleUtilisateur(Integer idUtilisateur, Integer idMetier, String cRole, AsyncCallback<Integer> callback);
	
	public void getAllMetier(Integer idUtilisateur, AsyncCallback<List<UtilisateurMetierRoleModel>> callback);
	
	public void insertOrUpdate(Utilisateur utilisateur, List<UtilisateurMetierRoleModel> list, AsyncCallback<Utilisateur> callback);
	
//	public void insertOrUpdate(MetierMzPzModel metier, List<AttributEtendu> attributEtendus, AsyncCallback<Metier> callback);
}
