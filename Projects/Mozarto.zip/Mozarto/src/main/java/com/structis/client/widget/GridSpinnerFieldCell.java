package com.structis.client.widget;

import com.google.gwt.cell.client.ValueUpdater;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.sencha.gxt.cell.core.client.form.SpinnerFieldCell;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor;

public abstract class GridSpinnerFieldCell<N extends Number> extends SpinnerFieldCell<N>  {
	public GridSpinnerFieldCell(NumberPropertyEditor<N> propertyEditor) {
		super(propertyEditor);		
		setWidth(80);
	}
	
	@Override
	protected void onBlur(com.google.gwt.cell.client.Cell.Context context, com.sencha.gxt.core.client.dom.XElement parent, N value, com.google.gwt.dom.client.NativeEvent event, com.google.gwt.cell.client.ValueUpdater<N> valueUpdater) {
		super.onBlur(context, parent, value, event, valueUpdater);
		onChangeProcess(context.getIndex(),getInputElement(parent).getValue());
	};
	
	/*protected void onKeyDown(Context context, Element parent, N value, NativeEvent event,
		      ValueUpdater<N> valueUpdater) {
		super.onKeyDown(context, parent, value, event, valueUpdater);
		onChangeProcess(context.getIndex(),getInputElement(parent).getValue());
		//Window.alert(getInputElement(parent).getValue());
	}*/
	public abstract void onChangeProcess(int index,String newValue);
	public abstract void onCheckDisable(int index,NativeEvent event);
	
	@Override
	protected void onKeyPress(final Context context, final Element parent, N value, NativeEvent event, ValueUpdater<N> valueUpdate) {
	    super.onKeyPress(context, parent, value, event, valueUpdate);
	    onCheckDisable(context.getIndex(),event);
	}
	    

}

