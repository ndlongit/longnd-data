package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.shared.model.reference.CompositionReferenceGridModel;

public class CompositionUnSelectReferenceEvent extends GwtEvent<CompositionUnSelectReferenceHandler> {

	private static Type<CompositionUnSelectReferenceHandler> TYPE = new Type<CompositionUnSelectReferenceHandler>();

	private Integer idReference;
	private Integer idModelVersion;
	private Grid<CompositionReferenceGridModel> sourceGrid;
	
	public static Type<CompositionUnSelectReferenceHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<CompositionUnSelectReferenceHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(CompositionUnSelectReferenceHandler handler) {
		handler.onLoad(this);
	}

	
	public Integer getIdReference() {
		return idReference;
	}

	public void setIdReference(Integer idReference) {
		this.idReference = idReference;
	}

	public Integer getIdModelVersion() {
		return idModelVersion;
	}

	public void setIdModelVersion(Integer idModelVersion) {
		this.idModelVersion = idModelVersion;
	}	
	
	public Grid<CompositionReferenceGridModel> getSourceGrid() {
		return sourceGrid;
	}

	public void setSourceGrid(Grid<CompositionReferenceGridModel> sourceGrid) {
		this.sourceGrid = sourceGrid;
	}
}
