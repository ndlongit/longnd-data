package com.structis.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.CellClickEvent;
import com.sencha.gxt.widget.core.client.event.CellClickEvent.CellClickHandler;
import com.sencha.gxt.widget.core.client.event.CompleteEditEvent;
import com.sencha.gxt.widget.core.client.event.CompleteEditEvent.CompleteEditHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.grid.Grid.GridCell;
import com.sencha.gxt.widget.core.client.grid.editing.ClicksToEdit;
import com.sencha.gxt.widget.core.client.grid.editing.GridInlineEditing;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.panel.AbstractGestionMetierForm;
import com.structis.client.properties.AttributEtenduProperties;
import com.structis.client.service.ClientAttributEtenduServiceAsync;
import com.structis.shared.model.AttributEtendu;

public class AttributReferenceElementGrid extends VerticalLayoutContainer {

	private static final AttributEtenduProperties properties = GWT.create(AttributEtenduProperties.class);

	private final Messages messages = GWT.create(Messages.class);

	private Grid<AttributEtendu> grid;
	
	private int rowEditable = -1;
	
	private boolean editable = true;
	
	private String type = "";

	private GridInlineEditing<AttributEtendu> editing;

	private ColumnConfig<AttributEtendu, String> libelle;
	
	private AbstractGestionMetierForm parent;
	
	public AttributReferenceElementGrid(){
		buildGrid();
		addHandler();
	}
	
	protected void buildGrid(){
		libelle = new ColumnConfig<AttributEtendu, String>(properties.lLibelle(), 220, messages.metiersFormLibelle());
		final ColumnConfig<AttributEtendu, String> valeur = new ColumnConfig<AttributEtendu, String>(properties.lValeur(), 220, messages.metiersFormValeur());
		final ColumnConfig<AttributEtendu, String> commentaire = new ColumnConfig<AttributEtendu, String>(properties.lCommentaire(), 220, messages.metiersFormCommentaires());
	 
		ColumnConfig<AttributEtendu, AttributEtendu> action = new ColumnConfig<AttributEtendu, AttributEtendu>(
				new IdentityValueProvider<AttributEtendu>());
		action.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRegleGridaction()));
		action.setSortable(false);
		action.setMenuDisabled(true);
		action.setWidth(70);
		action.setAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		AttributActionCell cellAction = new AttributActionCell() {

			@Override
			public void onEdit(AttributEtendu node) {
				if (editable && node != null){
				    rowEditable = grid.getStore().indexOf(node);
					editing.startEditing(new GridCell(rowEditable, 0));
				}
			}

			@Override
			public void onDelete(AttributEtendu record) {
				if (editable && record != null){
					if ("R".equals(record.getCTypeAttributEtendu())){
						showMessageBox(messages.metiersFormRefconfig(), record);
					}
					else {
						showMessageBox(messages.metiersFormEltconfig(), record);
					}
				}
			}

			private void showMessageBox(String typeStr, final AttributEtendu node) {
				CustomizeConfirmBox confirmMessageBox = new CustomizeConfirmBox(messages.commonConfirmDelete(), messages.metiersFormConfirmdelete(typeStr));
				confirmMessageBox.getButton().addSelectHandler(new SelectHandler() {
					
					@Override
					public void onSelect(SelectEvent event) {
						ClientAttributEtenduServiceAsync.Util.getInstance().delete(node, new AsyncCallbackWithErrorResolution<Integer>() {

							@Override
							public void onSuccess(Integer arg0) {
								parent.loadData(type);
							}
						});
					}
				});
				confirmMessageBox.show();
			}

			@Override
			public void onAdd(AttributEtendu node) {
				if (editable){
//					editingItemStatus = node.getStatus();
//				    node.setStatus(1);
				    int indexOfNewAtt = grid.getStore().indexOf(node);
					AttributEtendu newAtt = newAttributEtendu(1);
					grid.getStore().add(indexOfNewAtt, newAtt);
					rowEditable = indexOfNewAtt;
					editing.startEditing(new GridCell(rowEditable, 0));
				}
			}
		};
		action.setCell(cellAction);
		
	    List<ColumnConfig<AttributEtendu, ?>> l = new ArrayList<ColumnConfig<AttributEtendu, ?>>();
	    l.add(libelle);
	    l.add(valeur);
	    l.add(commentaire);
	    l.add(action);
	    libelle.setMenuDisabled(true);
	    valeur.setMenuDisabled(true);
	    commentaire.setMenuDisabled(true);
	    action.setMenuDisabled(true);
	 
	    ColumnModel<AttributEtendu> cm = new ColumnModel<AttributEtendu>(l);
	 
	    final ListStore<AttributEtendu> store = new ListStore<AttributEtendu>(properties.getIdAttributEtendu());
	 
	    grid = new Grid<AttributEtendu>(store, cm);
	    grid.getView().setAutoExpandColumn(libelle);
	    grid.getView().setAutoFill(true);
	 
	    // EDITING//
	    editing = new GridInlineEditing<AttributEtendu>(grid);
		editing.addEditor(libelle, new TextField());
	    editing.addEditor(valeur, new TextField());
	    editing.addEditor(commentaire, new TextField());
	    editing.setClicksToEdit(ClicksToEdit.TWO);
	    
	    add(grid, new VerticalLayoutData(1, 0.80));
	    
	}
	
	protected void addHandler(){
		grid.addCellClickHandler(new CellClickHandler() {
			
			@Override
			public void onCellClick(CellClickEvent event) {
//				if (rowSelected != -1 && rowSelected != event.getRowIndex()){
//					if (editing.isEditing())
//						editing.cancelEditing();
//				}
//				rowSelected = event.getRowIndex();
//				editingItem = grid.getStore().get(rowSelected);
				if (event.getRowIndex() == rowEditable && event.getCellIndex() != 3){
					editing.startEditing(new GridCell(event.getRowIndex(), event.getCellIndex()));
				}
			}
		});
		editing.addCompleteEditHandler(new CompleteEditHandler<AttributEtendu>() {

			@Override
			public void onCompleteEdit(CompleteEditEvent<AttributEtendu> event) {
				parent.toggleChange(true);
			}
		});
	}

	public Grid<AttributEtendu> getGrid() {
		return grid;
	}

	public void setGrid(Grid<AttributEtendu> grid) {
		this.grid = grid;
	}

	public GridInlineEditing<AttributEtendu> getEditing() {
		return editing;
	}

	public void setEditing(GridInlineEditing<AttributEtendu> editing) {
		this.editing = editing;
	}
	
	public AttributEtendu newAttributEtendu(int status){
		AttributEtendu attributEtendu = new AttributEtendu();
		attributEtendu.setCTypeAttributEtendu(type);
		attributEtendu.setStatus(status);
		return attributEtendu;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public boolean isEditable() {
		return editable;
	}

	public void setParent(AbstractGestionMetierForm parent) {
		this.parent = parent;
	}

	public AbstractGestionMetierForm getParent() {
		return parent;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}
}
