package com.structis.client.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;

public interface TestServiceAsync {
	public static class Util {

		private static TestServiceAsync instance = GWT
				.create(TestService.class);

		public static TestServiceAsync getInstance() {
			return instance;
		}
	}
	void testServer(String name, AsyncCallback<String> callback);
}
