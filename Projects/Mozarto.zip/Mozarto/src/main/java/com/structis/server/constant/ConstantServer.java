package com.structis.server.constant;

public final class ConstantServer {

	public static final String IMPORT_DATA_DONE = "OKI";

	public static final String IMPORT_SAS_BEGIN = "SAV";

	public static final String IMPORT_SAS_VERIFICATION = "SEC";

	public static final String IMPORT_SAS_VERIFIED = "SOK";

	public static final String IMPORT_DATA_UN_COMMITED = "KOD";

	public static final String IMPORT_DATA_FUNCTIONAL_ERROR = "KOF";

	public static final String IMPORT_DATA_TECHNICAL_ERROR = "KOT";
	
	// Import Element type
	public static final String IMPORT_TYPE_ELEMENT = "ELT";
	
	public static final String IMPORT_TYPE_REFERENCE = "RCE";
	
	public static final String IMPORT_TYPE_SUB_REFERENCE = "SRE";
	
	public static final String IMPORT_TYPE_CHARACTERISTIC = "CAR";
	
	public static final String TYPE_ATTRIBUTE = "ART";
	
	public static final String TYPE_PRESTATION = "PRE";
	
	public static final String PARAM_USER_ID = "userId";
	
	public static final String PARAM_NODE_ID = "nodeId";
	
	public static final String PARAM_MODEL_EVERSION_ID = "modeleVersionId";
	
	public static final String PARAM_COMPOSITION_ID = "compositionId";
	
	public static final String PARAM_REPORT_NAME = "reportName";
}
