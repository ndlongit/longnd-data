package com.structis.client.message;

import com.google.gwt.i18n.client.ConstantsWithLookup;

/**
* Interface that contains the constant resource Associate ActionMessages
* To map error code <-> Messages
*
* RDG, four digits with the first digit as follows:
* <ul>
* <li>  T: Technical error </ li>
* <li> F: Functional error </ li>
* </ Ul>
*
* 
*/
public interface ErrorMessages extends ConstantsWithLookup {

	// Technical error
	String t001();
	String t002();
	String t003();
	String t004();
	String t005();
	String t006();
	String t007();
	String t008();
	String t009();
	String t010();
	String t011();
	
	// Functional error
	String f001();
	String f002();
	String f003();
	String f004();
	String f005();
	String f006();
	String f007();
	String f008();
	String f009();
	String f010();
	String f019();
	String f020();
	String f100();
	
	
	//modelisateur conflict
	String rce11();
	String rce12();
	String rce13();
	String rce21();
	String rci22();
	String rci23();
	String rce31();
	String rci32();
	String rci33();	
	
	
}
