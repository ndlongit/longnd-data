package com.structis.client.panel.composition;

import java.util.Comparator;

import com.sencha.gxt.data.shared.SortDir;
import com.sencha.gxt.data.shared.Store.StoreSortInfo;
import com.structis.shared.comparator.CompositionReferenceGridModelComparator;
import com.structis.shared.model.reference.CompositionReferenceGridModel;

public class StoreCompositionReferenceSortInfo<M> extends StoreSortInfo<M> {

	private CompositionReferenceGridModelComparator comparator;
	public StoreCompositionReferenceSortInfo(Comparator<M> arg0, SortDir arg1) {
		super(arg0, arg1);
		this.comparator  = new CompositionReferenceGridModelComparator();
		
	}
	@Override
    public int compare(M o1, M o2) {
      int val = this.comparator.compare((CompositionReferenceGridModel)o1, (CompositionReferenceGridModel)o2);
      return val;
    }
	
	
}
