package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlReferenceElementMapper;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.MdlReferenceElementKey;

@Service
public class ReferenceElementServiceImpl implements ReferenceElementService {

	@Autowired
	MdlReferenceElementMapper mdlReferenceElementMapper;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<MdlReferenceElement> findByModeleVersionAndReference(Integer idModeleVersion, Integer idReference) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);
		return mdlReferenceElementMapper.findByModeleVersionAndReference(mapParameter);
	}
	
	@Override
	public void update(MdlReferenceElement referenceElement) {
		mdlReferenceElementMapper.update(referenceElement);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<MdlReferenceElement> findByModeleVersionAndElement(Integer idModeleVersion, Integer idElement) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idElement", idElement);
		return mdlReferenceElementMapper.findByModeleVersionAndElement(mapParameter);
	}

	@Override
	public void insert(MdlReferenceElement relation) {
		mdlReferenceElementMapper.insert(relation);
	}

	@Override	
	public void insertOrIncreaseQuantity(MdlReferenceElement re) {
		if (mdlReferenceElementMapper.findById(re.getId()) == null) {
			mdlReferenceElementMapper.insert(re);
		} else {
			mdlReferenceElementMapper.increaseQuantity(re);
		}		
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteByReferenceIdAndModelVersionId(Integer idReference, Integer modeleVersion) {
		Map params = new HashMap();
		params.put("idModeleVersion", modeleVersion);
		params.put("idReference", idReference);
		mdlReferenceElementMapper.deleteByCriteria(params);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteByIdModeleVersionAndIdReferences(Integer idModeleVersion, List<Integer> idReferences) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReferences", idReferences);
		mdlReferenceElementMapper.deleteByIdModeleVersionAndIdReferences(mapParameter);
	}

	@Override
	public void deleteById(MdlReferenceElementKey key) {
		mdlReferenceElementMapper.deleteById(key);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteSousElementsByIdElementAndIdReferences(Integer idModeleVersion, Integer idElement, Integer idReference) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idElement", idElement);
		mapParameter.put("idReference", idReference);
		mdlReferenceElementMapper.deleteSousModeleElementByIdElementAndIdReferences(mapParameter);
	}

	@Override
	public boolean isExistedRecord(
			Integer idModeleVersion, Integer idElement, Integer idReference) {
		MdlReferenceElementKey id = new MdlReferenceElementKey();
		id.setIdElement(idElement);
		id.setIdReference(idReference);
		id.setIdModeleVersion(idModeleVersion);
		MdlReferenceElement record =  mdlReferenceElementMapper.findById(id);
		return (record != null);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteByReferenceIdsAndElementIds(Integer idModeleVersion, List<Integer> idReferences,
			List<Integer> elementIds) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReferences", idReferences);
		mapParameter.put("elementIds", elementIds);
		mdlReferenceElementMapper.deleteByReferenceIdsAndElementIds(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void insertList(List<MdlReferenceElement> list) {
		if(list != null && list.size() > 0){
			Map mapParameter = new HashMap();
			mapParameter.put("list", list);
			mdlReferenceElementMapper.insertList(mapParameter);
		}
	}
}
