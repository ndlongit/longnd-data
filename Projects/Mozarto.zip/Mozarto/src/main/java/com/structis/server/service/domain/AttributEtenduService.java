package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.AttributEtendu;

/**
 * 
 * @author vu.dang
 *
 */
public interface AttributEtenduService {
	
	public AttributEtendu findById(Integer id);
	
	public Integer insert(AttributEtendu record);
	
	public Integer update(AttributEtendu record);
	
	public Integer delete(AttributEtendu record);
	
	public Integer deleteById(Integer id);
	
	public List<AttributEtendu> findAll();

	public List<AttributEtendu> findAttributElementByMetier(Integer idMetier);

	public List<AttributEtendu> findByCriteria(AttributEtendu criteria);

	public List<AttributEtendu> findByMetierAndType(String type, Integer idMetier);

	public List<AttributEtendu> findByModelVersionAndType(String type, Integer idModeleVersion);
	
	public List<AttributEtendu> findByMetierAndTypeAndLabelList(String type, Integer idMetier, List<String> labelList);
	
	public List<AttributEtendu> findByReferenceId(Integer referenceId);
	
	public List<AttributEtendu> findElementAttributeByElementId(Integer metierId, Integer elementId);

	public List<AttributEtendu> findAttributReferenceByMetier(Integer idMetier);
	
	public Integer insertList(List<AttributEtendu> attributEtendus);

	public short findMaxRang();

	public List<AttributEtendu> findAllByMetier(Integer idMetier);
}
