package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.structis.client.service.ClientAuthenticationService;
import com.structis.server.core.ConstantError;
import com.structis.server.service.domain.HabilitationUtilisateurService;
import com.structis.server.service.domain.MetierService;
import com.structis.server.service.domain.UtilisateurService;
import com.structis.server.service.security.GuiManager;
import com.structis.shared.config.ApplicationContext;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.model.HabilitationUtilisateur;
import com.structis.shared.model.Metier;
import com.structis.shared.model.Utilisateur;
import com.structis.shared.security.Role;
import com.structis.shared.security.RoleHelper;

@Service
public class ClientAuthenticationServiceImpl implements ClientAuthenticationService {

	@Autowired
	MetierService metierService;
	
	@Autowired
	UtilisateurService utilisateurService;
	
	@Autowired
	HabilitationUtilisateurService habilitationUtilisateurService;
	
	@Autowired
	GuiManager guiManager;
	
	@Override
	public ApplicationContext getCurrentLogin() {
		
		ApplicationContext appContext = null;
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		if (session.getAttribute("login") != null) {
			appContext = (ApplicationContext) session.getAttribute("login");
		}
		return appContext;
	}

	@Override
	public ApplicationContext login(String userName, String passWord, Integer idMetier) {
		Utilisateur user = utilisateurService.findUtilisateurByAccount(userName.toLowerCase());
		ApplicationContext appContext = null;
		if(user != null && user.getInActif()){
			if(user.getLMotdepasse().equals(passWord)){
				//check metier role
				HabilitationUtilisateur habilitationUtilisateur = habilitationUtilisateurService.findByIdUtilisateurAndIdMetier(user.getIdUtilisateur(), idMetier);
				if(habilitationUtilisateur != null){
					appContext = new ApplicationContext();
					appContext.setUtilisateur(user);
					selectMetier(idMetier, habilitationUtilisateur, appContext);
					ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
					HttpSession session = attr.getRequest().getSession();
					if (session.getAttribute("login") != null) {
						session.removeAttribute("login");
					}
					session.setAttribute("login", appContext);
				}else{
					//user don't hany any role on this metier
					throw new FunctionalException(ConstantError.ERR_WRONG_IDENTIFY);
				}
			}else{
				throw new FunctionalException(ConstantError.ERR_WRONG_PASS);
			}
		}else{
			throw new FunctionalException(ConstantError.ERR_WRONG_IDENTIFY);
		}
		return appContext;
	}

	@Override
	public ApplicationContext changeMetier(Integer metierId) {
		ApplicationContext appContext = null;
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		if (session.getAttribute("login") != null) {
			appContext = (ApplicationContext) session.getAttribute("login");
			HabilitationUtilisateur habilitationUtilisateur = habilitationUtilisateurService.findByIdUtilisateurAndIdMetier(appContext.getUtilisateur().getIdUtilisateur(), metierId);
			if(habilitationUtilisateur != null){
				selectMetier(metierId, habilitationUtilisateur, appContext);
			}else{
				return null;
			}
		}
		return appContext;
	}

	@Override
	public void logout() {
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		if (session.getAttribute("login") != null) {
			session.removeAttribute("login");
		}
	}
	private void selectMetier(Integer idMetier, HabilitationUtilisateur habilitationUtilisateur, ApplicationContext appContext){
		Metier metier = metierService.findById(idMetier);
		appContext.setMetier(metier);
		List<Role> roles = new ArrayList<Role>();
		roles.add(Role.ANONYMOUS);
		roles.add(RoleHelper.getRoleFromCode(habilitationUtilisateur.getCRole()));
		appContext.setRoles(roles);
		appContext.setActions(guiManager.getVisibilityAction(habilitationUtilisateur.getCRole()));
	}
	@Override
	public List<Metier> getAllMetier() {
		return metierService.findAll();
	}

}
