package com.structis.client.constant;

/**
 * Divers constants pour l'application client
 */
public class ConstantClient {

	public final static String LANGUAGE_CODE_FRENCH = "fr";

	public final static String LANGUAGE_CODE_ENGLISH = "en";

	public final static String LANGUAGE_CODE_GEMAN = "de";

	public final static String LANGUAGE_CODE_SPAIN = "es";

	public final static String DEFAULT_LANGUAGE_CODE = "fr";
	
	public final static String CONTENT = "appContent";

	public final static String DIV_ADMINISTRATION = "cbbAdministration";

	// Divers constants
	public final static String FLECH = " >  ";

	public final static String SIMPLE_COMBO_VALUE = "value";

	public final static String POINT = ".";

	public final static String[] TYPE_IMAGES = { ".jpg", ".bmp" };

	// Misc
	public static final String CANCEL_HISTORY = "cancel";

	public static final String PAGINATION = "paging";

	public static final String SEARCH_PREFIXE = "search.";
	
	public static final String ADMINISTRATION_METIER = "Administration";
	
	public static final String CODE_APPLICATION_MOZARTO = "M";

	
	public  class ScreenSize {
		public static final int HEADERHEIGHT = 65;
		public static final int MINWIDTH = 1020; //1024 - borders
		public static final int MINHEIGHT = 560; //768 - menu bar height of the browser
		public static final int MINLEFT = 200;
		public static final int MINCENTER = 200;
		public static final int MINHRIGHT = 400;
		public static final int COMPOSITEUR_MINLEFT = 120;
		public static final int COMPOSITEUR_MINRIGHT = 300;
		public static final int COMPOSITEUR_MINLEFTCENTER = 120;
		public static final int COMPOSITEUR_MINRIGHTCENTER = 200;
		public static final int SMALL_DEFAULT_RECORD_NUMBER = 30;
		public static final int LARGE_DEFAULT_RECORD_NUMBER = 150;
	}
	public class Action {
		public static final String createCaracteristique = "createCaracteristique";
		public static final String createReference = "createReference";
		public static final String createElement = "createElement";		
		public static final String dragElement = "dragElement";
	}
	public class Parameters {
		//url parameters
		public static final String ACTION = "action";
		public static final String UTILISATEUR = "idUtilisateur";
		public static final String METIER = "idMetier";
		public static final String MODELISATION = "idModelisation";
	}
}
