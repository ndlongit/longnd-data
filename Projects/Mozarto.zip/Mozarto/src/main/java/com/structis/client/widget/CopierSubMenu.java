package com.structis.client.widget;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.menu.Menu;
import com.structis.client.event.ModelisateurTreeCopyEvent;

public class CopierSubMenu extends Menu {
	
	private HTML cancelButton;

	private TextButton confirmButton;

	private CheckBox regles;

	private CheckBox messages;

	private CheckBox descendance;

	private SimpleEventBus bus;
	
	
	public CopierSubMenu(String title, SimpleEventBus b){
		this.bus = b;
		final Dialog simple = new Dialog();
		simple.getElement().getStyle().setBackgroundColor("#FFFFFF");
//		simple.setBodyStyle("background:white");
//		simple.getButtonBar().setStyleName("whiteBackGround");
	    simple.setHeadingText(title);
	    simple.setButtonAlign(BoxLayoutPack.END);
	    confirmButton = new TextButton(PredefinedButton.OK.name());
		cancelButton = new HTML("Annuler");
		cancelButton.setStyleName("htmlLink");
	    simple.getButtonBar().add(cancelButton);
	    simple.getButtonBar().add(confirmButton);
	    simple.getButtonById(PredefinedButton.OK.name()).hide();
	    VerticalLayoutContainer container = new VerticalLayoutContainer();
	    regles = new CheckBox();
	    messages = new CheckBox();
	    descendance = new CheckBox();
	    regles.setValue(true);
	    messages.setValue(true);
	    descendance.setValue(true);
	    container.add(regles);
	    container.add(messages);
	    container.add(descendance);
	    
	    regles.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<Boolean> arg0) {

				checkValidateEnable();
				
			}
		});
	    messages.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<Boolean> arg0) {

				checkValidateEnable();
				
			}
		});
	    descendance.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<Boolean> arg0) {

				if(descendance.getValue()){
					regles.disable();
					messages.disable();
				}else{
					regles.enable();
					messages.enable();
				}
				checkValidateEnable();
			}
		});
	    cancelButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				hide();
				bus.fireEvent(new ModelisateurTreeCopyEvent(false, null, null, null));
				
			}
		});
	    confirmButton.addSelectHandler(new SelectHandler() {
			
			@Override
			public void onSelect(SelectEvent event) {
				hide();
				bus.fireEvent(new ModelisateurTreeCopyEvent(true, regles.getValue(), messages.getValue(), descendance.getValue()));
			}
		});
	    simple.setHideOnButtonClick(true);
		simple.add(container);
	    simple.setResizable(false);
	    simple.setDraggable(false);
	    simple.setWidth(300);
	    simple.setHeight(130);
	    simple.setPosition(0, 0);
	    add(simple);
//	    setWidth(300);
//	    setHeight(100);
	 
	}
	
	public HTML getCancelButton() {
		return cancelButton;
	}

	public void setCancelButton(HTML cancelButton) {
		this.cancelButton = cancelButton;
	}

	public TextButton getConfirmButton() {
		return confirmButton;
	}

	public void setConfirmButton(TextButton confirmButton) {
		this.confirmButton = confirmButton;
	}

	public CheckBox getRegles() {
		return regles;
	}

	public void setRegles(CheckBox regles) {
		this.regles = regles;
	}

	public CheckBox getMessages() {
		return messages;
	}

	public void setMessages(CheckBox messages) {
		this.messages = messages;
	}

	public CheckBox getDescendance() {
		return descendance;
	}

	public void setDesendance(CheckBox descendance) {
		this.descendance = descendance;
	}
	private void checkValidateEnable(){
		if (!regles.getValue() && !messages.getValue() && !descendance.getValue())
	    	confirmButton.disable();
	    else 
	    	confirmButton.enable();
	}
}
