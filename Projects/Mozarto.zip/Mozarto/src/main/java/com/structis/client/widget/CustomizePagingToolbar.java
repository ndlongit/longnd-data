package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.sencha.gxt.widget.core.client.event.BlurEvent;
import com.sencha.gxt.widget.core.client.event.BlurEvent.BlurHandler;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor.IntegerPropertyEditor;
import com.sencha.gxt.widget.core.client.form.SpinnerField;
import com.structis.client.image.Images;

public class CustomizePagingToolbar extends HorizontalPanel {


	private HTML totalRecordLabel;
	
	Images images = GWT.create(Images.class);

	private int totalRecord = 1;

	protected SpinnerField<Integer> pagingNumberSpinner;

	private int numPages;

	private HTML next;

	public HTML getNext() {
		return next;
	}

	public void setNext(HTML next) {
		this.next = next;
	}

	public HTML getPrev() {
		return prev;
	}

	public void setPrev(HTML prev) {
		this.prev = prev;
	}

	private HTML prev;

	public HTML getTotalRecordLabel() {
		return totalRecordLabel;
	}

	public void setTotalRecordLabel(HTML totalRecordLabel) {
		this.totalRecordLabel = totalRecordLabel;
	}

	public SpinnerField<Integer> getPagingNumberSpinner() {
		return pagingNumberSpinner;
	}

	public void setPagingNumberSpinner(SpinnerField<Integer> pagingNumberSpinner) {
		this.pagingNumberSpinner = pagingNumberSpinner;
	}

	public int getNumPages() {
		return numPages;
	}

	public void setNumPages(int numPages) {
		this.numPages = numPages;
	}

	public void setTotalRecord(int totalRecord) {
		this.totalRecord = totalRecord;
	}

	public int getTotalRecord() {
		return totalRecord;
	}

	protected void onButtonClick() {
	}

	protected void onSpinnerClick(int record) {
	}

	public CustomizePagingToolbar() {
	
		prev = new HTML();
		Image prevIcon = new Image();
		prevIcon.setResource(images.prevIcon());
		prevIcon.setStyleName("iconPadding");
		prev.setHTML(prevIcon + "");
		//			prev.setStyleName("searchButton");
		prev.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				int value = Integer.parseInt(pagingNumberSpinner.getText());
				if( value > 1 ) {
					pagingNumberSpinner.setText(value - 1 + "");
					pagingNumberSpinner.setValue(value - 1);
					onButtonClick();
				}
			}
		});
		next = new HTML();
		Image nextIcon = new Image();
		nextIcon.setResource(images.nextIcon());
		nextIcon.setStyleName("iconPadding");
		next.setHTML(nextIcon + "");
		//			next.setStyleName("searchButton");
		next.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				int value = Integer.parseInt(pagingNumberSpinner.getText());
				int maxValue = pagingNumberSpinner.getMaxValue().intValue();
				if( value < maxValue ) {
					pagingNumberSpinner.setText(value + 1 + "");
					pagingNumberSpinner.setValue(value + 1);
					onButtonClick();
				}

			}
		});
		pagingNumberSpinner = new SpinnerField<Integer>(new IntegerPropertyEditor());
		pagingNumberSpinner.setIncrement(1);
		pagingNumberSpinner.setMinValue(1);
		//			pagingNumberSpinner.setMaxValue(1);
		pagingNumberSpinner.setWidth(50);
		pagingNumberSpinner.setValue(1);

		pagingNumberSpinner.addSelectionHandler(new SelectionHandler<Integer>() {

			@Override
			public void onSelection(SelectionEvent<Integer> event) {
				onSpinnerClick(event.getSelectedItem().intValue());

			}
		});
		pagingNumberSpinner.addBlurHandler(new BlurHandler() {

			@Override
			public void onBlur(BlurEvent event) {
				if( pagingNumberSpinner.getValue() < 0 || pagingNumberSpinner.getValue() > totalRecord ) {
					pagingNumberSpinner.setValue(1);
					pagingNumberSpinner.clearInvalid();
				}
				onButtonClick();
			}
		});
		add(prev);
		add(pagingNumberSpinner);
		totalRecordLabel = new HTML("/");
		totalRecordLabel.setWidth("auto");
		add(pagingNumberSpinner);
		add(totalRecordLabel);
		add(next);
	}
	

	public void refresh(int numpages) {
		getPagingNumberSpinner().setMaxValue(numpages);
		setTotalRecord(numpages);
		getTotalRecordLabel().setText("/" + String.valueOf(numpages));
		int value = Integer.parseInt(getPagingNumberSpinner().getText());
		if( value == 1 ) {
			Image prevIcon = new Image();
			prevIcon.setResource(images.leftArrowButtonDisable());
			getPrev().setHTML(prevIcon + "");
		}
		else {
			Image prevIcon = new Image();
			prevIcon.setResource(images.prevIcon());
			getPrev().setHTML(prevIcon + "");
		}
		if( value == numpages ) {
			Image nextIcon = new Image();
			nextIcon.setResource(images.rightArrowButtonDisable());
			getNext().setHTML(nextIcon + "");
		}
		else {
			Image nextIcon = new Image();
			nextIcon.setResource(images.nextIcon());
			getNext().setHTML(nextIcon + "");
		}
	}

}