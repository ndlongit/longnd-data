package com.structis.client.navigation;

import com.structis.client.ecran.AccueilEcran;
import com.structis.client.ecran.LoginEcran;
import com.structis.client.panel.GestionDesUtilisateursContainer;
import com.structis.client.panel.GestionDuMetierContainer;
import com.structis.client.panel.ModelisateurContainer;
import com.structis.client.panel.admin.GestionDesElementDeCompositionContainer;
import com.structis.client.panel.admin.GestionDesMetiersContainer;
import com.structis.client.panel.admin.GestionDesUtilisateursAdminContainer;
import com.structis.client.panel.composition.CompositionContainer;
import com.structis.shared.security.Role;

/**
 * Class implementation of navigation service
 * Voir {@link NavigationService}
 * 
 *
 */
public class NavigationManager extends NavigationAbstract implements
		NavigationService {
	
	protected NavigationManager(){
	}

	@Override
	protected void initNavigation() {

		// Init role as anonymous
		roles.add(Role.ANONYMOUS);
		
		// init the navigation
		mapNavigation.put(Action.ACTION_ACCEUIL, new Ecran(new AccueilEcran()));
		mapNavigation.put(Action.ACTION_LOGIN, new Ecran(new LoginEcran()));
		mapNavigation.put(Action.ACTION_MODELISATEUR, new Ecran(new ModelisateurContainer()));
		mapNavigation.put(Action.ACTION_COMPOSITEUR, new Ecran(new CompositionContainer()));
		mapNavigation.put(Action.ACTION_GESTION_DES_ELEMENTS_DE_COMPOSITION, new Ecran(new GestionDesElementDeCompositionContainer()));
		mapNavigation.put(Action.ACTION_GESTION_DES_METIERS, new Ecran(new GestionDesMetiersContainer()));
		mapNavigation.put(Action.ACTION_GESTION_DU_METIER, new Ecran(new GestionDuMetierContainer()));
		mapNavigation.put(Action.ACTION_GESTION_DES_UTILISATEURS_ADMINGENERAL, new Ecran(new GestionDesUtilisateursAdminContainer()));
		mapNavigation.put(Action.ACTION_GESTION_DES_UTILISATEURS, new Ecran(new GestionDesUtilisateursContainer()));
	}

}
