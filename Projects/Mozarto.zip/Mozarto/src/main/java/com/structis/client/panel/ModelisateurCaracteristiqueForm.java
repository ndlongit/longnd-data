package com.structis.client.panel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.StatusCodeException;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer.HorizontalLayoutData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.FocusEvent;
import com.sencha.gxt.widget.core.client.event.FocusEvent.FocusHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FormPanel.LabelAlign;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.form.Validator;
import com.sencha.gxt.widget.core.client.form.validator.MaxLengthValidator;
import com.sencha.gxt.widget.core.client.form.validator.MaxLengthValidator.MaxLengthMessages;
import com.sencha.gxt.widget.core.client.form.validator.MinLengthValidator;
import com.sencha.gxt.widget.core.client.form.validator.MinLengthValidator.MinLengthMessages;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.RenameTreeNodeEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.navigation.Action;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.panel.validator.DupplicateValidator;
import com.structis.client.properties.TreeNodeModelProperties;
import com.structis.client.service.ClientCaracteristiqueServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.client.widget.PagingToolBarWithoutDisplayText;
import com.structis.server.core.ConstantError;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.reference.CarateristiqueFormModel;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurCaracteristiqueForm extends AbstractModelisateurEditForm {

	private TextField libele;

	private TextArea commentaires;

	private MdlCaracteristique caracteristique;

	private ListStore<TreeNodeModel> storeEde;

	private ListStore<TreeNodeModel> storeEds;
	
	private NavigationModelisateurForm navigationModelisateurForm;
	
	private ModelisateurRegleMessageList modelisateurRegleMessageList;
	
	//private NavigationService navigation = NavigationFactory.getNavigation();
	
	private VerticalLayoutContainer gridEdsContainer;
	
	@SuppressWarnings("unchecked")
	Validator<String> dupplicateValidation = new DupplicateValidator();

	protected String libelleActuel = "";

	protected String commentaireActuel = "";
	
	private Grid<TreeNodeModel> gridEds;

	public ModelisateurCaracteristiqueForm(SimpleEventBus bus, TreeNodeModel item, TreeNodeModel parent) {
		super(bus, item, parent);						
	}
	
	public ModelisateurCaracteristiqueForm(SimpleEventBus bus, TreeNodeModel item) {
		super(bus, item);				
	}
	
	protected VerticalLayoutContainer buildPanel() {
		Label titleLable = new Label(messages.modelisateurCaracteristique());
		titleLable.addStyleName("editFormTitle");

		VerticalLayoutContainer mainContainer = new VerticalLayoutContainer();

		mainContainer.add(titleLable);
		mainContainer.add(new HTML("<hr/>"));

		libele = new TextField();
		libele.setValidateOnBlur(true);
		libele.setAutoValidate(true);
		MaxLengthValidator validatorMax = new MaxLengthValidator(50);
		validatorMax.setMessages(new MaxLengthMessages() {
			@Override
			public String maxLengthText(int length) {
				return messages.commonLongeurMaxError(50);
			}
		});

		MinLengthValidator validatorMin = new MinLengthValidator(1);
		validatorMin.setMessages(new MinLengthMessages() {

			@Override
			public String minLengthText(int length) {
				return messages.commonObligatoire();
			}
		});		
		libele.addValidator(validatorMax);
		//libele.addValidator(validatorMin);

		commentaires = new TextArea();
		commentaires.setHeight(50);

		FieldLabel libeleFieldLabel = new FieldLabel(libele, messages.modelisateurFormLibelle());
		libeleFieldLabel.setLabelSeparator("");
		libeleFieldLabel.setLabelWidth(40);
		libeleFieldLabel.setLabelAlign(LabelAlign.LEFT);
		FieldLabel commentairesFieldLabel = new FieldLabel(commentaires, messages.modelisateurFormCommentaires());
		commentairesFieldLabel.setLabelSeparator("");
		commentairesFieldLabel.setLabelAlign(LabelAlign.TOP);

		HorizontalLayoutContainer relationContainer = new HorizontalLayoutContainer();
		TreeNodeModelProperties nodeProperties = GWT.create(TreeNodeModelProperties.class);
		//grid element de entree
		
		storeEde = new ListStore<TreeNodeModel>(nodeProperties.key());
		ColumnConfig<TreeNodeModel, String> ccEde = new ColumnConfig<TreeNodeModel, String>(nodeProperties.libelle());
		ccEde.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRelationElementEntree()));
		ccEde.setSortable(false);
		ccEde.setMenuDisabled(true);
		List<ColumnConfig<TreeNodeModel, ?>> lEde = new ArrayList<ColumnConfig<TreeNodeModel, ?>>();
		lEde.add(ccEde);
		Grid<TreeNodeModel> gridEde = new Grid<TreeNodeModel>(storeEde, new ColumnModel<TreeNodeModel>(lEde));
		gridEde.setBorders(true);
		gridEde.getView().setForceFit(true);

		//grid element de sortie
		RpcProxy<PagingLoadConfig, PagingLoadResult<TreeNodeModel>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<TreeNodeModel>>() {
			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<TreeNodeModel>> callback) {
				ClientCaracteristiqueServiceAsync.Util.getInstance().loadChildrenPaging(treeNode.getIdModeleVersion(), treeNode.getId(), loadConfig, callback);
			}
	    };
		storeEds = new ListStore<TreeNodeModel>(nodeProperties.key());
		PagingLoader<PagingLoadConfig, PagingLoadResult<TreeNodeModel>> loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<TreeNodeModel>>(proxy);
		loader.setRemoteSort(true);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, TreeNodeModel, PagingLoadResult<TreeNodeModel>>(
				storeEds));
		ColumnConfig<TreeNodeModel, String> ccEds = new ColumnConfig<TreeNodeModel, String>(nodeProperties.libelle());
		ccEds.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRelationElementSortie()));
		ccEds.setSortable(false);
		ccEds.setMenuDisabled(true);
		List<ColumnConfig<TreeNodeModel, ?>> lEds = new ArrayList<ColumnConfig<TreeNodeModel, ?>>();
		lEds.add(ccEds);
		gridEds = new Grid<TreeNodeModel>(storeEds, new ColumnModel<TreeNodeModel>(lEds));
		gridEds.setLoadMask(true);
		gridEds.setLoader(loader);
		gridEds.setBorders(false);
		gridEds.getView().setForceFit(true);
		PagingToolBarWithoutDisplayText gridEdsToolBar = new PagingToolBarWithoutDisplayText(ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
		gridEdsToolBar.bind(loader);
		gridEdsToolBar.getElement().getStyle().setProperty("borderBottom", "none");
		gridEdsContainer = AppUtil.createGridWidthPagingContainer(gridEds, gridEdsToolBar);
		
		relationContainer.add(gridEde, new HorizontalLayoutData(.4, 1, new Margins(0, 5, 20, 0)));
		relationContainer.add(gridEdsContainer, new HorizontalLayoutData(.6, 1, new Margins(0, 0, 20, 0)));

		mainContainer.add(libeleFieldLabel, new VerticalLayoutData(.98, -1));
		mainContainer.add(commentairesFieldLabel, new VerticalLayoutData(.98, -1));
		mainContainer.add(new Label(messages.modelisateurFormRelations()));
		mainContainer.add(relationContainer, new VerticalLayoutData(.98, 1));
		return mainContainer;
	}

	protected void addHandler() {
		addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent paramResizeEvent) {
				libele.clearInvalid();
			}
		});
/*		libele.addChangeHandler(new ChangeHandler() {
		
		@Override
		public void onChange(ChangeEvent paramChangeEvent) {
			libele.removeValidator(dupplicateValidation);
			toggleSaveCancel(true);
		}
	});*/
		libele.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				libelleActuel = libele.getText();
			}
		});
		libele.addKeyUpHandler(new KeyUpHandler() {			
			@Override
			public void onKeyUp(KeyUpEvent paramKeyUpEvent) {
				if(!libelleActuel.equals(libele.getText())){
					toggleSaveCancel(true);
				}
			}
		});
		libele.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				toggleSaveCancel(true);
			}
		});
		commentaires.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				commentaireActuel = commentaires.getText();
			}
		});
		commentaires.addKeyUpHandler(new KeyUpHandler() {	

			@Override
			public void onKeyUp(KeyUpEvent paramKeyUpEvent) {
				if(!commentaireActuel.equals(commentaires.getText())){
					toggleSaveCancel(true);
				}
			}
		});
		commentaires.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> arg0) {
				toggleSaveCancel(true);
			}
		});
/*		commentaires.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
				toggleSaveCancel(true);
			}
		});*/
		validerButton.addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				if( !"".equals(libele.getValue()) &&  libele.getValue().length() <= 50) {
					if (caracteristique.getIdCaracteristique() == null && parentNode != null) {						
						caracteristique.setIdModeleVersion(parentNode.getIdModeleVersion());
						Integer parentId = parentNode.getId() != null ? parentNode.getId() : parentNode.getTempId();
						caracteristique.setIdCaracteristiqueParent(parentId);
					}
					caracteristique.setLLibelleLong(libele.getValue());
					caracteristique.setLCommentaire(commentaires.getValue());					
					
					ClientCaracteristiqueServiceAsync.Util.getInstance().insertOrUpdate(navigation.getContext().getUtilisateur().getIdUtilisateur()
							,navigation.getContext().getMetier().getIdMetier(),  
							caracteristique, new AsyncCallbackWithErrorResolution<Integer>() {
								@Override
								public void onSuccess(Integer arg0) {
									ClientCaracteristiqueServiceAsync.Util.getInstance().findById(arg0,  new AsyncCallbackWithErrorResolution<MdlCaracteristique>() {
		
										@Override
										public void onSuccess(MdlCaracteristique paramT) {
											treeNode.setId(paramT.getIdCaracteristique());
											treeNode.setLibelle(paramT.getLLibelleLong());
											if(caracteristique.getIdCaracteristique() == null){
												getNavigationModelisateurForm().toggleDetailButton(false);
												getModelisateurRegleMessageList().loadListRelgeAndMessage();
												if(paramT.getIdModeleVersion() != null){
													Map<String, String> params = new HashMap<String, String>();
													params.put(ConstantClient.Parameters.MODELISATION, paramT.getIdModeleVersion()+"");
													NavigationEvent navigationEvent = new NavigationEvent(params);
													navigation.goToTabEcran(Action.ACTION_MODELISATEUR,navigationEvent);
												}
											}
											caracteristique = paramT;
											RenameTreeNodeEvent renameTreeNodeEvent = new RenameTreeNodeEvent(getTabId(), caracteristique.getLLibelleLong());
											renameTreeNodeEvent.setNewId(caracteristique.getIdCaracteristique());
											renameTreeNodeEvent.setNewVersionId(caracteristique.getIdModeleVersion());
											bus.fireEvent(renameTreeNodeEvent);
											toggleSaveCancel(false);
											libele.removeValidator(dupplicateValidation);
											libele.clearInvalid();
											HorizontalPanel navigationPanel = getNavigationModelisateurForm().getNavigationPanel();
											if (navigationPanel.getWidgetCount() > 0)
												navigationPanel.remove(navigationPanel.getWidgetCount() - 1);
											final HTML label = new HTML(caracteristique.getLLibelleLong());
											label.setStylePrimaryName("htmlLink");
											navigationPanel.add(label);
										}
									});
									//caracteristique.setIdCaracteristique(arg0);
								}
								
								@Override
								public void onFailure(Throwable caught){	
									if (caught instanceof StatusCodeException) {
										StatusCodeException fe = (StatusCodeException) caught;
										String errMessage = "";
										if(caracteristique.getIdCaracteristiqueParent() == null){
											errMessage = messages.commonDuplicateModeleLibelle(libele.getText());
										}else{
											errMessage = messages.commonDuplicateLibelle(libele.getText());
										}
										if (fe.getEncodedResponse().equals(ConstantError.ERR_DUPLICATED)) {											
											MessageBox box = new MessageBox(messages.commonInfoHeader(),errMessage);
											box.show();
											libele.addValidator(dupplicateValidation);
											libele.validate();
										} else {											
												AppUtil.showMessageBox(caught.getMessage());											
										}
									} else {
										AppUtil.showMessageBox(caught.getMessage());
									}
								}
							});
					}
				
			}
		});
		annulerButton.getHtml().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				showConfirmCloseMessage(messages.modelisateurCaracteristiqueLabel());		
			}
		});
	}

	public void loadForm() {		
			libele.removeValidator(dupplicateValidation);
			if (treeNode.getId() != null || treeNode.getTempId() != null ) {
				Integer id = treeNode.getId() != null ? treeNode.getId() : treeNode.getTempId(); 
				ClientCaracteristiqueServiceAsync.Util.getInstance().findCarateristiqueFormReferenceById(
						id, new AsyncCallbackWithErrorResolution<CarateristiqueFormModel>() {
							@Override
							public void onSuccess(CarateristiqueFormModel result) {
								if( result != null ) {
									caracteristique = result.getCaracteristique();
									libele.clear();
									libele.setValue(caracteristique.getLLibelleLong());
									commentaires.setValue(caracteristique.getLCommentaire());
									storeEde.clear();
									if( result.getListElementEntree() != null && result.getListElementEntree().size() > 0 ) {
										storeEde.addAll(result.getListElementEntree());
									}
									/*storeEds.clear();
									if( result.getListElementSortie() != null && result.getListElementSortie().size() > 0 ) {
										storeEds.addAll(result.getListElementSortie());
									}*/
									gridEds.getLoader().load();
								}
							}
						});
			} else {
				caracteristique = new MdlCaracteristique();				
				libele.clear();
				libele.setValue(treeNode.getLibelle());
				if(libele.getText().trim().equals(messages.commontreenewnode())){
					libele.reset();
					libele.setEmptyText(messages.commontreenewnode());
				}
				commentaires.clear();
				storeEde.clear();
				if(parentNode != null){
					storeEde.add(parentNode);
				}
				
			}
	}

	

	@Override
	protected void resetForm() {
		loadForm();
	}

	public NavigationModelisateurForm getNavigationModelisateurForm() {
		return navigationModelisateurForm;
	}

	public void setNavigationModelisateurForm(NavigationModelisateurForm navigationModelisateurForm) {
		this.navigationModelisateurForm = navigationModelisateurForm;
	}

	public ModelisateurRegleMessageList getModelisateurRegleMessageList() {
		return modelisateurRegleMessageList;
	}

	public void setModelisateurRegleMessageList(ModelisateurRegleMessageList modelisateurRegleMessageList) {
		this.modelisateurRegleMessageList = modelisateurRegleMessageList;
	}


}
