package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurCloseTabEvent extends GwtEvent<ModelisateurCloseTabHandler> {

	private static Type<ModelisateurCloseTabHandler> TYPE = new Type<ModelisateurCloseTabHandler>();

	public static Type<ModelisateurCloseTabHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModelisateurCloseTabHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModelisateurCloseTabHandler handler) {
		handler.onLoad(this);
	}

	private TreeNodeModel treeNode;	
	private TreeNodeModel parentNode;

	private Integer idParent; 
	private String labelParent;

	public ModelisateurCloseTabEvent(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}

	public TreeNodeModel getTreeNode() {
		return treeNode;
	}

	public void setTreeNode(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}
	
	public Integer getIdParent() {
		return idParent;
	}

	public void setIdParent(Integer idParent) {
		this.idParent = idParent;
	}

	public String getLabelParent() {
		return labelParent;
	}

	public void setLabelParent(String labelParent) {
		this.labelParent = labelParent;
	}

	public TreeNodeModel getParentNode() {
		return parentNode;
	}

	public void setParentNode(TreeNodeModel parentNode) {
		this.parentNode = parentNode;
	}
	

	
}
