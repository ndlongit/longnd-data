package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class CompositionHaveChangeEvent  extends GwtEvent<CompositionHaveChangeHandler>{

	private static Type<CompositionHaveChangeHandler> TYPE = new Type<CompositionHaveChangeHandler>();
	public static Type<CompositionHaveChangeHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<CompositionHaveChangeHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(CompositionHaveChangeHandler handler) {
		handler.onLoad(this);
	}
	
	public CompositionHaveChangeEvent() {
	}

}
