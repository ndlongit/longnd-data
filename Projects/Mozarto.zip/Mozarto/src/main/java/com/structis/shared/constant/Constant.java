package com.structis.shared.constant;

public class Constant {

	public final static String TYPE_ARTICLE = "Article";

	public final static String TYPE_PRESTATION = "Prestation";

	public final static String TYPE_ELEMENT_ARTICLE = "ART";

	public final static String TYPE_ELEMENT_PRESTATION = "PRE";

	public final static String TYPE_FAMILLE_FAMILLE = "FAM";
	
	public final static String TYPE_FAMILLE_SOUSFAMILLE = "SFA";
	
	public final static String TYPE_FAMILLE_GROUPE = "GRP";
	
	public final static String TYPE_FAMILLE_SOUSGROUPE = "SGR";
	
	public final static String TYPE_FAMILLE_TYPEPRESTATION = "TPR";
	
	public final static String METIER_ADMIN = "Administration";

	
	//export csv files
	public static final String CLIENT_DATE_STR = "Client_Date";
	public static final String CARACTERISTIQUE_IDMODELEVERSION_STR = "Caracteristique_IDModeleVersion";
	public static final String ELEMENT_SORTBY = "sort_by";
	public static final String ELEMENT_SORTDIR = "sort_dir";
	public static final String LIBELLE_METIER = "metier";
	public static final String ELEMENT_SEARCH_STR = "search_str";
	public static final String ID_METIER = "metier_id";
	public static final String ID_USER = "user_id";
	public static final String CLIENT_TIMEZONEOFFSET = "client_timezone_offset";
}
