package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlModeleMapper;
import com.structis.server.persistence.MdlModeleVersionMapper;
import com.structis.shared.model.reference.ModeleModel;

@Service("modeleService")
public class ModeleServiceImpl implements ModeleService {

	@Autowired
	MdlModeleMapper mapper;
	
	@Autowired
	MdlModeleVersionMapper modeleVersionMapper;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<ModeleModel> findAllByMetier(Integer idModele, Integer idMetier, String sortField, String sortDir) {
		Map map = new HashMap();
		map.put("sortField", sortField);
		map.put("sortDir", sortDir);
		map.put("idMetier", idMetier);
		if (idModele != null){
			map.put("idModele", String.valueOf(idModele));
			return mapper.findByMetierAndModele (map);
		}
		return mapper.findByMetier(map);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public int updateByIdModele(Integer idModele, boolean actif) {
		Map map = new HashMap();
		map.put("idModele", idModele);
		map.put("inActif", actif);
		modeleVersionMapper.updateByIdModele(map);
		return mapper.updateByIdModele(map);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void updateModifiedBy(Integer utilisatuerId, Integer idModeleVersion) {
		Map params = new HashMap();
		params.put("idUtilisateurDmaj", utilisatuerId);
		params.put("idModeleVersion", idModeleVersion);
		modeleVersionMapper.updateModifiedBy(params);
	}

	@Override
	public List<ModeleModel> findAllLastPublicVersionByMetier(Integer idMetier) {
		return mapper.findAllLastPublicVersionByMetier(idMetier);
	}

	@Override
	public int findNVersionByIdModele(Integer idModeleVersion) {
		return modeleVersionMapper.findNVersionByIdModeleVersion(idModeleVersion);
	}
}
