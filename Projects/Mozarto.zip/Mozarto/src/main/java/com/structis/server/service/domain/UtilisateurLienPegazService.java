package com.structis.server.service.domain;

import com.structis.shared.model.UtilisateurLienPegaz;

public interface UtilisateurLienPegazService {
	public void insert(UtilisateurLienPegaz utilisateurLienPegaz);
}
