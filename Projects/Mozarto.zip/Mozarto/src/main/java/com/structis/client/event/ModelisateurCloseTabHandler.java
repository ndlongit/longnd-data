package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ModelisateurCloseTabHandler extends EventHandler {
	void onLoad(ModelisateurCloseTabEvent modelisateurCloseTabEvent);
}
