package com.structis.server.service.domain;

import java.util.List;
import java.util.Map;

import com.sencha.gxt.data.shared.SortDir;
import com.structis.shared.model.CmpComposition;
import com.structis.shared.model.reference.CompositionAccueilModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionAndMessageModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionModel;
import com.structis.shared.model.reference.CompositionCarateristiqueSelectAbleModel;
import com.structis.shared.model.reference.CompositionElementGridModel;
import com.structis.shared.model.reference.CompositionModel;
import com.structis.shared.model.reference.CompositionReferenceGridModel;
import com.structis.shared.model.reference.CompositionTreeComboboxModel;

public interface CompositionService {
	List<CompositionCarateristiqueSelectAbleModel> findCompositionCarateristiqueSelectAbleBeforeLastNode(Integer idModeleVersion);
		
	CompositionCarateristiqueFilterActionAndMessageModel checkActionAfterFilter(Integer idCaracteristiqueSelected,Integer idModeleVersion);
	
	List<CompositionCarateristiqueFilterActionModel> checkActionBeforeFilter(Integer idCaracteristiqueSelected,Integer idModeleVersion);
	
	List<CompositionReferenceGridModel> findCompositionReferenceByCaracteristique(List<Integer> idCaracteristiques,Integer idModeleVersion);
	
	List<CompositionReferenceGridModel> findAllCompositionReferenceByCaracteristiquesLimit(Integer limit,Integer idModeleVersion);
	
	List<CompositionElementGridModel> findCompositionElementByReferences(List<Integer> idReferences,Integer idModeleVersion);
	
	CompositionTreeComboboxModel getCompositionTreeAndComboboxLastNode(Integer idModeleVersion);
	
	String testGetMessage();
	
	Map<Integer, List<String[]>> findMessageByIdReference(Integer idModeleVersion, Integer idReference);
	
	Integer insertUpdateComposition(CompositionModel composition);
	
	CmpComposition findById(Integer idComposition);
	
	void cleanCompositionInfor(CmpComposition composition);
	
	List<CompositionAccueilModel> findCompositionByModeleVersion(Integer idModele, String sortField, SortDir sortDir);

	Integer deleteById(Integer idComposition);
}
