package com.structis.client.util;

import com.structis.shared.model.reference.TreeNodeModel;

public class KeyNodeGenerator {
	private static char DOT = '.';	
	private static int  autoIncrease = 0;
	public static String getSimpleAutoKey() {
		return "" + ++autoIncrease;
	}
	
	public static String getKey(String parentId, String type, Integer id) {
		if( parentId != null )
			return parentId + "-" + type + "-" + id;
		else
			return type + "-" + id;
	}
	
//	public static String gernerateKey(TreeNodeModel parentNode, ModelNodeType type, Integer id) {
//		
//		String key = null;
//		if (parentNode == null ) {
//			key = "";
//		} else {
//			key = parentNode.getKeyPath() ;				
//		}
//		key =  key + DOT + type.getLabel()+ id;				
//		return key;
//	}
//	public static String getParentKey(TreeNodeModel node) {		
//		String key = node.getKeyPath();
//		String parentKey = null;
//		int idx  = 0;
//		if (key == null || key.length() == 0) {
//			return null;
//		}
//		idx = key.lastIndexOf(DOT);
//		if ( idx > 0) {
//			parentKey = key.substring(0, idx);
//		}
//		return parentKey;
//	}
	public static Integer getIdFromKeyPath(String path) {		
		String key = path;		
		int idx  = 0;
		if (key == null || key.length() == 0) {
			return null;
		}
		idx = key.lastIndexOf(DOT);
		if ( idx >= 0) {
			key = key.substring(idx+1);
		}
		if (key.length() > 0) {
			key = key.substring(1);
		}
		return Integer.parseInt(key);		
	}
	
	public static void main(String[] arg) {
		
//		System.out.println(">>>" + getIdFromKeyPath(".C1.C2.R3.E1"));
//		System.out.println(">>>" + getIdFromKeyPath(".C2"));
//		System.out.println(">>>" + getIdFromKeyPath(""));
		System.out.println(">>>" + gernerateKeyWithNewId("", 5));	
	}

	public static String gernerateKeyWithNewId(String path, Integer id) {
		String key = path;		
		int idx  = 0;
		if (key == null || key.length() == 0) {
			return null;
		}
		idx = key.lastIndexOf(DOT);
		if ( idx >= 0) {
			key = key.substring(0, idx+2) + id;
		}
		return key;
	}

	public static String gernerateKey(TreeNodeModel item) {
		return ""+item.hashCode();
	}
}
