package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sencha.gxt.data.shared.SortDir;
import com.structis.server.persistence.ElementMapper;
import com.structis.shared.model.Element;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.CompositionElementGridModel;

/**
 * @author vu.dang
 */
@Service("elementService")
public class ElementServiceImpl implements ElementService {

	@Autowired
	private ElementMapper mapper;

	public Element findById(Integer id) {
		return mapper.findById(id);
	}

	@Transactional
	public Integer insert(Element record) {
		return mapper.insert(record);
	}

	@Transactional
	public Integer update(Element record) {
		return mapper.update(record);
	}

	@Transactional
	public Integer delete(Element record) {
		return mapper.delete(record);
	}

	@Transactional
	public Integer deleteById(Integer id) {
		return mapper.deleteById(id);
	}

	public List<Element> findAll() {
		return mapper.findAll();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Element> findElementByModelVersionAndReference(Integer idModeleVersion, Integer idReference) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);
		return mapper.findByModelversionAndReference(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Element> findActifAndInactifByCriteria(Element element, int firstElement, int numberElements, String sortBy, SortDir sortDir) {
		Map mapParameter = new HashMap();
		mapParameter.put("sortBy", sortBy);
		mapParameter.put("sortDir", sortDir);

		mapParameter.put("first", firstElement);
		mapParameter.put("number", numberElements);
		mapParameter.put("inActif", element.getInActif());
		mapParameter.put("idMetier", element.getIdMetier());
		mapParameter.put("cElement", element.getCElement());
		mapParameter.put("lNomenclatureFournisseur", element.getLNomenclatureFournisseur());
		mapParameter.put("lLibelleLong", element.getLLibelleLong());
		return mapper.findActifAndInactifByCriteria(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Element> findAllByCriteria(Element element, int firstElement, int numberElements, String sortBy, SortDir sortDir) {
		Map mapParameter = new HashMap();
		mapParameter.put("sortBy", sortBy);
		mapParameter.put("sortDir", sortDir);
		mapParameter.put("first", firstElement);
		mapParameter.put("number", numberElements);
		mapParameter.put("idMetier", element.getIdMetier());
		mapParameter.put("cElement", element.getCElement());
		mapParameter.put("lNomenclatureFournisseur", element.getLNomenclatureFournisseur());
		mapParameter.put("lLibelleLong", element.getLLibelleLong());
		return mapper.findAllByCriteria(mapParameter);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Integer findCountByCriteria(Element element, int firstElement, int numberElements, String sortBy, SortDir sortDir){
		Map mapParameter = new HashMap();
		mapParameter.put("sortBy", sortBy);
		mapParameter.put("sortDir", sortDir);
		mapParameter.put("first", firstElement);
		mapParameter.put("number", numberElements);
		mapParameter.put("inActif", element.getInActif());
		mapParameter.put("idMetier", element.getIdMetier());
		mapParameter.put("cElement", element.getCElement());
		mapParameter.put("lNomenclatureFournisseur", element.getLNomenclatureFournisseur());
		mapParameter.put("lLibelleLong", element.getLLibelleLong());
		return mapper.findCountByCriteria(mapParameter);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<AttributEtenduMetierERValueModel> findAttributEtenduElementValueByIdAndMetier(Integer idElement,
			Integer idMetier) {
		Map mapParameter = new HashMap();
		mapParameter.put("idElement", idElement);
		mapParameter.put("idMetier", idMetier);
		return mapper.findAttributElementValue(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<Element> findAllByCriteria(Element element, String sortBy, SortDir sortDir) {
		Map mapParameter = new HashMap();
		mapParameter.put("sortBy", sortBy);
		mapParameter.put("sortDir", sortDir);
		mapParameter.put("inActif", element.getInActif());
		mapParameter.put("idMetier", element.getIdMetier());
		mapParameter.put("cElement", element.getCElement());
		mapParameter.put("lNomenclatureFournisseur", element.getLNomenclatureFournisseur());
		mapParameter.put("lLibelleLong", element.getLLibelleLong());
		return mapper.findAllByCriteria(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<AttributEtenduMetierERValueModel> findAllAttributElementValueByMetier(Integer idMetier) {
		Map mapParameter = new HashMap();
		mapParameter.put("idMetier", idMetier);
		return mapper.findAllAttributElementValue(mapParameter);
	}

	@Override
	public List<Element> findAllByMetier(Integer idMetier) {
		return mapper.findAllByMetier(idMetier);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Element> findAllActifAndInactifElementByMetier(Integer idMetier,Integer numberRecord, String sortBy, SortDir sortDir) {
		Map mapParameter = new HashMap();
		mapParameter.put("idMetier", idMetier);
		mapParameter.put("number", numberRecord);
		mapParameter.put("sortBy", sortBy);
		mapParameter.put("sortDir", sortDir);
		return mapper.findAllActifAndInactifElementByMetier(mapParameter);
	}
	
	@Override
	public Integer findCountAllElementByMetier(Integer idMetier) {
		return mapper.findCountAllElementByMetier(idMetier);
	}

	@Override
	public List<Element> findByBaseCriteria(Element criteria) {
		return mapper.findByBaseCriteria(criteria);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Element findByIdLienCoummun(Integer idModeleVersion,Integer idLienCommun) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommun", idLienCommun);
		return mapper.findByIdLienCommun(mapParameter);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Element> findByCode(String code, Integer idMetier) {
		Map map = new HashMap();
		map.put("cElement", code);
		map.put("idMetier", idMetier);
		return mapper.findByCode(map);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Element> findByNomenclatureFournisseur(String lNomenclatureFournisseur, Integer idMetier) {
		Map map = new HashMap();
		map.put("idMetier", idMetier);
		map.put("lNomenclatureFournisseur", lNomenclatureFournisseur);
		List<Element> findByCode = mapper.findByNomenclatureFournisseur(map);
		return findByCode;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Element findByCodeAndModelVersion(String code, Integer idModeleVersion) {
		Map map = new HashMap();
		map.put("cElement", code);
		map.put("idModeleVersion", idModeleVersion);		
		return mapper.findByCodeAndModelVersion(map);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Element> findByBaseCriteriaAndElementCodeList(Element criteria, List<String> elementCodeList) {
		Map params = new HashMap();
		params.put("elementCodeList", elementCodeList);
		
		params.put("cTypeElement", criteria.getCTypeElement());
		params.put("idFamille", criteria.getIdFamille());
		params.put("idMetier", criteria.getIdMetier());
		params.put("inActif", criteria.getInActif());
		params.put("lNomenclatureFournisseur", criteria.getLNomenclatureFournisseur());
		
		return mapper.findByBaseCriteriaAndElementCodeList(params);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Element> findByBaseCriteriaAndSupplierCodeList(Element criteria, List<String> supplierCodeList) {
		Map params = new HashMap();
		params.put("supplierCodeList", supplierCodeList);
		params.put("cElement", criteria.getCElement());
		params.put("cTypeElement", criteria.getCTypeElement());
		params.put("idFamille", criteria.getIdFamille());
		params.put("idMetier", criteria.getIdMetier());
		params.put("inActif", criteria.getInActif());
		
		return mapper.findByBaseCriteriaAndSupplierCodeList(params);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<CompositionElementGridModel> findCompositionElementByModelversionAndReference(Integer idModeleVersion, Integer idReference) {
		Map map = new HashMap();
		map.put("idModeleVersion", idModeleVersion);
		map.put("idReference", idReference);
		return mapper.findCompositionElementByModelversionAndReference(map);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Element> findCompositionElement(Integer compositionId) {
		Map map = new HashMap();
		map.put("compositionId", compositionId);
		map.put("idReference", null);
		return mapper.findCompositionElement(map);
	}

	@Override
	public List<Element> findManuallySelectedCompositionElement(Integer compositionId) {
		return mapper.findManuallySelectedCompositionElement(compositionId);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Element> findCompositionElementByReference(Integer compositionId, Integer idReference) {
		Map map = new HashMap();
		map.put("compositionId", compositionId);
		map.put("idReference", idReference);
		return mapper.findCompositionElement(map);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Integer findCountByCriteriaAdvanced(Element element, String valeurAttributEtendu) {
		Map mapParameter = new HashMap();
		mapParameter.put("inActif", element.getInActif());
		mapParameter.put("idMetier", element.getIdMetier());
		mapParameter.put("cElement", element.getCElement());
		mapParameter.put("cTypeElement", element.getCTypeElement());
		mapParameter.put("idFamille", element.getIdFamille());
		mapParameter.put("valeurAttributEtendu", valeurAttributEtendu);
		mapParameter.put("lNomenclatureFournisseur", element.getLNomenclatureFournisseur());
		mapParameter.put("lLibelleLong", element.getLLibelleLong());
		return mapper.findCountByCriteriaAdvanced(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<Element> findActifAndInactifByCriteriaAdvanced(Element element, String attribut, int firstElement, int numberElements,
			String sortBy, SortDir sortDir) {
		Map mapParameter = new HashMap();
		mapParameter.put("sortBy", sortBy);
		mapParameter.put("sortDir", sortDir);
		mapParameter.put("first", firstElement);
		mapParameter.put("number", numberElements);
		mapParameter.put("inActif", element.getInActif());
		mapParameter.put("idMetier", element.getIdMetier());
		mapParameter.put("cElement", element.getCElement());
		mapParameter.put("cTypeElement", element.getCTypeElement());
		mapParameter.put("idFamille", element.getIdFamille());
		mapParameter.put("valeurAttributEtendu", attribut);
		mapParameter.put("lNomenclatureFournisseur", element.getLNomenclatureFournisseur());
		mapParameter.put("lLibelleLong", element.getLLibelleLong());
		return mapper.findActifAndInactifByCriteriaAdvanced(mapParameter);
	}
}
