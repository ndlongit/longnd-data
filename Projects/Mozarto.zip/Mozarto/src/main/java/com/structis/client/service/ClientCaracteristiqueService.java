package com.structis.client.service;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.reference.CarateristiqueFormModel;
import com.structis.shared.model.reference.TreeNodeModel;

@RemoteServiceRelativePath("springGwtServices/clientCaracteristiqueService")
public interface ClientCaracteristiqueService extends RemoteService {
	/**
	 * @param idCaracteristique
	 * @return
	 */
	public MdlCaracteristique findById(Integer idCaracteristique);

	public MdlCaracteristique findByIdModele(Integer idModele);

	/**
	 * @param record
	 */
	public void updateCaracteristique(MdlCaracteristique record,Integer metierId);

	public Integer insertOrUpdate(Integer utilisatuerId, Integer metierId, MdlCaracteristique record);

	public CarateristiqueFormModel findCarateristiqueFormReferenceById(Integer idCaracteristique);

	public void remove(MdlCaracteristique record);

	Integer insert(MdlCaracteristique record, Integer metierId, Integer utilisatuerId);
	
	PagingLoadResult<TreeNodeModel> loadChildrenPaging(Integer idModeleVersion, Integer idCaracteristique, PagingLoadConfig loadConfig);

	
}
