package com.structis.client.widget;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.editor.client.Editor;
import com.google.gwt.editor.client.EditorError;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.text.shared.AbstractSafeHtmlRenderer;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.sencha.gxt.cell.core.client.form.ComboBoxCell.TriggerAction;
import com.sencha.gxt.core.client.XTemplates;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.BeforeShowEvent;
import com.sencha.gxt.widget.core.client.event.BeforeShowEvent.BeforeShowHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.ComboBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.form.Validator;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.Action;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.MetierProperties;
import com.structis.client.service.ClientAuthenticationServiceAsync;
import com.structis.shared.config.ApplicationContext;
import com.structis.shared.model.Metier;

public class LoginWindow extends Window {
	private TextButton validerButton;

	private final Messages messages = GWT.create(Messages.class);

	private TextField identifyTextField;

	private PasswordTextBox passTextField;

	private ComboBox<Metier> metierCombobox;

	private boolean show = false;

	private NavigationService navigation = NavigationFactory.getNavigation();

	interface ComboBoxTemplates extends XTemplates {

		@XTemplate("<div  style = \"height:11px;\" >&nbsp;{lLibelle}</div>")
		SafeHtml state(String lLibelle);

	}

	public LoginWindow(String header) {
		this.setHeadingHtml(header);
		setButtonAlign(BoxLayoutPack.END);
		setResizable(false);
		setClosable(false);

		identifyTextField = new TextField();
		FieldLabel identifyFieldLabel = new FieldLabel(identifyTextField, messages.loginWindowLabelIdentifiant());
		HorizontalPanel identifierHPanel = new HorizontalPanel();

		identifierHPanel.add(identifyFieldLabel);
		Image reloadIcon = new Image();
		reloadIcon.setResource(Images.RESOURCES.reload());
		reloadIcon.getElement().getStyle().setProperty("marginTop", "2px");
		reloadIcon.getElement().getStyle().setProperty("marginLeft", "2px");
		reloadIcon.getElement().getStyle().setProperty("cursor", "pointer");

		identifierHPanel.add(reloadIcon);
		passTextField = new PasswordTextBox();

		FieldLabel passFieldLabel = new FieldLabel(passTextField, messages.loginWindowLabelMotdepasse());
		VerticalLayoutContainer container = new VerticalLayoutContainer();
		MetierProperties metierProperties = GWT.create(MetierProperties.class);
		final ListStore<Metier> metierStore = new ListStore<Metier>(metierProperties.idMetier());
		LabelProvider<Metier> lavelProvider = new LabelProvider<Metier>() {

			@Override
			public String getLabel(Metier item) {
				return item.getLLibelle();
			}
		};
		metierCombobox = new ComboBox<Metier>(metierStore, lavelProvider, new AbstractSafeHtmlRenderer<Metier>() {

			@Override
			public SafeHtml render(Metier item) {
				final ComboBoxTemplates comboBoxTemplates = GWT.create(ComboBoxTemplates.class);
				return comboBoxTemplates.state(item.getLLibelle());
			}
		});
		metierCombobox.addValidator(new Validator<Metier>() {

			@Override
			public List<EditorError> validate(Editor<Metier> editor, Metier value) {

				return null;
			}
		});
		metierCombobox.setTriggerAction(TriggerAction.ALL);
		reloadIcon.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				identifyTextField.reset();
				passTextField.setValue("");
				setInChangeMetier(false);
			}
		});

		ClientAuthenticationServiceAsync.Util.getInstance().getAllMetier(
				new AsyncCallbackWithErrorResolution<List<Metier>>() {
					@Override
					public void onSuccess(List<Metier> result) {
						metierStore.clear();
						metierStore.addAll(result);
					}
				});
		FieldLabel metierFieldLabel = new FieldLabel(metierCombobox, messages.commonMetier());

		container.add(identifierHPanel);
		container.add(passFieldLabel);
		container.add(metierFieldLabel);

		add(container);

		validerButton = new TextButton(messages.commonValiderButton());
		validerButton.getElement().getStyle().setProperty("paddingRight", "8px");
		validerButton.addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				if(identifyTextField.isEnabled()){
					boolean invalid = true;
					String identify = identifyTextField.getValue();
					String pass = passTextField.getValue();
					Metier metier = metierCombobox.getValue();
					if( identify == null ) {
						identifyTextField.markInvalid(messages.commonObligatoire());
						invalid = false;
					}
					if( metier == null ) {
						metierCombobox.markInvalid(messages.commonObligatoire());
						invalid = false;
					}
					if( !invalid ) {
						return;
					}
					login(identify, pass, metier.getIdMetier());
				}else{
					Metier metier = metierCombobox.getValue();
					if( metier == null ) {
						metierCombobox.markInvalid(messages.commonObligatoire());
						return;
					}
					changeMetier(metier.getIdMetier());
				}
			}
		});
		addBeforeShowHandler(new BeforeShowHandler() {
			
			@Override
			public void onBeforeShow(BeforeShowEvent event) {
				if(navigation.getContext().getUtilisateur() != null && navigation.getContext().getUtilisateur().getCUtilisateur() != null){
					setInChangeMetier(true);
				}
			}
		});
		addButton(validerButton);
	}

	private void login(String userLogin, String pass, Integer idMetier) {
		ClientAuthenticationServiceAsync.Util.getInstance().login(
				userLogin, pass, idMetier, new AsyncCallbackWithErrorResolution<ApplicationContext>() {
					@Override
					public void onSuccess(ApplicationContext result) {
						if(result != null){
							hide();
							navigation.setApplicationContext(result);
							setInChangeMetier(true);
							navigation.goToEcran(Action.ACTION_ACCEUIL);
							
						}
					}
				});
	}
	private void changeMetier(Integer idMetie){
		ClientAuthenticationServiceAsync.Util.getInstance().changeMetier(idMetie, new AsyncCallbackWithErrorResolution<ApplicationContext>() {

			@Override
			public void onSuccess(ApplicationContext result) {
				if(result != null){
					hide();
					setInChangeMetier(true);
					navigation.setApplicationContext(result);
					navigation.goToEcran(Action.ACTION_ACCEUIL);
				}
			}
		});
	}
	public void setInChangeMetier(boolean isChangeMetier) {
		identifyTextField.setEnabled(!isChangeMetier);
		passTextField.setEnabled(!isChangeMetier);
		if(isChangeMetier){
			identifyTextField.setValue(navigation.getContext().getUtilisateur().getCUtilisateur());
			passTextField.setValue(navigation.getContext().getUtilisateur().getLMotdepasse());
			metierCombobox.setValue(navigation.getContext().getMetier());
		}
	}
}
