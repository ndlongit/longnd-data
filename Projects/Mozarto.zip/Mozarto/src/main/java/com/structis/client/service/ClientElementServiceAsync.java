package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.client.widget.CustomizePagingLoadResult;
import com.structis.shared.model.Element;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ElementFormModel;
import com.structis.shared.model.reference.ElementInsertResult;
import com.structis.shared.model.reference.TreeNodeModel;

public interface ClientElementServiceAsync {
	public static class Util {

		private static ClientElementServiceAsync instance = GWT.create(ClientElementService.class);

		public static ClientElementServiceAsync getInstance() {
			return instance;
		}

	}

	public void insert(Element element, List<AttributEtenduMetierERValueModel> attributEtenduElements, boolean update,
			AsyncCallback<Element> callback);

	public void findById(Integer idElement, AsyncCallback<Element> callback);

	public void loadPaging(PagingLoadConfig loadConfig, Element element, String attribut, boolean rechAvancee, AsyncCallback<CustomizePagingLoadResult<Element>> callback);

	public void findElementFormModelByElementId(Integer idModeleVersion, Integer elementId,
			AsyncCallback<ElementFormModel> asyncCallbackWithErrorResolution);

	public void findElementFormModelByElementCodeAndModelVersion(String text, Integer idModeleVersion,
			AsyncCallback<ElementFormModel> asyncCallbackWithErrorResolution);

	public void updateElement(ElementFormModel elementForm, AsyncCallback<Void> callback);

	public void insertReferenceElementList(Integer nodeParentId, List<TreeNodeModel> list, AsyncCallback<Void> callback);

	public void updateElementInRules(TreeNodeModel parentNode, ElementFormModel elementForm, AsyncCallback<Void> callback);

	public void insertReferenceElementListInRules(TreeNodeModel parentInfo, List<TreeNodeModel> list,
			AsyncCallback<ElementInsertResult> callback);

	public void deleteById(Integer idElement, AsyncCallback<Element> callback);

	void loadParentPaging(Integer idElement, Integer idModelVersion, PagingLoadConfig loadConfig,
			AsyncCallback<PagingLoadResult<MdlReferenceElement>> callback);
}
