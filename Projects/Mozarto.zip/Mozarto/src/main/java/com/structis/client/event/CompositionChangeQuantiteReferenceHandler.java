package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface CompositionChangeQuantiteReferenceHandler extends EventHandler {
	void onLoad(CompositionChangeQuantiteReferenceEvent event);
}
