package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.sencha.gxt.cell.core.client.AbstractEventCell;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.HasSelectHandlers;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.image.Images;
import com.structis.shared.model.AttributEtendu;

public abstract class AttributActionCell extends AbstractEventCell<AttributEtendu> implements
		HasSelectHandlers {

	interface Templates extends SafeHtmlTemplates {
		@SafeHtmlTemplates.Template("<div name=\"{0}\" style=\"{1}\">{2}</div>")
		SafeHtml cell(String name, SafeStyles styles, SafeHtml value);
	}

	public AttributActionCell() {
		super("click", "keydown");
	}

	public static int EMPTY_NEW = 0;

	public static int EDITABLE = 2;
	
	private static Templates templates = GWT.create(Templates.class);
	
	private static final SafeHtml ICON_ADD = makeImage(Images.RESOURCES.add());

	private static final SafeHtml ICON_EDIT = makeImage(Images.RESOURCES.edit());

	private static final SafeHtml ICON_DELETE = makeImage(Images.RESOURCES.delete());

	@Override
	public void onBrowserEvent(com.google.gwt.cell.client.Cell.Context context, Element parent,
			AttributEtendu value, NativeEvent event,
			com.google.gwt.cell.client.ValueUpdater<AttributEtendu> valueUpdater) {
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
		// Handle the click event.
		if( "click".equals(event.getType()) ) {
			EventTarget eventTarget = event.getEventTarget();
			if( parent.isOrHasChild(Element.as(eventTarget)) ) {
				Element el = Element.as(eventTarget);
				if( el.getNodeName().equalsIgnoreCase("IMG") ) {
					if( el.getParentElement().getAttribute("name").equals("ICON_EDIT") ) {
						onEdit(value);
					}
					else if( el.getParentElement().getAttribute("name").equals("ICON_DELETE") ) {
						onDelete(value);
					}
					else if(el.getParentElement().getAttribute("name").equals("ICON_ADD")){
						onAdd(value);
					}
				}
			}
		}
	};

	@Override
	public void render(Context context, AttributEtendu value, SafeHtmlBuilder sb) {
		if( value == null ) {
			return;
		}
		SafeStyles imgStyle = SafeStylesUtils.fromTrustedString("display:inline;cursor:hand;cursor:pointer;padding-left:6px;");
		SafeHtml rendered;
		if (value.getStatus() == EMPTY_NEW ){
        	rendered = templates.cell("ICON_ADD", imgStyle, ICON_ADD);
 	        sb.append(rendered);
        } else {
			rendered = templates.cell("ICON_EDIT", imgStyle, ICON_EDIT);
			sb.append(rendered);
			rendered = templates.cell("ICON_DELETE", imgStyle, ICON_DELETE);
			sb.append(rendered);
        }
	}

	private static SafeHtml makeImage(ImageResource resource) {
		AbstractImagePrototype proto = AbstractImagePrototype.create(resource);
		return proto.getSafeHtml();
	}

	@Override
	public HandlerRegistration addSelectHandler(SelectHandler handler) {
		return addHandler(handler, SelectEvent.getType());
	}

	public abstract void onEdit(AttributEtendu node);

	public abstract void onDelete(AttributEtendu node);

	public abstract void onAdd (AttributEtendu node);

}
