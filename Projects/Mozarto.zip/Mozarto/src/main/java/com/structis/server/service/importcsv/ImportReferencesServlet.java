package com.structis.server.service.importcsv;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;

import com.googlecode.jcsv.reader.internal.CSVReaderBuilder;
import com.structis.client.util.ImportUtil;
import com.structis.server.constant.ConstantServer;
import com.structis.server.core.ConstantError;
import com.structis.server.core.SpringGetter;
import com.structis.server.service.domain.ImportElementErrorService;
import com.structis.server.service.domain.ImportService;
import com.structis.server.service.domain.ModelisateurRegleMessageService;
import com.structis.server.service.domain.ReferenceService;
import com.structis.shared.constant.Constant;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.exception.TechnicalException;
import com.structis.shared.model.Import;
import com.structis.shared.model.ImportElementError;

@SuppressWarnings("serial")
public class ImportReferencesServlet extends CSVImport {

	private static final Logger LOGGER = Logger.getLogger(ImportReferencesServlet.class);

	private ImportService importService;

	private ReferenceService referenceService;

	private ImportElementErrorService importElementErrorService;

	private ModelisateurRegleMessageService modelisateurRegleMessageService;

	private Integer metierId = null;

	private Integer userId = null;

	private Integer nodeId = null;

	private Integer modelVersionId = null;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		importService = (ImportService) SpringGetter.getBean(getServletContext(), ImportService.SERVIECE_NAME);
		referenceService = (ReferenceService) SpringGetter.getBean(getServletContext(), "referenceService");
		importElementErrorService = (ImportElementErrorService) SpringGetter.getBean(
				getServletContext(), ImportElementErrorService.SERVIECE_NAME);
		modelisateurRegleMessageService = (ModelisateurRegleMessageService) SpringGetter.getBean(
				getServletContext(), "modelisateurRegleMessageService");
	}

	@SuppressWarnings("rawtypes")
	private File writeFile(HttpServletRequest request) throws Exception {

		File uploadFile = null;
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);

		if( isMultipart ) {
			FileOutputStream out = null;

			// Create a factory for disk-based file items
			try {
				FileItemFactory factory = new DiskFileItemFactory();

				// Create a new file upload handler
				ServletFileUpload upload = new ServletFileUpload(factory);

				// Parse the request
				List items = upload.parseRequest(request);
				if( items != null && items.size() > 0 ) {
					for( Object object : items ) {

						FileItem item = (FileItem) object;
						String fieldName = item.getFieldName();

						if( item.isFormField() ) {
							if( Constant.ID_METIER.equalsIgnoreCase(fieldName) ) {
								metierId = Integer.parseInt(item.getString());
							}

							else if( ConstantServer.PARAM_USER_ID.equalsIgnoreCase(fieldName) ) {
								userId = Integer.parseInt(item.getString());
							}

							else if( ConstantServer.PARAM_NODE_ID.equalsIgnoreCase(fieldName) ) {
								nodeId = Integer.parseInt(item.getString());
							}

							else if( ConstantServer.PARAM_MODEL_EVERSION_ID.equalsIgnoreCase(fieldName) ) {
								modelVersionId = Integer.parseInt(item.getString());
							}
						}
						else {
							String clientFileLocation = item.getName();
							clientFileLocation = clientFileLocation.replaceAll("\\\\", "/");

							int lastSeperatorIndex = clientFileLocation.lastIndexOf("/");
							String clientFileName = clientFileLocation.substring(lastSeperatorIndex + 1);

							byte[] data = item.get();

							File fileFolder = new File(getServletContext().getRealPath("/files"));
							if( !fileFolder.exists() ) {
								fileFolder.mkdir();
							}

							String uploadFileName = fileFolder.getAbsolutePath() + "/" + clientFileName;
							uploadFile = new File(uploadFileName);

							if( uploadFile.exists() ) {
								uploadFile.delete();
							}

							uploadFile.createNewFile();

							out = new FileOutputStream(uploadFile);
							out.write(data);
							out.close();
						}
					}
				}
			}
			catch( Exception e ) {
				if( out != null ) {
					out.close();
				}
				throw e;
			}
			finally {
				out = null;
			}
			return uploadFile;
		}
		else {
			return null;
		}
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String importType = ConstantServer.IMPORT_TYPE_REFERENCE;

		PrintWriter out = response.getWriter();

		String errorMessage = "";
		String outputFile = null;
		List<String[]> csvData = null;
		Import newImport = null;

		File f = null;

		try {
			f = writeFile(request);

			if( f != null ) {
				Reader reader = new FileReader(f.getAbsolutePath());

				csvData = CSVReaderBuilder.newDefaultReader(reader).readAll();
				csvData = ImportUtil.addErrorColumns(csvData);

				String[] headerColums = csvData.get(0);

				int attributeValueStartIndex = ImportUtil.findStartColumnIndex(headerColums, "Attribut");
				int attributeValueEndIndex = ImportUtil.findEndColumnIndex(headerColums, "valeur");

				int characteristicStartIndex = ImportUtil.findStartColumnIndex(headerColums, "Caracteristique");
				int characteristicEndIndex = ImportUtil.findEndColumnIndex(headerColums, "Caracteristique");

				int elementQuantityStartIndex = findElementQuantityStartIndex(
						headerColums, "Pegaz_element", "Fournisseur_Element");
				int elementQuantityEndIndex = ImportUtil.findEndColumnIndex(headerColums, "Quantite");

				outputFile = ImportUtil.buildOutputFile(f);
				List<String> statusList = new ArrayList<String>();
				statusList.add(ConstantServer.IMPORT_SAS_BEGIN);
				statusList.add(ConstantServer.IMPORT_SAS_VERIFICATION);

				Import importObject = null;
				List<Import> results = importService.findIdsByImportType(importType);

				if( results == null || results.size() == 0 ) {
					newImport = ImportUtil.createNewImport(metierId, userId, importType, modelVersionId);
					importService.insert(newImport);
				}
				else {
					importObject = results.get(0);
					String importStatus = importObject.getCEtatImport();

					if( ConstantServer.IMPORT_SAS_BEGIN.equalsIgnoreCase(importStatus) || ConstantServer.IMPORT_SAS_VERIFICATION.equalsIgnoreCase(importStatus) ) {
						errorMessage = "Vous ne pouvez pas réaliser l'import des références et leurs liaisons car l'utilisateur " + importObject.getUser().getCUtilisateur() + " est en train de le faire.";
						throw new FunctionalException(null, ConstantError.ERR_IMPORT_INPROGRESS, errorMessage);
					}

					Integer importId = importObject.getIdImport();
					importService.deletePreviousImportedData(importId);
					newImport = ImportUtil.createNewImport(metierId, userId, importType, modelVersionId);
					importService.insert(newImport);
				}

				Integer importId = newImport.getIdImport();

				try {
					csvData = referenceService.importReferencesToSas(
							newImport, metierId, csvData, modelVersionId, attributeValueStartIndex, attributeValueEndIndex,
							characteristicStartIndex, characteristicEndIndex, elementQuantityStartIndex,
							elementQuantityEndIndex, messageSource);

					if( ImportUtil.hasErrors(csvData) ) {

						newImport.setCEtatImport(ConstantServer.IMPORT_DATA_FUNCTIONAL_ERROR);

						//Update Import Status
						importService.update(newImport);
					}
					else {
						List<ImportElementError> errors = importElementErrorService.findByImportedId(importId);
						if( errors == null || errors.size() == 0 ) {
							newImport.setCEtatImport(ConstantServer.IMPORT_SAS_VERIFICATION);

							//Update Import Status
							importService.update(newImport);

							referenceService.importReferencesToMozarto(
									importId, metierId, csvData.get(0).length - 1, modelVersionId, csvData,
									attributeValueStartIndex - 1, attributeValueEndIndex - 1, characteristicStartIndex - 1,
									characteristicEndIndex - 1, elementQuantityStartIndex - 1, elementQuantityEndIndex - 1,
									userId, nodeId, modelisateurRegleMessageService, messageSource);

							//Import done
							newImport.setCEtatImport(ConstantServer.IMPORT_DATA_DONE);

						}
						else {
							newImport.setCEtatImport(ConstantServer.IMPORT_DATA_FUNCTIONAL_ERROR);

							//Update Import Status
							importService.update(newImport);
						}
					}
				}
				catch( Exception e ) {
					newImport.setCEtatImport(ConstantServer.IMPORT_DATA_FUNCTIONAL_ERROR);
					throw e;
				}
			}
		}
		catch( Exception e ) {
			if( newImport != null ) {
				newImport.setCEtatImport(ConstantServer.IMPORT_DATA_TECHNICAL_ERROR);
			}
			if( e instanceof FunctionalException || e instanceof TechnicalException ) {
				errorMessage = e.getMessage();
			}
			else {
				errorMessage =  messageSource.getMessage("import.error", null, locale);
			}
			LOGGER.error(e.getMessage(), e);
		}
		finally {
			if( newImport != null ) {

				//Update Import Status
				importService.update(newImport);
			}

			ImportUtil.processImportOutput(request, out, csvData, outputFile, errorMessage);

			out.flush();
			out.close();
		}
	}

	private static int findElementQuantityStartIndex(String[] headerColums, String columnName1, String columnName2) {
		for( int i = 0 ; i < headerColums.length ; i++ ) {
			if( columnName1.equalsIgnoreCase(headerColums[i]) || columnName2.equalsIgnoreCase(headerColums[i]) ) {
				return i;
			}
		}
		return -1;
	}
}
