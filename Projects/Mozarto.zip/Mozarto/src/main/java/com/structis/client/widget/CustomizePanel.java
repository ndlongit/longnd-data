package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;

public abstract class CustomizePanel extends VerticalLayoutContainer {
	protected SimpleEventBus bus;

	protected final Messages messages = GWT.create(Messages.class);

	protected final Images images = GWT.create(Images.class);

	protected VerticalLayoutContainer mainPanel;
	
	protected HorizontalLayoutContainer collapsePanel;

	protected HTML collapseButtonBottom;

	protected HTML expandButtonBottom;

	protected HTML collapseButtonTop;

	protected HTML expandButtonTop;

	
	public CustomizePanel(SimpleEventBus bus){
		setStyleName("whiteBackGround");
		this.bus = bus;
		mainPanel = buildPanel();
		collapsePanel = buildCollapsePanel();
		if(collapseButtonBottom == null)
			collapseButtonBottom = new HTML();
		if(expandButtonBottom == null)
			expandButtonBottom = new HTML();
//		mainPanel.add(collapseButtonBottom);
        
        add(mainPanel, new VerticalLayoutData(1, 1));
        add(collapsePanel);
        collapsePanel.hide();
        collapsePanel.getElement().setPadding(new Padding(3, 10, 0, 3));
        collapsePanel.removeStyleName("whiteBackGround");
        collapsePanel.getElement().getStyle().setProperty("backgroundColor", "#DFE8F6");
        collapsePanel.getElement().setHeight(35, true);
        addHandler();
        
	}
	

	public void addHandler(){
		
	}
	
	public abstract HorizontalLayoutContainer buildCollapsePanel();
	
	public abstract VerticalLayoutContainer buildPanel();

	public VerticalLayoutContainer getMainPanel() {
		return mainPanel;
	}

	public void setMainPanel(VerticalLayoutContainer mainPanel) {
		this.mainPanel = mainPanel;
	}

	public HorizontalLayoutContainer getCollapsePanel() {
		return collapsePanel;
	}

	public void setCollapsePanel(HorizontalLayoutContainer collapsePanel) {
		this.collapsePanel = collapsePanel;
	}

	public void setCollapseButtonBottom(HTML collapseButtonBottom) {
		this.collapseButtonBottom = collapseButtonBottom;
	}

	public HTML getCollapseButtonBottom() {
		return collapseButtonBottom;
	}

	public void setCollapseButtonTop(HTML collapseButtonTop) {
		this.collapseButtonTop = collapseButtonTop;
	}

	public HTML getCollapseButtonTop() {
		return collapseButtonTop;
	}

	public void setExpandButtonTop(HTML expandButtonTop) {
		this.expandButtonTop = expandButtonTop;
	}

	public HTML getExpandButtonTop() {
		return expandButtonTop;
	}


	public HTML getExpandButtonBottom() {
		return expandButtonBottom;
	}


	public void setExpandButtonBottom(HTML expandButtonBottom) {
		this.expandButtonBottom = expandButtonBottom;
	}
	
	
}
