package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.SousReferenceReference;
import com.structis.shared.model.SousReferenceReferenceKey;

public interface SousReferenceReferenceService {

	public static final String SERVICE_NAME = "sousReferenceReferenceService";

	int deleteById(SousReferenceReferenceKey key);

	int delete(SousReferenceReference record);

	int insert(SousReferenceReference record);

	int insertSelective(SousReferenceReference record);

	SousReferenceReference findById(SousReferenceReferenceKey key);

	List<SousReferenceReference> findAll();

	void deleteByReferenceIds(List<Integer> idReferences);
}
