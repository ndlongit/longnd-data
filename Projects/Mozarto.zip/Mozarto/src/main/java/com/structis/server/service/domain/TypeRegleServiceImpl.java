package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlTypeRegleMapper;

@Service
public class TypeRegleServiceImpl implements TypeRegleService {

	@Autowired
	MdlTypeRegleMapper mdlTypeRegleMapper;

	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public String findTypeRegle(String cSourceTypeLien, String cCibleTypeLien) {
		Map mapParameters = new HashMap();
		mapParameters.put("cSourceTypeLien", cSourceTypeLien);
		mapParameters.put("cCibleTypeLien", cCibleTypeLien);
		return mdlTypeRegleMapper.findBySourceAndCible(mapParameters);
	}

}
