package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.RoleUtilisateur;

public interface RoleUtilisateurService {
	
	List<RoleUtilisateur> findAll();
	
	RoleUtilisateur findByUtilisateurAndMetier(Integer idUtilisateur, Integer idMetier);
	
//	List<RoleUtilisateur> findAllNonAdmin();
}
