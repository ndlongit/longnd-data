package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GestionMetierDisableMetierEvent extends GwtEvent<GestionMetierDisableMetierHandler> {

	private static Type<GestionMetierDisableMetierHandler> TYPE = new Type<GestionMetierDisableMetierHandler>();
	private String tabLabel;
	private Integer idMetier;

	public static Type<GestionMetierDisableMetierHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionMetierDisableMetierHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionMetierDisableMetierHandler handler) {
		handler.onLoad(this);
	}	

	public GestionMetierDisableMetierEvent(String tabLabel) {
		this.tabLabel = tabLabel;
	}

	public GestionMetierDisableMetierEvent(Integer idMetier) {
		this.idMetier = idMetier;
	}

	public String getTabLabel() {
		return tabLabel;
	}

	public void setTabLabel(String newLabel) {
		this.tabLabel = newLabel;
	}

	public void setIdMetier(Integer idMetier) {
		this.idMetier = idMetier;
	}

	public Integer getIdMetier() {
		return idMetier;
	}

}
