package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.Element;

public class ElementSelectEvent extends GwtEvent<ElementSelectHandler> {

	private static Type<ElementSelectHandler> TYPE = new Type<ElementSelectHandler>();

	public static Type<ElementSelectHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ElementSelectHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ElementSelectHandler handler) {
		handler.onLoad(this);
	}

	private Element element;

	public ElementSelectEvent(Element element) {
		this.setElement(element);
	}

	public void setElement(Element element) {
		this.element = element;
	}

	public Element getElement() {
		return element;
	}
	
}
