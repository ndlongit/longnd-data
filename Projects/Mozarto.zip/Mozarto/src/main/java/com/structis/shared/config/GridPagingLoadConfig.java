package com.structis.shared.config;

import java.util.List;

import com.sencha.gxt.data.shared.SortInfo;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;

public class GridPagingLoadConfig implements PagingLoadConfig {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public List<? extends SortInfo> getSortInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSortInfo(List<? extends SortInfo> info) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setLimit(int limit) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setOffset(int offset) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getLimit() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getOffset() {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
