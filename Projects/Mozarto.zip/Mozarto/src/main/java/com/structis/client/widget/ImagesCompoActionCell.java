package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.sencha.gxt.cell.core.client.AbstractEventCell;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.HasSelectHandlers;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.constant.ConstantClient;
import com.structis.client.image.Images;
import com.structis.shared.model.reference.CompositionAccueilModel;

public abstract class ImagesCompoActionCell extends AbstractEventCell<CompositionAccueilModel> implements HasSelectHandlers {
	interface Templates extends SafeHtmlTemplates {
		@SafeHtmlTemplates.Template("<div name=\"{0}\" style=\"{1}\">{2}</div>")
		SafeHtml cell(String name, SafeStyles styles, SafeHtml value);
	}

	public ImagesCompoActionCell() {
		super("click", "keydown");
	}

	/**
	 * Create a singleton instance of the templates used to render the cell.
	 */
	private static Templates templates = GWT.create(Templates.class);

	private static final SafeHtml ICON_MODELE_DELETE = makeImage(Images.RESOURCES.delete());

	private static final SafeHtml ICON_MODELE_DUPLICATE = makeImage(Images.RESOURCES.duplicateIcon());

	private static final SafeHtml ICON_MODELE_MODIFY = makeImage(Images.RESOURCES.edit());

	private static final SafeHtml ICON_MODELE_DELETE_DISABLE = makeImage(Images.RESOURCES.deleteDisable());

	private static final SafeHtml ICON_MODELE_MODIFY_DISABLE = makeImage(Images.RESOURCES.editDisable());

	@Override
	public void onBrowserEvent(com.google.gwt.cell.client.Cell.Context context, Element parent, CompositionAccueilModel value,
			NativeEvent event, com.google.gwt.cell.client.ValueUpdater<CompositionAccueilModel> valueUpdater) {
		// Let AbstractCell handle the keydown event.
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
		// Handle the click event.
		if( "click".equals(event.getType()) ) {
			// Ignore clicks that occur outside of the outermost element.
			EventTarget eventTarget = event.getEventTarget();
			if( parent.isOrHasChild(Element.as(eventTarget)) ) {
				// if (parent.getFirstChildElement().isOrHasChild(
				// Element.as(eventTarget))) {
				// use this to get the selected element!!
				Element el = Element.as(eventTarget);
				// check if we really click on the image
				if( el.getNodeName().equalsIgnoreCase("IMG") ) {
					//Window.alert(el.getParentElement().getAttribute("name"));
					if( el.getParentElement().getAttribute("name").equals("ICON_MODELE_DELETE") ) {
						onCompoDelete(value);
					}
					if( el.getParentElement().getAttribute("name").equals("ICON_MODELE_DUPLICATE") ) {
						onCompoDuplicate(value);
					}
					if( el.getParentElement().getAttribute("name").equals("ICON_MODELE_MODIFY") ) {
						onCompoModify(value);
					}
				}
			}
		}
	};

	@Override
	public void render(Context context, CompositionAccueilModel value, SafeHtmlBuilder sb) {
		if( value == null ) {
			return;
		}
		SafeStyles imgStyle = SafeStylesUtils.fromTrustedString("float:left;cursor:hand;cursor:pointer;");
		SafeHtml rendered;

		rendered = templates.cell("ICON_MODELE_DUPLICATE", imgStyle, ICON_MODELE_DUPLICATE);
		sb.append(rendered);
		if (ConstantClient.CODE_APPLICATION_MOZARTO.equals(value.getCApplicationOrigine())){
			rendered = templates.cell("ICON_MODELE_MODIFY", imgStyle, ICON_MODELE_MODIFY);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_DELETE", imgStyle, ICON_MODELE_DELETE);
			sb.append(rendered);
		}
		else {
			rendered = templates.cell("ICON_MODELE_MODIFY_DISABLE", imgStyle, ICON_MODELE_MODIFY_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_DELETE_DISABLE", imgStyle, ICON_MODELE_DELETE_DISABLE);
			sb.append(rendered);
		}
	}

	private static SafeHtml makeImage(ImageResource resource) {
		AbstractImagePrototype proto = AbstractImagePrototype.create(resource);
		return proto.getSafeHtml();
	}

	@Override
	public HandlerRegistration addSelectHandler(SelectHandler handler) {
		return addHandler(handler, SelectEvent.getType());
	}

	public abstract void onCompoDuplicate(CompositionAccueilModel compo);

	public abstract void onCompoModify(CompositionAccueilModel compo);

	public abstract void onCompoDelete(CompositionAccueilModel compo);

}
