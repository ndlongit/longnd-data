package com.structis.server.service.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sencha.gxt.data.shared.SortDir;
import com.structis.server.persistence.CmpCompositionMapper;
import com.structis.server.persistence.MdlCaracteristiqueMapper;
import com.structis.shared.comparator.CompositionElementGridModelComparator;
import com.structis.shared.constant.CodeRegle;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.constant.Niveau;
import com.structis.shared.model.CmpCaracteristiqueSelect;
import com.structis.shared.model.CmpCaracteristiqueSelectKey;
import com.structis.shared.model.CmpComposition;
import com.structis.shared.model.CmpElementSelect;
import com.structis.shared.model.CmpElementSelectKey;
import com.structis.shared.model.CmpReference;
import com.structis.shared.model.CmpReferenceElement;
import com.structis.shared.model.CmpReferenceElementKey;
import com.structis.shared.model.CmpRegleElement;
import com.structis.shared.model.CmpRegleElementKey;
import com.structis.shared.model.Element;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlLienCaracteristique;
import com.structis.shared.model.MdlLienElement;
import com.structis.shared.model.MdlLienReference;
import com.structis.shared.model.MdlMessage;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.MdlRegle;
import com.structis.shared.model.reference.CompositionAccueilModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionAndMessageModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionModel;
import com.structis.shared.model.reference.CompositionCarateristiqueModel;
import com.structis.shared.model.reference.CompositionCarateristiqueSelectAbleModel;
import com.structis.shared.model.reference.CompositionElementGridModel;
import com.structis.shared.model.reference.CompositionModel;
import com.structis.shared.model.reference.CompositionReferenceGridModel;
import com.structis.shared.model.reference.CompositionTreeComboboxModel;
import com.structis.shared.model.reference.TreeNodeCompositionModel;
import com.structis.shared.model.reference.TreeNodeModel;

@Service
public class CompositionServiceImpl implements CompositionService {

	@Autowired
	MdlCaracteristiqueMapper mdlCaracteristiqueMapper;
	
	@Autowired
	CmpCompositionMapper cmpCompositionMapper;
	
	@Autowired
	RegleService regleService;

	@Autowired
	LienCommunService lienCommunService;

	@Autowired
	LiencaracteristiqueService liencaracteristiqueService;

	@Autowired
	CaracteristiqueService caracteristiqueService;

	@Autowired
	ReferenceService referenceService;

	@Autowired
	LienReferenceService lienReferenceService;

	@Autowired
	LienElementService lienElementService;

	@Autowired
	ElementService elementService;
	
	@Autowired
	ResourceBundleMessageSource messageSource;
	
	@Autowired
	MessageService messageService;
	
	@Autowired
	CompositionCaracteristiqueSelectService compositionCaracteristiqueSelectService;

	@Autowired
	CompositionElementSelectService compositionElementSelectService;

	@Autowired
	CompositionReferenceElementService compositionReferenceElementService;

	@Autowired
	CompositionRegleElementService compositionRegleElementService;

	@Autowired
	CompositionReferenceService compositionReferenceService;
	
	@Autowired
	TmpCompositionDataElementUtil tmpCompositionDataElementUtil;
	@Override
	public List<CompositionCarateristiqueSelectAbleModel> findCompositionCarateristiqueSelectAbleBeforeLastNode(
			Integer idModeleVersion) {
		/*List<MdlCaracteristique> caracteristiques = caracteristiqueService.findCharacteristicHierarchy(idModeleVersion);
		Map<Integer,Integer> mapCara = new HashMap<Integer,Integer>();
		for(MdlCaracteristique cara:caracteristiques){
			mapCara.put(cara.getIdCaracteristique(), cara.getLevel());
		}*/
		List<CompositionCarateristiqueSelectAbleModel> result = mdlCaracteristiqueMapper.findCompositionCarateristiqueSelectAbleBeforeLastNode(idModeleVersion);
		/*for(CompositionCarateristiqueSelectAbleModel re:result){
			if(mapCara.get(re.getIdCaracteristique()) != null){
				re.setLevel(mapCara.get(re.getIdCaracteristique().intValue()));
			}
		}
		Collections.sort(result,new CompositionCarateristiqueSelectAbleModelComparator());*/
		return result;
	}

	
	@Override
	public CompositionCarateristiqueFilterActionAndMessageModel checkActionAfterFilter(Integer idCaracteristiqueSelected,
			Integer idModeleVersion) {

		List<CompositionCarateristiqueFilterActionModel> actionList = new ArrayList<CompositionCarateristiqueFilterActionModel>();
		Map<Integer,List<String[]>> messagesMap = new HashMap<Integer,List<String[]>>();
		//get all the regle of selected Caracteristique
		int idSourceLienCommunSelected = lienCommunService.getIdLienCommmun(
				idModeleVersion, idCaracteristiqueSelected, ModelNodeType.CARACTERISTIQUE.getLabel(), false);

		//if( idSourceLienCommunSelected > 0){
		List<Integer> idLiens = new ArrayList<Integer>();
		if( idSourceLienCommunSelected > 0 )
			idLiens.add(idSourceLienCommunSelected);
		TreeNodeModel sourceNode = new TreeNodeModel();
		sourceNode.setId(idCaracteristiqueSelected);
		sourceNode.setIdModeleVersion(idModeleVersion);
		sourceNode.setModelType(ModelNodeType.CARACTERISTIQUE);
		idLiens.addAll(regleService.findLienCommunsHierarchyUp(sourceNode, idModeleVersion));
		List<MdlRegle> regleList = new ArrayList<MdlRegle>();
		List<MdlMessage> messageList = new ArrayList<MdlMessage>();
		
		
		
		if( idLiens.size() > 0 ) {
			regleList = regleService.findRegleListExcludeAnnuler(idModeleVersion, idLiens);
			messageList = messageService.findMessageByLienCommun(idModeleVersion, idLiens);
		}
		if(messageList != null && messageList.size() > 0){
			for(MdlMessage message:messageList){
				int niveau = message.getNPriorite();
				List<String[]> messageStrings = new ArrayList<String[]>();
				if(messagesMap.get(niveau) == null){
					messageStrings = new ArrayList<String[]>();
					messagesMap.put(niveau,messageStrings);
				}else{
					messageStrings = messagesMap.get(niveau);
				}
				String[] messageInfo = new String[]{message.getIdMessage()+"",message.getLLibelleLong()};
				messageStrings.add(messageInfo/*message.getIdMessage()+" "+ message.getLLibelleLong()*/);
			}
		}
		if( regleList != null && regleList.size() > 0 ) {
			List<CompositionCarateristiqueSelectAbleModel> currentList = findCompositionCarateristiqueSelectAbleBeforeLastNode(idModeleVersion);
			Map<Integer, Integer> idLienCommunsMap = new HashMap<Integer, Integer>();
			List<Integer> idCaras = new ArrayList<Integer>();
			//loop the combobox list 
			for( CompositionCarateristiqueSelectAbleModel combobox : currentList ) {
				if( combobox.getIdCaracteristique() != idCaracteristiqueSelected ) {
					List<CompositionCarateristiqueModel> listCara = combobox.getCarateristiqueList();
					if( listCara != null && listCara.size() > 0 ) {
						//loop list carateristique inside combobox list 
						for( CompositionCarateristiqueModel cara : listCara ) {
							idCaras.add(cara.getIdCaracteristique());
						}
					}
				}
			}
			List<MdlLienCaracteristique> lienCaracteristiques = liencaracteristiqueService.findLienCaracteristiqueByCaracteristiqueList(
					idModeleVersion, idCaras);
			if( lienCaracteristiques != null && lienCaracteristiques.size() > 0 ) {
				for( MdlLienCaracteristique lienCara : lienCaracteristiques ) {
					idLienCommunsMap.put(lienCara.getIdCaracteristique(), lienCara.getIdLienCommun());
				}
			}
			if( !idLienCommunsMap.isEmpty() ) {
				//loop the combobox list 
				for( CompositionCarateristiqueSelectAbleModel combobox : currentList ) {
					if( combobox.getIdCaracteristique() != idCaracteristiqueSelected ) {
						List<CompositionCarateristiqueModel> listCara = combobox.getCarateristiqueList();
						if( listCara != null && listCara.size() > 0 ) {
							CompositionCarateristiqueFilterActionModel actioFilternModel = new CompositionCarateristiqueFilterActionModel();
							actioFilternModel.setIdCarateristiqueComboboxTarget(combobox.getIdCaracteristique());
							//loop list carateristique inside combobox list 
							for( CompositionCarateristiqueModel cara : listCara ) {
								// get idCommuns
								if( idLienCommunsMap.get(cara.getIdCaracteristique()) != null ) {
									for( MdlRegle regle : regleList ) {
										if( regle.getIdModeleVersion().intValue() == idModeleVersion && regle.getIdCibleLienCommun().intValue() == idLienCommunsMap.get(cara.getIdCaracteristique()).intValue() ) {
											// loop regle if regle target  = item in the  list carateristique -> set action 
											//combobox.setIdCarateristiqueAction(cara.getIdCaracteristique());
											//combobox.setPriorityAction(regle.getNPriorite().intValue());
											actioFilternModel.getActions().put(
													cara.getIdCaracteristique(), regle.getNPriorite().intValue());
										}
									}
								}
							}
							if( actioFilternModel.getActions().size() > 0 ) {
								actionList.add(actioFilternModel);
							}
						}
					}
				}
			}
		}
		CompositionCarateristiqueFilterActionAndMessageModel resultActionMessageModel = new CompositionCarateristiqueFilterActionAndMessageModel();
		resultActionMessageModel.setActionList(actionList);
		resultActionMessageModel.setMessagesMap(messagesMap);
		//}	
		return resultActionMessageModel;
	}
	
	
	@Override
	public List<CompositionReferenceGridModel> findCompositionReferenceByCaracteristique(List<Integer> idCaracteristiques,
			Integer idModeleVersion) {
		Map<Integer, List<CompositionReferenceGridModel>> resultList = new HashMap<Integer,  List<CompositionReferenceGridModel>>();
		if(idCaracteristiques != null && idCaracteristiques.size() ==1){
			return findCompositionReference(idCaracteristiques.get(0),idModeleVersion);
		}else{
			Map<Integer,CompositionReferenceGridModel> finalResult = new HashMap<Integer,CompositionReferenceGridModel>();
			for(Integer idCaracteristique:idCaracteristiques){
				List<CompositionReferenceGridModel> nextResult = findCompositionReference(idCaracteristique,idModeleVersion);
				resultList.put(idCaracteristique, nextResult);
			}
			for(Integer caraKey:resultList.keySet()){
				List<CompositionReferenceGridModel> listModel = resultList.get(caraKey);
				for(CompositionReferenceGridModel model:listModel){
					boolean containAll = true;
					for(Integer caraKey1:resultList.keySet()){
						containAll = false;
						List<CompositionReferenceGridModel> listModel1 = resultList.get(caraKey1);
						/*if(!listModel1.contains(model)){
							containAll = false;
							continue;
						}*/
						for(int i = 0; i < listModel1.size() ; i++){
							if(listModel1.get(i).getIdReference().intValue() == model.getIdReference().intValue()){
								containAll = true;
							}
						}
						if(!containAll){
							break;
						}
					}
					if(containAll){
						if(finalResult.get(model.getIdReference()) == null){
							finalResult.put(model.getIdReference(),model);
						}else if(model.getRelation() > finalResult.get(model.getIdReference()).getRelation()){
							finalResult.put(model.getIdReference(),model);
						}
						
					}
				}
			}
			return new ArrayList<CompositionReferenceGridModel>(finalResult.values());
		}
	}
	
	private List<CompositionReferenceGridModel> findCompositionReference(Integer idCaracteristique, Integer idModeleVersion){
		Map<Integer, CompositionReferenceGridModel> resultList = new HashMap<Integer, CompositionReferenceGridModel>();
		List<Integer> idLienCommunList = new ArrayList<Integer>();
		List<Integer> idCarateristiqueList = new ArrayList<Integer>();
		String idString = "";
		//for( Integer idCaracteristique : idCaracteristiques ) {
			idString += idCaracteristique + ",";
		//}
		idCarateristiqueList.add(idCaracteristique);
		/*
		 * int idSourceLienCommun = lienCommunService.getIdLienCommmun(idModeleVersion,
		 * idCaracteristique, ModelNodeType.CARACTERISTIQUE.getLabel(), false);
		 * if(idSourceLienCommun > 0 ){ idLienCommunList.add(idSourceLienCommun); }
		 */
		//find all Hierarchy parent of list carateristique
		List<Integer> parentParentHierarchy = caracteristiqueService.findIdParentsHierarchy(idString);

		if( parentParentHierarchy != null && parentParentHierarchy.size() > 0 ) {
			idCarateristiqueList.addAll(parentParentHierarchy);
		}
		//find idLienCommun List from id Carateristique List -> add to idLienCommunList
		List<Integer> idLienCommunCaracteristiqueList = new ArrayList<Integer>();
		if( idCarateristiqueList.size() > 0 ) {
			idLienCommunCaracteristiqueList = liencaracteristiqueService.findLienCaracteristiqueIdsByCaracteristiqueList(
					idModeleVersion, idCarateristiqueList);
		}
		//add idLienCommun to idLienCommunList
		if( idLienCommunCaracteristiqueList != null && idLienCommunCaracteristiqueList.size() > 0 ) {
			idLienCommunList.addAll(idLienCommunCaracteristiqueList);
		}

		//get all reference from the regle
		List<MdlRegle> currentRegles = new ArrayList<MdlRegle>();
		if( idLienCommunList.size() > 0 ) {
			currentRegles = regleService.findRegleListExcludeAnnuler(idModeleVersion, idLienCommunList);
		}
		//List<Integer> idCibleFromLienCommuns = new ArrayList<Integer>();
		Map<Integer, MdlRegle> reglesLinkToReferencesMap = new HashMap<Integer, MdlRegle>();
		if( currentRegles.size() > 0 ) {
			for( MdlRegle regle : currentRegles ) {
				if( regle.getCTypeRegle().equals(CodeRegle.CARACTERISTIQUE_VS_REFERENCE.getLabel()) ) {
					//idCibleFromLienCommuns.add(regle.getIdCibleLienCommun());
					reglesLinkToReferencesMap.put(regle.getIdCibleLienCommun(), regle);
				}
			}
		}
		//List<MdlReference> referenceFromRegles = new ArrayList<MdlReference>();
		List<MdlLienReference> referenceFromRegles = new ArrayList<MdlLienReference>();
		if( reglesLinkToReferencesMap.size() > 0 ) {
			referenceFromRegles = lienReferenceService.findIncludeReferenceByIdLienCommuns(
					idModeleVersion, new ArrayList<Integer>(reglesLinkToReferencesMap.keySet()));
		}
		if( referenceFromRegles != null && referenceFromRegles.size() > 0 ) {
			for( MdlLienReference lref : referenceFromRegles ) {
				int defaultSelected = 0;
				if(reglesLinkToReferencesMap.get(lref.getIdLienCommun()).getNPriorite().intValue() ==  Niveau.INDISPENSABLE.getIndex()){
					defaultSelected = 1;
				}
				CompositionReferenceGridModel compositionReferenceGridModel = createCompositionReferenceGridModel(
						lref.getIdReference(), lref.getMdlReference().getLLibelleLong(), true,
						reglesLinkToReferencesMap.get(lref.getIdLienCommun()).getNQuantite().intValue(), defaultSelected,
						reglesLinkToReferencesMap.get(lref.getIdLienCommun()).getNPriorite().intValue());
				if( !resultList.containsKey(lref.getIdReference()) ) {
					//if(reglesLinkToReferencesMap.get(lref.getIdLienCommun()).getNPriorite().intValue() != Niveau.INTERDITE.getIndex()){
						resultList.put(lref.getIdReference(), compositionReferenceGridModel);
					//}
				}else {
					if(reglesLinkToReferencesMap.get(lref.getIdLienCommun()).getNPriorite().intValue() < resultList.get(lref.getIdReference()).getRelation().intValue()){
						//if(resultList.get(lref.getIdReference()).getRelation().intValue() != Niveau.INTERDITE.getIndex()){
							resultList.put(lref.getIdReference(), compositionReferenceGridModel);
						/*}else{
							resultList.remove(lref.getIdReference());
						}*/
					}
					
				}
			}
		}
		//get all direct reference 
		List<MdlReference> referenceDirectFromCaracteristique = referenceService.findReferencesByModeleVersionAndCaracteristiqueList(
				idModeleVersion, idCarateristiqueList);
		if( referenceDirectFromCaracteristique != null && referenceDirectFromCaracteristique.size() > 0 ) {
			for( MdlReference ref : referenceDirectFromCaracteristique ) {
				if( !resultList.containsKey(ref.getIdReference()) ) {
					CompositionReferenceGridModel compositionReferenceGridModel = createCompositionReferenceGridModel(
							ref.getIdReference(), ref.getLLibelleLong(), false, 0, 0, 0);
					resultList.put(ref.getIdReference(), compositionReferenceGridModel);
				}/*else{
					if(resultList.get(ref.getIdReference()).getRelation().intValue() == Niveau.INTERDITE.getIndex()){						
						resultList.remove(ref.getIdReference());
					}
				}*/
			}
		}
		for(Integer key:new ArrayList<Integer>(resultList.keySet())){
			if(resultList.get(key) != null && resultList.get(key).getRelation() != null && resultList.get(key).getRelation().intValue() == Niveau.INTERDITE.getIndex()){
				resultList.remove(key);
			}
		}
		
		return new ArrayList<CompositionReferenceGridModel>(resultList.values());
	}
	private CompositionReferenceGridModel createCompositionReferenceGridModel(Integer idReference, String lLibelleLong,
			boolean isInherited, Integer quantite, Integer status, Integer relation) {
		CompositionReferenceGridModel compositionReferenceGridModel = new CompositionReferenceGridModel();
		compositionReferenceGridModel.setIdReference(idReference);
		compositionReferenceGridModel.setLLibelleLong(lLibelleLong);
		compositionReferenceGridModel.setInherited(isInherited);
		compositionReferenceGridModel.setQuantite(quantite);
		compositionReferenceGridModel.setStatus(status);
		compositionReferenceGridModel.setRelation(relation);
		return compositionReferenceGridModel;
	}

	@Override
	public List<CompositionCarateristiqueFilterActionModel> checkActionBeforeFilter(Integer idCaracteristiqueSelected,
			Integer idModeleVersion) {

		List<CompositionCarateristiqueFilterActionModel> actionList = new ArrayList<CompositionCarateristiqueFilterActionModel>();
		//get all regle have id_cible_lien_commun = carateristique id_lien_commun and priorite = 1 or = 3
		int idSourceLienCommunSelected = lienCommunService.getIdLienCommmun(
				idModeleVersion, idCaracteristiqueSelected, ModelNodeType.CARACTERISTIQUE.getLabel(), false);
		List<MdlRegle> regles = new ArrayList<MdlRegle>();
		if( idSourceLienCommunSelected > 0 ) {
			regles = regleService.findRegleByIdCibleLienCommun(idModeleVersion, idSourceLienCommunSelected);
		}
		//->if regle list size > 0 -> get the current combobox list
		if( regles != null && regles.size() > 0 ) {
			List<CompositionCarateristiqueSelectAbleModel> currentList = findCompositionCarateristiqueSelectAbleBeforeLastNode(idModeleVersion);
			List<Integer> idCaras = new ArrayList<Integer>();
			//loop the combobox list 
			for( CompositionCarateristiqueSelectAbleModel combobox : currentList ) {
				if( combobox.getIdCaracteristique() != idCaracteristiqueSelected ) {
					List<CompositionCarateristiqueModel> listCara = combobox.getCarateristiqueList();
					if( listCara != null && listCara.size() > 0 ) {
						//loop list carateristique inside combobox list 
						for( CompositionCarateristiqueModel cara : listCara ) {
							idCaras.add(cara.getIdCaracteristique());
						}
					}
				}
			}
			List<MdlLienCaracteristique> lienCaracteristiques = liencaracteristiqueService.findLienCaracteristiqueByCaracteristiqueList(
					idModeleVersion, idCaras);
			Map<Integer, Integer> idLienCommunsMap = new HashMap<Integer, Integer>();
			if( lienCaracteristiques != null && lienCaracteristiques.size() > 0 ) {
				for( MdlLienCaracteristique lienCara : lienCaracteristiques ) {
					idLienCommunsMap.put(lienCara.getIdCaracteristique(), lienCara.getIdLienCommun());
				}
			}
			//-> check to return final list
			//loop the combobox list 
			for( CompositionCarateristiqueSelectAbleModel combobox : currentList ) {
				if( combobox.getIdCaracteristique() != idCaracteristiqueSelected ) {
					List<CompositionCarateristiqueModel> listCara = combobox.getCarateristiqueList();
					if( listCara != null && listCara.size() > 0 ) {
						CompositionCarateristiqueFilterActionModel actioFilternModel = new CompositionCarateristiqueFilterActionModel();
						actioFilternModel.setIdCarateristiqueComboboxTarget(combobox.getIdCaracteristique());
						//loop list carateristique inside combobox list 
						for( CompositionCarateristiqueModel cara : listCara ) {
							// get idCommuns
							if( idLienCommunsMap.get(cara.getIdCaracteristique()) != null ) {
								for( MdlRegle regle : regles ) {
									if( regle.getIdModeleVersion().intValue() == idModeleVersion && regle.getIdSourceLienCommun().intValue() == idLienCommunsMap.get(cara.getIdCaracteristique()) && Niveau.CONSEILLEE.getIndex() != regle.getNPriorite() ) {
										// loop regle if regle target  = item in the  list carateristique -> set action 
										//combobox.setIdCarateristiqueAction(cara.getIdCaracteristique());
										//combobox.setPriorityAction(regle.getNPriorite().intValue());
										actioFilternModel.getActions().put(
												cara.getIdCaracteristique(), regle.getNPriorite().intValue());
									}
								}
							}
						}
						if( actioFilternModel.getActions().size() > 0 ) {
							actionList.add(actioFilternModel);
						}
					}
				}
			}
		}

		return actionList;
	}

	@Override
	public List<CompositionReferenceGridModel> findAllCompositionReferenceByCaracteristiquesLimit(Integer limit,
			Integer idModeleVersion) {
		List<CompositionReferenceGridModel> resultList = new ArrayList<CompositionReferenceGridModel>();
		List<MdlReference> references = referenceService.findAllReferenceByIdModeleVersionLimit(limit, idModeleVersion);
		for( MdlReference ref : references ) {
			CompositionReferenceGridModel compositionReferenceGridModel = createCompositionReferenceGridModel(
					ref.getIdReference(), ref.getLLibelleLong(), false, 0, 0, 0);
			resultList.add(compositionReferenceGridModel);
		}
		return resultList;
	}

	@Override
	public List<CompositionElementGridModel> findCompositionElementByReferences(List<Integer> idReferences,
			Integer idModeleVersion) {
		List<CompositionElementGridModel> resultList = new ArrayList<CompositionElementGridModel>();
		if( idReferences.size() > 0 ) {
			List<MdlReference> references = referenceService.findByIds(idModeleVersion, idReferences);
			for( MdlReference reference : references ) {
				List<CompositionElementGridModel> elementtList = new ArrayList<CompositionElementGridModel>();
				List<Integer> idLienCommunList = new ArrayList<Integer>();
				List<MdlRegle> regles = new ArrayList<MdlRegle>();
				//get parent
				TreeNodeModel sourceNode = new TreeNodeModel();
				sourceNode.setId(reference.getIdReference());
				sourceNode.setIdModeleVersion(idModeleVersion);
				sourceNode.setModelType(ModelNodeType.REFERENCE);
				idLienCommunList.addAll(regleService.findLienCommunsHierarchyUp(sourceNode, idModeleVersion));
				// get all idliencommun
				int idSourceLienCommun = lienCommunService.getIdLienCommmun(
						idModeleVersion, reference.getIdReference(), ModelNodeType.REFERENCE.getLabel(), true);
				if( idSourceLienCommun > 0 ) {
					idLienCommunList.add(idSourceLienCommun);
				}
				/**
				 * get all direct current relge of source Node include : regle of parent, regle of
				 * children and regle of sourceNode
				 */
				if( idLienCommunList.size() > 0 ) {
					regles = regleService.findRegleListExcludeAnnuler(idModeleVersion, idLienCommunList);
				}
				//get all element from regle from id lien commun
				if( regles.size() > 0 ) {
					Map<Integer, MdlRegle> reglesLinkToElementsMap = new HashMap<Integer, MdlRegle>();
					for( MdlRegle regle : regles ) {
						if( (CodeRegle.REFERENCE_VS_ELEMENT.getLabel().equals(regle.getCTypeRegle()) && regle.getIdSourceLienCommun().intValue() == idSourceLienCommun) || (CodeRegle.CARACTERISTIQUE_VS_ELEMENT.getLabel().equals(
								regle.getCTypeRegle()) && regle.getIdSourceLienCommun() != idSourceLienCommun) ) {

							//CompositionElementGridModel compositionElementGridModel = createCompositionElementGridModel();
							reglesLinkToElementsMap.put(regle.getIdCibleLienCommun(), regle);
						}
					}
					List<MdlLienElement> elementFromRegles = new ArrayList<MdlLienElement>();
					if( reglesLinkToElementsMap.size() > 0 ) {
						elementFromRegles = lienElementService.findWithElementByIdLienCommuns(
								idModeleVersion, new ArrayList<Integer>(reglesLinkToElementsMap.keySet()));
						for( MdlLienElement lienElement : elementFromRegles ) {
							int niveau = reglesLinkToElementsMap.get(lienElement.getIdLienCommun()).getNPriorite().intValue();
							int defaultSelected = 0;
							int defaultQuantity = reglesLinkToElementsMap.get(lienElement.getIdLienCommun()).getNQuantite().intValue();
							if (niveau == Niveau.INDISPENSABLE.getIndex()) {
								defaultSelected = 1;
							} else if (niveau == Niveau.INTERDITE.getIndex()) {
								defaultQuantity = 0;
							}
							
							CompositionElementGridModel model = createCompositionElementGridModel(
									lienElement.getIdElement(), lienElement.getElement().getCElement(),
									lienElement.getElement().getLLibelleLong(),
									lienElement.getElement().getLNomenclatureFournisseur(),
									defaultQuantity, defaultSelected,
									reference.getIdReference(),
									reglesLinkToElementsMap.get(lienElement.getIdLienCommun()).getNPriorite().intValue(),
									reference.getLLibelleLong(),reglesLinkToElementsMap.get(lienElement.getIdLienCommun()).getIdRegle());
							elementtList.add(model);
						}
					}

				}

				//get all direct element
				List<CompositionElementGridModel> elements = elementService.findCompositionElementByModelversionAndReference(idModeleVersion, reference.getIdReference());
				for( CompositionElementGridModel e : elements ) {
					
					/*CompositionElementGridModel model = createCompositionElementGridModel(
							e.getIdElement(), e.getCElement(), e.getLLibelleLong(), e.getLNomenclatureFournisseur(), 0, 0,
							reference.getIdReference(), 0, reference.getLLibelleLong(),0);*/
					e.setLibeleReference(reference.getLLibelleLong());
					e.setDefaultQuantite(e.getQuantite());
					e.setDefaultStatus(1);
					e.setStatus(1);
					e.setIdReference(reference.getIdReference());
					e.setRelation(0);
					e.setIdRegle(0);
					elementtList.add(e);
				}
				if(elementtList !=null && elementtList.size() > 0){
					Collections.sort(elementtList,new CompositionElementGridModelComparator());
					resultList.addAll(elementtList);
				}
			}
		}
		return resultList;
	}

	private CompositionElementGridModel createCompositionElementGridModel(Integer idElement, String cElement,
			String lLibelleLong, String lNomenclatureFournisseur, Integer quantite, Integer status, Integer idReference,
			Integer relation, String libeleReference,Integer idRegle) {
		CompositionElementGridModel compositionElementGridModel = new CompositionElementGridModel();
		compositionElementGridModel.setIdElement(idElement);
		compositionElementGridModel.setCElement(cElement);
		compositionElementGridModel.setLLibelleLong(lLibelleLong);
		compositionElementGridModel.setLNomenclatureFournisseur(lNomenclatureFournisseur);
		compositionElementGridModel.setDefaultQuantite(quantite);
		compositionElementGridModel.setQuantite(quantite);
		compositionElementGridModel.setDefaultStatus(status);
		compositionElementGridModel.setStatus(status);
		compositionElementGridModel.setIdReference(idReference);
		compositionElementGridModel.setRelation(relation);
		compositionElementGridModel.setLibeleReference(libeleReference);
		compositionElementGridModel.setIdRegle(idRegle);
		return compositionElementGridModel;
	}

	@Override
	public CompositionTreeComboboxModel getCompositionTreeAndComboboxLastNode(Integer idModeleVersion){
		List<MdlCaracteristique> caracteristiques = caracteristiqueService.findCharacteristicHierarchy(idModeleVersion);
		//TreeStore<TreeNodeModel>  treeStore = new TreeStore<TreeNodeModel>(null);
		
		TreeNodeCompositionModel treeModel = new TreeNodeCompositionModel();
		List<CompositionCarateristiqueSelectAbleModel> nodeBeforeLastNodesResult = new ArrayList<CompositionCarateristiqueSelectAbleModel>();
		
		if(caracteristiques != null && caracteristiques.size() > 0){
			Map<Integer,List<MdlCaracteristique>> mapCaracteristiqueWithLevel = new HashMap<Integer,List<MdlCaracteristique>>();
			for(MdlCaracteristique caracteristique:caracteristiques){
				int level = caracteristique.getLevel();
				if(level > 0){
					List<MdlCaracteristique> caracteristiqueList = mapCaracteristiqueWithLevel.get(level);
					if(caracteristiqueList == null){
						caracteristiqueList = new ArrayList<MdlCaracteristique>();
						mapCaracteristiqueWithLevel.put(level, caracteristiqueList);
					}
					
					caracteristiqueList.add(caracteristique);
				}else{
					treeModel.setId(caracteristique.getIdCaracteristique());
					treeModel.setLibelle(caracteristique.getLLibelleLong());
					treeModel.setHasChildren(true);
					/*if(treeModel.getChildren() == null){
						treeModel.setChildren(new ArrayList<TreeNodeCompositionModel>());
					}
					treeModel.addChildren(rootNode);*/
				}
			}
			//List<Integer> nodeBeforeLastNode = caracteristiqueService.findNodesBeforeLastNode(idModeleVersion);
			List<CompositionCarateristiqueSelectAbleModel> nodeBeforeLastNodes = mdlCaracteristiqueMapper.findCompositionCarateristiqueSelectAbleBeforeLastNode(idModeleVersion);
			Map<Integer,CompositionCarateristiqueSelectAbleModel> mapNodeBeforeLastNode = new HashMap<Integer,CompositionCarateristiqueSelectAbleModel>();
			for(CompositionCarateristiqueSelectAbleModel compositionCarateristiqueSelectAbleModel:nodeBeforeLastNodes){
				mapNodeBeforeLastNode.put(compositionCarateristiqueSelectAbleModel.getIdCaracteristique(), compositionCarateristiqueSelectAbleModel);
			}
			if(mapNodeBeforeLastNode.containsKey(treeModel.getId())){
				nodeBeforeLastNodesResult.add(mapNodeBeforeLastNode.get(treeModel.getId()));
			}
			pushCaracteristiquesToTree(mapCaracteristiqueWithLevel,treeModel,1,mapNodeBeforeLastNode,nodeBeforeLastNodesResult);
			
		}
		CompositionTreeComboboxModel model = new CompositionTreeComboboxModel();
		model.setNodeBeforeLastNodesResults(nodeBeforeLastNodesResult);
		model.setTreeNodeCompositionModel(treeModel);
		return model;
	}

	private void pushCaracteristiquesToTree(Map<Integer, List<MdlCaracteristique>> mapCaracteristiqueWithLevel,
			TreeNodeCompositionModel treeModel, int level,
			Map<Integer, CompositionCarateristiqueSelectAbleModel> nodeBeforeLastNodes,
			List<CompositionCarateristiqueSelectAbleModel> nodeBeforeLastNodesResult) {
		if(mapCaracteristiqueWithLevel.get(level) != null){
			List<MdlCaracteristique> caracteristiqueList = mapCaracteristiqueWithLevel.get(level);
			if(caracteristiqueList != null && caracteristiqueList.size() > 0){
				if(treeModel.getChildren() == null){
					treeModel.setChildren(new ArrayList<TreeNodeCompositionModel>());
				}
				for(MdlCaracteristique cara:caracteristiqueList){
					if(cara.getIdCaracteristiqueParent().intValue() == treeModel.getId().intValue()){
						treeModel.setHasChildren(true);
						TreeNodeCompositionModel subNode = new TreeNodeCompositionModel();
						subNode.setId(cara.getIdCaracteristique());
						subNode.setLibelle(cara.getLLibelleLong());
						if(nodeBeforeLastNodes.get(subNode.getId()) != null){
							subNode.setNodeBeforeLastNode(true);
							nodeBeforeLastNodesResult.add(nodeBeforeLastNodes.get(subNode.getId()));
						}
						//subNode.setHasChildren(true);
						treeModel.addChildren(subNode);
						pushCaracteristiquesToTree(mapCaracteristiqueWithLevel, subNode,level+1,nodeBeforeLastNodes,nodeBeforeLastNodesResult);
					}
				}
			}
		}
	}


	@Override
	public String testGetMessage() {
		String errorMessage = messageSource.getMessage("import.subReference.error.importing", null, Locale.FRANCE);
		return errorMessage;
	}


	@Override
	public Map<Integer, List<String[]>> findMessageByIdReference(Integer idModeleVersion, Integer idReference) {
		Map<Integer,List<String[]>> messagesMap = new HashMap<Integer,List<String[]>>();

		String typeSourceLien = ModelNodeType.REFERENCE.getLabel();

		int idSourceLienCommun = lienCommunService.getIdLienCommmun(idModeleVersion, idReference, typeSourceLien, false);
		List<Integer> idLienCommunList = new ArrayList<Integer>();
		if( idSourceLienCommun > 0 ) {
			idLienCommunList.add(idSourceLienCommun);
		}
		TreeNodeModel sourceNode = new TreeNodeModel();
		sourceNode.setId(idReference);
		sourceNode.setIdModeleVersion(idModeleVersion);
		sourceNode.setModelType(ModelNodeType.REFERENCE);
		idLienCommunList.addAll(regleService.findLienCommunsHierarchyUp(sourceNode, idModeleVersion));
		List<MdlMessage> messageList = new ArrayList<MdlMessage>();
		if(idLienCommunList.size() > 0){
			messageList = messageService.findMessageByLienCommun(idModeleVersion, idLienCommunList);
			if(messageList != null && messageList.size() > 0){
				for(MdlMessage message:messageList){
					int niveau = message.getNPriorite();
					List<String[]> messageStrings = new ArrayList<String[]>();
					if(messagesMap.get(niveau) == null){
						messageStrings = new ArrayList<String[]>();
						messagesMap.put(niveau,messageStrings);
					}else{
						messageStrings = messagesMap.get(niveau);
					}
					String[] messageInfo = new String[]{message.getIdMessage()+"",message.getLLibelleLong()};
					messageStrings.add(messageInfo/*message.getIdMessage()+" "+ message.getLLibelleLong()*/);
				}
			}
		}
		return messagesMap;
	}

	
	
	
	@Override
	@Transactional
	public Integer insertUpdateComposition(CompositionModel composition) {
		CmpComposition cmpComposition = composition.getComposition();
		cmpComposition.setDDateheureDmaj(new Date());
		if(cmpComposition.getIdComposition() == null || cmpComposition.getIdComposition() == 0){
			cmpCompositionMapper.insert(cmpComposition);
		}else{
			CmpComposition cmpCompositionUpdate = cmpCompositionMapper.findById(cmpComposition.getIdComposition());
			cmpCompositionUpdate.setLLibelleLong(cmpComposition.getlLibelleLong());
			cmpCompositionMapper.update(cmpCompositionUpdate);
			cmpComposition = cmpCompositionUpdate;
			cleanCompositionInfor(cmpComposition);
		}
		Integer idModeleVersion = cmpComposition.getIdModeleVersion();
		Integer idComposition = cmpComposition.getIdComposition();
		
		//insert list of Caracteristiques
		List<Integer> cmpCaracteristiquesSelect = composition.getCmpCaracteristiquesSelect();
		
		if(cmpCaracteristiquesSelect!=null && cmpCaracteristiquesSelect.size() >0){
			List<CmpCaracteristiqueSelect> cmpCaracteristiqueSelectInsertList = new ArrayList<CmpCaracteristiqueSelect>();
			for(Integer idCarateristique:cmpCaracteristiquesSelect){
				CmpCaracteristiqueSelectKey key = new CmpCaracteristiqueSelectKey(idModeleVersion
						, idComposition, idCarateristique);
				CmpCaracteristiqueSelect cmpCaracteristiqueSelect = new CmpCaracteristiqueSelect();
				cmpCaracteristiqueSelect.setIdModeleVersion(idModeleVersion);
				cmpCaracteristiqueSelect.setId(key);
				cmpCaracteristiqueSelectInsertList.add(cmpCaracteristiqueSelect);
			}
			compositionCaracteristiqueSelectService.insertList(cmpCaracteristiqueSelectInsertList);
		}
		
		//insert list of References
		List<CompositionReferenceGridModel>  compositionReferences = composition.getCmpReference();
		if(compositionReferences != null && compositionReferences.size() >0){
			List<CmpReference> cmpReferenceList = new ArrayList<CmpReference>();
			for(CompositionReferenceGridModel reference:compositionReferences){
				CmpReference cmpReference = new CmpReference( idModeleVersion, idComposition, reference.getIdReference(), (short) reference.getQuantite().intValue());
				cmpReferenceList.add(cmpReference);
			}
			compositionReferenceService.insertList(cmpReferenceList);
		}
		//insert list of _reference_element and _regle_element
		//List<CompositionElementGridModel>  referenceElements = composition.getCmpReferenceRegleElement();
		List<CompositionElementGridModel>  referenceElements = tmpCompositionDataElementUtil.getCdrElementData();
		if(referenceElements != null && referenceElements.size() >0){
			List<CmpReferenceElement> cmpReferenceElementList = new ArrayList<CmpReferenceElement>();
			List<CmpRegleElement> cmpRegleElementList = new ArrayList<CmpRegleElement>();
			for(CompositionElementGridModel element:referenceElements){
				if(element.getRelation().intValue() > 0){
					//insert list _regle_element
					CmpRegleElement cmpRegleElement = new CmpRegleElement();
					CmpRegleElementKey key = new CmpRegleElementKey(
							idModeleVersion, idComposition, element.getIdReference(), element.getIdRegle(),
							element.getIdElement());
					cmpRegleElement.setId(key);
					cmpRegleElement.setNQuantite((short) element.getQuantite().intValue());
					cmpRegleElement.setInSelection((element.getStatus() > 0?true:false));
					cmpRegleElementList.add(cmpRegleElement);
				}else{
					//insert list _reference_element
					CmpReferenceElement cmpReferenceElement = new CmpReferenceElement();
					CmpReferenceElementKey key = new CmpReferenceElementKey(
							idModeleVersion, idComposition, element.getIdReference(), element.getIdElement());
					cmpReferenceElement.setId(key);
					cmpReferenceElement.setNQuantite((short) element.getQuantite().intValue());
					cmpReferenceElement.setInSelection((element.getStatus() > 0?true:false));
					cmpReferenceElementList.add(cmpReferenceElement);
				}
			}
			if(cmpRegleElementList.size() > 0){
				compositionRegleElementService.insertList(cmpRegleElementList);
			}
			if(cmpReferenceElementList.size() > 0){
				compositionReferenceElementService.insertList(cmpReferenceElementList);
			}
		}
		
		//insert list of cmp_element_select
		LinkedHashMap<Integer, Element> cmpElementSelectsMap = tmpCompositionDataElementUtil.getEsElementData();
		if(cmpElementSelectsMap != null && cmpElementSelectsMap.size() >0){
			List<Element> cmpElementSelects = new ArrayList<Element>(cmpElementSelectsMap.values());
			List<CmpElementSelect> cmpElementSelectList = new ArrayList<CmpElementSelect>();
			for(Element element:cmpElementSelects){
				CmpElementSelect cmpElementSelect = new CmpElementSelect();
				CmpElementSelectKey key = new CmpElementSelectKey(idModeleVersion, idComposition, element.getIdElement());
				cmpElementSelect.setId(key);
				cmpElementSelect.setNQuantite((short) element.getQte().intValue());
				cmpElementSelectList.add(cmpElementSelect);
			}
			compositionElementSelectService.insertList(cmpElementSelectList);
		}
		return idComposition;
	}


	@Override
	@Transactional
	public void cleanCompositionInfor(CmpComposition composition) {
		compositionReferenceElementService.deleteByIdComposition(composition.getIdComposition());
		compositionRegleElementService.deleteIdComposition(composition.getIdComposition());
		compositionElementSelectService.deleteByIdComposition(composition.getIdComposition());
		compositionCaracteristiqueSelectService.deleteByIdComposition(composition.getIdComposition());
		compositionReferenceService.deleteByIdComposition(composition.getIdComposition());
		cmpCompositionMapper.update(composition);
	}
	
	
	@Override
	public CmpComposition findById(Integer idComposition) {
		return cmpCompositionMapper.findById(idComposition);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<CompositionAccueilModel> findCompositionByModeleVersion(Integer idModele, String sortField, SortDir sortDir) {
		Map map = new HashMap();
		map.put("sortField", sortField);
		map.put("sortDir", sortDir);
		map.put("idModele", idModele);
		return cmpCompositionMapper.findByModeleVersion (map);
	}


	@Override
	public Integer deleteById(Integer idComposition) {
		compositionCaracteristiqueSelectService.deleteByIdComposition(idComposition);
		compositionElementSelectService.deleteByIdComposition(idComposition);
		compositionReferenceElementService.deleteByIdComposition(idComposition);
		compositionReferenceService.deleteByIdComposition(idComposition);
		compositionRegleElementService.deleteIdComposition(idComposition);
		return cmpCompositionMapper.deleteById(idComposition);
	}
}
