package com.structis.client.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.structis.server.constant.ConstantServer;
import com.structis.shared.model.Import;

public class ImportUtil {

	public static final String[] ATTRIBUTE_VALUE_TYPES = { "NAT", "VAT" };

	private static final String NEW_LINE = "\r\n";

	public static List<String[]> addErrorColumns(List<String[]> csvData) {

		List<String[]> results = new ArrayList<String[]>();

		String[] row = null;
		String[] newRow = null;

		//Header row
		row = csvData.get(0);
		newRow = new String[row.length + 1];
		System.arraycopy(row, 0, newRow, 1, row.length);
		newRow[0] = "Messages erreur";
		results.add(newRow);

		for( int i = 1 ; i < csvData.size() ; i++ ) {
			row = csvData.get(i);
			newRow = new String[row.length + 1];
			System.arraycopy(row, 0, newRow, 1, row.length);
			newRow[0] = null;
			results.add(newRow);
		}
		return results;
	}

	public static String prependError(String error, String newError) {
		if( isNullOrEmpty(newError) ) {
			return error;
		}

		if( isNullOrEmpty(error) ) {
			return "\"" + newError + "\"";
		}

		String result = "\"" + newError + "\", " + error;
		return result;
	}

	public static String appendError(String error, String newError) {
		if( isNullOrEmpty(newError) ) {
			return error;
		}

		if( isNullOrEmpty(error) ) {
			return "\"" + newError + "\"";
		}

		return error += ", \"" + newError + "\"";
	}

	public static void prependErrorToRow(List<String[]> csvData, int rowNum, String error) {
		String[] row = csvData.get(rowNum);
		String currentError = row[0];
		String newError = prependError(currentError, error);
		row[0] = newError;
	}

	public static void addErrorToRow(List<String[]> csvData, int rowNum, String error) {
		String[] row = csvData.get(rowNum);
		String currentError = row[0];
		String newError = appendError(currentError, error);
		row[0] = newError;
	}

	//Build base URL of the application. Ex: http://10.117.71.66:8091/mozarto
	public static String buildBaseUrl(HttpServletRequest request) {
		String protocol = request.getProtocol();
		int index = protocol.lastIndexOf("/");
		String protocolName = protocol.substring(0, index);
		String hostName = request.getServerName();
		int port = request.getServerPort();
		String contextName = request.getContextPath();
		return protocolName.toLowerCase() + "://" + hostName + ":" + port + contextName;
	}

	public static boolean checkMaxLength(String cellValue, int length) {
		if( isNullOrEmpty(cellValue) ) {
			return true;
		}
		try {
			return cellValue.getBytes("utf-8").length <= length;
		}
		catch( UnsupportedEncodingException e ) {
			return false;
		}
	}

	public static void writeResultToFile(List<String[]> csvData, String outputFile) throws IOException {

		File outFile = new File(outputFile);

		if( outFile.exists() ) {
			outFile.delete();
		}

		outFile.createNewFile();

		BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFile));

		for( String[] row : csvData ) {
			String line = "";
			for( int i = 0 ; i < row.length ; i++ ) {
				String cell = row[i];
				if( isNullOrEmpty(cell) ) {
					cell = "";
				}
				
				line += cell + ";";
			}
			
			// Remove last comma
			line = line.substring(0, line.length() - 1);
			out.write(line.getBytes());
			out.write(NEW_LINE.getBytes("utf-8"));
		}
		
		out.flush();
		out.close();
	}

	@SuppressWarnings("rawtypes")
	public static boolean isNullOrEmpty(Object obj) {
		if( obj == null ) {
			return true;
		}

		if( obj instanceof String ) {
			if( obj.toString().trim().length() == 0 ) {
				return true;
			}
		}

		if( obj instanceof String[] ) {
			String[] items = (String[]) obj;

			if( items.length == 0 ) {
				return true;
			}

			for( String item : items ) {
				if( item != null && item.toString().trim().length() > 0 ) {
					return false;
				}
			}

			return true;
		}

		if( obj instanceof Collection ) {
			Collection items = (Collection) obj;
			for( Iterator iterator = items.iterator() ; iterator.hasNext() ; ) {
				Object item = (Object) iterator.next();
				if( item != null && item.toString() != null && item.toString().trim().length() > 0 ) {
					return false;
				}
			}
			return true;
		}

		return false;
	}

	public static boolean hasErrors(List<String[]> csvData) {
		if( isNullOrEmpty(csvData) ) {
			return false;
		}

		for( int i = 1 ; i < csvData.size() ; i++ ) {
			if( !isNullOrEmpty(csvData.get(i)[0]) ) {
				return true;
			}
		}
		return false;
	}

	public static String buildOutputFile(File f) {
		String inputFile = f.getAbsolutePath();

		int commaIndex = inputFile.lastIndexOf(".");

		String fileWithoutExtension = null;

		if( commaIndex > 0 ) {
			fileWithoutExtension = inputFile.substring(0, commaIndex);
		}
		else {
			fileWithoutExtension = inputFile;
		}

		return fileWithoutExtension + "_erreur.csv";
	}

	public static int findStartColumnIndex(String[] headerColums, String columnName) {
		for( int i = 0 ; i < headerColums.length ; i++ ) {
			if( columnName != null && columnName.equalsIgnoreCase(headerColums[i]) ) {
				return i;
			}
		}
		return -1;
	}

	public static int findEndColumnIndex(String[] headerColums, String columnName) {
		for( int i = headerColums.length - 1 ; i >= 0 ; i-- ) {
			if( columnName != null && columnName.equalsIgnoreCase(headerColums[i]) ) {
				return i;
			}
		}
		return -1;
	}

	public static void processImportOutput(HttpServletRequest request, PrintWriter out, List<String[]> csvData,
			String outputFile, String errorMessage) throws IOException {
		if( ImportUtil.hasErrors(csvData) ) {
			ImportUtil.writeResultToFile(csvData, outputFile);
			String resultFile = outputFile.replaceAll("\\\\", "/");

			String baseUrl = ImportUtil.buildBaseUrl(request);
			int lastSeperatorIndex = resultFile.lastIndexOf("/");
			String resultFileName = resultFile.substring(lastSeperatorIndex + 1);
			String downloadFileUrl = baseUrl + "/downloadFile";
			out.println("0=" + downloadFileUrl + "=" + resultFileName);
		}
		else {
			if( ImportUtil.isNullOrEmpty(errorMessage) ) {
				out.println("1=L'import est fait avec succès.");
			}
			else {
				out.println("2=" + errorMessage);
			}
		}
	}

	public static Import createNewImport(Integer metierId, Integer userId, String importType, Integer modelVersionId) {
		Import newImport = new Import();
		newImport.setCEtatImport(ConstantServer.IMPORT_SAS_BEGIN);
		newImport.setCTypeImport(importType);
		newImport.setDDateheureCrea(new Date());
		newImport.setIdUtilisateurCrea(userId);
		newImport.setIdMetier(metierId);
		newImport.setIdModeleVersion(modelVersionId);
		return newImport;
	}
}
