package com.structis.client.panel;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.BeforeSelectionEvent;
import com.google.gwt.event.logical.shared.BeforeSelectionHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.TabItemConfig;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.structis.client.constant.ConstantClient;
import com.structis.client.ecran.EcranLoadable;
import com.structis.client.event.CreerModeleEvent;
import com.structis.client.event.CreerModeleHandler;
import com.structis.client.event.ModelisateurAnnulerCreerModeleEvent;
import com.structis.client.event.ModelisateurAnnulerCreerModeleHandler;
import com.structis.client.event.ModifierModeleEvent;
import com.structis.client.event.ModifierModeleHandler;
import com.structis.client.event.ModifyEvent;
import com.structis.client.message.ActionMessages;
import com.structis.client.message.Messages;
import com.structis.client.navigation.Action;
import com.structis.client.navigation.NavigationEvent;

public class ModelisateurContainer extends AbstractTabPanel implements EcranLoadable {

	private SimpleEventBus bus = new SimpleEventBus();

	private ModelisateurAccueilPanel itemHome;

	ActionMessages actionMessages = GWT.create(ActionMessages.class);

	private ModelisateurPanel modelisateurPanel;

	//private TabPanel modelisateurTabPanel;

	private Messages messages = GWT.create(Messages.class);
	
	private TabItemConfig modelisateurTabConfig;
	@Override
	protected void onAfterFirstAttach() {
		Action[] actions = {Action.ACTION_MODELISATEUR_ACCEUI,Action.ACTION_MODELISATEUR};
		initTabSet(Arrays.asList(actions));
		/*modelisateurTabPanel = new TabPanel();
		//modelisateurTabPanel.setAutoHeight(true);
		modelisateurTabPanel.setResizeTabs(false);
		modelisateurTabPanel.setAnimScroll(false);
		modelisateurTabPanel.setTabScroll(false);
		modelisateurTabPanel.setBorders(false);
		modelisateurTabPanel.setBodyBorder(false);*/
		tabSet.addStyleName("sub-tab-panel");
		itemHome = new ModelisateurAccueilPanel(bus);

		modelisateurPanel = new ModelisateurPanel(bus);

		tabSet.add(itemHome, actionMessages.getString(Action.ACTION_MODELISATEUR_ACCEUI.getLabel()));
		modelisateurTabConfig = new TabItemConfig(messages.modelisateurLabel());
		modelisateurTabConfig.setEnabled(false);
//		modelisateurPanel.setEnabled(false);
		tabSet.add(modelisateurPanel, modelisateurTabConfig);
		//modelisateurTabPanel.setActiveWidget(modelisateurPanel);
		tabSet.setActiveWidget(itemHome);
		add(tabSet);
		bus.addHandler(CreerModeleEvent.getType(), new CreerModeleHandler() {
			
			@Override
			public void onLoad(CreerModeleEvent creerModeleEvent) {
				removeAllTab();
				modelisateurTabConfig.setEnabled(true);
				tabSet.update(modelisateurPanel, modelisateurTabConfig);
				tabSet.setActiveWidget(modelisateurPanel);
				modelisateurPanel.getModelisateurTreePanel().createTree();
				navigation.getBus().fireEvent(new ModifyEvent(false));
			}
		});
		
		bus.addHandler(ModifierModeleEvent.getType(), new ModifierModeleHandler() {
			
			@Override
			public void onLoad(ModifierModeleEvent modifierModeleEvent) {
				int idModeleVersion = 0;
				removeAllTab();
				
				modelisateurTabConfig.setEnabled(true);
				tabSet.update(modelisateurPanel, modelisateurTabConfig);
				/*modelisateurTabPanel.remove(modelisateurPanel);
				modelisateurTabPanel.add(modelisateurPanel, modelisateurTabConfig);*/
				tabSet.setActiveWidget(modelisateurPanel);
//				modelisateurPanel.setEnabled(true);
				if(modifierModeleEvent.getIdModeleVersion() != null){
					idModeleVersion = modifierModeleEvent.getIdModeleVersion();
					Map<String, String> params = new HashMap<String, String>();
					params.put(ConstantClient.Parameters.MODELISATION, idModeleVersion+"");
					NavigationEvent navigationEvent = new NavigationEvent(params);
					navigation.goToTabEcran(Action.ACTION_MODELISATEUR,navigationEvent);
				}
				modelisateurPanel.getModelisateurTreePanel().loadTree(idModeleVersion);
				
			}
		});
		
		BeforeSelectionHandler<Widget> handler = new BeforeSelectionHandler<Widget>() {
		      @Override
		      public void onBeforeSelection(BeforeSelectionEvent<Widget> event) {
		        Widget w = event.getItem();
		        if (w instanceof ModelisateurAccueilPanel){
		        						
		        }
		      }
		    };
		    tabSet.addBeforeSelectionHandler(handler);
		    tabSet.addSelectionHandler(new SelectionHandler<Widget>() {
			@Override
			public void onSelection(SelectionEvent<Widget> event) {
				Widget w = event.getSelectedItem();
				int index = 0;
		        if (w instanceof ModelisateurAccueilPanel){
		        	AbstractModelisateurEditForm modifform = null;
		        	final TabPanel tabPanel = modelisateurPanel.getDetailFormTabPanel().getTabPanel();
					for (int i = 0; i < tabPanel.getWidgetCount(); i++){
		        		Widget obj = tabPanel.getWidget(i);
		        		if (obj instanceof NavigationModelisateurForm) {		
							AbstractModelisateurEditForm form = ((NavigationModelisateurForm) obj).getDetailForm();
							
			        		if (form.changed){
			        			tabPanel.setActiveWidget(form);
			        			modifform = form;
			        			index = i;
			        		}
		        		}
		        	}
					if(modifform != null){
	        			tabPanel.setActiveWidget(tabPanel.getWidget(index));
	        			tabSet.setActiveWidget(modelisateurPanel);
	        			MessageBox messsageBox = new MessageBox(messages.commonInfoHeader(), messages.modelisateurFormClosetabInfo());
	        			messsageBox.show();
	        			messsageBox.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
	        			return;
					}
	
					else{
						ModelisateurAccueilPanel accueilPanel = (ModelisateurAccueilPanel) w;
			        	accueilPanel.getAccueilModeleGrid().getGrid().getLoader().load();
		
						modelisateurTabConfig.setEnabled(false);
						tabSet.update(modelisateurPanel, modelisateurTabConfig);
			        }
				}
			}
		});
	    bus.addHandler(ModelisateurAnnulerCreerModeleEvent.getType(), new ModelisateurAnnulerCreerModeleHandler() {
			
			@Override
			public void onLoad(ModelisateurAnnulerCreerModeleEvent annulerCreerModeleEvent) {
				tabSet.setActiveWidget(itemHome);

				modelisateurTabConfig.setEnabled(false);
			}
		});
	    tabSet.addSelectionHandler(new SelectionHandler<Widget>() {
			
			@Override
			public void onSelection(SelectionEvent<Widget> event) {
				modelisateurPanel.forceLayout();
			}
		});
	}

	@Override
	public void onLoadApplication(NavigationEvent event) {
		if(event != null){
			String idModele = event.getParameter(ConstantClient.Parameters.MODELISATION);
			if(idModele != null ){
				int idModeleVersion = Integer.valueOf(idModele);
				modelisateurTabConfig.setEnabled(true);
				tabSet.update(modelisateurPanel, modelisateurTabConfig);
				tabSet.setActiveWidget(modelisateurPanel);
				modelisateurPanel.getModelisateurTreePanel().loadTree(idModeleVersion);
			}
		}
	}
	private void removeAllTab(){
		TabPanel tabPanel = modelisateurPanel.getDetailFormTabPanel().getTabPanel();
		while(tabPanel.getWidgetCount() > 0){
			tabPanel.remove(tabPanel.getActiveWidget());
		}
	}
}
