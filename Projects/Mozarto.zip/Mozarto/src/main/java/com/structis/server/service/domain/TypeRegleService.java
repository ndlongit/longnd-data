package com.structis.server.service.domain;

public interface TypeRegleService {
	String findTypeRegle(String cSourceTypeLien, String cCibleTypeLien);
}
