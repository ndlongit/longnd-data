package com.structis.server.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class FileDownloadServlet extends HttpServlet {

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fileName = request.getParameter("fileName").replaceAll("%20", " ");
		File fileFolder = new File(getServletContext().getRealPath("/files"));
		String downloadFileName = fileFolder.getAbsolutePath() + "/" + fileName;

		FileInputStream fileToDownload = new FileInputStream(downloadFileName);
		ServletOutputStream output = response.getOutputStream();
		response.setContentType("application/msexcel");
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
		response.setContentLength(fileToDownload.available());
		response.setCharacterEncoding("utf-8");

		int c;
		while( (c = fileToDownload.read()) != -1 ) {
			output.write(c);
		}

		output.flush();
		output.close();
		fileToDownload.close();
	}
}
