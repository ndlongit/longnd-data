package com.structis.server.service.importcsv;

import java.util.List;
import java.util.Locale;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import org.springframework.context.support.ResourceBundleMessageSource;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.structis.client.navigation.NavigationFactory;
import com.structis.server.core.SpringGetter;

@SuppressWarnings("serial")
public abstract class CSVImport extends RemoteServiceServlet {

	protected static final String VALUE = "VALEUR";

	protected static final String ATTRIBUT = "ATTRIBUT";

	protected static final String CODE_ELEMENT = "CODE ELEMENT";

	protected static Locale locale;

	protected static ResourceBundleMessageSource messageSource;

	static {
		locale = new Locale(NavigationFactory.getNavigation().getContext().getLanguageCode());
	}

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		messageSource = (ResourceBundleMessageSource) SpringGetter.getBean(getServletContext(), "messageSource");
	}

	protected static String buildRequiredErrorMessage(String fieldName) {
		Object[] params = { fieldName };
		return messageSource.getMessage("import.error.common.required", params, locale);
	}

	protected static String buildMaxLengthErrorMessage(String fieldName, int length) {
		Object[] params = { fieldName, length };
		return messageSource.getMessage("import.error.common.maxLength", params, locale);
	}

	public static String validateHeaderColumnNames(List<String> fixedHeaderColumns, String[] csvHeaderColums) {
		String error = ""; 
		for( int i = 1 ; i < csvHeaderColums.length ; i++ ) {
			String headerColumn = csvHeaderColums[i];
			if( !fixedHeaderColumns.contains(headerColumn.toUpperCase()) ) {
				Object[] params = { headerColumn };
				if( error == "" ) {//import.error.headerColumn.invalid
					error = "\"" + messageSource.getMessage("import.error.headerColumn.invalid", params, locale) + "\"";
				}
				else {
					error += ", \"" + messageSource.getMessage("import.error.headerColumn.invalid", params, locale) + "\"";
				}
			}
		}

		return error;
	}
}
