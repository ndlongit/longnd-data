package com.structis.client.panel;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.service.ClientAttributEtenduServiceAsync;
import com.structis.shared.model.AttributEtendu;

public class GestionDuMetierForm extends AbstractGestionMetierForm {

	private TextField libelle;
	private FieldSet infoFieldSet;
	
	public GestionDuMetierForm(SimpleEventBus bus) {
		super(bus);
	}

	protected void buildForm() {
		super.buildForm();
	}

	protected void addHandler() {
		addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent arg0) {
				container.setWidth(arg0.getWidth());
				container.setHeight(arg0.getHeight());
			}
		});
		container.addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent arg0) {
				resizeForm();
			}
		});
		validerButton.addSelectHandler(new SelectHandler() {
			
			@Override
			public void onSelect(SelectEvent event) {
				validerForm();
			}
		});
		annulerButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				annulerForm();
			}
		});
	}

	public TextField getLibelle() {
		return libelle;
	}

	public void setLibelle(TextField libelle) {
		this.libelle = libelle;
	}

	@Override
	public void buildInfoSet() {
		libelle = new TextField();
		libelle.setWidth("auto");
		infoFieldSet = new FieldSet();
		infoFieldSet.setHeadingText(messages.metiersFormInformation());
		infoFieldSet.add(new FieldLabel(libelle, messages.metiersFormLibelle()), new VerticalLayoutData(1, 1));
		infoSet.add(infoFieldSet, new VerticalLayoutData(1, 1));
	}

	@Override
	public void validerForm() {
		attributReferenceGrid.getGrid().getStore().commitChanges();
		attributElementGrid.getGrid().getStore().commitChanges();
		List<AttributEtendu> attributEtendus = new ArrayList<AttributEtendu>();
		addAttributs(attributReferenceGrid, attributEtendus);
		addAttributs(attributElementGrid, attributEtendus);
		ClientAttributEtenduServiceAsync.Util.getInstance().insertAndUpdate(
				attributEtendus, idMetier, new AsyncCallbackWithErrorResolution<Integer>() {

					@Override
					public void onSuccess(Integer arg0) {
						toggleChange(false);
					}
				});
	}

	@Override
	public void annulerForm() {
		ConfirmMessageBox messageBox = new ConfirmMessageBox(
				messages.commonConfirmation(), messages.metiersFormAnnulermessage());
		messageBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
		messageBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
		messageBox.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				fillGrids();
				toggleChange(false);
			}
		});
		messageBox.show();
	}

	@Override
	public void resizeForm() {
		libelle.setWidth("auto");
		attrefFieldSet.setHeight(container.getElement().getClientHeight() / 3);
	}
}
