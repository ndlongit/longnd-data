package com.structis.client.panel;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.structis.client.navigation.Action;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;


public class AbstractTabPanel extends SimpleContainer{
	protected List<Action> tabActionList = new ArrayList<Action>();
	protected TabPanel tabSet;
	protected NavigationService navigation = NavigationFactory.getNavigation();
	
	protected void initTabSet(List<Action> actions){
		tabActionList.clear();
		for(Action action:actions){
			tabActionList.add(action);
		}
		tabSet = new TabPanel();
	    tabSet.setResizeTabs(false);
	    
	    tabSet.setAnimScroll(true);
	    tabSet.setTabScroll(true);
	    tabSet.setBorders(false);
	    tabSet.setBodyBorder(false);
	    tabSet.setShadow(false);
	    tabSet.addSelectionHandler(new SelectionHandler<Widget>() {
			@Override
			public void onSelection(SelectionEvent<Widget> event) {
			    //get action
		        Widget w = event.getSelectedItem();
		        tabSet.getWidgetIndex(w);
		        Action action = tabActionList.get(tabSet.getWidgetIndex(w));
			    navigation.goToTabEcran(action,new NavigationEvent());
			}
		});
	}
}
