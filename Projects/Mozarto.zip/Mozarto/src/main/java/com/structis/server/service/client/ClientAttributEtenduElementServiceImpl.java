package com.structis.server.service.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.client.service.ClientAttributEtenduElementService;
import com.structis.server.service.domain.AttributEtenduElementService;
import com.structis.shared.model.AttributEtenduElement;

@Service("clientAttributEtenduElementService")
public class ClientAttributEtenduElementServiceImpl implements ClientAttributEtenduElementService {

	@Autowired
	AttributEtenduElementService attributEtenduElementService;
	@Override
	public List<AttributEtenduElement> insert(List<AttributEtenduElement> attributEtenduElement) {
		for (int i = 0; i < attributEtenduElement.size(); i++){
			attributEtenduElementService.insert(attributEtenduElement.get(i));
		}
		return attributEtenduElement;
	}

}
