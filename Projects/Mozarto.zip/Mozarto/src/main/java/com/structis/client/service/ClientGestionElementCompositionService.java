package com.structis.client.service;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.GestionElementCompositionReference;

@RemoteServiceRelativePath("springGwtServices/gestionElementCompositionService")
public interface ClientGestionElementCompositionService extends RemoteService {

	public GestionElementCompositionReference getGestionElementCompositionReference (Integer elementId, Integer metierId);
	
	public Metier getMetier (Integer idMetier);

}
