package com.structis.client.service;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * The client side stub for the RPC service.
 */
@RemoteServiceRelativePath("test")
public interface TestService extends RemoteService {
	/**
	 * 
	 * @param name
	 * @return
	 * @throws IllegalArgumentException
	 */
  String testServer(String name) throws IllegalArgumentException;
}
