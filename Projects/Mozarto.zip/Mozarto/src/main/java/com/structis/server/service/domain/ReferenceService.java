package com.structis.server.service.domain;

import java.util.List;

import org.springframework.context.support.ResourceBundleMessageSource;

import com.structis.shared.exception.FunctionalException;
import com.structis.shared.model.Import;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.SousReferenceModel;
import com.structis.shared.model.reference.ValuePlaceHolder;

public interface ReferenceService {
	/**
	 * @param idModeleVersion
	 * @param idCaracteristique
	 * @return
	 */
	List<MdlReference> findReferenceByModeleVersionAndCaracteristique(Integer idModeleVersion, Integer idCaracteristique);

	/**
	 * @param idModeleVersion
	 * @param idCaracteristique
	 * @return
	 */
	List<Integer> findReferenceIdListByModeleVersionAndCaracteristiqueList(Integer idModeleVersion,
			List<Integer> idCaracteristiques);
	/*
	 * 
	 */
	List<MdlReference> findReferencesByModeleVersionAndCaracteristiqueList(Integer idModeleVersion,
			List<Integer> idCaracteristiques);
	/**
	 * @param idModeleVersion
	 * @param idCaracteristique
	 * @return
	 */
	List<ValuePlaceHolder> findElementNumberOfReferenceByModeleVersionAndCaracteristique(Integer idModeleVersion,
			Integer idCaracteristique);

	/**
	 * @param idReference
	 * @return
	 */
	MdlReference findById(Integer idReference);
	/**
	 * 
	 * @param idModeleVersion
	 * @param idReferences
	 * @return
	 */
	List<MdlReference> findByIds(Integer idModeleVersion,List<Integer> idReferences);

	/**
	 * find list Attribut Etendu of reference depend to metier
	 * 
	 * @param idReference
	 * @param idMetier
	 * @return
	 */
	List<AttributEtenduMetierERValueModel> findAttributEtenduMetierERValueByIdAndMetier(Integer idModeleVersion,
			Integer idReference, Integer idMetier);

	/**
	 * @param reference
	 */
	void update(MdlReference reference);

	/**
	 * @param idModeleVersion
	 * @param libelle
	 * @return
	 */
	List<MdlReference> findByModeleVersionAndLibelle(Integer idModeleVersion, Integer idReference, String libelle);

	/**
	 * find all refenrences
	 * 
	 * @return
	 */
	List<MdlReference> findAllReferenceByIdModeleVersion(Integer idModeleVersion);
	
	List<MdlReference> findAllReferenceByIdModeleVersionLimit(Integer limitNumber,Integer idModeleVersion);

	/**
	 * find all sous-refenrences
	 * 
	 * @return
	 */
	List<SousReferenceModel> findAllSousReferenceByIdModeleVersion(Integer idModeleVersion);

	MdlReference findByIdLienCommun(Integer idModeleVersion, Integer idLienCommun);

	/**
	 * update attribute value of reference
	 * 
	 * @param attributs
	 */
	void updateAttributeAttendu(Integer idModeleVersion, Integer idReference,
			List<AttributEtenduMetierERValueModel> attributs, boolean isSous);

	/**
	 * update carateristique of reference
	 * 
	 * @param carateristiqueReferences
	 */
	void updateCarateristiqueReference(Integer idModeleVersion, Integer idReference,
			List<MdlCarateristiqueReference> carateristiqueReferences, boolean isSous);

	/**
	 * update element value of reference
	 * 
	 * @param referenceElement
	 */
	void updateReferenceElement(Integer idModelVersion, Integer idReference, List<MdlReferenceElement> referenceElement, boolean isSous);

	void insert(Integer idCaracteristiqueParent, MdlReference record);

	void update(MdlReference reference, List<AttributEtenduMetierERValueModel> listAttributEtendu,
			List<MdlCarateristiqueReference> listElementEntree, List<MdlReferenceElement> listElementSortie);

	List<String[]> importReferencesToSas(Import importData, Integer metierId, List<String[]> csvData, int modelVersion,
			int attributeValueStartIndex, int attributeValueEndIndex, int characteristicStartIndex,
			int characteristicEndIndex, int elementQuantityStartIndex, int elementQuantityEndIndex, ResourceBundleMessageSource messageSource) throws Exception;

	void delete(Integer idCaracteristiqueParent, MdlReference record);

	void insert(MdlReference reference) throws FunctionalException;

	Integer insertOrUpdate(Integer utilisateurId, MdlReference reference,
			List<AttributEtenduMetierERValueModel> listAttributEtendu, List<MdlCarateristiqueReference> listElementEntree,
			List<MdlReferenceElement> listElementSortie);

	List<MdlReference> findByBaseCriteria(MdlReference criteria);

	void importReferencesToMozarto(Integer importId, Integer metierId, int i, Integer modelVersionId, List<String[]> csvData,
			int attributeValueStartIndex, int attributeValueEndIndex, int characteristicStartIndex,
			int characteristicEndIndex, int elementQuantityStartIndex, int elementQuantityEndIndex, Integer userId,
			Integer nodeId, ModelisateurRegleMessageService modelisateurRegleMessageServicer, ResourceBundleMessageSource messageSource)
			throws Exception;
	
	List<ValuePlaceHolder>  findParentNumberByidReferencesNotInIdCarateristiques(Integer idModelVersion, List<Integer> idReferences);

	Integer insertAndLink(Integer utilisateurId, MdlReference reference,
			List<AttributEtenduMetierERValueModel> listAttributEtendu, List<MdlCarateristiqueReference> listElementEntree,
			List<MdlReferenceElement> listElementSortie, ModelisateurRegleMessageService modelisateurRegleMessageService,
			List<String[]> csvData, Integer lineNumber, ResourceBundleMessageSource messageSource);

	Integer updateAndLink(Integer utilisateurId, MdlReference reference,
			List<AttributEtenduMetierERValueModel> listAttributEtendu, List<MdlCarateristiqueReference> listElementEntree,
			List<MdlReferenceElement> listElementSortie, ModelisateurRegleMessageService modelisateurRegleMessageService,
			List<String[]> csvData, Integer lineNumber, ResourceBundleMessageSource messageSource);
	
	
	void deleteSousModele(Integer idModeleVersion,List<Integer> idReferences);
	
	void deleteById(List<Integer> idReferences);
	
	Integer coundSousModeleByIdReference(Integer idModelVersion, Integer idReferences);

	List<AttributEtenduMetierERValueModel> getListAttributEtenduByModelVersion(
			Integer idModeleVersion);
	
	List<String[]> importSubReferencesToSas(Import importData, Integer metierId, List<String[]> csvData, int modelVersion,
			int attributeValueStartIndex, int attributeValueEndIndex, int characteristicStartIndex,
			int characteristicEndIndex, int elementQuantityStartIndex, int elementQuantityEndIndex, ResourceBundleMessageSource messageSource) throws Exception;
	
	void importSubReferencesToMozarto(Integer importId, Integer metierId, int i, Integer modelVersionId, List<String[]> csvData,
			int attributeValueStartIndex, int attributeValueEndIndex, int characteristicStartIndex,
			int characteristicEndIndex, int elementQuantityStartIndex, int elementQuantityEndIndex, Integer userId,
			Integer nodeId, ModelisateurRegleMessageService modelisateurRegleMessageServicer, ResourceBundleMessageSource messageSource)
			throws Exception;
	
	List<MdlReference> findByIdLienCommuns(Integer idModeleVersion, List<Integer> idLienCommuns);

	List<Integer> findAutoGeneratedReferenceIds(Integer idModeleVersion, Boolean modifiedOnWeb);
	
	Integer countReferenceByIdModeleVersion(Integer idModeleVersion); 

	List<AttributEtenduMetierERValueModel> getListAttributeOfOtherSubModel(Integer idModeleVersion, Integer idSousModele, List<String> labelList);

	List<MdlReference> getSelectedReferencesByCompositionId(Integer compositionId);
	
	List<String> findLibelleInList(List<String> list, Integer idModeleVersion);
}
