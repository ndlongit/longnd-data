package com.structis.client.image;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;


public interface Images extends ClientBundle {
	
	public static final Images RESOURCES = GWT.create(Images.class);
	
	@Source("info_icon.png")
	ImageResource infoIcon();

	@Source("leaf_icon.png")
	ImageResource leafIcon();

	@Source("add.gif")
	ImageResource addIcon();

	@Source("arrowDown.jpg")
	ImageResource arrowDown();

	@Source("arrowUp.jpg")
	ImageResource arrowUp();

	@Source("file_icon.png")
	ImageResource fileIcon();

	@Source("delete.jpg")
	ImageResource delete();

	@Source("delete_gray.jpg")
	ImageResource deleteDisable();
	
	@Source("remove.jpg")
	ImageResource remove();
	
	@Source("edit.jpg")
	ImageResource edit();
	
	@Source("edit_gray.jpg")
	ImageResource editDisable();
	
	@Source("goto.jpg")
	ImageResource gotoNode();
	
	@Source("goto_gray.jpg")
	ImageResource gotoNodeDisable();
	
	@Source("icon_wait.gif")
	ImageResource waitIcon();

	@Source("icon_print.png")
	ImageResource printIcon();

	@Source("pbr_avi.gif")
	ImageResource aviIcon();

	@Source("pbr_doc.gif")
	ImageResource docIcon();

	@Source("pbr_html.gif")
	ImageResource htmlIcon();

	@Source("pbr_pdf.gif")
	ImageResource pdfIcon();

	@Source("pbr_pps.gif")
	ImageResource ppsIcon();

	@Source("pbr_xls.gif")
	ImageResource xlsIcon();

	@Source("pbr_zip.gif")
	ImageResource zipIcon();

	@Source("pbr_IMG.gif")
	ImageResource imgIcon();

	@Source("search_icon.jpg")
	ImageResource searchIcon();

	@Source("left_arrow_button.jpg")
	ImageResource prevIcon();

	@Source("right_arrow_button.jpg")
	ImageResource nextIcon();

	@Source("java.png")
	ImageResource add();

	@Source("plus.gif")
	ImageResource plus();

	@Source("minus.gif")
	ImageResource minus();

	@Source("java.png")
	ImageResource java();
	
	@Source("chbblank.png")
	ImageResource uncheckIcon();
	
	@Source("chbfull.png")
	ImageResource checkIcon();
	
	@Source("chbdisabled.png")
	ImageResource uncheckDisabledIcon();
	
	@Source("chbcheckeddisabled.png")
	ImageResource checkDisabledIcon();
	
	@Source("trash.png")
	ImageResource trash();
	
	@Source("validate.png")
	ImageResource validate();	
	
	@Source("public.jpg")
	ImageResource publicate();
	
	@Source("public_gray.jpg")
	ImageResource publicateDisable();
	
	@Source("left_arrow.jpg")
	ImageResource execute();
	
	@Source("left_arrow_gray.jpg")
	ImageResource executeDisable();

	@Source("trash.png")
	ImageResource undelete();

	@Source("reset.png")
	ImageResource reset();
	
	@Source("resetall.png")
	ImageResource resetAll();
	
	@Source("collapse_top.gif")
	ImageResource collapseTop();
	
	@Source("collapse_bottom.gif")
	ImageResource collapseBottom();
	
	@Source("collapse_left.gif")
	ImageResource collapseLeft();
	
	@Source("collapse_right.gif")
	ImageResource collapseRight();
	
	@Source("arrow_two_head.png")
	ImageResource arrow2heads();
	
	@Source("right_arrow.png")
	ImageResource rightArrow();
	
	@Source("tree_state_change.jpg")
	ImageResource treeMenu();
	
	@Source("grey_left_arrow_button.jpg")
	ImageResource leftArrowButtonDisable();
	
	@Source("grey_right_arrow_button.jpg")
	ImageResource rightArrowButtonDisable();
	
	@Source("tree_menu_icon_open.jpg")
	ImageResource treeMenuIconOpen();
	
	@Source("tree_menu_icon_close.jpg")
	ImageResource treeMenuIconClose();
	
	@Source("reload.jpg")
	ImageResource reload();
	
	@Source("radioButtonUnselect.png")
	ImageResource uncheckRadio();
	
	@Source("radioButtonSelect.jpg")
	ImageResource checkRadio();
	
	@Source("icon_copy.gif")
	ImageResource duplicateIcon();
}
