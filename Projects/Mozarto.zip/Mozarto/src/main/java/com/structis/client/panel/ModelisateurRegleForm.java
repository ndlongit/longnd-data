package com.structis.client.panel;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor.IntegerPropertyEditor;
import com.sencha.gxt.widget.core.client.form.Radio;
import com.sencha.gxt.widget.core.client.form.SpinnerField;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.form.validator.MinLengthValidator;
import com.sencha.gxt.widget.core.client.form.validator.MinLengthValidator.MinLengthMessages;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.ErrorMessages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.service.ClientRegleMessageServiceAsync;
import com.structis.client.widget.CustimizeMessageBox;
import com.structis.client.widget.CustomizeConfirmMessageBox;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.constant.Niveau;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;
import com.structis.shared.model.reference.RuleConflictInfo;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurRegleForm extends AbstractFieldsetEditForm {

	protected TextField elementTextField;

	protected Label regleEntreLabel;

	protected Radio indispensableRadio;

	protected Radio conseilleRadio;

	protected Radio interditeRadio;

	protected SpinnerField<Integer> indispensableSpinner;

	protected SpinnerField<Integer> conseilleSpinner;

	private ModelisateurRegleMessageList parent;

	private TreeNodeModel targetElement;

	private TreeNodeModel sourceNode;
	
	private boolean changed = false;

	//private ToggleGroup toggleNiveau;
	
	private int idRegle = 0;
	
	private NavigationService navigation = NavigationFactory.getNavigation();
	
	public ModelisateurRegleForm(SimpleEventBus bus, ModelisateurRegleMessageList parent) {
		super(bus);

		this.parent = parent;
		annulerButton.setEnable(true);
		validerButton.setEnabled(true);
//		setResize(false);
	}

	@Override
	public void loadForm(TreeNodeModel item) {
		this.sourceNode = item;
		regleEntreLabel.setText(messages.modelisateurFormRegleRegleEntre()+" "+sourceNode.getLibelle());
		toggleSaveCancel(false);
		
	}
	
	public void loadRegle(ModelisateurRegleMessageListModel regle){
		resetForm();
		if(regle.getTargetNode().getModelType() != ModelNodeType.ELEMENT){
			conseilleSpinner.disable();
			conseilleSpinner.clear();
			indispensableSpinner.disable();
			indispensableSpinner.clear();
		}
//			else{
//			conseilleSpinner.enable();
//			indispensableSpinner.enable();
//		}
		this.idRegle = regle.getId();
		this.targetElement = regle.getTargetNode();
		elementTextField.setValue(targetElement.getLibelle());
		if(regle.getRelation().intValue() == Niveau.INTERDITE.getIndex()){
			interditeRadio.setValue(true, true);
		}else if(regle.getRelation().intValue() == Niveau.CONSEILLEE.getIndex()){
			conseilleRadio.setValue(true, true);
			conseilleSpinner.setValue(regle.getQuantite());
		}else{
			indispensableRadio.setValue(true,true);
			indispensableSpinner.setValue(regle.getQuantite());
			validerButton.setEnabled(false);
			annulerButton.setEnable(false);
		}
		validerButton.setEnabled(false);
		annulerButton.setEnable(false);
		parent.getCreateMessage().setEnable(true);
		parent.getCreateRegle().setEnable(true);
		parent.getReglesMessagesGrid().enable();
		
	}
	
	public void addHandler() {
		/*toggleNiveau.addValueChangeHandler(new ValueChangeHandler<HasValue<Boolean>>() {
			 
		      @Override
		      public void onValueChange(ValueChangeEvent<HasValue<Boolean>> event) {
		    	  ToggleGroup group = (ToggleGroup)event.getSource();
		          Radio radio = (Radio)group.getValue();
		          toogleRelation(radio);
		      }
		    });*/
		ValueChangeHandler<Boolean> changeHanlder = new ValueChangeHandler<Boolean>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<Boolean> event) {
				Radio niveauRadio = (Radio) event.getSource();
				if(niveauRadio.getValue()){
					toogleRelation(niveauRadio);
				}
				changed = true;
				validerButton.setEnabled(true);
				annulerButton.setEnable(true);
				parent.getCreateMessage().setEnable(false);
				parent.getCreateRegle().setEnable(false);
				parent.getReglesMessagesGrid().disable();
			}
		};
		indispensableRadio.addValueChangeHandler(changeHanlder);
		conseilleRadio.addValueChangeHandler(changeHanlder);
		interditeRadio.addValueChangeHandler(changeHanlder);
		
		indispensableSpinner.addValueChangeHandler(new ValueChangeHandler<Integer>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<Integer> event) {
				changed = true;
				validerButton.setEnabled(true);
				annulerButton.setEnable(true);
				parent.getCreateMessage().setEnable(false);
				parent.getCreateRegle().setEnable(false);
				parent.getReglesMessagesGrid().disable();
			}
		});
		
		conseilleSpinner.addValueChangeHandler(new ValueChangeHandler<Integer>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<Integer> event) {
				changed = true;
				validerButton.setEnabled(true);
				annulerButton.setEnable(true);
				parent.getCreateMessage().setEnable(false);
				parent.getCreateRegle().setEnable(false);
				parent.getReglesMessagesGrid().disable();
			}
		});
		indispensableSpinner.addSelectionHandler(new SelectionHandler<Integer>() {
			
			@Override
			public void onSelection(SelectionEvent<Integer> arg0) {
				changed = true;
				validerButton.setEnabled(true);
				annulerButton.setEnable(true);
				parent.getCreateMessage().setEnable(false);
				parent.getCreateRegle().setEnable(false);
				parent.getReglesMessagesGrid().disable();
			}
		});
		conseilleSpinner.addSelectionHandler(new SelectionHandler<Integer>() {
			
			@Override
			public void onSelection(SelectionEvent<Integer> arg0) {
				changed = true;
				validerButton.setEnabled(true);
				annulerButton.setEnable(true);
				parent.getCreateMessage().setEnable(false);
				parent.getCreateRegle().setEnable(false);
				parent.getReglesMessagesGrid().disable();
			}
		});
		
		
		elementTextField.addValueChangeHandler(new ValueChangeHandler<String>() {
			
			@Override
			public void onValueChange(ValueChangeEvent<String> event) {
				changed = true;
				validerButton.setEnabled(true);
				annulerButton.setEnable(true);
				parent.getCreateMessage().setEnable(false);
				parent.getCreateRegle().setEnable(false);
				parent.getReglesMessagesGrid().disable();
			}
		});
		
		annulerButton.getHtml().addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				parent.unDisplayRegleForm();
				resetForm();
				parent.getReglesMessagesGrid().enable();
			}
		});
		validerButton.addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				checkConflictRegle();
			}
		});
		elementTextField.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
				if(elementTextField != null){
					elementTextField.clearInvalid();
				}
				parent.getReglesMessagesGrid().disable();
			}
		});
		
	}

	@Override
	protected VerticalLayoutContainer buildPanel() {
		setHeadingHtml(messages.modelisateurFormRegles());
		getElement().getStyle().setProperty("padding", "4px");
		regleEntreLabel = new Label(messages.modelisateurFormRegleRegleEntre());

		elementTextField = new TextField();
		elementTextField.setReadOnly(true);
		elementTextField.setWidth(200);
		elementTextField.setSelectOnFocus(true);
		MinLengthValidator validatorMin = new MinLengthValidator(1);
		validatorMin.setMessages(new MinLengthMessages() {

			@Override
			public String minLengthText(int length) {
				return messages.commonObligatoire();
			}
		});
		elementTextField.addValidator(validatorMin);

		FieldLabel elementField = new FieldLabel(elementTextField, messages.modelisateurFormRegleTelement());
		elementField.setLabelSeparator("");
		elementField.setLabelWidth(70);
		elementField.getElement().getStyle().setPaddingTop(4, Unit.PX);
		elementField.getElement().getStyle().setPaddingRight(16, Unit.PX);
		HorizontalPanel hPanel = new HorizontalPanel();
		//hPanel.setWidth("100%");
		//hPanel.setHeight("40px");
		hPanel.add(elementField);
		Label messageSelect = new Label(messages.modelisateurFormRegleLementselectmessage());
		//messageSelect.getElement().getStyle().setPaddingLeft(2,, unit);
		//messageSelect.setWidth("295px");
		hPanel.add(messageSelect);
		indispensableRadio = new Radio();
		indispensableRadio.setBoxLabel(messages.modelisateurFormRegleLevelIndispensable());
		conseilleRadio = new Radio();
		conseilleRadio.setBoxLabel(messages.modelisateurFormRegleLevelConseillee());
		interditeRadio = new Radio();
		interditeRadio.setBoxLabel(messages.modelisateurFormRegleLevelInterdite());
		/*toggleNiveau = new ToggleGroup();
		toggleNiveau.add(indispensableRadio);
		toggleNiveau.add(conseilleRadio);
		toggleNiveau.add(interditeRadio);*/

		indispensableSpinner = new SpinnerField<Integer>(new IntegerPropertyEditor());
		indispensableSpinner.setMinValue(1);
		indispensableSpinner.setWidth(50);
		indispensableSpinner.setIncrement(1);
		conseilleSpinner = new SpinnerField<Integer>(new IntegerPropertyEditor());
		conseilleSpinner.setMinValue(1);
		conseilleSpinner.setWidth(50);
		conseilleSpinner.setIncrement(1);

		FlexTable tableRegle = new FlexTable();
		tableRegle.setCellSpacing(10);
		tableRegle.setCellPadding(2);
		tableRegle.setWidget(0, 5, indispensableRadio);
		tableRegle.setWidget(1, 5, conseilleRadio);
		tableRegle.setWidget(2, 5, interditeRadio);
		tableRegle.setWidget(0, 6, indispensableSpinner);
		tableRegle.setWidget(1, 6, conseilleSpinner);
		tableRegle.setHeight("auto");

		VerticalLayoutContainer regleContainer = new VerticalLayoutContainer();
		//regleContainer.setHeight(200);
		regleContainer.add(regleEntreLabel, new VerticalLayoutData(1, -1, new Margins(0)));
		regleContainer.add(hPanel, new VerticalLayoutData(1, -1, new Margins(0)));
		regleContainer.add(new Label(messages.modelisateurFormRegleNiveaurelation()), new VerticalLayoutData(
				1, -1, new Margins(0, 0, 5, 0)));
		regleContainer.add(tableRegle, new VerticalLayoutData(-1, -1, new Margins(0, 0, 5, 0)));
		regleContainer.setHeight(1000);
		return regleContainer;
	}

	public void resetForm() {
		idRegle = 0;
//		conseilleSpinner.setVisible(true);
//		indispensableSpinner.setVisible(true);
		conseilleSpinner.clearInvalid();
		indispensableSpinner.clearInvalid();
		elementTextField.clearInvalid();
		elementTextField.reset();
		indispensableRadio.setValue(false);
		conseilleRadio.setValue(false);
		interditeRadio.setValue(false);
		indispensableSpinner.reset();
		conseilleSpinner.reset();
		targetElement = null;
		changed = false;
	}

	public void setTartget(TreeNodeModel node) {
		if(node.getModelType() != ModelNodeType.ELEMENT){
			conseilleSpinner.clearInvalid();
			indispensableSpinner.clearInvalid();
			conseilleSpinner.disable();
			indispensableSpinner.disable();
			conseilleSpinner.clear();
			indispensableSpinner.clear();
			
		}else{
			conseilleSpinner.enable();
			indispensableSpinner.enable();
		}
		boolean isExistsTarget = false;
		List<ModelisateurRegleMessageListModel> reglesMessages = parent.getReglesMessagesStore().getAll();
		for(ModelisateurRegleMessageListModel item:reglesMessages){
			if(ModelisateurRegleMessageListModel.REGLE_TYPE.equals(item.getType())){
				if(!item.isHeritage()){
					if(item.getTargetNode().getModelType() == node.getModelType() && item.getTargetNode().getId().intValue() == node.getId().intValue()){
						isExistsTarget = true;
						break;
					}
				}
			}
		}
		if( node.getModelType() == sourceNode.getModelType() ) {
			if( node.getId() != sourceNode.getId() ) {
				if(!isExistsTarget){
					elementTextField.clearInvalid();
					targetElement = node;
					elementTextField.setValue(node.getLibelle());
				}
			}
		}
		else {
			if(!isExistsTarget){
				elementTextField.clearInvalid();
				targetElement = node;
				elementTextField.setValue(node.getLibelle());
			}
		}
		
	}
	

	private void checkConflictRegle() {
		conseilleSpinner.clearInvalid();
		indispensableSpinner.clearInvalid();
		elementTextField.clearInvalid();
		int priorite = 0;
		Integer quantite = 0;
		
		if( elementTextField.getValue() != null ) {
			priorite = getPriorite();
			if(priorite == Niveau.INDISPENSABLE.getIndex()){
				if(targetElement.getModelType() == ModelNodeType.ELEMENT){
					quantite = indispensableSpinner.getValue();
					if(quantite == null || quantite == 0){
						indispensableSpinner.forceInvalid(messages.commonObligatoire());
						return ;
					}
				}
			}else if(priorite == Niveau.CONSEILLEE.getIndex()){
				if(indispensableSpinner.isVisible() && conseilleSpinner.isVisible()){
					quantite = conseilleSpinner.getValue();
					if(quantite == null || quantite == 0){
						conseilleSpinner.forceInvalid(messages.commonObligatoire());
						return ;
					}
				}
			}else if(priorite == Niveau.INTERDITE.getIndex()){
				priorite = 1;
			}else{
				return ;
			}
			
		}else{
			elementTextField.forceInvalid(messages.commonObligatoire());
			return ;
		}
		final int ppriorite = priorite;
		final int pquantite = quantite;
		boolean isUpate = (idRegle > 0 ? true:false);
		ClientRegleMessageServiceAsync.Util.getInstance().checkConflict(sourceNode, targetElement, ppriorite, pquantite, isUpate,new AsyncCallbackWithErrorResolution<RuleConflictInfo>() {
			@Override
			public void onSuccess(RuleConflictInfo result) {
				ErrorMessages errorMessages = GWT.create(ErrorMessages.class);
				if(result != null){
					String content = errorMessages.getString(result.getCode());
					content = content.replace("Libelle_node_target", targetElement.getLibelle());
					content = content.replace("Libelle_node_source_of_previous_rule", result.getNodeSourceOfPreviousRule().getLibelle());
					content = content.replace("Libelle_node_source", sourceNode.getLibelle());
					
					if(result.getType().equals(RuleConflictInfo.ERROR)){
						//String header = messages.commonErreurInconnu();
						CustimizeMessageBox messageBox = new CustimizeMessageBox(messages.commonInfoHeader(), content);
						messageBox.show();
						//elementTextField.markInvalid(content.replace("<b>", "").replace("</b>", ""));
					}else{
						content = "<table><tr><td style='line-height:100%' >"+content+"</td></tr></table>";
						final CustomizeConfirmMessageBox confirmBox = new CustomizeConfirmMessageBox(
								messages.commonConfirmation(), content);
						confirmBox.setWidth(300);
						confirmBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
						confirmBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
						confirmBox.addHideHandler(new HideHandler() {
							public void onHide(HideEvent event) {
								if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
									if(idRegle == 0){
										insertRegle(sourceNode, targetElement, ppriorite, pquantite);
									}else{
										updateRegle(targetElement, ppriorite, pquantite);
									}
								}
								else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {
									
								}
							}
						});
						confirmBox.show();
					}
				}else{
					if(idRegle == 0){
						insertRegle(sourceNode, targetElement, ppriorite, pquantite);
					}else{
						updateRegle(targetElement, ppriorite, pquantite);
					}
				}
				
			}
		});
		
	}
	private void insertRegle(TreeNodeModel sourceNode,TreeNodeModel targetElement,int priorite,int quantite){
		int idUser = navigation.getContext().getUtilisateur().getIdUtilisateur();
		ClientRegleMessageServiceAsync.Util.getInstance().insertRegle(idUser,sourceNode, targetElement, priorite, quantite, new AsyncCallbackWithErrorResolution<ModelisateurRegleMessageListModel>() {
			@Override
			public void onSuccess(ModelisateurRegleMessageListModel result) {
				if(result != null){
					idRegle = result.getId();
					parent.getReglesMessagesStore().add(result);
					List<ModelisateurRegleMessageListModel> select = new ArrayList<ModelisateurRegleMessageListModel>();
					select.add(result);
					parent.getReglesMessagesGrid().getSelectionModel().setSelection(select);
					parent.setRowUpdateIndex(parent.getReglesMessagesStore().indexOf(result));
				}
				changed = false;
				validerButton.setEnabled(false);
				annulerButton.setEnable(false);
				parent.getCreateMessage().setEnable(true);
				parent.getCreateRegle().setEnable(true);
				parent.getReglesMessagesGrid().enable();
				parent.getReglesMessagesGrid().getLoader().load();
			}
		});
	}
	private void updateRegle(TreeNodeModel targetElement,int priorite,int quantite){
		int idUser = navigation.getContext().getUtilisateur().getIdUtilisateur();
		ClientRegleMessageServiceAsync.Util.getInstance().updateRegle(idUser,idRegle, targetElement, priorite, quantite, new AsyncCallbackWithErrorResolution<ModelisateurRegleMessageListModel>() {
			@Override
			public void onSuccess(ModelisateurRegleMessageListModel result) {
				if(result != null){
					String key = ""+result.getType()+result.getId();
					ModelisateurRegleMessageListModel record = parent.getReglesMessagesStore().findModelWithKey(key);
					if(record != null){
						parent.getReglesMessagesStore().update(result);
					}
				}
				changed = false;
				validerButton.setEnabled(false);
				annulerButton.setEnable(false);
				parent.getCreateMessage().setEnable(true);
				parent.getCreateRegle().setEnable(true);
				parent.getReglesMessagesGrid().enable();
			}
		});
	}
	private int getPriorite(){
		int priorite = 0;
		Radio radio = null;
		if(indispensableRadio.getValue()){
			radio = indispensableRadio;
		}else if(conseilleRadio.getValue()){
			radio = conseilleRadio;
		}else if(interditeRadio.getValue()){
			radio = interditeRadio;
		}
		
		if( radio != null ) {

			if( radio.getBoxLabel().equals(messages.modelisateurFormRegleLevelIndispensable()) ) {
				priorite = Niveau.INDISPENSABLE.getIndex();
			}
			else if( radio.getBoxLabel().equals(messages.modelisateurFormRegleLevelConseillee()) ) {
				priorite = Niveau.CONSEILLEE.getIndex();
			}
			else if( radio.getBoxLabel().equals(messages.modelisateurFormRegleLevelInterdite()) ) {
				priorite = Niveau.INTERDITE.getIndex();
			}
		}
		return priorite;
	}
	private void toogleRelation(Radio radio ){
		conseilleSpinner.clearInvalid();
		indispensableSpinner.clearInvalid();
        if(radio.getBoxLabel().equals(messages.modelisateurFormRegleLevelIndispensable())){
        	if(targetElement != null && ModelNodeType.ELEMENT.equals(targetElement.getModelType())){
	        	conseilleSpinner.setValue(null);
	        	conseilleSpinner.disable();
	        	indispensableSpinner.enable();
	        	if(indispensableSpinner.getValue() == null){
	        		indispensableSpinner.setValue(1);
	        	}
        	}
        	else{
        		conseilleSpinner.disable();
        		indispensableSpinner.disable();
        	}
        	conseilleRadio.setValue(false);
        	interditeRadio.setValue(false);
        }else if(radio.getBoxLabel().equals(messages.modelisateurFormRegleLevelConseillee())){
        	if(targetElement != null && targetElement.getModelType().equals(ModelNodeType.ELEMENT)){
	        	indispensableSpinner.setValue(null);
	        	indispensableSpinner.disable();
	        	conseilleSpinner.enable();
	        	if(conseilleSpinner.getValue() == null){
	        		 conseilleSpinner.setValue(1);
	        	}
        	}
        	else{
        		conseilleSpinner.disable();
        		indispensableSpinner.disable();
        	}
        	indispensableRadio.setValue(false);
        	interditeRadio.setValue(false);
        }else {
        	if(targetElement != null && targetElement.getModelType().equals(ModelNodeType.ELEMENT)){
	        	indispensableSpinner.disable();
	        	conseilleSpinner.disable();
	        	indispensableSpinner.setValue(null);
	        	conseilleSpinner.setValue(null);
        	}
        	else{
        		conseilleSpinner.disable();
        		indispensableSpinner.disable();
        	}
        	indispensableRadio.setValue(false);
        	conseilleRadio.setValue(false);
        }
	}

	public int getIdRegle() {
		return idRegle;
	}

	public void setIdRegle(int idRegle) {
		this.idRegle = idRegle;
	}

	public TreeNodeModel getSourceNode() {
		return sourceNode;
	}

	public void setSourceNode(TreeNodeModel sourceNode) {
		this.sourceNode = sourceNode;
	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	public boolean isChanged() {
		return changed;
	}
}
