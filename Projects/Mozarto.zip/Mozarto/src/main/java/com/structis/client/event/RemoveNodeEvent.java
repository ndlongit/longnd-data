package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.TreeNodeModel;

public class RemoveNodeEvent extends GwtEvent<RemoveNodeHandler> {

	private static Type<RemoveNodeHandler> TYPE = new Type<RemoveNodeHandler>();
	private TreeNodeModel treeNode;
	

	public static Type<RemoveNodeHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<RemoveNodeHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(RemoveNodeHandler handler) {
		handler.onLoad(this);
	}
		

	public RemoveNodeEvent(TreeNodeModel treeNode) {
		super();		
		this.treeNode = treeNode;
	}

	public TreeNodeModel getTreeNode() {
		return treeNode;
	}

	public void setTreeNode(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}

	
	

}
