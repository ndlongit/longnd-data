package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GestionUtilisateurRenameUtilisateurEvent extends GwtEvent<GestionUtilisateurRenameUtilisateurHandler> {

	private static Type<GestionUtilisateurRenameUtilisateurHandler> TYPE = new Type<GestionUtilisateurRenameUtilisateurHandler>();
	private String tabId;
	private String newLabel;

	public static Type<GestionUtilisateurRenameUtilisateurHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionUtilisateurRenameUtilisateurHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionUtilisateurRenameUtilisateurHandler handler) {
		handler.onLoad(this);
	}	

	public GestionUtilisateurRenameUtilisateurEvent(String tabId, String newLabel) {
		this.newLabel = newLabel;
		this.tabId = tabId;
	}

	public String getNewLabel() {
		return newLabel;
	}

	public void setNewLabel(String newLabel) {
		this.newLabel = newLabel;
	}

	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

}
