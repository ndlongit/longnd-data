package com.structis.client.panel.composition;

public class MessageDisplayModel {
	private String idCBB;
	private Integer idRelation;
	private String message;
	
	public MessageDisplayModel(String idCBB,Integer idRelation,String message){
		this.idCBB = idCBB;
		this.idRelation = idRelation;
		this.message = message;
	}
	public String getIdCBB() {
		return idCBB;
	}
	public Integer getIdRelation() {
		return idRelation;
	}
	public String getMessage() {
		return message;
	}
}
