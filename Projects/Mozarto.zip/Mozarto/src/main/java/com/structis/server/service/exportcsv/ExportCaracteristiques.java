package com.structis.server.service.exportcsv;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import com.googlecode.jcsv.writer.CSVWriter;
import com.googlecode.jcsv.writer.internal.CSVWriterBuilder;
import com.structis.server.csvconverter.MdlCaracteristiqueEntryConverter;
import com.structis.shared.model.MdlCaracteristique;

public class ExportCaracteristiques {
	private List<List<MdlCaracteristique>> caracteristiqueLists;
	
	public ExportCaracteristiques(){
		caracteristiqueLists = new ArrayList<List<MdlCaracteristique>>();
	}
	
	public Writer export (String filename, int size){
		try {
			Writer out = new FileWriter(filename);

			String header = "";
			for (int k = 0; k < size-1; k++){
				header += "Niveau " + k + ";";
			}
			header += "Niveau " + (size-1) + "\n";
			out.write(header);
			MdlCaracteristiqueEntryConverter mdlCaracteristiqueEntryConverter = new MdlCaracteristiqueEntryConverter();
			CSVWriterBuilder<List<MdlCaracteristique>> csvWriterBuilder = new CSVWriterBuilder<List<MdlCaracteristique>>(out);
			CSVWriterBuilder<List<MdlCaracteristique>> entryConverter = csvWriterBuilder.entryConverter(mdlCaracteristiqueEntryConverter);
			CSVWriter<List<MdlCaracteristique>> csvWriter = entryConverter.build();
			csvWriter.writeAll(caracteristiqueLists);

			return out;
		}
		catch( IOException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public void setCaracteristiques(List<List<MdlCaracteristique>> caracteristiques) {
		this.caracteristiqueLists = caracteristiques;
	}

	public List<List<MdlCaracteristique>> getCaracteristiques() {
		return caracteristiqueLists;
	}
}
