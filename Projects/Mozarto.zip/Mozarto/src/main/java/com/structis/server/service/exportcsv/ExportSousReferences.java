package com.structis.server.service.exportcsv;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import com.googlecode.jcsv.writer.CSVWriter;
import com.googlecode.jcsv.writer.internal.CSVWriterBuilder;
import com.structis.server.csvconverter.SousReferenceEntryConverter;
import com.structis.shared.model.reference.ReferenceAttributsCaracteristiquesElementsModel;

public class ExportSousReferences {
	private List<ReferenceAttributsCaracteristiquesElementsModel> referenceList;
	
	public ExportSousReferences(){
		referenceList = new ArrayList<ReferenceAttributsCaracteristiquesElementsModel>();
	}
	
	public Writer export (String filename, int numAttr, int numCaract, int numElem){
		try {
			Writer out = new FileWriter(filename);

			String header = "";
			
			header += "SousModele;";
			for (int i = 0; i < numAttr-1; i++){
				header += "Attribut;Valeur;";
			}
			if (numAttr > 0)
				header += "Attribut;Valeur;";
			for (int i = 0; i < numCaract-1; i++){
				header += "Caracteristique;";
			}
			if (numCaract > 0)
				header += "Caracteristique;";
			for (int i = 0; i < numElem-1; i++){
				header += "Pegaz_element;Quantite;";
			}
			if (numElem > 0)
				header += "Pegaz_element;Quantite\n";
			else 
				header += "\n";
			out.write(header);
			SousReferenceEntryConverter referenceEntryConverter = new SousReferenceEntryConverter();
			CSVWriterBuilder<ReferenceAttributsCaracteristiquesElementsModel> csvWriterBuilder = new CSVWriterBuilder<ReferenceAttributsCaracteristiquesElementsModel>(out);
			CSVWriterBuilder<ReferenceAttributsCaracteristiquesElementsModel> entryConverter = csvWriterBuilder.entryConverter(referenceEntryConverter);
			CSVWriter<ReferenceAttributsCaracteristiquesElementsModel> csvWriter = entryConverter.build();
			csvWriter.writeAll(referenceList);

			return out;
		}
		catch( IOException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public List<ReferenceAttributsCaracteristiquesElementsModel> getReferenceList() {
		return referenceList;
	}

	public void setReferenceList(List<ReferenceAttributsCaracteristiquesElementsModel> referenceList) {
		this.referenceList = referenceList;
	}
}
