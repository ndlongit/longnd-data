package com.structis.client.panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.structis.client.message.ActionMessages;
import com.structis.client.message.Messages;

public class ModelisateurRightPanel extends ContentPanel {

	@SuppressWarnings("unused")
	private SimpleEventBus bus;

	@SuppressWarnings("unused")
	private final Messages messages = GWT.create(Messages.class);

	ActionMessages actionMessages = GWT.create(ActionMessages.class);

	public ModelisateurRightPanel(SimpleEventBus bus) {
		this.bus = bus;
		buildPanel();
		addHandler();
	}

	private void buildPanel() {
		setHeaderVisible(false);
	}

	private void addHandler() {

	}

	public void onLoadPanel() {

	}

}
