package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface GestionMetierCloseTabHandler extends EventHandler {
	void onLoad(GestionMetierCloseTabEvent gestionMetierCloseTabEvent);
}
