package com.structis.client.panel.admin;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.core.client.Style.SelectionMode;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutData;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer.HBoxLayoutAlign;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.selection.SelectionChangedEvent;
import com.sencha.gxt.widget.core.client.selection.SelectionChangedEvent.SelectionChangedHandler;
import com.structis.client.event.GestionUtilisateurDisableUtilisateurEvent;
import com.structis.client.event.GestionUtilisateurRenameUtilisateurEvent;
import com.structis.client.event.GestionUtilisateurRenameUtilisateurHandler;
import com.structis.client.event.GestionUtilisateursAddTabEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.Action;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.UtilisateurProperties;
import com.structis.client.service.ClientGestionUtilisateursServiceAsync;
import com.structis.client.widget.HtmlButton;
import com.structis.shared.model.Metier;
import com.structis.shared.model.RoleUtilisateur;
import com.structis.shared.model.Utilisateur;
import com.structis.shared.security.Role;

public class GestionDesUtilisateursAdminLeftPanel extends VerticalLayoutContainer {
	
	public static final int PAGING_LIMIT = 30;

	private SimpleEventBus bus;

	private Images images = GWT.create(Images.class);

	private final Messages messages = GWT.create(Messages.class);

	private NavigationService navigation = NavigationFactory.getNavigation();

	private HTML metierLabel;
	
	@SuppressWarnings("unused")
	private Integer idMetier;

	private FieldSet utilisateursFieldset;
	
	private Grid<Utilisateur> gridUtilisateurs;
	
	private ListStore<Utilisateur> storeUtilisateurs;
	
	private Utilisateur selectedUtilisateur;

	private HtmlButton addBtn;

	private HtmlButton modifBtn;

	private HtmlButton delBtn;
	
	private List<RoleUtilisateur> roleUtilisateurs;

	private VerticalLayoutContainer container;

	private Metier metier;

	private PagingLoader<PagingLoadConfig, PagingLoadResult<Utilisateur>> loader;

	public GestionDesUtilisateursAdminLeftPanel(final SimpleEventBus bus) {
		metier = navigation.getContext().getMetier();
		idMetier = metier.getIdMetier();
		this.bus = bus;
		setStyleName("whiteBackGround");
		
		metierLabel = new HTML();
		metierLabel.setHTML(messages.commonMetier() + ": " + metier.getLLibelle());
		metierLabel.setStyleName("htmlLink");

		add(metierLabel);

		utilisateursFieldset = new FieldSet();
		utilisateursFieldset.setHeadingText(messages.commonUtilisateurs());
		utilisateursFieldset.setStyleName("fieldsetPadding");
		add(utilisateursFieldset, new VerticalLayoutData(1, 1));
		buildFieldSet();
		addHandler();
		
		/*ClientAccueilModelisateurServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

			@Override
			public void onSuccess(Metier result) {
				metierLabel.setHTML(messages.commonMetier() + ": " + result.getLLibelle());
				metierLabel.setStyleName("htmlLink");
				addHandler();

			}
		});*/
		
		loadUtilisateurs();
		loadAllRoles();
	}

	public void loadUtilisateurs() {
/*		int value = Integer.parseInt(pagingToolbar.getPagingNumberSpinner().getText());
		int offset = (value - 1) * PAGING_LIMIT;
		ClientGestionUtilisateursServiceAsync.Util.getInstance().findAll(offset, PAGING_LIMIT, new AsyncCallbackWithErrorResolution<PagingListUtilisateurModel>() {

			@Override
			public void onSuccess(PagingListUtilisateurModel result) {
				if(result != null){
					storeUtilisateurs.replaceAll(result.getUtilisateurs());
					ClientGestionUtilisateursServiceAsync.Util.getInstance().findAllRole(new AsyncCallbackWithErrorResolution<List<RoleUtilisateur>>() {

						@Override
						public void onSuccess(List<RoleUtilisateur> arg0) {
							roleUtilisateurs = new ArrayList<RoleUtilisateur>();
							RoleUtilisateur r = new RoleUtilisateur();
							r.setCRole("");
							r.setLLibelle("");
							roleUtilisateurs.add(r);
							roleUtilisateurs.addAll(arg0);
						}
					});
					recordNumber = result.getTotalRecord();
					afterLoad();
				}
			}
		});*/

		RpcProxy<PagingLoadConfig, PagingLoadResult<Utilisateur>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<Utilisateur>>() {

			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<Utilisateur>> callback) {
				ClientGestionUtilisateursServiceAsync.Util.getInstance().findAllByMetier(null, loadConfig, callback);
			}
		};
		loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<Utilisateur>>(proxy);
		loader.setRemoteSort(true);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, Utilisateur, PagingLoadResult<Utilisateur>>(
				storeUtilisateurs));
		gridUtilisateurs.setLoader(loader);
		loader.load();
	}

	public void addHandler() {
		/*addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent arg0) {
				Window.alert("resize");
				if (arg0.getHeight() > 130)
					listViewUtilisateurs.setHeight(arg0.getHeight() - 140);
				listViewUtilisateurs.setWidth(arg0.getWidth() - 10);
			}
		});
		utilisateursFieldset.addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent arg0) {
			}
		});*/
		modifBtn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				bus.fireEvent(new GestionUtilisateursAddTabEvent(selectedUtilisateur, roleUtilisateurs));
			}
		});
		addBtn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				bus.fireEvent(new GestionUtilisateursAddTabEvent(null, roleUtilisateurs));
			}
		});
		delBtn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				if (selectedUtilisateur != null){
					bus.fireEvent(new GestionUtilisateursAddTabEvent(selectedUtilisateur, roleUtilisateurs));
					bus.fireEvent(new GestionUtilisateurDisableUtilisateurEvent(selectedUtilisateur.getIdUtilisateur()));
				}
			}
		});
		bus.addHandler(GestionUtilisateurRenameUtilisateurEvent.getType(), new GestionUtilisateurRenameUtilisateurHandler() {
			
			@Override
			public void onLoad(GestionUtilisateurRenameUtilisateurEvent event) {
				loadUtilisateurs();
			}
		});
		metierLabel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				navigation.goToEcran(Action.ACTION_LOGIN);
			}
		});
		gridUtilisateurs.addCellDoubleClickHandler(new CellDoubleClickHandler() {
			
			@Override
			public void onCellClick(CellDoubleClickEvent event) {
				bus.fireEvent(new GestionUtilisateursAddTabEvent(selectedUtilisateur, roleUtilisateurs));
			}
		});
	}
	
	public void buildFieldSet() {
		container = new VerticalLayoutContainer();
		utilisateursFieldset.add(container);
		HBoxLayoutContainer buttonPanel = new HBoxLayoutContainer();
		buttonPanel.setPadding(new Padding(1));
		buttonPanel.setHBoxLayoutAlign(HBoxLayoutAlign.TOP);
		addBtn = new HtmlButton(messages.gestionelemcompoLeftNouveaubouton(), images.add());
		modifBtn = new HtmlButton(messages.gestionelemcompoLeftModifierbouton(), images.edit());
		delBtn = new HtmlButton(messages.gestionelemcompoLeftDesactiverbouton(), images.remove());
		buttonPanel.add(addBtn, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		buttonPanel.add(modifBtn, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		buttonPanel.add(delBtn, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		buttonPanel.setBorders(true);
		container.add(buttonPanel);
		
		UtilisateurProperties props = GWT.create(UtilisateurProperties.class);
		storeUtilisateurs = new ListStore<Utilisateur>(props.idUtilisateur());
		ColumnConfig<Utilisateur, String> nom = new ColumnConfig<Utilisateur, String>(
				props.nomComplet());
		nom.setCell(new AbstractCell<String>() {

			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, String label, SafeHtmlBuilder sb) {
				String styleString = "";
				Utilisateur utilisateur = gridUtilisateurs.getStore().get(context.getIndex());
				
				if (utilisateur.getInActif())
					styleString = utilisateur.getNomComplet();
				else 
					styleString = "<span class='inactiveItem' >" + utilisateur.getNomComplet() + "</span>";
				sb.appendHtmlConstant(styleString);
			}
			
		});
		nom.setColumnStyle(SafeStylesUtils.forBorderStyle(BorderStyle.HIDDEN));
		List<ColumnConfig<Utilisateur, ?>> l = new ArrayList<ColumnConfig<Utilisateur, ?>>();
		l.add(nom);
		ColumnModel<Utilisateur> cm = new ColumnModel<Utilisateur>(l);
		
		gridUtilisateurs = new Grid<Utilisateur>(storeUtilisateurs,cm);
		
		gridUtilisateurs.setBorders(false);
		gridUtilisateurs.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		gridUtilisateurs.setHideHeaders(true);
		gridUtilisateurs.getView().setAutoFill(true);
		gridUtilisateurs.getSelectionModel().addSelectionChangedHandler(new SelectionChangedHandler<Utilisateur>() {

			@Override
			public void onSelectionChanged(SelectionChangedEvent<Utilisateur> event) {
				if (event.getSelection().size() > 0)
					selectedUtilisateur = event.getSelection().get(0);
			}
		});
		container.add(gridUtilisateurs, new VerticalLayoutData(1, 1));
		
		buildPaging();
	}

	protected void buildPaging() {
		
	}
	
	protected void loadAllRoles() {
		ClientGestionUtilisateursServiceAsync.Util.getInstance().findAllRole(new AsyncCallbackWithErrorResolution<List<RoleUtilisateur>>() {

			@Override
			public void onSuccess(List<RoleUtilisateur> arg0) {
				roleUtilisateurs = new ArrayList<RoleUtilisateur>();
				RoleUtilisateur r = new RoleUtilisateur();
				r.setCRole("");
				r.setLLibelle("");
				roleUtilisateurs.add(r);
				if (arg0 != null && arg0.size() > 0){
					for(int i = 0; i < arg0.size(); i++){
						RoleUtilisateur roleUtilisateur = arg0.get(i);
						if(!Role.ADMINISTRATEURGENERAL.getCode().equals(roleUtilisateur.getCRole())){
							roleUtilisateurs.add(roleUtilisateur);
						}
					}
				}
			}
		});
	}

}
