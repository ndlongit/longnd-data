package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ModifyHandler extends EventHandler {
	void onLoad(ModifyEvent modifyingEvent);
}
