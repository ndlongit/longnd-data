package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class ActionEvent extends GwtEvent<ActionHandler> {
	
	private static Type<ActionHandler> TYPE = new Type<ActionHandler>();
	
	public static Type<ActionHandler> getType(){
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ActionHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ActionHandler handler) {
		handler.onAction(this);
	}

}
