package com.structis.client.panel.composition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.SortDir;
import com.sencha.gxt.data.shared.event.StoreDataChangeEvent;
import com.sencha.gxt.data.shared.event.StoreDataChangeEvent.StoreDataChangeHandler;
import com.sencha.gxt.data.shared.loader.LoadEvent;
import com.sencha.gxt.data.shared.loader.LoadHandler;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.container.VBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VBoxLayoutContainer.VBoxLayoutAlign;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.BlurEvent;
import com.sencha.gxt.widget.core.client.event.BlurEvent.BlurHandler;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.event.RowMouseDownEvent;
import com.sencha.gxt.widget.core.client.event.RowMouseDownEvent.RowMouseDownHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.event.ShowEvent;
import com.sencha.gxt.widget.core.client.event.ShowEvent.ShowHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor.IntegerPropertyEditor;
import com.sencha.gxt.widget.core.client.form.SpinnerField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.grid.LiveGridView;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.CompositionCaracteristiqueChangeEvent;
import com.structis.client.event.CompositionCaracteristiqueChangeHandler;
import com.structis.client.event.CompositionChangeQuantiteReferenceEvent;
import com.structis.client.event.CompositionSelectReferenceEvent;
import com.structis.client.event.CompositionUnSelectReferenceEvent;
import com.structis.client.event.LoadCompositionEvent;
import com.structis.client.event.LoadCompositionHandler;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.CompositionReferenceProperties;
import com.structis.client.service.ClientCompositionServiceAsync;
import com.structis.client.widget.CustimizeMessageBox;
import com.structis.client.widget.CustomizeConfirmMessageBox;
import com.structis.client.widget.CustomizePagingLoadResult;
import com.structis.client.widget.ExCheckBoxCell;
import com.structis.client.widget.GridSpinnerFieldCell;
import com.structis.shared.comparator.CompositionReferenceGridModelComparator;
import com.structis.shared.constant.Niveau;
import com.structis.shared.model.reference.CompositionReferenceGridModel;
public class CompositionReferenceListForm extends VerticalLayoutContainer {
	private SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private final Integer DEFAULT_PAGE_SIZE = 30;

	private PagingLoader<CompositionReferenceFilter, CustomizePagingLoadResult<CompositionReferenceGridModel>> gridLoader;

	//private List<CompositionReferenceGridModel> references = new ArrayList<CompositionReferenceGridModel>();
	private CompositionReferenceProperties compositionReferenceProps = GWT.create(CompositionReferenceProperties.class);

	private ListStore<CompositionReferenceGridModel> store = new ListStore<CompositionReferenceGridModel>(compositionReferenceProps.idReference());

	private Grid<CompositionReferenceGridModel> grid;

	private Integer pageSize = DEFAULT_PAGE_SIZE;

	private HTML totalRecord;

	private Integer idModeleVersion = 1;

	private CompositionReferenceFilter filter = new CompositionReferenceFilter();

	private CompositionElementDeReference elementForm;

	private List<Integer> currentCaracteristiqueIds = new ArrayList<Integer>();

	private NavigationService navigation = NavigationFactory.getNavigation();

	private CustimizeMessageBox infoMessageBox;

	private AlertMessageWindow alertMessageBox;

	private Stack<MessageDisplayModel> stackMessage = new Stack<MessageDisplayModel>();
	
	private Stack<MessageDisplayModel> stackMessageInfo = new Stack<MessageDisplayModel>();
	
	private boolean isMessageBoxDisplaying = false;

	private int currenRow = 0;
	
	private List<Integer>  currentSelectReference = new ArrayList<Integer>();
	
	private ConfirmChangeReferenceQuantiteWindow confirmWindow;
	
	//private Map<Integer,CompositionReferenceGridModel> toFierQuantiteChange = new HashMap<Integer, CompositionReferenceGridModel>();
	
	public CompositionReferenceListForm(SimpleEventBus bus) {
		super();
		filter.setIdModeleVersion(idModeleVersion);
		filter.setLimit(pageSize);
		filter.setOffset(0);
		addStyleName("whiteBackGround");
		setBorders(true);
		this.bus = bus;
		buildPanel();
		loadForm();
		addHandlers();

	}

	private void loadForm() {
	}

	private void addHandlers() {
		bus.addHandler(CompositionCaracteristiqueChangeEvent.getType(), new CompositionCaracteristiqueChangeHandler() {
			@Override
			public void onLoad(CompositionCaracteristiqueChangeEvent event) {
				idModeleVersion = event.getIdModelVersion();
				currentCaracteristiqueIds = event.getIdCaracteristiques();
				loadGrid();

			}

		});
		grid.getStore().addStoreDataChangeHandler(new StoreDataChangeHandler<CompositionReferenceGridModel>() {

			@Override
			public void onDataChange(StoreDataChangeEvent<CompositionReferenceGridModel> event) {
				//Window.alert(event.getSource().get)
			}
		});
	}

	@Override
	protected void onAfterFirstAttach() {
		if( navigation.getContext().getIdModeleVersionComposition() != 0 ) {
			idModeleVersion = navigation.getContext().getIdModeleVersionComposition();
			store.clear();
			
			loadGrid();
		}
		navigation.getBus().addHandler(LoadCompositionEvent.getType(), new LoadCompositionHandler() {
			@Override
			public void onLoad(LoadCompositionEvent loadCompositionEvent) {
				idModeleVersion = loadCompositionEvent.getIdModeleVersion();
				store.clear();
				currentCaracteristiqueIds.clear();
				loadGrid();
			}
		});
	}

	private void loadGrid() {
		if( filter == null ) {
			filter = new CompositionReferenceFilter();
		}
		filter.setCaracteristiqueIds(currentCaracteristiqueIds);
		filter.setIdModeleVersion(idModeleVersion);
		filter.setSelectedList(getSelectItems());
		gridLoader.load();
	}

	public List<CompositionReferenceGridModel> getSelectItems() {
		List<CompositionReferenceGridModel> selectedItems = new ArrayList<CompositionReferenceGridModel>();

		if( store.getAll() != null ) {
			for( CompositionReferenceGridModel item : store.getAll() ) {
				if( item.getStatus() != null && item.getStatus() > 0 ) {
					selectedItems.add(item);
				}
			}
		}
		return selectedItems;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void buildPanel() {
		ColumnConfig<CompositionReferenceGridModel, CompositionReferenceGridModel> selectColumn = new ColumnConfig<CompositionReferenceGridModel, CompositionReferenceGridModel>(
				new IdentityValueProvider<CompositionReferenceGridModel>());
		ColumnConfig<CompositionReferenceGridModel, CompositionReferenceGridModel> nameColumn = new ColumnConfig<CompositionReferenceGridModel, CompositionReferenceGridModel>(
				new IdentityValueProvider<CompositionReferenceGridModel>());
		nameColumn.setSortable(false);
		nameColumn.setMenuDisabled(true);
		nameColumn.setHeader(SafeHtmlUtils.fromString(messages.modelisateurReference()));
		nameColumn.setCell(new AbstractCell<CompositionReferenceGridModel>() {
			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, CompositionReferenceGridModel value,
					SafeHtmlBuilder sb) {
				String label = value.getLLibelleLong();
				if( value instanceof CompositionReferenceGridModel ) {
					CompositionReferenceGridModel node = (CompositionReferenceGridModel) value;
					if( Niveau.CONSEILLEE.getIndex() == node.getRelation() ) {
						sb.appendHtmlConstant("<span class='treeRegleNode' >" + label + "</span>");
					}
					else if( Niveau.INDISPENSABLE.getIndex() == node.getRelation() ) {
						sb.appendHtmlConstant("<span class='treeRegleNodeGrey' >" + label + "</span>");
					}
					else if( Niveau.INTERDITE.getIndex() == node.getRelation() ) {
						sb.appendHtmlConstant("<span class='treeRegleNodeStrikeGrey' >" + label + "</span>");
					}
					else {
						sb.appendHtmlConstant(label);
					}
				}
				else {
					sb.appendHtmlConstant(label);
				}
			}
		});
		ColumnConfig<CompositionReferenceGridModel, Integer> quantiteColumn = new ColumnConfig<CompositionReferenceGridModel, Integer>(
				compositionReferenceProps.quantite(), 100, messages.compositionRightElementgridQte());

		List<ColumnConfig<CompositionReferenceGridModel, ?>> listColumn = new ArrayList<ColumnConfig<CompositionReferenceGridModel, ?>>();
		listColumn.add(selectColumn);
		listColumn.add(nameColumn);
		listColumn.add(quantiteColumn);

		ExCheckBoxCell select = new ExCheckBoxCell() {
			@Override
			public void onClick(final CompositionReferenceGridModel node) {
				grid.mask(messages.commonEncours());
				getElementForm().getGrid().mask(messages.commonEncours());
				final int newStatus = (node.getStatus() + 1) % 2;

				if( newStatus == 1 ) {
					node.setStatus(newStatus);
					updateSelecteReference(node);
					processMessage(node.getIdReference());
				}
				else {
					if( hasChangesOnElement(node.getIdReference()) ) {
						final CompositionReferenceGridModel fnode = node;
						String content = "<table><tr><td style='line-height:100%' >"+messages.compositionRightReferenceDeselectWhenElementChange()+"</td></tr></table>";
						final CustomizeConfirmMessageBox confirmBox = new CustomizeConfirmMessageBox(
								messages.commonConfirmheader(), content);
						confirmBox.addHideHandler(new HideHandler() {
							public void onHide(HideEvent event) {
								if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
									fnode.setStatus(newStatus);
									fnode.setQuantite(0);
									store.update(fnode);
									store.clearSortInfo();
									store.addSortInfo(new StoreCompositionReferenceSortInfo(
											new CompositionReferenceGridModelComparator(), SortDir.DESC));
									currentSelectReference.remove(fnode.getIdReference());
									removeElements(fnode);
								}
								else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {
									getElementForm().getGrid().unmask();
									grid.unmask();
								}
							}
						});
						confirmBox.show();
					}
					else {
						node.setStatus(newStatus);
						node.setQuantite(0);
						store.update(node);
						//store.applySort(false);
						store.clearSortInfo();
						store.addSortInfo(new StoreCompositionReferenceSortInfo(
								new CompositionReferenceGridModelComparator(), SortDir.DESC));
						removeElements(node);
						currentSelectReference.remove(node.getIdReference());
						/*getElementForm().getGrid().unmask();
						grid.unmask();*/
					}
				}
			}

		};

		selectColumn.setCell(select);
		selectColumn.setHeader(SafeHtmlUtils.fromString("Select"));
		selectColumn.setSortable(false);
		selectColumn.setMenuDisabled(true);
		selectColumn.setWidth(50);

		final GridSpinnerFieldCell<Integer> quantiteCell = new GridSpinnerFieldCell<Integer>(new IntegerPropertyEditor()){

			@Override
			public void onChangeProcess(int index,String newValueString) {
				final CompositionReferenceGridModel node = store.get(index);
				if(!"".equals(newValueString)){
					final int value = Integer.valueOf(newValueString);
					if(node.getStatus() > 0 ){
						//processUpdateValue(node, value,this);
						Timer dismissTimer = new Timer() {
					        @Override
					        public void run() {
					        	processUpdateValue(node, value);
					        }
					      };
					     dismissTimer.schedule(5);
					}
				}else{
					int oldValue = node.getQuantite();
					store.commitChanges();
					node.setQuantite(oldValue);
					store.update(node);
				}
			}
			@Override
			public void onCheckDisable(int index, NativeEvent event) {
				final CompositionReferenceGridModel node = store.get(index);
				if( node.getStatus().intValue() == 0 ){
					  event.stopPropagation();
					  event.preventDefault();
				}
			}
			
		};
		//quantiteCell.setEditable(null, false);
		quantiteCell.addSelectionHandler(new SelectionHandler() {
			@Override
			public void onSelection(SelectionEvent event) {
				//				event.get
				//				store.commitChanges();	
				final CompositionReferenceGridModel node = store.get(currenRow);
				final int value = (Integer) event.getSelectedItem();
				//final int oldValue = node.getQuantite();
				if(node.getStatus() > 0 ){
					processUpdateValue(node, value);
				}else{
					int oldValue = node.getQuantite();
					store.commitChanges();
					node.setQuantite(oldValue);
					store.update(node);
					//grid.getView().refresh(false);
				}
			}
		});
		
		quantiteCell.setAllowBlank(true);
		quantiteCell.setAllowNegative(false);
		quantiteCell.setWidth(70);
		quantiteColumn.setCell(quantiteCell);
		quantiteColumn.setWidth(75);
		quantiteColumn.setSortable(false);
		quantiteColumn.setMenuDisabled(true);

		ColumnModel<CompositionReferenceGridModel> cm = new ColumnModel<CompositionReferenceGridModel>(listColumn);
		RpcProxy<CompositionReferenceFilter, CustomizePagingLoadResult<CompositionReferenceGridModel>> proxy = new RpcProxy<CompositionReferenceFilter, CustomizePagingLoadResult<CompositionReferenceGridModel>>() {
			@Override
			public void load(CompositionReferenceFilter loadConfig,
					AsyncCallback<CustomizePagingLoadResult<CompositionReferenceGridModel>> callback) {

				CompositionReferenceFilter newFilter = (CompositionReferenceFilter) loadConfig;
				newFilter.setLimit(pageSize);
				ClientCompositionServiceAsync.Util.getInstance().findCompositionReferenceByCaracteristiquesPaging(
						filter, callback);
			}
		};
		
		gridLoader = new PagingLoader<CompositionReferenceFilter, CustomizePagingLoadResult<CompositionReferenceGridModel>>(
				proxy) {
			@Override
			protected CompositionReferenceFilter newLoadConfig() {
				return filter;
			}
		};
		//gridLoader.setRemoteSort(true);
		gridLoader.addLoadHandler(new LoadHandler<CompositionReferenceFilter, CustomizePagingLoadResult<CompositionReferenceGridModel>>() {
			@Override
			public void onLoad(
					LoadEvent<CompositionReferenceFilter, CustomizePagingLoadResult<CompositionReferenceGridModel>> event) {
				totalRecord.setText("/ " + event.getLoadResult().getfinalTotal());
				store.clear();
				store.addAll(event.getLoadResult().getData());
				//store.clearSortInfo();
				//store.addSortInfo(new StoreCompositionReferenceSortInfo(new CompositionReferenceGridModelComparator(), SortDir.DESC));

				//grid.getView().refresh(false);
				
				List<CompositionReferenceGridModel> selectedItems = getSelectItems();
				List<CompositionReferenceGridModel> eventItems = new ArrayList<CompositionReferenceGridModel>();
				if(selectedItems != null && selectedItems.size() >0){
					for(CompositionReferenceGridModel selectedItem:selectedItems){
						if(!currentSelectReference.contains(selectedItem.getIdReference())){
							eventItems.add(selectedItem);
							currentSelectReference.add(selectedItem.getIdReference());
						}
					}
					CompositionSelectReferenceEvent eventSelect = new CompositionSelectReferenceEvent();
					eventSelect.setSourceGrid(grid);
					eventSelect.setIdModelVersion(idModeleVersion);
					eventSelect.setIdReferences(eventItems);
					bus.fireEvent(eventSelect);
				}
			}

		});
		
		store = new ListStore<CompositionReferenceGridModel>(compositionReferenceProps.idReference());
		store.addSortInfo(new StoreCompositionReferenceSortInfo(new CompositionReferenceGridModelComparator(), SortDir.DESC));



		grid = new Grid<CompositionReferenceGridModel>(store, cm) {

		};
		LiveGridView liveGridView = new LiveGridView<CompositionReferenceGridModel>();
		liveGridView.setForceFit(true);
		grid.setView(liveGridView);
		grid.setLoadMask(true);
		grid.setLoader(gridLoader);
		grid.getView().setAutoExpandColumn(nameColumn);
		grid.setBorders(false);
		grid.getView().setStripeRows(true);
		grid.getView().setColumnLines(true);
		grid.setLazyRowRender(20);
		//grid.getView().setAutoFill(true);
		grid.addRowMouseDownHandler(new RowMouseDownHandler() {
			@Override
			public void onRowMouseDown(RowMouseDownEvent event) {
				currenRow = event.getRowIndex();
			}
		});
		
		//	    cp.setWidget(this); 	      
		add(grid, new VerticalLayoutData(1,.97));

		VBoxLayoutContainer pagingToolbar = new VBoxLayoutContainer();
		final SpinnerField<Integer> pagingNumberSpinner = new SpinnerField<Integer>(new IntegerPropertyEditor());
		pagingNumberSpinner.setIncrement(10);
		pagingNumberSpinner.setMinValue(1);
//		pagingNumberSpinner.setMaxValue(150);
		
		pagingNumberSpinner.addSelectionHandler(new SelectionHandler<Integer>() {

			@Override
			public void onSelection(SelectionEvent<Integer> event) {
				pageSize = event.getSelectedItem().intValue();
				if(pageSize > ConstantClient.ScreenSize.LARGE_DEFAULT_RECORD_NUMBER){
					showMessageBox();
				}
				else{
					loadGrid();
				}
				//gridLoader.load();
			}
		});
		
		pagingNumberSpinner.addBlurHandler(new BlurHandler() {

			@Override
			public void onBlur(BlurEvent event) {
				if( pagingNumberSpinner.getValue() < 0 ) {
					pagingNumberSpinner.setValue(10);
				}
				pageSize = pagingNumberSpinner.getValue();
				//gridLoader.load();
				if(pageSize > ConstantClient.ScreenSize.LARGE_DEFAULT_RECORD_NUMBER){
					showMessageBox();
				}
				else{
					loadGrid();
				}
			}
		});
		pagingNumberSpinner.setWidth(70);
		pagingNumberSpinner.setValue(pageSize);
		FieldLabel spinnerField = new FieldLabel(pagingNumberSpinner, messages.commonAffichage());
		spinnerField.setLabelWidth(50);

		pagingToolbar.setVBoxLayoutAlign(VBoxLayoutAlign.RIGHT);
		pagingToolbar.setPadding(new Padding(4, 0, 0, 0));
		pagingToolbar.add(spinnerField);
		totalRecord = new HTML("");
		totalRecord.setWidth("70px");
		pagingToolbar.add(totalRecord);
		add(pagingToolbar,new VerticalLayoutData(1,45));

	}

	protected void showMessageBox() {
		final ConfirmMessageBox messageBox = new ConfirmMessageBox(messages.commonConfirmheader(), messages.compositionRightReferenceSeuil(ConstantClient.ScreenSize.LARGE_DEFAULT_RECORD_NUMBER));
		messageBox.setWidth(500);
		messageBox.setHeight(120);
		messageBox.setResizable(false);
		messageBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
		messageBox.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				messageBox.hide();
				loadGrid();
			}
		});
		messageBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
		messageBox.getButtonById(PredefinedButton.NO.name()).addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				messageBox.hide();
			}
		});
		messageBox.show();
	}
	private void processUpdateValue(final CompositionReferenceGridModel node, final int value){
		
		if(Integer.valueOf(node.getQuantite()) != value && hasChangesOnElement(node.getIdReference()) ) {
			SelectHandler nonHandler = new SelectHandler() {
				
				@Override
				public void onSelect(SelectEvent event) {
					store.commitChanges();
					node.setQuantite(value);
					store.update(node);
					
					if(node.getStatus() != null && node.getStatus() > 0 ){
						//bus.fireEvent(new CompositionChangeQuantiteReferenceEvent(node,true));
						fierChangeQuantite(node, true);
					}
					//grid.getView().refresh(false);
				}
			};
			SelectHandler ouiHandler = new SelectHandler() {
				
				@Override
				public void onSelect(SelectEvent event) {
					store.commitChanges();
					node.setQuantite(value);
					store.update(node);
					if(node.getStatus() != null && node.getStatus() > 0 ){
						//bus.fireEvent(new CompositionChangeQuantiteReferenceEvent(node,false));
						fierChangeQuantite(node, false);
					}
					//grid.getView().refresh(false);
				}
			};
			SelectHandler annulerHandler = new SelectHandler() {
				
				@Override
				public void onSelect(SelectEvent event) {
					//quantiteCell.setValue(null, null, oldValue);
					int oldValue = node.getQuantite();
					store.commitChanges();
					node.setQuantite(oldValue);
					store.update(node);
					//grid.getView().refresh(false);
					grid.unmask();
				}
			};
			if(!ConfirmChangeReferenceQuantiteWindow.isShow()){
				confirmWindow = new ConfirmChangeReferenceQuantiteWindow(messages.commonConfirmheader(),
						messages.compositionRightReferenceQuantiteChange(), ouiHandler, nonHandler, annulerHandler);
				confirmWindow.show();
				confirmWindow.setWidth(400);
			}
		}else{
			if(Integer.valueOf(node.getQuantite()) != value){
				/*store.commitChanges();
				node.setQuantite(value);
				store.update(node);
				//grid.getView().refresh(false);
				if(node.getStatus() != null && node.getStatus() > 0 ){
					bus.fireEvent(new CompositionChangeQuantiteReferenceEvent(node,true));
				}*/
				store.commitChanges();
				node.setQuantite(value);
				store.update(node);
				fierChangeQuantite(node, true);
			}
		}
	}
	private void fierChangeQuantite(final CompositionReferenceGridModel node,final boolean overwirte){
		grid.mask(messages.commonEncours());
		getElementForm().getGrid().mask(messages.commonEncours());
		ClientCompositionServiceAsync.Util.getInstance().doAction(new AsyncCallbackWithErrorResolution<Void>() {
			@Override
			public void onSuccess(Void result) {
				//grid.getView().refresh(false);
				if(node.getStatus() != null && node.getStatus() > 0 ){
					bus.fireEvent(new CompositionChangeQuantiteReferenceEvent(node,overwirte));
				}
				grid.unmask();
				getElementForm().getGrid().unmask();
			}
		});
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void updateSelecteReference(final CompositionReferenceGridModel node){
		if( node.getStatus() != 0 && node.getQuantite() == 0 ) {
			node.setQuantite(1);
		}
		ClientCompositionServiceAsync.Util.getInstance().doAction(new AsyncCallbackWithErrorResolution<Void>() {
			@Override
			public void onSuccess(Void result) {
				//grid.getView().refresh(false);
				store.update(node);
				store.clearSortInfo();
				store.addSortInfo(new StoreCompositionReferenceSortInfo(
						new CompositionReferenceGridModelComparator(), SortDir.DESC));
				//store.applySort(false);
				grid.mask(messages.commonEncours());
				List<CompositionReferenceGridModel> selectedItems = new ArrayList<CompositionReferenceGridModel>();
				selectedItems.add(node);
				currentSelectReference.add(node.getIdReference());
				
				CompositionSelectReferenceEvent event = new CompositionSelectReferenceEvent();
				event.setSourceGrid(grid);
				event.setIdModelVersion(idModeleVersion);
				event.setIdReferences(selectedItems);
				bus.fireEvent(event);
				//grid.unmask();
			}
		});
		
	}
	protected void removeElements(final CompositionReferenceGridModel node) {
		
		grid.mask(messages.commonEncours());
		getElementForm().getGrid().mask(messages.commonEncours());
		ClientCompositionServiceAsync.Util.getInstance().doAction(new AsyncCallbackWithErrorResolution<Void>() {
			@Override
			public void onSuccess(Void result) {
				CompositionUnSelectReferenceEvent e = new CompositionUnSelectReferenceEvent();
				e.setSourceGrid(grid);
				e.setIdReference(node.getIdReference());
				e.setIdModelVersion(idModeleVersion);
				bus.fireEvent(e);
				grid.unmask();
				getElementForm().getGrid().unmask();
			}
		});
	}

	private boolean hasChangesOnElement(Integer idReference) {
		if( getElementForm() != null ) {
			/*for( CompositionElementGridModel item : getElementForm().getStore().getAll() ) {
				if( item.getIdReference().equals(idReference) ) {
					if((item.getStatus() >0)
							&& (item.getQuantite() != item.getDefaultQuantite() && item.getIsChanged() != null &&  item.getIsChanged())){
						return true;
					}
				}
			}*/
			if(getElementForm().getHasChangeReferenceIds().contains(idReference)){
				return true;
			}
		}
		return false;
	}

	public CompositionElementDeReference getElementForm() {
		return elementForm;
	}

	public void setElementForm(CompositionElementDeReference elementForm) {
		this.elementForm = elementForm;
	}

	private void processMessage(Integer idReference) {
		ClientCompositionServiceAsync.Util.getInstance().findMessageByIdReference(
				idModeleVersion, idReference, new AsyncCallbackWithErrorResolution<Map<Integer, List<String[]>>>() {

					@Override
					public void onSuccess(Map<Integer, List<String[]>> messageMap) {
						if( messageMap != null && messageMap.keySet().size() > 0 ) {
							for( Integer key : messageMap.keySet() ) {
								List<String[]> messageTexts = messageMap.get(key);
								if( messageTexts.size() > 0 ) {
									if( key == Niveau.INFORMATION.getIndex() ) {
										String messageInfos = "";
										int i = 0;
										for( String[] message : messageTexts ) {
											if( !CompositionCaracteristiqueListForm.alreadyDisplayMessage.contains(message[0]) ) {
												CompositionCaracteristiqueListForm.alreadyDisplayMessage.add(message[0]);
												if( i > 0 ){
													messageInfos =  messageInfos + "<hr style='width:298px' />"+  message[1];
												}else{
													messageInfos = messageInfos + " " + message[1] ;
												}
												i++;
											}

										}
										if( !messageInfos.equals("") ) {
											stackMessage.push(new MessageDisplayModel(null, key, messageInfos));
										}
									}
									if( key == Niveau.AVERTISSEMENT.getIndex() ) {
										String messageAdver = "";
										int i = 0;
										for( String[] message : messageTexts ) {
											if( !CompositionCaracteristiqueListForm.alreadyDisplayMessage.contains(message[0]) ) {
												CompositionCaracteristiqueListForm.alreadyDisplayMessage.add(message[0]);
												if( i > 0  ){
													messageAdver = messageAdver + "<hr style='width:298px' />" + message[1];
												}else{
													messageAdver = messageAdver + " " + message[1] ;
												}
												i++;
											}

										}
										if( !messageAdver.equals("") ) {
											stackMessage.push(new MessageDisplayModel(null, key, messageAdver));
										}
									}
									if( key == Niveau.ALERTE.getIndex() ) {
										for( String[] message : messageTexts ) {
											if( !CompositionCaracteristiqueListForm.alreadyDisplayMessage.contains(message[0]) ) {
												CompositionCaracteristiqueListForm.alreadyDisplayMessage.add(message[0]);
												stackMessage.push(new MessageDisplayModel(null, key, message[1]));
											}
										}
									}
									Collections.sort(stackMessage, new MessageDisplayModelComparator());
								}
							}
							processDisplayMessage();
						}
					}
				});
	}
	
	private void processDisplayMessage() {
		
		if( !isMessageBoxDisplaying) {
			if( !stackMessage.empty() ){
				MessageDisplayModel item = stackMessage.pop();
				if( item.getIdRelation() == Niveau.INFORMATION.getIndex() ) {
					processMessageInfo(item.getMessage());
				}
				else if( item.getIdRelation() == Niveau.AVERTISSEMENT.getIndex() ) {
					processMessageAdverd(item.getMessage());
				}
				else if( item.getIdRelation() == Niveau.ALERTE.getIndex() ) {
					processMessageAlert(item.getMessage());
				}
			}else{
				if( !stackMessageInfo.empty() ){
					do{
						MessageDisplayModel item = stackMessageInfo.pop();
						if( item.getIdRelation() == Niveau.INFORMATION.getIndex() ) {
							processMessageInfo(item.getMessage());
						}
					}while(!stackMessageInfo.empty());
				}
			}
		}
	}
	
	
	private void processMessageInfo(String message) {
		String content = "<table><tr><td style='line-height:100%' >" + message + "</td></tr></table>";
		infoMessageBox = new CustimizeMessageBox(messages.modelisateurFormMessageImportanceInformation(), content);
		infoMessageBox.setClosable(true);
		infoMessageBox.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
		infoMessageBox.addHideHandler(new HideHandler() {
			@Override
			public void onHide(HideEvent event) {
				isMessageBoxDisplaying = false;
				processDisplayMessage();
			}
		});
		infoMessageBox.addShowHandler(new ShowHandler() {
			
			@Override
			public void onShow(ShowEvent event) {
				Timer dismissTimer = new Timer() {
			        @Override
			        public void run() {
			        	infoMessageBox.hide();
			        }
			      };
			      dismissTimer.schedule(5000);
			}
		});
		infoMessageBox.show();
	}

	private void processMessageAdverd(String message) {
		String content = "<table><tr><td style='line-height:100%' >" + message + "</td></tr></table>";
		infoMessageBox = new CustimizeMessageBox(messages.modelisateurFormMessageImportanceAvertissement(), content);
		infoMessageBox.setClosable(true);
		infoMessageBox.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
		infoMessageBox.setModal(false);
		infoMessageBox.addHideHandler(new HideHandler() {
			@Override
			public void onHide(HideEvent event) {
				isMessageBoxDisplaying = false;
				processDisplayMessage();
			}
		});
		infoMessageBox.show();
	}

	private void processMessageAlert(String message) {
		alertMessageBox = new AlertMessageWindow(messages.modelisateurFormMessageImportanceAlerte(), message);
		alertMessageBox.addHideHandler(new HideHandler() {

			@Override
			public void onHide(HideEvent event) {
				isMessageBoxDisplaying = false;
				processDisplayMessage();
			}
		});
		alertMessageBox.show();
	}

}
