package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ElementCompositionGridHandler extends EventHandler {

	void onLoad(ElementCompositionGridEvent elementCompositionGridEvent);
}
