package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class ModelisateurAnnulerCreerModeleEvent  extends GwtEvent<ModelisateurAnnulerCreerModeleHandler>{

	private static Type<ModelisateurAnnulerCreerModeleHandler> TYPE = new Type<ModelisateurAnnulerCreerModeleHandler>();
	public static Type<ModelisateurAnnulerCreerModeleHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModelisateurAnnulerCreerModeleHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModelisateurAnnulerCreerModeleHandler handler) {
		handler.onLoad(this);
	}
	
	public ModelisateurAnnulerCreerModeleEvent() {
	}

}
