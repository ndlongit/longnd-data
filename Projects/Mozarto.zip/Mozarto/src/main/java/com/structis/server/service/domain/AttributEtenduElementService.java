package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.AttributEtenduElement;
import com.structis.shared.model.AttributEtenduElementKey;
import com.structis.shared.model.Element;
import com.structis.shared.model.reference.AttributElementModel;

/**
 * 
 * @author vu.dang
 *
 */
public interface AttributEtenduElementService {
	
	public AttributEtenduElement findById(AttributEtenduElementKey id);
	
	public Integer insert(AttributEtenduElement record);

	public Integer update(AttributEtenduElement record);
	
	public Integer delete(AttributEtenduElement record); 
	
	public Integer deleteById(AttributEtenduElementKey id);
	
	public List<AttributEtenduElement> findAll();
	
	public List<AttributEtenduElement> findByIdElement(Integer idElement);
	
	public Integer insertList (List<AttributEtenduElement> attributEtenduElements);

	public int deleteByIdElement(Integer idElement);
	
	List<Element> findByBaseCriteria(AttributEtenduElement criteria);

	public List<AttributElementModel> findAttributEtenduByElement(Integer elementId);	

	public int deleteByIdAttribut(Integer idAttribut);

}
