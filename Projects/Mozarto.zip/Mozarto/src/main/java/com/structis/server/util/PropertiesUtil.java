package com.structis.server.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesUtil {

    private Properties properties;

    public PropertiesUtil(String resourceFileName) {
        properties = new Properties();
        try {
            loadResource(properties, resourceFileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getValue(String key) {
        return getValue(key, "");
    }

    public String getValue(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    private static void loadResource(Properties properties, String resourceFileName) throws IOException {
    	File f = new File(resourceFileName);
        FileInputStream inputStrim = new FileInputStream(resourceFileName);
        properties.load(inputStrim);
        inputStrim.close();
    }
}
