package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class RenameTreeNodeEvent extends GwtEvent<RenameTreeNodeHandler> {

	private static Type<RenameTreeNodeHandler> TYPE = new Type<RenameTreeNodeHandler>();
	private String tabId;

	public static Type<RenameTreeNodeHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<RenameTreeNodeHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(RenameTreeNodeHandler handler) {
		handler.onLoad(this);
	}	
	private Integer nodeParentId;
	private String newLabel;
	private Integer newId;
	private Integer newVersionId;

	public RenameTreeNodeEvent(String tabId, String newLabel) {
		this.newLabel = newLabel;
		this.tabId = tabId;
	}


	public Integer getNodeParentId() {
		return nodeParentId;
	}

	public void setNodeParentId(Integer nodeParentId) {
		this.nodeParentId = nodeParentId;
	}	

	public String getNewLabel() {
		return newLabel;
	}

	public void setNewLabel(String newLabel) {
		this.newLabel = newLabel;
	}

	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

	public Integer getNewId() {
		return newId;
	}

	public void setNewId(Integer newId) {
		this.newId = newId;
	}

	public Integer getNewVersionId() {
		return newVersionId;
	}

	public void setNewVersionId(Integer newVersionId) {
		this.newVersionId = newVersionId;
	}
	
		

}
