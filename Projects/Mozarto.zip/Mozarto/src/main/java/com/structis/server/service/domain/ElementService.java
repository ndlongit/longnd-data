package com.structis.server.service.domain;

import java.util.List;

import com.sencha.gxt.data.shared.SortDir;
import com.structis.shared.model.Element;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.CompositionElementGridModel;

/**
 * @author vu.dang
 */
public interface ElementService {

	public Element findById(Integer id);

	public List<Element> findActifAndInactifByCriteria(Element element, int firstElement, int numberElements, String sortBy,
			SortDir sortDir);

	public List<Element> findActifAndInactifByCriteriaAdvanced(Element element, String attribut, int offset, int limit,
			String sortBy, SortDir sortDir);

	public Integer findCountByCriteria(Element element, int firstElement, int numberElements, String sortBy, SortDir sortDir);

	public Integer findCountByCriteriaAdvanced(Element element, String valeurAttributEtendu);

	public List<Element> findAllByCriteria(Element element, String sortBy, SortDir sortDir);

	//	public List<Element> findAllActifByCriteria(Element element, String sortBy, SortDir sortDir);

	public Integer insert(Element record);

	public Integer update(Element record);

	public Integer delete(Element record);

	public Integer deleteById(Integer id);

	public List<Element> findAll();

	public List<Element> findElementByModelVersionAndReference(Integer idModeleVersion, Integer idReference);

	public List<AttributEtenduMetierERValueModel> findAttributEtenduElementValueByIdAndMetier(Integer idElement,
			Integer idMetier);

	public List<AttributEtenduMetierERValueModel> findAllAttributElementValueByMetier(Integer idMetier);

	public List<Element> findAllByMetier(Integer idMetier);

	public List<Element> findAllActifAndInactifElementByMetier(Integer idMetier, Integer numberRecord, String sortBy,
			SortDir sortDir);

	public Integer findCountAllElementByMetier(Integer idMetier);

	public List<Element> findByCode(String cElement, Integer idMetier);

	public List<Element> findByNomenclatureFournisseur(String lNomenclatureFournisseur, Integer idMetier);

	List<Element> findByBaseCriteria(Element criteria);

	Element findByIdLienCoummun(Integer idModeleVersion, Integer idLienCommun);

	public Element findByCodeAndModelVersion(String code, Integer modelVersion);

	public List<Element> findByBaseCriteriaAndElementCodeList(Element criteria, List<String> elementCodeList);

	public List<Element> findByBaseCriteriaAndSupplierCodeList(Element criteria, List<String> supplierCodeList);

	public List<CompositionElementGridModel> findCompositionElementByModelversionAndReference(Integer idModeleVersion,
			Integer idReference);

	public List<Element> findCompositionElement(Integer compositionId);

	public List<Element> findCompositionElementByReference(Integer compositionId, Integer idReference);

	public List<Element> findManuallySelectedCompositionElement(Integer compositionId);
}
