
package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.ElementQuantiteModel;
/**
 * 
 * @author vinh.tong
 *
 */
public interface ElementQuantiteProperties extends PropertyAccess<ElementQuantiteModel> {
  ModelKeyProvider<ElementQuantiteModel> idElement();

  ValueProvider<ElementQuantiteModel, String> cElement();

  ValueProvider<ElementQuantiteModel, String> lLibelleLong();

  ValueProvider<ElementQuantiteModel, Integer> qte();
  
  ValueProvider<ElementQuantiteModel, Boolean> added();
}
