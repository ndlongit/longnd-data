package com.structis.client.panel.composition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Image;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.core.client.dom.ScrollSupport.ScrollMode;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.SortDir;
import com.sencha.gxt.data.shared.Store.StoreSortInfo;
import com.sencha.gxt.data.shared.event.StoreSortEvent;
import com.sencha.gxt.data.shared.event.StoreSortEvent.StoreSortHandler;
import com.sencha.gxt.data.shared.loader.LoadEvent;
import com.sencha.gxt.data.shared.loader.LoadHandler;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.HeaderClickEvent;
import com.sencha.gxt.widget.core.client.event.HeaderClickEvent.HeaderClickHandler;
import com.sencha.gxt.widget.core.client.event.RowMouseDownEvent;
import com.sencha.gxt.widget.core.client.event.RowMouseDownEvent.RowMouseDownHandler;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor.IntegerPropertyEditor;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.tips.QuickTip;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.CompositionChangeQuantiteReferenceEvent;
import com.structis.client.event.CompositionChangeQuantiteReferenceHandler;
import com.structis.client.event.CompositionHaveChangeEvent;
import com.structis.client.event.CompositionSelectReferenceEvent;
import com.structis.client.event.CompositionSelectReferenceHandler;
import com.structis.client.event.CompositionUnSelectReferenceEvent;
import com.structis.client.event.CompositionUnSelectReferenceHandler;
import com.structis.client.event.LoadCompositionEvent;
import com.structis.client.event.LoadCompositionHandler;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.CompositionElementGridModelProperties;
import com.structis.client.service.ClientCompositionServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.client.widget.CompositionElementCheckBoxCell;
import com.structis.client.widget.CustomizeGroupingView;
import com.structis.client.widget.GridSpinnerFieldCell;
import com.structis.client.widget.PagingToolBarWithoutDisplayText;
import com.structis.shared.comparator.CompositionElementGridModelComparator;
import com.structis.shared.constant.Niveau;
import com.structis.shared.model.reference.CompositionElementGridModel;
import com.structis.shared.model.reference.CompositionReferenceGridModel;
import com.structis.shared.security.Role;
import com.structis.shared.security.RoleHelper;

public class CompositionElementDeReference extends ContentPanel {

	private SimpleEventBus bus;

	private static final CompositionElementGridModelProperties props = GWT.create(CompositionElementGridModelProperties.class);

	private final Messages messages = GWT.create(Messages.class);

	private Grid<CompositionElementGridModel> grid;

	private ListStore<CompositionElementGridModel> store;

	private NavigationService navigation = NavigationFactory.getNavigation();

	private HTML collapseButtonBottom;

	private Images images = GWT.create(Images.class);

	private int currenRow = 0;

	private CompositionElementGridModelComparator codeColComparator;

	private CompositionElementGridModelComparator lNomenclatureFournisseurColComparator;

	private CompositionElementGridModelComparator libelleColComparator;

	private List<Integer> hasChangeReferenceIds = new ArrayList<Integer>();

	private PagingLoader<PagingLoadConfig, PagingLoadResult<CompositionElementGridModel>> loader;
	
	public CompositionElementDeReference(SimpleEventBus bus) {
		this.bus = bus;
		buildPanel();
		addHandler();
	}

	private void buildPanel() {
		setHeaderVisible(false);
		FieldSet eltFieldSet = new FieldSet();
		eltFieldSet.setHeadingText(messages.compositionRightCompositiongridTitle());
		eltFieldSet.setStyleName("fieldsetPadding");
		add(eltFieldSet);

		VerticalLayoutContainer container = new VerticalLayoutContainer();
		eltFieldSet.add(container);

		CompositionElementCheckBoxCell select = new CompositionElementCheckBoxCell() {
			@Override
			public void onClick(CompositionElementGridModel node) {
				node.setStatus((node.getStatus() + 1) % 2);
				store.update(node);
				updateCompositionElementTMPdata(node);
				bus.fireEvent(new CompositionHaveChangeEvent());
			}
		};
		ColumnConfig<CompositionElementGridModel, CompositionElementGridModel> selectCol;
		selectCol = new ColumnConfig<CompositionElementGridModel, CompositionElementGridModel>(
				new IdentityValueProvider<CompositionElementGridModel>());
		selectCol.setFixed(true);
		selectCol.setCell(select);
		selectCol.setWidth(45);
		selectCol.setHeader(messages.compositionRightElementgridSelect());
		selectCol.setSortable(false);

		ColumnConfig<CompositionElementGridModel, String> codeCol = new ColumnConfig<CompositionElementGridModel, String>(
				props.cElement(), 50, messages.compositionRightElementgridCode());
		codeColComparator = new CompositionElementGridModelComparator();
		codeColComparator.setColumn(0);

		ColumnConfig<CompositionElementGridModel, String> libelleCol = new ColumnConfig<CompositionElementGridModel, String>(
				props.lLibelleLong(), 180, messages.compositionRightElementgridLibelle());

		setCellDisplay(libelleCol, 2, true);
		libelleColComparator = new CompositionElementGridModelComparator();
		libelleColComparator.setColumn(1);
		//libelleCol.setComparator(libelleColComparator);
		ValueProvider<CompositionElementGridModel, String> fake = new ValueProvider<CompositionElementGridModel, String>() {
			@Override
			public String getValue(CompositionElementGridModel object) {
				return "";
			}

			@Override
			public void setValue(CompositionElementGridModel object, String value) {
			}

			@Override
			public String getPath() {
				return "";
			}
		};
		codeCol.setFixed(true);
		ColumnConfig<CompositionElementGridModel, String> fakeCol = new ColumnConfig<CompositionElementGridModel, String>(
				fake, 30, "");
		ColumnConfig<CompositionElementGridModel, String> fakeCol2 = new ColumnConfig<CompositionElementGridModel, String>(
				fake, 30, "");

		ColumnConfig<CompositionElementGridModel, Integer> qteCol = new ColumnConfig<CompositionElementGridModel, Integer>(
				props.quantite(), 60, messages.compositionRightElementgridQte());

		ColumnConfig<CompositionElementGridModel, String> referenceCol = new ColumnConfig<CompositionElementGridModel, String>(
				props.libeleReference(), 80, "reference");

		ColumnConfig<CompositionElementGridModel, String> lNomenclatureFournisseurCol = new ColumnConfig<CompositionElementGridModel, String>(
				props.lNomenclatureFournisseur(), 250);
		lNomenclatureFournisseurCol.setMenuDisabled(true);
		lNomenclatureFournisseurCol.setHeader(messages.compositionRightElementgridNomenclaturefournisseur());
		lNomenclatureFournisseurColComparator = new CompositionElementGridModelComparator();
		lNomenclatureFournisseurColComparator.setColumn(2);

		qteCol.setFixed(true);
		AbstractImagePrototype proto = AbstractImagePrototype.create(Images.RESOURCES.arrow2heads());
		AbstractImagePrototype proto2 = AbstractImagePrototype.create(Images.RESOURCES.rightArrow());

		fakeCol.setHeader(proto.getSafeHtml());
		fakeCol.setMenuDisabled(true);
		fakeCol.setFixed(true);

		fakeCol.setColumnStyle(SafeStylesUtils.fromTrustedString("border-left:none;"));
		fakeCol.setColumnHeaderClassName("gridImageHeader;");
		libelleCol.setColumnStyle(SafeStylesUtils.fromTrustedString("border-right:none;"));
		libelleCol.setColumnHeaderClassName("gridBeforeImageHeader");
		fakeCol2.setHeader(proto2.getSafeHtml());
		fakeCol2.setMenuDisabled(true);
		lNomenclatureFournisseurCol.setColumnStyle(SafeStylesUtils.fromTrustedString("border-right:none;"));
		lNomenclatureFournisseurCol.setColumnHeaderClassName("gridBeforeImageHeader");
		fakeCol2.setFixed(true);
		fakeCol2.setColumnStyle(SafeStylesUtils.fromTrustedString("border-left:none;"));
		fakeCol2.setColumnHeaderClassName("gridImageHeader;");

		/*
		 * SpinnerFieldCell<Integer> qte = new SpinnerFieldCell<Integer>(new
		 * IntegerPropertyEditor());
		 */
		final GridSpinnerFieldCell<Integer> qte = new GridSpinnerFieldCell<Integer>(new IntegerPropertyEditor()) {

			@Override
			public void onChangeProcess(int index, String newValueString) {
				final CompositionElementGridModel node = store.get(index);
				if( !"".equals(newValueString) ) {
					if( node.getStatus() > 0 && node.getRelation() != Niveau.INDISPENSABLE.getIndex() ) {
						final int value = Integer.valueOf(newValueString);
						store.commitChanges();
						node.setQuantite(value);
						node.setIsChanged(true);
						store.update(node);
						if( node.getQuantite() != node.getDefaultQuantite() && node.getIsChanged() != null && node.getIsChanged() ) {
							if( !hasChangeReferenceIds.contains(node.getIdReference()) ) {
								hasChangeReferenceIds.add(node.getIdReference());
							}
						}
					}
				}
				else {
					int oldValue = node.getQuantite();
					store.commitChanges();
					node.setQuantite(oldValue);
					store.update(node);
				}
				updateCompositionElementTMPdata(node);
				bus.fireEvent(new CompositionHaveChangeEvent());
			}

			@Override
			public void onCheckDisable(int index, NativeEvent event) {
				final CompositionElementGridModel node = store.get(index);
				if( node.getStatus().intValue() == 0 || !Role.UTILISATEURINVITE.getCode().equals(
						navigation.getContext().getRoles().get(1).getCode()) ) {
					event.stopPropagation();
					event.preventDefault();
				}
			}

		};
		//qte.setEditable(null, false);
		qte.addSelectionHandler(new SelectionHandler<Integer>() {
			@Override
			public void onSelection(SelectionEvent<Integer> event) {
				final CompositionElementGridModel node = store.get(currenRow);
				if( node.getStatus() > 0 && node.getRelation() != Niveau.INDISPENSABLE.getIndex() && !RoleHelper.isRestricted() ) {
					final int value = (Integer) event.getSelectedItem();
					node.setQuantite(value);
					node.setIsChanged(true);
					store.update(node);
					store.commitChanges();
					if( node.getQuantite() != node.getDefaultQuantite() && node.getIsChanged() != null && node.getIsChanged() ) {
						if( !hasChangeReferenceIds.contains(node.getIdReference()) ) {
							hasChangeReferenceIds.add(node.getIdReference());
						}
					}
				}
				else {
					store.update(node);
					store.commitChanges();
				}
				updateCompositionElementTMPdata(node);
				bus.fireEvent(new CompositionHaveChangeEvent());
			}
		});
		qteCol.setCell(qte);
		qteCol.setSortable(false);
		qte.setMinValue(1);
		qteCol.setMenuDisabled(true);
		qte.setWidth(70);
		qteCol.setWidth(75);

		codeCol.setMenuDisabled(true);
		libelleCol.setMenuDisabled(true);

		List<ColumnConfig<CompositionElementGridModel, ?>> l = new ArrayList<ColumnConfig<CompositionElementGridModel, ?>>();

		setCellDisplay(codeCol, 1, false);
		setCellDisplay(libelleCol, 2, true);
		setCellDisplay(lNomenclatureFournisseurCol, 4, true);

		l.add(selectCol);
		l.add(codeCol);
		l.add(libelleCol);
		l.add(fakeCol);
		l.add(lNomenclatureFournisseurCol);
		l.add(fakeCol2);
		l.add(qteCol);
		ColumnModel<CompositionElementGridModel> cm = new ColumnModel<CompositionElementGridModel>(l);
		cm.setHidden(4, true);
		cm.setHidden(5, true);
		
		store = new ListStore<CompositionElementGridModel>(new ModelKeyProvider<CompositionElementGridModel>() {
			@Override
			public String getKey(CompositionElementGridModel item) {
				return item.hashCode() + "";
			}
		});

		store.addSortInfo(new StoreSortInfo<CompositionElementGridModel>(props.order(), SortDir.ASC));
		
		
		
		RpcProxy<PagingLoadConfig, PagingLoadResult<CompositionElementGridModel>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<CompositionElementGridModel>>() {
			@Override
			public void load(PagingLoadConfig loadConfig, final AsyncCallback<PagingLoadResult<CompositionElementGridModel>> callback) {
				//ClientReferenceServiceAsync.Util.getInstance().loadCaracteristiquePaging(treeNode.getIdModeleVersion(), treeNode.getId(), loadConfig, callback);
				ClientCompositionServiceAsync.Util.getInstance().loadCeElementPagingTMPData(loadConfig, callback);
			}
	    };
	    
	    loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<CompositionElementGridModel>>(proxy);
		loader.setRemoteSort(false);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, CompositionElementGridModel, PagingLoadResult<CompositionElementGridModel>>(
				store));
		
		grid = new Grid<CompositionElementGridModel>(store, cm);
		grid.setLoader(loader);
		
		final CustomizeGroupingView<CompositionElementGridModel> view = new CustomizeGroupingView<CompositionElementGridModel>() {
		};
		view.setShowGroupedColumn(true);
		/*view.setEnableGroupingMenu(false);
		view.setEnableNoGroups(true);*/
		//	    view.setAdjustForHScroll(true);
		//view.setForceFit(true);
		grid.setView(view);
		view.groupBy(referenceCol);
		grid.addHeaderClickHandler(new HeaderClickHandler() {
			@Override
			public void onHeaderClick(HeaderClickEvent event) {
				if( event.getColumnIndex() == 3 ) {
					grid.getColumnModel().setColumnWidth(4, 250);
					grid.getColumnModel().setHidden(4, false);
					grid.getColumnModel().setHidden(5, false);
					grid.getColumnModel().setHidden(3, true);
					//libelleCol.setColumnStyle(SafeStylesUtils.fromTrustedString("border-right:normal;"));
				}
				else if( event.getColumnIndex() == 5 ) {
					grid.getColumnModel().setHidden(4, true);
					grid.getColumnModel().setHidden(5, true);
					grid.getColumnModel().setHidden(3, false);
					//libelleCol.setColumnStyle(SafeStylesUtils.fromTrustedString("border-right:none;"));
				}

			}
		});
		grid.addRowMouseDownHandler(new RowMouseDownHandler() {

			@Override
			public void onRowMouseDown(RowMouseDownEvent event) {
				currenRow = event.getRowIndex();
			}
		});
		selectCol.setHeader(messages.compositionRightElementgridSelect());
		selectCol.setMenuDisabled(true);

		grid.setBorders(false);
		grid.getView().setStripeRows(true);
		grid.getView().setForceFit(true);
		grid.getView().setColumnLines(true);
		grid.getView().setAutoExpandColumn(lNomenclatureFournisseurCol);
		//	    grid.setHeight(500);
		new QuickTip(grid);
		
		container.setScrollMode(ScrollMode.AUTO);
		
		PagingToolBarWithoutDisplayText gridEdeToolBar = new PagingToolBarWithoutDisplayText(ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
		gridEdeToolBar.bind(loader);
		gridEdeToolBar.getElement().getStyle().setProperty("borderBottom", "none");
		VerticalLayoutContainer  gridEdeContainer = AppUtil.createGridWidthPagingContainer(grid, gridEdeToolBar);
		
		container.add(gridEdeContainer, new VerticalLayoutData(1, .98));

		collapseButtonBottom = new HTML();

		Image collapseIcon2 = new Image();
		collapseIcon2.setPixelSize(16, 16);
		collapseIcon2.setResource(images.collapseRight());
		collapseButtonBottom.setHTML(collapseIcon2 + "");
		collapseButtonBottom.setStyleName("searchButton");
		container.add(collapseButtonBottom);
		container.getElement().setPadding(new Padding(0, 0, 3, 0));
		container.getElement().setMargins(new Margins(0, 0, 3, 0));
		collapseButtonBottom.setVisible(false);
		
	}

	private void setCellDisplay(ColumnConfig<CompositionElementGridModel, String> col, final int index, final boolean qtip) {

		col.setCell(new AbstractCell<String>() {
			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, String value, SafeHtmlBuilder sb) {
				String styleItalic;
				String styleItalicGray;
				String styleItalicStriteGray;
				String styleNormal;
				CompositionElementGridModel model = store.get(context.getIndex());
				String label = "";
				switch( index ) {
					case 0 : //selectCol						
						break;
					case 1 : //code
						label = model.getCElement();
						break;
					case 2 : //libelle
						label = model.getLLibelleLong();
						break;
					case 3 : // fake
						break;
					case 4 : // nomen
						label = model.getLNomenclatureFournisseur();
						break;
					case 5 :
						break;
					case 6 : //qteCol
						label = "" + model.getQuantite();
						break;
				}
				if( label == null )
					label = "";
				if( qtip ) {
					styleItalic = "<span class='treeRegleNode' qtip=\"" + label + "\">" + label + "</span>";
					styleItalicGray = "<span class='treeRegleNodeGrey' qtip=\"" + label + "\">" + label + "</span>";
					styleItalicStriteGray = "<span class='treeRegleNodeStrikeGrey' qtip=\"" + label + "\">" + label + "</span>";
					styleNormal = "<span qtip=\"" + label + "\">" + label + "</span>";
				}
				else {
					styleItalic = "<span class='treeRegleNode' >" + label + "</span>";
					styleItalicGray = "<span class='treeRegleNodeGrey' >" + label + "</span>";
					styleItalicStriteGray = "<span class='treeRegleNodeStrikeGrey' >" + label + "</span>";
					styleNormal = label;
				}
				if( model.getRelation() == null ) {
					sb.appendHtmlConstant(styleNormal);
				}
				else {
					if( Niveau.CONSEILLEE.getIndex() == model.getRelation() ) {
						sb.appendHtmlConstant(styleItalic);
					}
					else if( Niveau.INDISPENSABLE.getIndex() == model.getRelation() ) {
						sb.appendHtmlConstant(styleItalicGray);
					}
					else if( Niveau.INTERDITE.getIndex() == model.getRelation() ) {
						sb.appendHtmlConstant(styleItalicStriteGray);
					}
					else {
						sb.appendHtmlConstant(styleNormal);
					}
				}
				//sb.appendHtmlConstant("<span qtip='" + label + "'>" + label + "</span>");				
			}
		});
	}
	
	@Override
	protected void onAfterFirstAttach() {
		ClientCompositionServiceAsync.Util.getInstance().clearElementTMPData(new AsyncCallbackWithErrorResolution<Void>() {
			@Override
			public void onSuccess(Void result) {
			}
		});
		super.onAfterFirstAttach();
	}
	private void addHandler() {
		bus.addHandler(CompositionSelectReferenceEvent.getType(), new CompositionSelectReferenceHandler() {
			@Override
			public void onLoad(final CompositionSelectReferenceEvent event) {
				List<CompositionReferenceGridModel> references = event.getReferences();
				final Map<Integer, Integer> mapReferences = new HashMap<Integer, Integer>();
				for( CompositionReferenceGridModel reference : references ) {
					mapReferences.put(reference.getIdReference(), reference.getQuantite());
				}
				ClientCompositionServiceAsync.Util.getInstance().onSelectReferenceTMPData(mapReferences, event.getIdModelVersion(), new AsyncCallbackWithErrorResolution<Void>() {
					@Override
					public void onSuccess(Void result) {
						if(loader.getLastLoadConfig() != null){
							loader.load(0 ,ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
						}else{
							loader.load();
						}
						grid.unmask();
						event.getSourceGrid().unmask();
						bus.fireEvent(new CompositionHaveChangeEvent());
					}
				});
				
			}
		});
		bus.addHandler(CompositionUnSelectReferenceEvent.getType(), new CompositionUnSelectReferenceHandler() {
			@Override
			public void onLoad(final CompositionUnSelectReferenceEvent event) {
				
				List<Integer> idReferences = new ArrayList<Integer>();
				idReferences.add(event.getIdReference());
				ClientCompositionServiceAsync.Util.getInstance().onUnSelectReferenceTMPData(idReferences, new AsyncCallbackWithErrorResolution<Void>() {
					@Override
					public void onSuccess(Void result) {
						if( hasChangeReferenceIds.contains(event.getIdReference()) ) {
							hasChangeReferenceIds.remove(event.getIdReference());
						}
						if(loader.getLastLoadConfig() != null){
							loader.load(0 ,ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
						}else{
							loader.load();
						}
						grid.unmask();
						bus.fireEvent(new CompositionHaveChangeEvent());
					}
				});
			}
		});
		bus.addHandler(CompositionChangeQuantiteReferenceEvent.getType(), new CompositionChangeQuantiteReferenceHandler() {

			@Override
			public void onLoad(final CompositionChangeQuantiteReferenceEvent event) {
				final CompositionReferenceGridModel model = event.getReference();
				if( model != null ) {
					
					ClientCompositionServiceAsync.Util.getInstance().changeReferenceQuantieTMPData(model.getIdReference(), model.getQuantite(), event.isOverwrite(), new AsyncCallbackWithErrorResolution<Void>() {
						@Override
						public void onSuccess(Void result) {
							if( event.isOverwrite() ) {
								hasChangeReferenceIds.remove(model.getIdReference());
							}
							loader.load();
							bus.fireEvent(new CompositionHaveChangeEvent());
						}
					});
					
				}
			}
		});
		navigation.getBus().addHandler(LoadCompositionEvent.getType(), new LoadCompositionHandler() {
			@Override
			public void onLoad(LoadCompositionEvent loadCompositionEvent) {
				store.clear();
				ClientCompositionServiceAsync.Util.getInstance().clearElementTMPData(new AsyncCallbackWithErrorResolution<Void>() {
					@Override
					public void onSuccess(Void result) {
					}
				});
				hasChangeReferenceIds.clear();
				codeColComparator.setFirstLoad(true);
				codeColComparator.setColumn(0);
			}
		});
		grid.getStore().addStoreSortHandler(new StoreSortHandler<CompositionElementGridModel>() {

			@Override
			public void onSort(StoreSortEvent<CompositionElementGridModel> event) {
				if( event.getSource() != null && event.getSource().getSortInfo() != null && event.getSource().getSortInfo().size() > 0 ) {
					StoreSortInfo<CompositionElementGridModel> storeSortInfo = event.getSource().getSortInfo().get(0);
					if( SortDir.ASC.equals(storeSortInfo.getDirection()) ) {
						storeSortInfo.setDirection(SortDir.DESC);
					}
				}
			}
		});
		loader.addLoadHandler(new LoadHandler<PagingLoadConfig, PagingLoadResult<CompositionElementGridModel>>() {
			@Override
			public void onLoad(LoadEvent<PagingLoadConfig, PagingLoadResult<CompositionElementGridModel>> event) {
				forceLayout();
			}
		});
	}

	public Grid<CompositionElementGridModel> getGrid() {
		return grid;
	}

	public void setGrid(Grid<CompositionElementGridModel> grid) {
		this.grid = grid;
	}

	public ListStore<CompositionElementGridModel> getStore() {
		return store;
	}

	public void setStore(ListStore<CompositionElementGridModel> store) {
		this.store = store;
	}

	public void setCollapseButtonBottom(HTML collapseButtonBottom) {
		this.collapseButtonBottom = collapseButtonBottom;
	}

	public HTML getCollapseButtonBottom() {
		return collapseButtonBottom;
	}

	public List<CompositionElementGridModel> getSelectItems() {
		List<CompositionElementGridModel> selectedItems = new ArrayList<CompositionElementGridModel>();

		if( store.getAll() != null ) {
			for( CompositionElementGridModel item : store.getAll() ) {
				//if( item.getStatus() != null /*&& item.getStatus() > 0*/ ) {
				selectedItems.add(item);
				//}
			}
		}
		return selectedItems;

	}

	public CompositionElementGridModelComparator getCodeColComparator() {
		return codeColComparator;
	}

	public void setCodeColComparator(CompositionElementGridModelComparator codeColComparator) {
		this.codeColComparator = codeColComparator;
	}

	public List<Integer> getHasChangeReferenceIds() {
		return hasChangeReferenceIds;
	}

	public void setHasChangeReferenceIds(List<Integer> hasChangeReferenceIds) {
		this.hasChangeReferenceIds = hasChangeReferenceIds;
	}
	
	private void updateCompositionElementTMPdata(CompositionElementGridModel node){
		ClientCompositionServiceAsync.Util.getInstance().updateCElementTMPData(node, new AsyncCallbackWithErrorResolution<Void>() {
			@Override
			public void onSuccess(Void result) {
				
			}
		});
	}
	
}
