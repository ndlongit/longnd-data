package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.SousReferenceReferenceMapper;
import com.structis.shared.model.SousReferenceReference;
import com.structis.shared.model.SousReferenceReferenceKey;

@Service(SousReferenceReferenceService.SERVICE_NAME)
public class SousReferenceReferenceServiceImpl implements SousReferenceReferenceService {

	@Autowired
	private SousReferenceReferenceMapper mapper;

	@Override
	public int deleteById(SousReferenceReferenceKey key) {
		return mapper.deleteById(key);
	}

	@Override
	public int delete(SousReferenceReference record) {
		return mapper.delete(record);
	}

	@Override
	public int insert(SousReferenceReference record) {
		return mapper.insert(record);
	}

	@Override
	public int insertSelective(SousReferenceReference record) {
		return mapper.insertSelective(record);
	}

	@Override
	public SousReferenceReference findById(SousReferenceReferenceKey key) {
		return mapper.findById(key);
	}

	@Override
	public List<SousReferenceReference> findAll() {
		return mapper.findAll();
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteByReferenceIds(List<Integer> idReferences) {
		Map mapParameter = new HashMap();
		mapParameter.put("idReferences", idReferences);
		mapper.deleteByReferenceIds(mapParameter);
	}
}
