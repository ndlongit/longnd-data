package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.sencha.gxt.cell.core.client.AbstractEventCell;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.HasSelectHandlers;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.image.Images;
import com.structis.shared.model.MdlCarateristiqueReference;

public abstract class ImagesCell extends AbstractEventCell<MdlCarateristiqueReference> implements HasSelectHandlers  {
	interface Templates extends SafeHtmlTemplates {
		@SafeHtmlTemplates.Template("<div name=\"{0}\" style=\"{1}\">{2}</div>")
		SafeHtml cell(String name, SafeStyles styles, SafeHtml value);
	}
	private Integer idDirectedCaracteristique;
	public static Integer EMPTY_NEW = 0;
	public static Integer WAITING_SELECT = 1;
	public static Integer CARACTERISTIC_SELECTED = 2;
	public static Integer VALIDATED = 3;
	
	public ImagesCell(Integer parentId) {
		super("click", "keydown");	
		idDirectedCaracteristique = parentId;
	}
	/**
	 * Create a singleton instance of the templates used to render the cell.
	 */
	private static Templates templates = GWT.create(Templates.class);
	private static final SafeHtml ICON_ADD = makeImage(Images.RESOURCES.add());
	private static final SafeHtml ICON_DELETE = makeImage(Images.RESOURCES.trash());
	private static final SafeHtml ICON_VALIDATE = makeImage(Images.RESOURCES.validate());
	private static final SafeHtml ICON_CANCEL = makeImage(Images.RESOURCES.remove());
	@Override
	public void onBrowserEvent(com.google.gwt.cell.client.Cell.Context context,
	Element parent, MdlCarateristiqueReference value, NativeEvent event,
	com.google.gwt.cell.client.ValueUpdater<MdlCarateristiqueReference> valueUpdater) {
		// Let AbstractCell handle the keydown event.
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
		
		// Handle the click event.
		if( "click".equals(event.getType()) ) {
			// Ignore clicks that occur outside of the outermost element.
			EventTarget eventTarget = event.getEventTarget();
			if( parent.isOrHasChild(Element.as(eventTarget)) ) {
				// if (parent.getFirstChildElement().isOrHasChild(
				// Element.as(eventTarget))) {
				// use this to get the selected element!!
				Element el = Element.as(eventTarget);
				// check if we really click on the image
				if( el.getNodeName().equalsIgnoreCase("IMG") ) {
					//Window.alert(el.getParentElement().getAttribute("name"));
					if(el.getParentElement().getAttribute("name").equals("ICON_DELETE"))
						onDelete(value);
					if(el.getParentElement().getAttribute("name").equals("ICON_ADD")){
						onAdd(value);
					}
					if(el.getParentElement().getAttribute("name").equals("ICON_VALIDATE")){
						onValidate(value);
					}
					if(el.getParentElement().getAttribute("name").equals("ICON_CANCEL")){
						onCancel(value);
					}
				}
			}
		}
	};


	@Override
    public void render(Context context, MdlCarateristiqueReference value, SafeHtmlBuilder sb) {
		 if (value == null) {
	            return;
	        }
	        SafeStyles imgStyle = SafeStylesUtils
	                .fromTrustedString("float:left;cursor:hand;cursor:pointer;");
	        SafeHtml rendered;
	        if (value.getStatus() == EMPTY_NEW ){
	        	rendered = templates.cell("ICON_ADD", imgStyle, ICON_ADD);
	 	        sb.append(rendered);
	        } else if(value.getStatus() != VALIDATED ){
	        	if (value.getStatus() ==  CARACTERISTIC_SELECTED) {
		        	rendered = templates.cell("ICON_VALIDATE", imgStyle, ICON_VALIDATE);
			        sb.append(rendered);
	        	}
		        rendered = templates.cell("ICON_CANCEL", imgStyle, ICON_CANCEL);
		        sb.append(rendered);
	        } else {     		        	
		        	if (idDirectedCaracteristique != null &&  idDirectedCaracteristique != value.getIdCaracteristique()) {
		        		if (value.getIdCaracteristique() == null || idDirectedCaracteristique.intValue() != value.getIdCaracteristique().intValue()) {
					        rendered = templates.cell("ICON_DELETE", imgStyle, ICON_DELETE);
					        sb.append(rendered);
		        		}
		        	}
	        }
    }

	
	private static SafeHtml makeImage(ImageResource resource) {
		AbstractImagePrototype proto = AbstractImagePrototype.create(resource);
		return proto.getSafeHtml();
	}
	@Override
	public HandlerRegistration addSelectHandler(SelectHandler handler) {
		return addHandler(handler, SelectEvent.getType());
	}
	
//	
//	public Integer getIdDirectedCaracteristique() {
//		return idDirectedCaracteristique;
//	}
//
//	public void setIdDirectedCaracteristique(Integer idDirectedCaracteristique) {
//		this.idDirectedCaracteristique = idDirectedCaracteristique;
//	}
//






	//add delete handler
	public abstract void onDelete(MdlCarateristiqueReference node);
	public abstract void onAdd(MdlCarateristiqueReference node);
	//add new handler
	public abstract void onValidate(MdlCarateristiqueReference node);
	public abstract void onCancel(MdlCarateristiqueReference node);

}
