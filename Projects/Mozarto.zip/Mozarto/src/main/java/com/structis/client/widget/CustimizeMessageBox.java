package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.structis.client.message.Messages;

public class CustimizeMessageBox extends MessageBox {
	private final Messages messages = GWT.create(Messages.class);
	public CustimizeMessageBox(String headingHtml, String messageHtml) {
		super(headingHtml, messageHtml);
		setWidth(300);
		getButtonById(PredefinedButton.OK.name()).setText(messages.commonOui());
	}

}
