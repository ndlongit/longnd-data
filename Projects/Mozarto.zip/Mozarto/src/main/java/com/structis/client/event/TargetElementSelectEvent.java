package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.TreeNodeModel;

public class TargetElementSelectEvent extends GwtEvent<TargetElementSelectHandler> {

	private static Type<TargetElementSelectHandler> TYPE = new Type<TargetElementSelectHandler>();

	public static Type<TargetElementSelectHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<TargetElementSelectHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(TargetElementSelectHandler handler) {
		handler.onLoad(this);
	}

	private TreeNodeModel treeNode;

	public TargetElementSelectEvent(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}

	public TreeNodeModel getTreeNode() {
		return treeNode;
	}

	public void setTreeNode(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}
}
