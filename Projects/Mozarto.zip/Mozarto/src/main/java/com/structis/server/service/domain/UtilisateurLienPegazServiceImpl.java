package com.structis.server.service.domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.UtilisateurLienPegazMapper;
import com.structis.shared.model.UtilisateurLienPegaz;

@Service("utilisateurLienPegazService")
public class UtilisateurLienPegazServiceImpl implements UtilisateurLienPegazService {

	@Autowired
	UtilisateurLienPegazMapper utilisateurLienPegazMapper;
	
	@Override
	public void insert(UtilisateurLienPegaz utilisateurLienPegaz) {
		utilisateurLienPegazMapper.insert(utilisateurLienPegaz);
	}

}
