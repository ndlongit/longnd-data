package com.structis.server.service.security;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.stereotype.Service;

@Service("guiManager")
public class GuiManagerImpl implements GuiManager {

	private HashMap<String, List<String>> guiVisibilityRules;

	@Override
	public LinkedHashMap<String, String> getVisibilityAction(String cRole) {
		List<String> rules = this.getGuiVisibilityRules().get(cRole);
		LinkedHashMap<String,String> result = null;
		if(rules != null && rules.size() > 0){
			result = parseGuiRules(rules);
		}
		return result;
	}

	public HashMap<String, List<String>> getGuiVisibilityRules() {
		return guiVisibilityRules;
	}

	public void setGuiVisibilityRules(HashMap<String, List<String>> guiVisibilityRules) {
		this.guiVisibilityRules = guiVisibilityRules;
	}

	private LinkedHashMap<String, String> parseGuiRules(List<String> rules) {
		LinkedHashMap<String, String> ret = new LinkedHashMap<String, String>();

		if( rules == null ) {
			return ret;
		}
		for( String rule : rules ) {

			String[] elements = rule.split("\t");
			if( elements.length < 2 ) {
				continue;
			}
			String actionID = elements[0];
			String permission = elements[1];

			ret.put(actionID, permission);
		}
		return ret;
	}
}
