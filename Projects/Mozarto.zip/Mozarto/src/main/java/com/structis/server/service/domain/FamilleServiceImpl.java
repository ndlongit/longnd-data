package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.persistence.FamilleMapper;
import com.structis.server.util.StringUtils;
import com.structis.shared.model.Famille;

/**
 * 
 * @author vu.dang
 *
 */
@Service("familleService")
public class FamilleServiceImpl implements FamilleService {
	@Autowired
	private FamilleMapper famillePO;
	
	public Famille findById(Integer id) {
		return famillePO.findById(id);	
	}
	
	@Transactional
	public Integer insert(Famille famille) {
		 return famillePO.insert(famille);	
	}
	
	@Transactional
	public void update(Famille famille) {
		famillePO.update(famille);	
	}
		
	@Transactional
	public void delete(Famille famille) {
		famillePO.delete(famille);	
	}
	
	@Transactional
	public void deleteById(Integer id) {
		famillePO.deleteById(id);	
	}
	public List<Famille> findAll() {
		return famillePO.findAll();		
	}

	@Override
	public List<Famille> findByMetier(Integer idMetier) {
		return famillePO.findByMetier(idMetier);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Famille> findByMetierAndLabel(Integer idMetier, String label) {
		if( !StringUtils.isNullOrEmtpy(label) ) {
			label = label.toUpperCase();
		}
		Map params = new HashMap();
		params.put("idMetier", idMetier);
		params.put("label", label);
		return famillePO.findByMetierAndLabel(params);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Famille> findEmptyFamily(Integer metierId, String elementType) {
		Map params = new HashMap();
		params.put("metierId", metierId);
		params.put("elementType", elementType);
		params.put("label", "");
		return famillePO.findEmptyFamily(params);
	}

	@Override
	public List<Famille> findByBaseCriteria(Famille criteria) {
		return famillePO.findByBaseCriteria(criteria);
	}
}
