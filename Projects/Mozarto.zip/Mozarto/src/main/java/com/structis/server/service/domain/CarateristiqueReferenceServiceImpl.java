package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlCarateristiqueReferenceMapper;
import com.structis.shared.model.MdlCarateristiqueReference;

@Service
public class CarateristiqueReferenceServiceImpl implements CarateristiqueReferenceService {
	
	@Autowired
	MdlCarateristiqueReferenceMapper mdlCarateristiqueReferenceMapper;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<MdlCarateristiqueReference> findByModeleVersionAndReference(Integer idModeleVersion, Integer idReference) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);
		return mdlCarateristiqueReferenceMapper.findByModeleVersionAndReference(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteByModeleVersionAndReference(Integer idModeleVersion, Integer idReference) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);
		mdlCarateristiqueReferenceMapper.deleteByParameters(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void insertList(List<MdlCarateristiqueReference> listCarateristiqueReference) {
		if(listCarateristiqueReference != null && listCarateristiqueReference.size() > 0){
			Map mapParameter = new HashMap();
			mapParameter.put("carateristiqueReferenceList", listCarateristiqueReference);
			mdlCarateristiqueReferenceMapper.insertList(mapParameter);
		}
		
	}

	@Override
	public void insert(MdlCarateristiqueReference record) {		
		mdlCarateristiqueReferenceMapper.insert(record);		
	}

	@Override
	public void delete(MdlCarateristiqueReference record) {
		mdlCarateristiqueReferenceMapper.deleteById(record.getId());
	}

	@Override
	public List<MdlCarateristiqueReference> findByBaseCriteria(MdlCarateristiqueReference criteria) {
		return mdlCarateristiqueReferenceMapper.findByBaseCriteria(criteria);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteByModeleVersionIdCarateristiquesAndIdReferences(Integer idModeleVersion,List<Integer> idCarateristiques, List<Integer> idReferences) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReferences", idReferences);
		mapParameter.put("idCaracteristiques", idCarateristiques);
		mdlCarateristiqueReferenceMapper.deleteByIdReferencesAndIdCarateristiques(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteByReferenceIdsAndCharacteristicIds(Integer idModeleVersion, List<Integer> idReferences, List<Integer> ids) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReferences", idReferences);
		mapParameter.put("ids", ids);
		mdlCarateristiqueReferenceMapper.deleteByReferenceIdsAndCharacteristicIds(mapParameter);
	}
}
