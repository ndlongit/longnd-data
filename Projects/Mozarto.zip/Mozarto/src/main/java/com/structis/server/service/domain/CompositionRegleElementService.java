package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.CmpRegleElement;

public interface CompositionRegleElementService {
	void insertList(List<CmpRegleElement> cmpRegleElements);
	
	void deleteIdComposition(Integer idComposition);
}
