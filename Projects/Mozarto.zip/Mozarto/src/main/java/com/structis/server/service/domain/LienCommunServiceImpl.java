package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.persistence.MdlLienCommunMapper;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.MdlLienCaracteristique;
import com.structis.shared.model.MdlLienCommun;
import com.structis.shared.model.MdlLienElement;
import com.structis.shared.model.MdlLienReference;

@Service
public class LienCommunServiceImpl implements LienCommunService {
	@Autowired
	LiencaracteristiqueService liencaracteristiqueService;
	
	@Autowired
	MdlLienCommunMapper mdlLienCommunMapper;
	
	@Autowired
	LienReferenceService lienReferenceService;
	
	@Autowired
	LienElementService lienElementService;
	
	@Override
	public int insert(MdlLienCommun lienCommun) {
		return mdlLienCommunMapper.insert(lienCommun);
	}
	
	@Transactional
	@Override
	public int getIdLienCommmun(int idModeleVersion, int sourceId, String typeLien, boolean createOption) {
		int idLienCommun = 0;
		if(typeLien.equals(ModelNodeType.CARACTERISTIQUE.getLabel())){
			MdlLienCaracteristique source =  liencaracteristiqueService.findLienCaracteristiqueByCaracteristique(idModeleVersion,sourceId);
			if(source != null){
				idLienCommun = source.getIdLienCommun();
			}else if(source == null && createOption){
				// insert into mz_mdl_lien_commun
				idLienCommun = createLienCommun(typeLien, idModeleVersion);
				//insert into mz_mdl_lien_caracteristique
				MdlLienCaracteristique lienCaracteristique = new MdlLienCaracteristique();
				lienCaracteristique.setIdLienCommun(idLienCommun);
				lienCaracteristique.setIdCaracteristique(sourceId);
				lienCaracteristique.setIdModeleVersion(idModeleVersion);
				liencaracteristiqueService.insert(lienCaracteristique);
			}
		}else if(typeLien.equals(ModelNodeType.REFERENCE.getLabel())){
			MdlLienReference source = lienReferenceService.findLienReferenceByReference(idModeleVersion, sourceId);
			if(source != null){
				idLienCommun = source.getIdLienCommun();
			}else if(source == null && createOption){
				idLienCommun = createLienCommun(typeLien, idModeleVersion);
				//insert into mz_mdl_lien_reference
				MdlLienReference lienReference = new MdlLienReference();
				lienReference.setIdLienCommun(idLienCommun);
				lienReference.setIdReference(sourceId);
				lienReference.setIdModeleVersion(idModeleVersion);
				lienReferenceService.insert(lienReference);
			}
		}else if(typeLien.equals(ModelNodeType.ELEMENT.getLabel())){
			MdlLienElement source = lienElementService.findLienElementByElement(idModeleVersion, sourceId);
			if(source != null){
				idLienCommun = source.getIdLienCommun();
			}else if(source==null && createOption){
				idLienCommun = createLienCommun(typeLien, idModeleVersion);
				//insert into mz_mdl_lien_element
				MdlLienElement lienElement = new MdlLienElement();
				lienElement.setIdLienCommun(idLienCommun);
				lienElement.setIdElement(sourceId);
				lienElement.setIdModeleVersion(idModeleVersion);
				lienElementService.insert(lienElement);
			}
		}
		return idLienCommun;
	}
	
	@Transactional
	private int createLienCommun(String typeLien,Integer idModeleVersion){
		MdlLienCommun lienCommun = new MdlLienCommun();
		lienCommun.setCTypeLien(typeLien);
		lienCommun.setIdModeleVersion(idModeleVersion);
		insert(lienCommun);
		return lienCommun.getIdLienCommun();
	}

	@Override
	public MdlLienCommun findById(int idLienCommun) {
		return mdlLienCommunMapper.findById(idLienCommun);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteByIdLienCoummuns(int idModeleVersion, List<Integer> idLienCommuns) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommuns", idLienCommuns);
		mdlLienCommunMapper.deleteByIds(mapParameter);
	}
	
	@Override
	public MdlLienCommun getLienCommmun(int idModeleVersion, int sourceId, String typeLien, boolean createOption) {
		return findById(getIdLienCommmun(idModeleVersion, sourceId, typeLien, createOption));
	}
	
}
