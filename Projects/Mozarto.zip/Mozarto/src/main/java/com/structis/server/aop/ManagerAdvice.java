package com.structis.server.aop;

import org.aspectj.lang.annotation.Aspect;

@Aspect
/**
 * Utilise javamelody
 */
public class ManagerAdvice {
	  
	/*private static Logger logger = Logger.getLogger(ManagerAdvice.class);
	
	  @Around("com.structis.server.aop.SystemArchitecture.inCallerLayer()")
	  public Object profile(ProceedingJoinPoint pjp) throws Throwable {
		  try {
			  return pjp.proceed();
		  } catch (Throwable ex) {
			  // Pour mapper les runtime exceptions qui 
			  // ne sont pas encore mapper
			  ex.printStackTrace();
			  logger.error(ex.getMessage());
			  throw ExceptionMapper.map(ex);
		  }
	  }
	  
	  @Around("com.structis.server.aop.SystemArchitecture.inManagerLayer()")
	  public Object profile2(ProceedingJoinPoint pjp) throws Throwable {
		  try {
			  return pjp.proceed();
		  } catch (Throwable ex) {
			  throw ExceptionMapper.map(ex);
		  }
		  finally {
			  MDC.put("manager", pjp.getSignature().getDeclaringTypeName());
			  MDC.put("methods", pjp.getSignature().getName());
		  }
	  }
*/
}
