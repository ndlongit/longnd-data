package com.structis.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.FormPanel.SubmitCompleteEvent;
import com.google.gwt.user.client.ui.FormPanel.SubmitCompleteHandler;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FileUploadField;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.structis.client.event.ModifierModeleEvent;
import com.structis.client.message.Messages;
import com.structis.client.util.NameValuePair;

public class FileImportDialog extends Dialog implements EntryPoint {

	private final FormPanel form = new FormPanel();

	private VerticalLayoutContainer p = new VerticalLayoutContainer();

	private Messages messages = GWT.create(Messages.class);

	private String title;

	private TextButton importButton;

	private FileUploadField file;

	private Label label;

	private Label resultLabel;
	
	private SimpleEventBus bus = new SimpleEventBus();
	
	private class CustomizeFileUploadField extends FileUploadField{
		@Override
		public FileUploadFieldMessages getMessages() {
			return new FileUploadFieldMessages() {
				
				@Override
				public String browserText() {
					return messages.commonImportPopupBrowsebutton();
				}
			};			
		}
	}
	
	public FileImportDialog(SimpleEventBus bus,String title) {
		this.title = title;
		this.bus = bus;
		buildPanel();
		addHanddler();
	}

	public void buildPanel(){
		setHeadingText(title);
		setButtonAlign(BoxLayoutPack.CENTER);
		setWidth(500);
		setHeight(140);
		add(form);
		form.add(p);

		label = new Label(messages.commonImportPopupMessage());
		label.setHeight("30px");
		
		file = new CustomizeFileUploadField();
		
		p.add(label);
		
		p.add(file, new VerticalLayoutData(1, 1));
		
		resultLabel = new Label();
		
		p.add(resultLabel, new VerticalLayoutData(1, 1));

		importButton = getButtonById(PredefinedButton.OK.name());
		importButton.setText(messages.commonImportPopupImportbutton());
		importButton.disable();
		
		form.setEncoding(FormPanel.ENCODING_MULTIPART);
		form.setMethod(FormPanel.METHOD_POST);
	}
	
	public void addHanddler(){
		file.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent arg0) {
				if( file.getValue().endsWith(".csv") ) {
					importButton.enable();
				}
				else {
					importButton.disable();
				}
			}
		});
		importButton.addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				if( file.isVisible() ) {
					if( file.getValue().endsWith(".csv") ) {
						form.submit();
						importButton.setVisible(false);
						importButton.setText(messages.commonFermerButton());
						setClosable(false);
						file.setVisible(false);
						label.setVisible(false);
						resultLabel.setText(messages.waitingMessage());
					}
				}
				else {
					hide();
				}
			}
		});

		form.addSubmitCompleteHandler(new SubmitCompleteHandler() {
			@Override
			public void onSubmitComplete(SubmitCompleteEvent arg0) {
				importButton.setVisible(true);
				setClosable(true);
				String result = arg0.getResults();

				String[] temps = result.split("=", 3);
				if( "0".equalsIgnoreCase(temps[0]) ) {
					String url = temps[1];
					String fileName = temps[2];

					List<NameValuePair> values = new ArrayList<NameValuePair>();
					values.add(new NameValuePair("fileName", fileName));
					url += "?fileName=" + fileName;

					String linkRef = "<a target='_blank' href='" + url + "'>" + messages.importErrorTextLink() + "</a>";
					HTML link = new HTML(linkRef);
					p.add(link);
					link.addClickHandler(new ClickHandler() {
						
						@Override
						public void onClick(ClickEvent paramClickEvent) {
							hide();
						}
					});
					
					resultLabel.setText(messages.importErrorMessage());
					//hide();
				}
				else if( "1".equalsIgnoreCase(temps[0]) || "2".equalsIgnoreCase(temps[0]) ) {
					resultLabel.setText(temps[1]);
				}
				bus.fireEvent(new ModifierModeleEvent(0));
			}
		});
	}
	
	public void onModuleLoad() {
	}

	public void addParamElement(String name, String value) {
		TextField field = new TextField();
		field.setName(name);
		field.setValue(value);
		field.setVisible(false);
		p.add(field);
	}

	public void setFormAction(String url) {
		String baseUrl = GWT.getHostPageBaseURL(); // http://10.117.71.66:8091/mozarto/
		form.setAction(baseUrl + url);
	}
}
