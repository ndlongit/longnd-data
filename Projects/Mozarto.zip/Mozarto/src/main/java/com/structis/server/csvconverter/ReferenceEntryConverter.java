package com.structis.server.csvconverter;

import java.util.List;

import com.googlecode.jcsv.writer.CSVEntryConverter;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ReferenceAttributsCaracteristiquesElementsModel;

public class ReferenceEntryConverter implements CSVEntryConverter<ReferenceAttributsCaracteristiquesElementsModel> {

	@Override
	public String[] convertEntry(ReferenceAttributsCaracteristiquesElementsModel r) {
		String[] columns = null;
		if( r != null ) {
			List<AttributEtenduMetierERValueModel> attributEtenduMetierERValueModels = r.getAttributEtenduMetierERValueModels();
			List<MdlCarateristiqueReference> carateristiqueReferences = r.getCaracteristiques();
			List<MdlReferenceElement> referenceElements = r.getReferenceElements();
			columns = new String[attributEtenduMetierERValueModels.size() * 2 + 1 + r.getNumCaractMax() + r.getNumElemtMax() * 2];

			columns[0] = r.getReference().getLLibelleLong();
			for( int i = 0 ; i < attributEtenduMetierERValueModels.size() ; i++ ) {
				AttributEtenduMetierERValueModel attributEtenduMetierERValueModel = attributEtenduMetierERValueModels.get(i);
				columns[1 + 2*i] = attributEtenduMetierERValueModel.getAttributEtenduLibelle();
				if( attributEtenduMetierERValueModel.getValeur() != null )
					columns[2 + 2*i] = attributEtenduMetierERValueModel.getValeur();
				else
					columns[2 + 2*i] = "";
			}
			int filled_columns = 1 + attributEtenduMetierERValueModels.size() * 2;
			for( int i = 0 ; i < r.getNumCaractMax() ; i++ ) {
				if( i < carateristiqueReferences.size() && carateristiqueReferences.get(i) != null ) {
					columns[1 + attributEtenduMetierERValueModels.size() * 2 + i] = carateristiqueReferences.get(i).getCaracteristiqueLibelle();
				}
				else {
					columns[1 + attributEtenduMetierERValueModels.size() * 2 + i] = "";
				}
			}
			filled_columns = 1 + attributEtenduMetierERValueModels.size() * 2 + r.getNumCaractMax();
			for( int i = 0 ; i < r.getNumElemtMax() ; i++ ) {
				if( i < referenceElements.size() && referenceElements.get(i) != null && referenceElements.get(i).getElementCode() != null && referenceElements.get(
						i).getNQuantite() != null ) {
					columns[filled_columns + 2*i] = referenceElements.get(i).getElementCode();
					columns[filled_columns + 2*i + 1] = referenceElements.get(i).getNQuantite().toString();
				}
				else {
					columns[filled_columns + 2*i] = "";
					columns[filled_columns + 2*i + 1] = "";
				}
			}
		}
		return columns;
	}

}
