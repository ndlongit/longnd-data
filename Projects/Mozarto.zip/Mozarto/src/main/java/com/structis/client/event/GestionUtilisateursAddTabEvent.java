package com.structis.client.event;

import java.util.List;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.RoleUtilisateur;
import com.structis.shared.model.Utilisateur;

public class GestionUtilisateursAddTabEvent extends GwtEvent<GestionUtilisateursAddTabHandler> {

	private static Type<GestionUtilisateursAddTabHandler> TYPE = new Type<GestionUtilisateursAddTabHandler>();
	
	private Utilisateur utilisateur;
	
	private List<RoleUtilisateur> roleUtilisateurs;

	public static Type<GestionUtilisateursAddTabHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionUtilisateursAddTabHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionUtilisateursAddTabHandler handler) {
		handler.onLoad(this);
	}

	public GestionUtilisateursAddTabEvent(Utilisateur utilisateur, List<RoleUtilisateur> roleUtilisateurs) {
		this.setUtilisateur(utilisateur);
		this.setRoleUtilisateurs(roleUtilisateurs);
	}

	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	public Utilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setRoleUtilisateurs(List<RoleUtilisateur> roleUtilisateurs) {
		this.roleUtilisateurs = roleUtilisateurs;
	}

	public List<RoleUtilisateur> getRoleUtilisateurs() {
		return roleUtilisateurs;
	}

}
