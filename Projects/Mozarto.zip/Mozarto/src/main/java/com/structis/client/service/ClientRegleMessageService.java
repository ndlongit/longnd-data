package com.structis.client.service;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;
import com.structis.shared.model.reference.RuleConflictInfo;
import com.structis.shared.model.reference.TreeNodeModel;

@RemoteServiceRelativePath("springGwtServices/clientRegleMessageService")
public interface ClientRegleMessageService extends RemoteService {
	ModelisateurRegleMessageListModel insertRegle(Integer idUser,TreeNodeModel source, TreeNodeModel target, Integer priorite, Integer quantite);
	
	ModelisateurRegleMessageListModel updateRegle(Integer idUser,int idRegle, TreeNodeModel target, Integer priorite, Integer quantite);

	/**
	 * find regle of one node in the tree
	 * 
	 * @param item
	 * @return
	 */
	List<ModelisateurRegleMessageListModel> findMessageRegleList(TreeNodeModel item);
	/**
	 * Check rule conflict 
	 * @param sourceNode
	 * @param targetNode
	 * @param priorite
	 * @param quantite
	 * @return RuleConflictInfo
	 */
	RuleConflictInfo checkConflict(TreeNodeModel sourceNode, TreeNodeModel targetNode, int priorite, int quantite, boolean isUpdate);
	/**
	 * 
	 * @param sourceNode
	 * @param idRegle
	 */
	void cancelInheritageRegle(Integer idUser,TreeNodeModel sourceNode, int idRegle);
	/**
	 * delete regle in the source node and annuler regle in the children node
	 * @param sourceNode
	 * @param idRegle
	 */
	void deleteRegle(Integer idUser,TreeNodeModel sourceNode,int idRegle);
	
	ModelisateurRegleMessageListModel insertMessage(Integer idUser, TreeNodeModel source, String libelle, Integer priorite);
	
	ModelisateurRegleMessageListModel updateMessage(Integer idUser, Integer idMessage, String libelle, Integer priorite);
	
	void deleteMessage(Integer idUser,TreeNodeModel sourceNode,int idMessage);

	void cancelInheritageMessage(Integer idUser, TreeNodeModel sourceNode, int idMessage);
	
	List<ModelisateurRegleMessageListModel> findReglePointToElement(TreeNodeModel item);
	
	PagingLoadResult<ModelisateurRegleMessageListModel> findMessageRegleListPaging(TreeNodeModel item, PagingLoadConfig loadConfig);
	
	PagingLoadResult<ModelisateurRegleMessageListModel> findReglePointToElementPaging(TreeNodeModel item, PagingLoadConfig loadConfig);
	
}
