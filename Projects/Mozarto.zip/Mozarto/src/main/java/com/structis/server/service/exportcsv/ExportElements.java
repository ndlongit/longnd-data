package com.structis.server.service.exportcsv;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import com.googlecode.jcsv.writer.CSVWriter;
import com.googlecode.jcsv.writer.internal.CSVWriterBuilder;
import com.structis.server.csvconverter.ElementEntryConverter;
import com.structis.shared.model.reference.ElementWithFamillesAndAttributsModel;

public class ExportElements {
	private List<ElementWithFamillesAndAttributsModel> elementList;
	
	public ExportElements(){
		elementList = new ArrayList<ElementWithFamillesAndAttributsModel>();
	}
	
	public Writer export (String filename, int size){
		try {
			Writer out = new FileWriter(filename);

			String header = "";
			
			header += "Famille-1;Famille-2;Famille-3;Famille-4;Type element;Code element;Libelle element;Nomenclature fournisseur;Actif;";
			for (int i = 0; i < size-1; i++){
				header += "Attribut;Valeur;";
			}
			if (size > 0)
				header += "Attribut;Valeur\n";
			else 
				header += "\n";
			out.write(header);
			ElementEntryConverter elementEntryConverter = new ElementEntryConverter();
			CSVWriterBuilder<ElementWithFamillesAndAttributsModel> csvWriterBuilder = new CSVWriterBuilder<ElementWithFamillesAndAttributsModel>(out);
			CSVWriterBuilder<ElementWithFamillesAndAttributsModel> entryConverter = csvWriterBuilder.entryConverter(elementEntryConverter);
			CSVWriter<ElementWithFamillesAndAttributsModel> csvWriter = entryConverter.build();
			csvWriter.writeAll(elementList);

			return out;
		}
		catch( IOException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public List<ElementWithFamillesAndAttributsModel> getElementList() {
		return elementList;
	}

	public void setElementList(List<ElementWithFamillesAndAttributsModel> elementList) {
		this.elementList = elementList;
	}
}
