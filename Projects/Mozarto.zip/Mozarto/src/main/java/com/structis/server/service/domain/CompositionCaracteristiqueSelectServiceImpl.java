package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.CmpCaracteristiqueSelectMapper;
import com.structis.shared.model.CmpCaracteristiqueSelect;

@Service
public class CompositionCaracteristiqueSelectServiceImpl implements CompositionCaracteristiqueSelectService {

	@Autowired
	CmpCaracteristiqueSelectMapper cmpCaracteristiqueSelectMapper;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void insertList(List<CmpCaracteristiqueSelect> cmpCaracteristiqueSelects) {
		Map parameters = new HashMap();
		parameters.put("cmpCaracteristiqueSelects", cmpCaracteristiqueSelects);
		cmpCaracteristiqueSelectMapper.insertList(parameters);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteByIdComposition(Integer idComposition) {
		Map parameters = new HashMap();
		parameters.put("idComposition", idComposition);
		cmpCaracteristiqueSelectMapper.deleteByIdComposition(parameters);
	}
	
}
