package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoadResultBean;
import com.structis.client.service.ClientAccueilModelisateurService;
import com.structis.server.service.domain.MetierService;
import com.structis.server.service.domain.ModeleService;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.ModeleModel;

@Service("accueilServiceImpl")
public class ClientAccueilModelisateurServiceImpl implements ClientAccueilModelisateurService {

	@Autowired
	ModeleService modeleService;
	
	@Autowired
	MetierService metierService;
	
	@Override
	public PagingLoadResult<ModeleModel> getModele(Integer idModele, Integer idMetier, PagingLoadConfig loadConfig) {
		String sortField = "dDateheureCrea";
		String sortDir = "DESC";
		if (loadConfig.getSortInfo().size() > 0){
			sortField = loadConfig.getSortInfo().get(0).getSortField();
			sortDir = loadConfig.getSortInfo().get(0).getSortDir().name();
		}
		List<ModeleModel> findAllByMetier = modeleService.findAllByMetier(idModele, idMetier, sortField, sortDir);
		ArrayList<ModeleModel> sublist = new ArrayList<ModeleModel>();
	    int start = loadConfig.getOffset();
	    int limit = findAllByMetier.size();
	    if (loadConfig.getLimit() > 0) {
	      limit = Math.min(start + loadConfig.getLimit(), limit);
	    }
	    for (int i = loadConfig.getOffset(); i < limit; i++) {
	      ModeleModel m = findAllByMetier.get(i);
	      sublist.add(m);
	    }
		return new PagingLoadResultBean<ModeleModel>(sublist, findAllByMetier.size(), loadConfig.getOffset());
	}

	@Override
	public Integer updateByIdModele(Integer idModele, boolean actif) {
		return modeleService.updateByIdModele(idModele, actif);
	}

	@Override
	public Metier getMetier(Integer idMetier) {
		return metierService.findById(idMetier);
	}

}
