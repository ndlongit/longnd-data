package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.ModeleModel;

public class CompositionLoadComposModeleEvent  extends GwtEvent<CompositionLoadComposModeleHandler>{
	
	private static Type<CompositionLoadComposModeleHandler> TYPE = new Type<CompositionLoadComposModeleHandler>();
	
	private ModeleModel modele;
	
	public static Type<CompositionLoadComposModeleHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<CompositionLoadComposModeleHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(CompositionLoadComposModeleHandler handler) {
		handler.onLoad(this);
	}
	
	public CompositionLoadComposModeleEvent(ModeleModel modeleModel) {
		this.setModele(modeleModel);
	}

	public void setModele(ModeleModel modele) {
		this.modele = modele;
	}

	public ModeleModel getModele() {
		return modele;
	}

}
