package com.structis.client.properties;

import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.RoleUtilisateur;

public interface RoleUtilisateurProperties extends PropertyAccess<RoleUtilisateur> {

	ModelKeyProvider<RoleUtilisateur> cRole();

	LabelProvider<RoleUtilisateur> lLibelle();
}
