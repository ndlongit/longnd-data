package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.TypeElement;

/**
 * 
 * @author vu.dang
 *
 */
public interface TypeElementService {
	
	public TypeElement findById(String id);
	
	public Integer insert(TypeElement record);
	
	public Integer update(TypeElement record);
	
	public Integer delete(TypeElement record);
	
	public Integer deleteById(String id);
	
	public List<TypeElement> findAll();
}
