package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoadResultBean;
import com.structis.client.service.ClientReferenceService;
import com.structis.server.service.domain.CaracteristiqueService;
import com.structis.server.service.domain.CarateristiqueReferenceService;
import com.structis.server.service.domain.ModelisateurRegleMessageService;
import com.structis.server.service.domain.ReferenceElementService;
import com.structis.server.service.domain.ReferenceService;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ReferenceFormModel;
import com.structis.shared.model.reference.TreeNodeModel;

@Service
public class ClientReferenceServiceImpl implements ClientReferenceService {

	@Autowired
	ReferenceService referenceService;

	@Autowired
	CaracteristiqueService caracteristiqueService;

	@Autowired
	CarateristiqueReferenceService carateristiqueReferenceService;

	@Autowired
	ReferenceElementService referenceElementService;

	@Autowired
	ModelisateurRegleMessageService modelisateurRegleMessageService;
	@Override
	public ReferenceFormModel findReferenceFormModelById(Integer idModeleVersion, Integer idReference, Integer idMetier) {
		MdlReference reference = referenceService.findById(idReference);
		List<AttributEtenduMetierERValueModel> attrValues = referenceService.findAttributEtenduMetierERValueByIdAndMetier(
				idModeleVersion, idReference, idMetier);
		/*List<MdlCarateristiqueReference> carateristiqueReferences = carateristiqueReferenceService.findByModeleVersionAndReference(
				idModeleVersion, idReference);*/
		/*List<MdlReferenceElement> referenceElements = referenceElementService.findByModeleVersionAndReference(
				idModeleVersion, idReference);*/

		ReferenceFormModel result = new ReferenceFormModel();
		result.setReference(reference);
		result.setListAttributEtendu(attrValues);
		//result.setListElementEntree(carateristiqueReferences);
		//result.setListElementSortie(referenceElements);

		return result;
	}

	@Override
	public void updateReference(ReferenceFormModel referenceForm) {
		//update Referene itseft
		MdlReference reference = referenceForm.getReference();
		// move to transaction
		referenceService.update(reference, referenceForm.getListAttributEtendu(), referenceForm.getListElementEntree(), referenceForm.getListElementSortie());
	}

	@Override
	public Integer insert(Integer idCaracteristiqueParent, ModelNodeType typeParent, MdlReference record) {
		// reference just link to characteristic  		
		referenceService.insert(idCaracteristiqueParent, record);
		return record.getIdReference();
	}

	@Override
	public void remove(Integer idCaracteristiqueParent, MdlReference record) {
		referenceService.delete(idCaracteristiqueParent, record);
	}

	@Override
	public Integer insertOrUpdate(Integer utilisateurId, Integer idCaracteristique, ReferenceFormModel referenceForm) {		
		// move to transaction
		MdlReference reference = referenceForm.getReference();		
		return referenceService.insertOrUpdate(utilisateurId, reference, referenceForm.getListAttributEtendu(), referenceForm.getListElementEntree(), referenceForm.getListElementSortie());
	}

	@Override
	public Integer insertOrUpdateInRules(TreeNodeModel parentNode, Integer utilisateurId,
			Integer parentId, ReferenceFormModel referenceForm) {
		MdlReference reference = referenceForm.getReference();
		if (parentNode != null && reference.getIdReference() != null) {
			if (modelisateurRegleMessageService.checkSatisfyRules(parentNode, reference.getIdReference())) {			
				return referenceService.insertOrUpdate(utilisateurId, reference, referenceForm.getListAttributEtendu(), referenceForm.getListElementEntree(), referenceForm.getListElementSortie());
			}
		} else {
			return referenceService.insertOrUpdate(utilisateurId, reference, referenceForm.getListAttributEtendu(), referenceForm.getListElementEntree(), referenceForm.getListElementSortie());
		}
		
		return null;
	}

	@Override
	public Boolean checkSatisfyRule(TreeNodeModel parentNode, Integer referenceId) {
		return modelisateurRegleMessageService.checkSatisfyRules(parentNode, referenceId, parentNode.getIdModeleVersion(), "R");
	}

	@Override
	public List<AttributEtenduMetierERValueModel> getListAttributEtenduByModelVersion(
			Integer idModeleVersion) {		
		return referenceService.getListAttributEtenduByModelVersion(idModeleVersion);
	}

	@Override
	public PagingLoadResult<MdlReferenceElement> loadElementPaging(Integer idModeleVersion, Integer idReference,
			PagingLoadConfig loadConfig) {
		List<MdlReferenceElement> findAllByReference = referenceElementService.findByModeleVersionAndReference(
				idModeleVersion, idReference);
		List<MdlReferenceElement> resullist = new ArrayList<MdlReferenceElement>();
	    int start = loadConfig.getOffset();
	    int limit = findAllByReference.size();
	    if (loadConfig.getLimit() > 0) {
	      limit = Math.min(start + loadConfig.getLimit(), limit);
	    }
	 
	    for(int i=loadConfig.getOffset(); i< limit ; i++){
	    	resullist.add(findAllByReference.get(i));
	    }
	    
		return new PagingLoadResultBean<MdlReferenceElement>(resullist, findAllByReference.size(), loadConfig.getOffset());
	}

	@Override
	public PagingLoadResult<MdlCarateristiqueReference> loadCaracteristiquePaging(Integer idModeleVersion, Integer idReference,
			PagingLoadConfig loadConfig) {
		List<MdlCarateristiqueReference> findAllByReference = carateristiqueReferenceService.findByModeleVersionAndReference(
				idModeleVersion, idReference);
		List<MdlCarateristiqueReference> resullist = new ArrayList<MdlCarateristiqueReference>();
	    int start = loadConfig.getOffset();
	    int limit = findAllByReference.size();
	    if (loadConfig.getLimit() > 0) {
	      limit = Math.min(start + loadConfig.getLimit(), limit);
	    }
	 
	    for(int i=loadConfig.getOffset(); i< limit ; i++){
	    	resullist.add(findAllByReference.get(i));
	    }
		return new PagingLoadResultBean<MdlCarateristiqueReference>(resullist, findAllByReference.size(), loadConfig.getOffset());
	}	
}
