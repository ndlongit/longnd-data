package com.structis.client.service;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.TreeNodeModel;

@RemoteServiceRelativePath("springGwtServices/clientModelisateurService")
public interface ClientModelisateurService extends RemoteService {
	/**
	 *  Return the children of given parent when expand node in the tree
	 * @param node folder
	 * @return the children
	 */
	public List<TreeNodeModel> getFolderChildren(TreeNodeModel node,boolean includeRegle);
	
	/**
	 * 
	 * @param node
	 * @return
	 */
	public List<TreeNodeModel> getParent(TreeNodeModel node);
	
	public List<MdlCaracteristique> findAll();
	
	public void deleteModelisateurNode(TreeNodeModel sourceNode, boolean isDeleteRegle, boolean isDeleteMessage, boolean isDeleteAll);
	
	public String validateToDelete(TreeNodeModel sourceNode, boolean isDeleteRegle, boolean isDeleteMessage, boolean isDeleteAll);
	
	public Metier getMetier(Integer idMetier);
	
	public TreeNodeModel duplicateNode(TreeNodeModel nodeToBeCopied, TreeNodeModel target, boolean isCopyRegle, boolean isCopyMessage, boolean isCopyChildren, Integer idUtilisateur, Integer idMetier);
}
