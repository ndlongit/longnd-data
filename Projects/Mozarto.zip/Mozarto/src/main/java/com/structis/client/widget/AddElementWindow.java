package com.structis.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.FramedPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.BeforeShowEvent;
import com.sencha.gxt.widget.core.client.event.BeforeShowEvent.BeforeShowHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.structis.client.constant.ConstantClient;
import com.structis.client.constant.ConstantClient.ScreenSize;
import com.structis.client.event.CompositionHaveChangeEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.panel.composition.CompositionElementSupplementaire;
import com.structis.client.service.ClientCompositionServiceAsync;
import com.structis.shared.model.Element;

public class AddElementWindow extends Window {
	private SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private HTML actionDescription;

	private TextField edcSearchTextField;

	private ElementCompositionGrid edcGrid;
	
	VerticalLayoutContainer west;

	private TextButton ajouterButton;

	private HTML annulerButton;
	
	private CompositionElementSupplementaire parent;

	private ElementAutonomeGrid elementAutonomeGrid;
	
	public AddElementWindow(SimpleEventBus bus, CompositionElementSupplementaire parent) {
		this.bus = bus;
		this.parent = parent;
		buildPanel();
		addHandler();		
	}

	private void buildPanel() {
		setPixelSize(750, 500);
//		setStyleName("whiteBackGround");
		CustomizeBorderlayoutContainer container = new CustomizeBorderlayoutContainer();
		BorderLayoutData westData = new BorderLayoutData(ScreenSize.MINLEFT);
		westData.setSplit(true);
		westData.setMargins(new Margins(0, 5, 0, 0));
		westData.setMinSize(ScreenSize.MINLEFT);
		ContentPanel leftPanel = new ContentPanel();
		leftPanel.setHeaderVisible(false);
		leftPanel.setBorders(false);
		leftPanel.setBodyBorder(false);
		container.setWestWidget(leftPanel, westData);
		
		setHeadingText(messages.compositionRightElementgridAddwindowTitle());

		actionDescription = new HTML();
		actionDescription.setHTML(messages.compositionRightElementgridAddwindowDescription());

		west = new VerticalLayoutContainer();
		leftPanel.add(west);
		west.add(actionDescription);
		west.add(new HTML("<hr/>"));
		
		edcSearchTextField = new TextField();
		edcSearchTextField.setEmptyText("");

		edcGrid = new ElementCompositionGrid(bus);
		west.add(edcGrid, new VerticalLayoutData(1,1));
		
		new MultiLanguageGridDragSource<Element>(edcGrid.getEdcGrid());
		
		edcGrid.getEdcGrid().getView().setForceFit(true);
		
		FramedPanel centerPanel = new FramedPanel();

		MarginData centerData = new MarginData();

		container.setCenterWidget(centerPanel, centerData);

		FieldSet fieldSet = new FieldSet();
		fieldSet.setHeadingText(messages.compositionRightElementgridEltsup());
		centerPanel.add(fieldSet);
		
		VerticalLayoutContainer gridContainer = new VerticalLayoutContainer();
		fieldSet.add(gridContainer, new VerticalLayoutData(1, 1));
		elementAutonomeGrid = new ElementAutonomeGrid(bus);
		gridContainer.add(elementAutonomeGrid, new VerticalLayoutData(1, 1));
		
//		elementAutonomeGrid.getGrid().getView().setSortingEnabled(false);
		
		annulerButton = new HTML(messages.commonAnnulerButton());
		annulerButton.setStyleName("htmlLink");
		ajouterButton = new TextButton(messages.commonAddButton());
		centerPanel.addButton(annulerButton);
		centerPanel.addButton(ajouterButton);
		centerPanel.setHeaderVisible(false);
		centerPanel.setButtonAlign(BoxLayoutPack.END);
		add(container);

	}

	private void addHandler() {
		
		annulerButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				hide();
			}
		});
		ajouterButton.addSelectHandler(new SelectHandler() {
			
			@Override
			public void onSelect(SelectEvent event) {
				elementAutonomeGrid.getGrid().getStore().commitChanges();
				//ListStore<Element> parentStore = parent.getElementAutonomeGrid().getGrid().getStore();
				List<Element> toAddUpdateElments = new ArrayList<Element>();
				for (Element elt : elementAutonomeGrid.getGrid().getStore().getAll()){
					if (elt.getAdded()){
						toAddUpdateElments.add(elt);
					}
					/*if (elt.getAdded()){
						Element tmp = parent.getElementAutonomeGrid().searchElementById(elt.getIdElement());
						if (tmp != null){
							parentStore.add(parentStore.indexOf(tmp), tmp);
							parentStore.remove(tmp);
						}
						else{
							parentStore.add(elt);
						}
						parentStore.update(elt);
					}*/
				}
				ClientCompositionServiceAsync.Util.getInstance().addUpdateEsElementTMPData(toAddUpdateElments, new AsyncCallbackWithErrorResolution<Void>() {

					@Override
					public void onSuccess(Void result) {
						 parent.getElementAutonomeGrid().getLoader().load(0, ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
						 bus.fireEvent(new CompositionHaveChangeEvent());
					}
				});
				hide();
			}
		});
		addBeforeShowHandler(new BeforeShowHandler() {
			
			@Override
			public void onBeforeShow(BeforeShowEvent event) {
				elementAutonomeGrid.getGrid().getStore().clear();
				edcGrid.getGridLoader().load();
				if (parent.getSortInfo() != null){
					elementAutonomeGrid.setSortInfo(parent.getSortInfo());
				}
				
			}
		});
	}
}
