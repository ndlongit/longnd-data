package com.structis.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.AttributEtendu;

public interface AttributEtenduProperties extends PropertyAccess<AttributEtendu> {
	ModelKeyProvider<AttributEtendu> getIdAttributEtendu();
	
    @Path("lLibelle")
	LabelProvider<AttributEtendu> getLLibelle();

	ValueProvider<AttributEtendu, String> lLibelle();

	ValueProvider<AttributEtendu, String> lValeur();

	ValueProvider<AttributEtendu, String> lCommentaire();

}
