package com.structis.client.panel.admin;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.core.client.Style.SelectionMode;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutData;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer.HBoxLayoutAlign;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.selection.SelectionChangedEvent;
import com.sencha.gxt.widget.core.client.selection.SelectionChangedEvent.SelectionChangedHandler;
import com.structis.client.event.GestionMetierAddTabEvent;
import com.structis.client.event.GestionMetierDisableMetierEvent;
import com.structis.client.event.GestionMetierRenameMetierEvent;
import com.structis.client.event.GestionMetierRenameMetierHandler;
import com.structis.client.navigation.Action;
import com.structis.client.panel.AbstractGestionMetierLeftPanel;
import com.structis.client.properties.MetierMzPzProperties;
import com.structis.client.service.ClientGestionMetierServiceAsync;
import com.structis.client.widget.HtmlButton;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.MetierMzPzModel;

public class GestionDesMetiersLeftPanel extends AbstractGestionMetierLeftPanel {

	private HtmlButton addBtn;
	private HtmlButton modifBtn;
	private HtmlButton delBtn;
	private MetierMzPzModel metierSelected = null;
	private PagingLoader<PagingLoadConfig, PagingLoadResult<MetierMzPzModel>> loader;
	public final static String METIER_ADMIN = "Administration";

	public GestionDesMetiersLeftPanel(final SimpleEventBus bus) {
		super(bus);
	}

	public void addHandler() {
		listMetiers.getSelectionModel().addSelectionChangedHandler(new SelectionChangedHandler<MetierMzPzModel>() {

			@Override
			public void onSelectionChanged(SelectionChangedEvent<MetierMzPzModel> event) {
				if (event.getSelection().size() > 0) {
					metierSelected = event.getSelection().get(0);
				}
			}
		});
		modifBtn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				if (metierSelected != null){
					bus.fireEvent(new GestionMetierAddTabEvent(metierSelected));
				}
			}
		});
		addBtn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				bus.fireEvent(new GestionMetierAddTabEvent(null));
			}
		});
		delBtn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				if (metierSelected != null && !METIER_ADMIN.equals(metierSelected.getLLibelle().trim())){
					bus.fireEvent(new GestionMetierAddTabEvent(metierSelected));
					bus.fireEvent(new GestionMetierDisableMetierEvent(metierSelected.getIdMetier()));
				}
			}
		});
		bus.addHandler(GestionMetierRenameMetierEvent.getType(), new GestionMetierRenameMetierHandler() {
			
			@Override
			public void onLoad(GestionMetierRenameMetierEvent event) {
				loadListMetiers();
			}
		});
		metierLabel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				navigation.goToEcran(Action.ACTION_LOGIN);
			}
		});
		listMetiers.addCellDoubleClickHandler(new CellDoubleClickHandler() {
			
			@Override
			public void onCellClick(CellDoubleClickEvent event) {
				bus.fireEvent(new GestionMetierAddTabEvent(metierSelected));
			}
		});
	}

	@Override
	public void afterLoadMetier(Metier result) {
		metierLabel.setHTML(messages.commonMetier() + ": " + result.getLLibelle());
		metierLabel.setStyleName("htmlLink");
		
		loadListMetiers();
		addHandler();
	}

	public void loadListMetiers() {
		RpcProxy<PagingLoadConfig, PagingLoadResult<MetierMzPzModel>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<MetierMzPzModel>>() {

			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<MetierMzPzModel>> callback) {
				ClientGestionMetierServiceAsync.Util.getInstance().findAll(loadConfig, callback);
			}
		};
		loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<MetierMzPzModel>>(proxy);
		loader.setRemoteSort(true);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, MetierMzPzModel, PagingLoadResult<MetierMzPzModel>>(
				metiers));
		listMetiers.setLoader(loader);
		loader.load();
	}

	@Override
	public void buildFieldSet()  {
		VerticalLayoutContainer container = new VerticalLayoutContainer();
		metiersFieldset.add(container);
		HBoxLayoutContainer buttonPanel = new HBoxLayoutContainer();
		buttonPanel.setPadding(new Padding(1));
		buttonPanel.setHBoxLayoutAlign(HBoxLayoutAlign.TOP);
		addBtn = new HtmlButton(messages.gestionelemcompoLeftNouveaubouton(), images.add());
		modifBtn = new HtmlButton(messages.gestionelemcompoLeftModifierbouton(), images.edit());
		delBtn = new HtmlButton(messages.gestionelemcompoLeftDesactiverbouton(), images.remove());
		buttonPanel.add(addBtn, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		buttonPanel.add(modifBtn, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		buttonPanel.add(delBtn, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		buttonPanel.setBorders(true);
		container.add(buttonPanel);
		MetierMzPzProperties props = GWT.create(MetierMzPzProperties.class);
		metiers = new ListStore<MetierMzPzModel>(props.idMetier());
		ColumnConfig<MetierMzPzModel, String> libelle = new ColumnConfig<MetierMzPzModel, String>(
				props.lLibelle());
		libelle.setColumnStyle(SafeStylesUtils.forBorderStyle(BorderStyle.HIDDEN));
		List<ColumnConfig<MetierMzPzModel, ?>> l = new ArrayList<ColumnConfig<MetierMzPzModel, ?>>();
		l.add(libelle);
		libelle.setCell(new AbstractCell<String>() {

					@Override
					public void render(com.google.gwt.cell.client.Cell.Context context, String label, SafeHtmlBuilder sb) {
						String styleString = "";
						if( label == null )
							label = "";

						if( METIER_ADMIN.equals(label.trim()) ) {
							styleString = "<span class='activeIatlic' >" + label + "</span>";
						}
						else {
							MetierMzPzModel metierMzPzModel = listMetiers.getStore().get(context.getIndex());
							
							if (metierMzPzModel.getInActif())
								styleString = metierMzPzModel.getLLibelle();
							else 
								styleString = "<span class='inactiveItem' >" + metierMzPzModel.getLLibelle() + "</span>";
						}
						sb.appendHtmlConstant(styleString);
					}
					
				});
		ColumnModel<MetierMzPzModel> cm = new ColumnModel<MetierMzPzModel>(l);
		
		listMetiers = new Grid<MetierMzPzModel>(metiers,cm);
		listMetiers.setHideHeaders(true);
		listMetiers.getView().setAutoFill(true);
		/*listMetiers = new ListView<MetierMzPzModel, String>(metiers, props.lLibelle()){

			@Override
			public void onBrowserEvent(Event event) {
			    super.onBrowserEvent(event);

			    switch (event.getTypeInt()) {
			      case Event.ONMOUSEOVER:
			        onMouseOver(event);
			        break;
			      case Event.ONMOUSEOUT:
			        onMouseOut(event);
			        break;
			      case Event.ONMOUSEDOWN:
			        onMouseDown(event);
			        break;
			      case Event.ONDBLCLICK:
			    	onMouseDbClick (event);
			    }
			  }

			private void onMouseDbClick(Event event) {
				bus.fireEvent(new GestionMetierAddTabEvent(metierSelected));
				
			}
		};*/
		listMetiers.setBorders(false);
		listMetiers.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		container.add(listMetiers, new VerticalLayoutData(1, 1));
		buildPaging();
	}

	protected void buildPaging() {
		/*pagingToolbar = new CustomizePagingToolbar(){

			@Override
			protected void onButtonClick() {
				recordNumber = pagingNumberSpinner.getValue();
				loadListMetiers();
			}
			
			@Override
			protected void onSpinnerClick(int record) {
				recordNumber = record;
				loadListMetiers();
			}
		};
		VBoxLayoutContainer c = new VBoxLayoutContainer();
		c.setVBoxLayoutAlign(VBoxLayoutAlign.RIGHT);
		c.add(pagingToolbar, new BoxLayoutData(new Margins(0, 5, 0, 0)));

		add(c,new VerticalLayoutData(1,45));*/
	}
}
