package com.structis.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.Scheduler;
import com.google.gwt.core.client.Scheduler.ScheduledCommand;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Image;
import com.sencha.gxt.core.client.Style.Side;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.SortDir;
import com.sencha.gxt.data.shared.loader.LoadEvent;
import com.sencha.gxt.data.shared.loader.LoadHandler;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutData;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VBoxLayoutContainer.VBoxLayoutAlign;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.BlurEvent;
import com.sencha.gxt.widget.core.client.event.BlurEvent.BlurHandler;
import com.sencha.gxt.widget.core.client.event.HeaderClickEvent;
import com.sencha.gxt.widget.core.client.event.HeaderClickEvent.HeaderClickHandler;
import com.sencha.gxt.widget.core.client.event.RowDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.RowDoubleClickEvent.RowDoubleClickHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor.IntegerPropertyEditor;
import com.sencha.gxt.widget.core.client.form.SpinnerField;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.grid.GridSelectionModel;
import com.sencha.gxt.widget.core.client.grid.LiveGridView;
import com.sencha.gxt.widget.core.client.tips.ToolTipConfig;
import com.structis.client.event.GestionElementCompositionEvent;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.ElementProperties;
import com.structis.client.service.ClientElementServiceAsync;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.Element;
import com.structis.shared.model.TypeElement;

public class ElementCompositionGrid extends VerticalLayoutContainer {

	SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private NavigationService navigation = NavigationFactory.getNavigation();
	
	private RechercheAvanceeDialog rechercheAvanceeDialog;

	private ListStore<Element> elementStore;

	private List<ColumnConfig<Element, ?>> l;

	private ColumnConfig<Element, String> codeColumn;

	private ColumnConfig<Element, String> libelleColumn;

	private ColumnConfig<Element, String> fournColumn;

	private PagingLoader<PagingLoadConfig, CustomizePagingLoadResult<Element>> gridLoader;

	private LiveGridView<Element> liveGridView;

	private String searchString;
	
	private String sortBy = "c_element";
	
	private String sortDir = SortDir.ASC.name();

	private Integer selectedElementId;

	private int recordNumber = 30;

	private Grid<Element> edcGrid;

	private TextField edcSearchTextField;

	private HTML searchButton;

	private Images images = GWT.create(Images.class);

	private HTML advanceSearchLink;

	private HTML totalRecord;

	private Integer idMetier;
	
	private boolean rechAvancee = false;
	
//	private boolean reLoad = true;

	public ElementCompositionGrid(SimpleEventBus bus1) {
		idMetier = navigation.getContext().getMetier().getIdMetier();
		this.bus = bus1;
		RpcProxy<PagingLoadConfig, CustomizePagingLoadResult<Element>> proxy = new RpcProxy<PagingLoadConfig, CustomizePagingLoadResult<Element>>() {

			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<CustomizePagingLoadResult<Element>> callback) {
				/*
				 * if( searchString != null ) { if( searchString.length() > 2 ) {
				 */
				
				if( searchString == null ) {
					searchString = "";
				} 
				Element element = new Element();
				element.setIdMetier(idMetier);
				loadConfig.setLimit(recordNumber);
				if( loadConfig.getSortInfo().size() > 0 ) {
					if( loadConfig.getSortInfo().get(0).getSortField().equals("lLibelleLong") ) {
						sortBy = "l_libelle_long";
					}
					else if( loadConfig.getSortInfo().get(0).getSortField().equals("lNomenclatureFournisseur") ) {
						sortBy = "l_nomenclature_fournisseur";
					}
					sortDir = loadConfig.getSortInfo().get(0).getSortDir().name();
				}
				String attribut = null;
				if(rechAvancee){
					TypeElement type = rechercheAvanceeDialog.getType().getValue();
					if(type != null){
						if( Constant.TYPE_ARTICLE.equals(type.getLLibelle()) )
							element.setCTypeElement(Constant.TYPE_ELEMENT_ARTICLE);
						else
							element.setCTypeElement(Constant.TYPE_ELEMENT_PRESTATION);
					}
					String libelle = rechercheAvanceeDialog.getLibelle().getText();
					if (libelle != null && !"".equals(libelle))
						element.setLLibelleLong("%" + libelle + "%");
					String nomenclature = rechercheAvanceeDialog.getNomenclatureFournisseur().getText();
					if(nomenclature != null && !"".equals(nomenclature))
						element.setLNomenclatureFournisseur("%" + nomenclature + "%");
					String code = rechercheAvanceeDialog.getCode().getText();
					if(code != null && !"".equals(code))
						element.setCElement("%" + code + "%");
					attribut = rechercheAvanceeDialog.getAttribut().getText();
					if(attribut == null || "".equals(attribut))
						attribut = null;
					else
						attribut = "%" + attribut + "%";
					element.setInActif(rechercheAvanceeDialog.getActif().getValue());
					if( rechercheAvanceeDialog.getTypeprestation().getValue() != null ) {
						element.setIdFamille(rechercheAvanceeDialog.getTypeprestation().getValue().getIdFamille());
					}
					else {
						if( rechercheAvanceeDialog.getSousgroupe().getValue() != null ) {
							element.setIdFamille(rechercheAvanceeDialog.getSousgroupe().getValue().getIdFamille());
						}
						else {
							if( rechercheAvanceeDialog.getGroupe().getValue() != null ) {
								element.setIdFamille(rechercheAvanceeDialog.getGroupe().getValue().getIdFamille());
							}
							else {
								if( rechercheAvanceeDialog.getSousfamille().getValue() != null ) {
									element.setIdFamille(rechercheAvanceeDialog.getSousfamille().getValue().getIdFamille());
								}
								else {
									if( rechercheAvanceeDialog.getFamille().getValue() != null ) {
										element.setIdFamille(rechercheAvanceeDialog.getFamille().getValue().getIdFamille());
									}
								}
							}
						}
					}
				}
				else {
					element.setLLibelleLong("%" + searchString + "%");
					element.setLNomenclatureFournisseur("%" + searchString + "%");
					element.setCElement("%" + searchString + "%");
				}
				ClientElementServiceAsync.Util.getInstance().loadPaging(loadConfig, element, attribut, rechAvancee, callback);
			}
		};
		ElementProperties props = GWT.create(ElementProperties.class);

		elementStore = new ListStore<Element>(new ModelKeyProvider<Element>() {
			@Override
			public String getKey(Element item) {
				return "" + item.getIdElement();
			}
		});
		gridLoader = new PagingLoader<PagingLoadConfig, CustomizePagingLoadResult<Element>>(proxy);
		gridLoader.setRemoteSort(true);
		gridLoader.addLoadHandler(new LoadHandler<PagingLoadConfig, CustomizePagingLoadResult<Element>>() {

			@Override
			public void onLoad(LoadEvent<PagingLoadConfig, CustomizePagingLoadResult<Element>> event) {
				totalRecord.setText("/ " + event.getLoadResult().getfinalTotal());
			}

		});
		codeColumn = new ColumnConfig<Element, String>(props.cElement(), 100, messages.commonElemcompogridCode());
		libelleColumn = new ColumnConfig<Element, String>(props.lLibelleLong(), 100, messages.commonElemcompogridLibelle());
		fournColumn = new ColumnConfig<Element, String>(
				props.lNomenclatureFournisseur(), 100, messages.commonElemcompogridNomenclatureFournisseur());

		codeColumn.setMenuDisabled(true);
		libelleColumn.setMenuDisabled(true);
		fournColumn.setMenuDisabled(true);
		codeColumn.setHideable(false);
		libelleColumn.setHideable(false);
		fournColumn.setHideable(true);
		

	    ValueProvider<Element, String> fake = new ValueProvider<Element, String>(){
			@Override
			public String getValue(Element object) {
				return "";
			}
			@Override
			public void setValue(Element object,
					String value) {				
			}

			@Override
			public String getPath() {	
				return "";
			}	    	
	    };
	    
	    AbstractImagePrototype proto = AbstractImagePrototype.create(Images.RESOURCES.arrow2heads());
	    AbstractImagePrototype proto2 = AbstractImagePrototype.create(Images.RESOURCES.rightArrow());

	    ColumnConfig<Element, String> fakeCol = new ColumnConfig<Element, String>(fake, 30, "");
	    ColumnConfig<Element, String> fakeCol2 = new ColumnConfig<Element, String>(fake, 30, "");
	    
	    fakeCol.setHeader(proto.getSafeHtml());
	    fakeCol.setMenuDisabled(true);
	    fakeCol.setFixed(true);
	    
	    
	    fakeCol.setColumnStyle(SafeStylesUtils
                .fromTrustedString("border-left:none;"));
	    fakeCol.setColumnHeaderClassName("gridImageHeader;");
	    libelleColumn.setColumnStyle(SafeStylesUtils
                .fromTrustedString("border-right:none;"));	    
	    libelleColumn.setColumnHeaderClassName("gridBeforeImageHeader");	    
	    fakeCol2.setHeader(proto2.getSafeHtml());
	    fakeCol2.setMenuDisabled(true);
	    fournColumn.setColumnStyle(SafeStylesUtils
                .fromTrustedString("border-right:none;"));
	    fournColumn.setColumnHeaderClassName("gridBeforeImageHeader");
	    fakeCol2.setFixed(true);
	    fakeCol2.setColumnStyle(SafeStylesUtils
                .fromTrustedString("border-left:none;"));
	    fakeCol2.setColumnHeaderClassName("gridImageHeader;");	  

		l = new ArrayList<ColumnConfig<Element, ?>>();
		l.add(codeColumn);
		l.add(libelleColumn);
		l.add(fakeCol);
		l.add(fournColumn);
		l.add(fakeCol2);

		ColumnModel<Element> cm = new ColumnModel<Element>(l);
		cm.setHidden(3, true);
		cm.setHidden(4, true);

		liveGridView = new LiveGridView<Element>();
		liveGridView.setForceFit(true);

		edcGrid = new Grid<Element>(elementStore, cm) {
			@Override
			protected void onAfterFirstAttach() {
				super.onAfterFirstAttach();
				Scheduler.get().scheduleDeferred(new ScheduledCommand() {
					@Override
					public void execute() {
						gridLoader.load();
					}
				});
			}
		};
		edcGrid.addHeaderClickHandler(new HeaderClickHandler() {

			@Override
			public void onHeaderClick(HeaderClickEvent event) {
				if( event.getColumnIndex() == 2 ) {
					edcGrid.getColumnModel().setColumnWidth(3, 100);
					edcGrid.getColumnModel().setHidden(3, false);
					edcGrid.getColumnModel().setHidden(4, false);
					edcGrid.getColumnModel().setHidden(2, true);
					libelleColumn.setColumnStyle(SafeStylesUtils.fromTrustedString("border-right:normal;"));
				}
				else if( event.getColumnIndex() == 4 ) {
					edcGrid.getColumnModel().setHidden(3, true);
					edcGrid.getColumnModel().setHidden(4, true);
					edcGrid.getColumnModel().setHidden(2, false);
					libelleColumn.setColumnStyle(SafeStylesUtils.fromTrustedString("border-right:none;"));
				}
			}
		});
		GridSelectionModel<Element> elt = new GridSelectionModel<Element>();
		elt.addSelectionHandler(new SelectionHandler<Element>() {

			@Override
			public void onSelection(SelectionEvent<Element> arg0) {
				selectedElementId = arg0.getSelectedItem().getIdElement();
			}
		});
		edcGrid.setSelectionModel(elt);
		//edcGrid.setHeight(300);
		edcGrid.addRowDoubleClickHandler(new RowDoubleClickHandler() {

			@Override
			public void onRowDoubleClick(RowDoubleClickEvent event) {
				bus.fireEvent(new GestionElementCompositionEvent(edcGrid.getStore().get(event.getRowIndex()).getIdElement()));

			}
		});

		edcGrid.setLoadMask(true);
		edcGrid.setLoader(gridLoader);
		edcGrid.setView(liveGridView);
		edcGrid.setBorders(true);
		edcGrid.setAllowTextSelection(false);
		//edcGrid.getView().setAutoFill(true);
		edcGrid.getView().setAutoExpandColumn(libelleColumn);
		//edcGrid.getView().setForceFit(true);
		
		HTML expandButton = new HTML();
		Image expIcon = new Image();
		//expIcon.setResource(images.expand());
		expandButton.setHTML(expIcon+"");
		
		
		edcSearchTextField = new TextField();
		edcSearchTextField.setEmptyText("");
		edcSearchTextField.addKeyDownHandler(new KeyDownHandler() {

			@Override
			public void onKeyDown(KeyDownEvent arg0) {
				if( arg0.getNativeKeyCode() == KeyCodes.KEY_ENTER ) {
					rechercheSimple();
				}
			}
		});
		HBoxLayoutContainer tblSearch = new HBoxLayoutContainer();
		BoxLayoutData flex = new BoxLayoutData(new Margins(0, 5, 0, 0));
		flex.setFlex(1);
		tblSearch.add(edcSearchTextField, flex);
		searchButton = new HTML();
		Image searchIcon = new Image();
		searchIcon.setResource(images.searchIcon());
		searchButton.setHTML(searchIcon+"");
		searchButton.setStyleName("searchButton");
		searchButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				edcSearchTextField.setEmptyText("");
				rechAvancee = false;
				rechercheSimple();
			}
		});
		tblSearch.add(searchButton);
		
		rechercheAvanceeDialog = new RechercheAvanceeDialog(bus, this);
		rechercheAvanceeDialog.setModal(true);
		rechercheAvanceeDialog.setBlinkModal(true);

		advanceSearchLink = new HTML();
		advanceSearchLink.setHTML(messages.modelisateurRechercheAvancee());
		advanceSearchLink.setStyleName("htmlLink");
		advanceSearchLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				rechercheAvanceeDialog.show();
			}
		});

		add(tblSearch, new VerticalLayoutData(1, -1));
		add(advanceSearchLink, new VerticalLayoutData(1, -1));
		add(edcGrid, new VerticalLayoutData(1, .9));

		VBoxLayoutContainer pagingToolbar = new VBoxLayoutContainer();
		final SpinnerField<Integer> pagingNumberSpinner = new SpinnerField<Integer>(new IntegerPropertyEditor());
		pagingNumberSpinner.setIncrement(10);
		pagingNumberSpinner.setMinValue(1);
		pagingNumberSpinner.addSelectionHandler(new SelectionHandler<Integer>() {

			@Override
			public void onSelection(SelectionEvent<Integer> event) {
				recordNumber = event.getSelectedItem().intValue();
				liveGridView.setCacheSize(recordNumber);
				gridLoader.load();
			}
		});
		pagingNumberSpinner.addBlurHandler(new BlurHandler() {

			@Override
			public void onBlur(BlurEvent event) {
				if( pagingNumberSpinner.getValue() == null || pagingNumberSpinner.getValue() < 0 ) {
					pagingNumberSpinner.setValue(10);
				}
				recordNumber = pagingNumberSpinner.getValue();
				liveGridView.setCacheSize(recordNumber);
				gridLoader.load();
			}
		});
		pagingNumberSpinner.setWidth(70);
		pagingNumberSpinner.setValue(recordNumber);
		FieldLabel spinnerField = new FieldLabel(pagingNumberSpinner, messages.commonAffichage());
		spinnerField.setLabelWidth(50);

		pagingToolbar.setVBoxLayoutAlign(VBoxLayoutAlign.RIGHT);
		pagingToolbar.setPadding(new Padding(4, 0, 0, 0));
		pagingToolbar.add(spinnerField);
		//pagingToolbar.setHeight(50);
		totalRecord = new HTML("");
		totalRecord.setWidth("70px");
		pagingToolbar.add(totalRecord);
		add(pagingToolbar, new VerticalLayoutData(1, 45));
		getElement().setPadding(new Padding(15, 0, 15, 0));
	}

	private void rechercheSimple() {

		if( edcSearchTextField.getText().length() == 0 || edcSearchTextField.getText().length() > 2 ) {
			edcSearchTextField.removeToolTip();
			setSearchString(edcSearchTextField.getText());
			getGridLoader().load();
		}
		else {
			ToolTipConfig config = new ToolTipConfig();
			config.setAnchorOffset(10);
			config.setBodyText(messages.gestionelemcompoLeftMoinstroiscaracteres());    
		    config.setMouseOffset(new int[] {0, 0});
		    config.setAnchor(Side.LEFT);
			edcSearchTextField.setToolTipConfig(config);
			edcSearchTextField.getToolTip().show();
		}
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

	public PagingLoader<PagingLoadConfig, CustomizePagingLoadResult<Element>> getGridLoader() {
		return gridLoader;
	}

	public void setGridLoader(PagingLoader<PagingLoadConfig, CustomizePagingLoadResult<Element>> gridLoader) {
		this.gridLoader = gridLoader;
	}

	public LiveGridView<Element> getLiveGridView() {
		return liveGridView;
	}

	public void setLiveGridView(LiveGridView<Element> liveGridView) {
		this.liveGridView = liveGridView;
	}

	public ListStore<Element> getElementStore() {
		return elementStore;
	}

	public void setElementStore(ListStore<Element> elementStore) {
		this.elementStore = elementStore;
	}

	public List<ColumnConfig<Element, ?>> getL() {
		return l;
	}

	public void setL(List<ColumnConfig<Element, ?>> l) {
		this.l = l;
	}

	public void setSelectedElementId(Integer selectedElementId) {
		this.selectedElementId = selectedElementId;
	}

	public Integer getSelectedElementId() {
		return selectedElementId;
	}

	public Grid<Element> getEdcGrid() {
		return edcGrid;
	}

	public void setEdcGrid(Grid<Element> edcGrid) {
		this.edcGrid = edcGrid;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortDir(String sortDir) {
		this.sortDir = sortDir;
	}

	public String getSortDir() {
		return sortDir;
	}

	public Integer getIdMetier() {
		return idMetier;
	}

	public void setIdMetier(Integer idMetier) {
		this.idMetier = idMetier;
	}

	public TextField getEdcSearchTextField() {
		return edcSearchTextField;
	}

	public void setEdcSearchTextField(TextField edcSearchTextField) {
		this.edcSearchTextField = edcSearchTextField;
	}

	public boolean isRechAvancee() {
		return rechAvancee;
	}

	public void setRechAvancee(boolean rechAvancee) {
		this.rechAvancee = rechAvancee;
	}
}
