package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface TargetElementSelectHandler extends EventHandler {
	void onLoad(TargetElementSelectEvent targetElementSelectEvent);
}
