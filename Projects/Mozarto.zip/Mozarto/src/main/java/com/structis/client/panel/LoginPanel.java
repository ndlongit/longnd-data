package com.structis.client.panel;

import com.google.gwt.event.shared.SimpleEventBus;
import com.structis.client.widget.LoginWindow;

public class LoginPanel extends AbstractPanel{
	private LoginWindow loginWindow;
	public LoginPanel(SimpleEventBus bus) {
		super(bus);
	}

	@Override
	public void buildPanel() {
		//loginWindow = new LoginWindow(messages.loginWindowTitle());
		//loginWindow.show();
	}

	@Override
	public void addHandler() {
		
	}

	/*public LoginWindow getLoginWindow() {
		return loginWindow;
	}

	public void setLoginWindow(LoginWindow loginWindow) {
		this.loginWindow = loginWindow;
	}*/
	
	public void showLoginWindow(){
		loginWindow = new LoginWindow(messages.loginWindowTitle());
		loginWindow.show();
	}
}
