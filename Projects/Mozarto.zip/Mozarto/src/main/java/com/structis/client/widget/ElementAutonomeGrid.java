package com.structis.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.sencha.gxt.cell.core.client.form.SpinnerFieldCell;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.SortDir;
import com.sencha.gxt.data.shared.SortInfo;
import com.sencha.gxt.data.shared.Store.StoreSortInfo;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.dnd.core.client.DND.Feedback;
import com.sencha.gxt.dnd.core.client.GridDropTarget;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.HeaderClickEvent;
import com.sencha.gxt.widget.core.client.event.HeaderClickEvent.HeaderClickHandler;
import com.sencha.gxt.widget.core.client.event.RowMouseDownEvent;
import com.sencha.gxt.widget.core.client.event.RowMouseDownEvent.RowMouseDownHandler;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor.IntegerPropertyEditor;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.properties.ElementProperties;
import com.structis.shared.model.Element;

public class ElementAutonomeGrid extends VerticalLayoutContainer {

	@SuppressWarnings("unused")
	protected SimpleEventBus bus;

	protected static final ElementProperties props = GWT.create(ElementProperties.class);

	protected final Messages messages = GWT.create(Messages.class);

	protected Grid<Element> grid;

	private ColumnConfig<Element, Element> selectCol;

	private ColumnConfig<Element, String> codeCol;

	private ColumnConfig<Element, String> libelleCol;

	private ColumnConfig<Element, String> nfournisseurCol;

	private ColumnConfig<Element, Integer> qteCol;
	
	private int currenRow = 0;

	protected  PagingLoader<PagingLoadConfig, PagingLoadResult<Element>> loader;
	
	public ElementAutonomeGrid(SimpleEventBus bus){
		this.bus = bus;
		buildPanel();
		addHandler();
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void buildPanel() {
		
	    codeCol = new ColumnConfig<Element, String>(props.cElement(), 80, messages.compositionRightElementgridCode());
	    libelleCol = new ColumnConfig<Element, String>(props.lLibelleLong(), 200, messages.compositionRightElementgridLibelle());
	    nfournisseurCol = new ColumnConfig<Element, String>(props.lNomenclatureFournisseur(), 200, messages.compositionRightElementgridNomenclaturefournisseur());
	    qteCol = new ColumnConfig<Element, Integer>(props.qte(), 60, messages.compositionRightElementgridQte());
	    SpinnerFieldCell<Integer> qte = new SpinnerFieldCell<Integer>(new IntegerPropertyEditor());
	    qte.addSelectionHandler(new SelectionHandler() {
			@Override
			public void onSelection(SelectionEvent paramSelectionEvent) {
				final int value = (Integer) paramSelectionEvent.getSelectedItem();
				final Element node = grid.getStore().get(currenRow);
				node.setQte(value);
				grid.getStore().update(node);
				grid.getStore().commitChanges();
				updateChangeQuantiteNode(node);
			}			
		});
		qteCol.setCell(qte);
		qte.setMinValue(1);
		qte.setWidth(40);
		qteCol.setSortable(false);
		
	    codeCol.setMenuDisabled(true);
	    libelleCol.setMenuDisabled(true);
	    qteCol.setMenuDisabled(true);
	    List<ColumnConfig<Element, ?>> l = new ArrayList<ColumnConfig<Element, ?>>();

	    CheckBoxCell select = new CheckBoxCell() {
			
			@Override
			public void onUncheck(Element node) {
				node.setAdded(true);
				updateCheck(node);
				//updateNode(node);
			}
			
			@Override
			public void onCheck(Element node) {
				node.setAdded(false);
				updateCheck(node);
			}
		};
	    
		selectCol = new ColumnConfig<Element, Element>(
				new IdentityValueProvider<Element>());
		selectCol.setCell(select);
		selectCol.setHeader(messages.compositionRightElementgridSelect());
		selectCol.setSortable(false);
		selectCol.setMenuDisabled(true);
		selectCol.setWidth(45);
		

	    ValueProvider<Element, String> fake = new ValueProvider<Element, String>(){
			@Override
			public String getValue(Element object) {
				return "";
			}
			@Override
			public void setValue(Element object,
					String value) {				
			}

			@Override
			public String getPath() {	
				return "";
			}	    	
	    };
	    
	    AbstractImagePrototype proto = AbstractImagePrototype.create(Images.RESOURCES.arrow2heads());
	    AbstractImagePrototype proto2 = AbstractImagePrototype.create(Images.RESOURCES.rightArrow());

	    ColumnConfig<Element, String> fakeCol = new ColumnConfig<Element, String>(fake, 30, "");
	    ColumnConfig<Element, String> fakeCol2 = new ColumnConfig<Element, String>(fake, 30, "");
	    
	    fakeCol.setHeader(proto.getSafeHtml());
	    fakeCol.setMenuDisabled(true);
	    fakeCol.setFixed(true);
	    
	    
	    fakeCol.setColumnStyle(SafeStylesUtils
                .fromTrustedString("border-left:none;"));
	    fakeCol.setColumnHeaderClassName("gridImageHeader;");
	    libelleCol.setColumnStyle(SafeStylesUtils
                .fromTrustedString("border-right:none;"));	    
	    libelleCol.setColumnHeaderClassName("gridBeforeImageHeader");	    
	    fakeCol2.setHeader(proto2.getSafeHtml());
	    fakeCol2.setMenuDisabled(true);
	    nfournisseurCol.setColumnStyle(SafeStylesUtils
                .fromTrustedString("border-right:none;"));
	    nfournisseurCol.setColumnHeaderClassName("gridBeforeImageHeader");
	    fakeCol2.setFixed(true);
	    fakeCol2.setColumnStyle(SafeStylesUtils
                .fromTrustedString("border-left:none;"));
	    fakeCol2.setColumnHeaderClassName("gridImageHeader;");	  
	    
	    l.add(selectCol); 
	    l.add(codeCol); 
	    l.add(libelleCol); 
	    l.add(fakeCol);	    	   
	    l.add(nfournisseurCol); 
	    l.add(fakeCol2); 
	    l.add(qteCol); 

	    ColumnModel<Element> cm = new ColumnModel<Element>(l);

	    cm.setHidden(4, true);
	    cm.setHidden(5, true);
	    
	    
	    grid = createGrid(cm);
	    
	    selectCol.setHeader(messages.compositionRightElementgridSelect());
	    selectCol.setMenuDisabled(true);
	    nfournisseurCol.setMenuDisabled(true);
	    grid.getView().setAutoExpandColumn(libelleCol);
//	    grid.setBorders(false);
	    grid.getView().setStripeRows(true);
	    grid.getView().setColumnLines(true);
	    grid.getView().setForceFit(true);
//	    grid.setHeight("auto");
//	    grid.setWidth("auto");
	   
//	    setAdjustForScroll(true);
	    GridDropTarget<Element> target = new GridDropTarget<Element>(grid){

	    };
	    target.setFeedback(Feedback.INSERT);
	    

		grid.addHeaderClickHandler(new HeaderClickHandler() {

			@Override
			public void onHeaderClick(HeaderClickEvent event) {
				if( event.getColumnIndex() == 3 ) {
					grid.getColumnModel().setColumnWidth(4, 200);
					grid.getColumnModel().setHidden(4, false);
					grid.getColumnModel().setHidden(5, false);
					grid.getColumnModel().setHidden(3, true);
					libelleCol.setColumnStyle(SafeStylesUtils.fromTrustedString("border-right:normal;"));
				}
				else if( event.getColumnIndex() == 5 ) {
					grid.getColumnModel().setHidden(4, true);
					grid.getColumnModel().setHidden(5, true);
					grid.getColumnModel().setHidden(3, false);
					libelleCol.setColumnStyle(SafeStylesUtils.fromTrustedString("border-right:none;"));
				}

			}
		});
		grid.addRowMouseDownHandler(new RowMouseDownHandler() {
			
			@Override
			public void onRowMouseDown(RowMouseDownEvent event) {
				currenRow = event.getRowIndex();
			}
		});
		addGrid();
	}
	
	protected Grid<Element> createGrid(ColumnModel<Element> cm ) {
		final ListStore<Element> store = new ListStore<Element>(props.idElement());
	    store.addSortInfo(new StoreSortInfo<Element>(props.lLibelleLong(), SortDir.ASC));
		return new Grid<Element>(store, cm);
	}
	
	protected void updateCheck(Element node){
		grid.getStore().update(node);
	}
	
	protected void updateChangeQuantiteNode(Element node){
		
	}

	protected void addGrid(){
		 add(grid, new VerticalLayoutData(1, 1));
	}
	
	private void addHandler() {
		addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent arg0) {
				grid.setHeight("auto");
				grid.setWidth("auto");
			}
		});
	}

	public Grid<Element> getGrid() {
		return grid;
	}

	public void setGrid(Grid<Element> grid) {
		this.grid = grid;
	}

	public ColumnConfig<Element, Element> getSelectCol() {
		return selectCol;
	}

	public void setSelectCol(ColumnConfig<Element, Element> selectCol) {
		this.selectCol = selectCol;
	}
	
	public Element searchElementById(Integer idElement){
		for (Element elt : grid.getStore().getAll()){
			if (elt.getIdElement().equals(idElement))
				return elt;
		}
		return null;
	}
	
	public void setSortInfo (SortInfo sortInfo){
		ValueProvider<Element, String> column = props.lLibelleLong();
		SortDir dir = sortInfo.getSortDir();
		if (sortInfo.getSortField().equals("qte")){
			grid.getStore().getSortInfo().clear();
			grid.getStore().addSortInfo(new StoreSortInfo<Element>(props.qte(), dir));
		}
		else {
			if (sortInfo.getSortField().equals("cElement")){
				column = props.cElement();
			}
			else if (sortInfo.getSortField().equals("lNomenclatureFournisseur")){
				column = props.lNomenclatureFournisseur();
			}
			grid.getStore().getSortInfo().clear();
			grid.getStore().addSortInfo(new StoreSortInfo<Element>(column, dir));
		}
	}
	
	public List<Element> getSelectedItems(){
		List<Element> itemsSelectd = new ArrayList<Element>();
		if(grid.getStore().getAll() != null && grid.getStore().getAll().size() > 0){
			for(Element element:grid.getStore().getAll()){
				itemsSelectd.add(element);
			}
		}
		return itemsSelectd;
	}

	public PagingLoader<PagingLoadConfig, PagingLoadResult<Element>> getLoader() {
		return loader;
	}

	public void setLoader(PagingLoader<PagingLoadConfig, PagingLoadResult<Element>> loader) {
		this.loader = loader;
	}
}
