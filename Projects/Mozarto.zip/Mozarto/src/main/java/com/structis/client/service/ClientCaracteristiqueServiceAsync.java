package com.structis.client.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.reference.CarateristiqueFormModel;
import com.structis.shared.model.reference.TreeNodeModel;

public interface ClientCaracteristiqueServiceAsync {
	public static class Util {

		private static ClientCaracteristiqueServiceAsync instance = GWT.create(ClientCaracteristiqueService.class);

		public static ClientCaracteristiqueServiceAsync getInstance() {
			return instance;
		}

	}

	void findById(Integer idCaracteristique, AsyncCallback<MdlCaracteristique> callback);

	void findByIdModele(Integer idModele, AsyncCallback<MdlCaracteristique> callback);

	void updateCaracteristique(MdlCaracteristique record, Integer metierId, AsyncCallback<Void> callback);

	void insert(MdlCaracteristique record, Integer metierId, Integer utilisatuerId, AsyncCallback<Integer> callback);

	void findCarateristiqueFormReferenceById(Integer idCaracteristique, AsyncCallback<CarateristiqueFormModel> callback);

	void remove(MdlCaracteristique record, AsyncCallback<Void> callback);

	void insertOrUpdate(Integer utilisatuerId, Integer metierId, MdlCaracteristique record, AsyncCallback<Integer> callback);

	void loadChildrenPaging(Integer idModeleVersion, Integer idCaracteristique, PagingLoadConfig loadConfig,
			AsyncCallback<PagingLoadResult<TreeNodeModel>> callback);
	

}
