package com.structis.client.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.ModeleModel;

public interface ClientAccueilModelisateurServiceAsync {
	public static class Util {

		private static ClientAccueilModelisateurServiceAsync instance = GWT
				.create(ClientAccueilModelisateurService.class);
	
		public static ClientAccueilModelisateurServiceAsync getInstance() {
			return instance;
		}
		
	}

	void getModele(Integer idModele, Integer idMetier, PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<ModeleModel>> callback);
	
	void updateByIdModele(Integer idModele, boolean actif, AsyncCallback<Integer> callback);
	
	void getMetier(Integer idMetier, AsyncCallback<Metier> callback);
}
