package com.structis.client.panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;

public abstract class AbstractPanel extends VerticalLayoutContainer{
	protected SimpleEventBus bus;

	protected final Messages messages = GWT.create(Messages.class);

	protected final Images images = GWT.create(Images.class);
	
	public AbstractPanel(SimpleEventBus bus){
		this.bus = bus;
		buildPanel();
		addHandler();
	}
	
	public abstract void buildPanel();

	public abstract void addHandler();

}
