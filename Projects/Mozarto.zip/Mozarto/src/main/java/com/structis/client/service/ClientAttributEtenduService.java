package com.structis.client.service;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.structis.shared.model.AttributEtendu;

/**
 * 
 * @author ngoc.ho
 *
 */
@RemoteServiceRelativePath("springGwtServices/clientAttributEtenduService")
public interface ClientAttributEtenduService extends RemoteService {
	
	/**
	 * 
	 * @return the list of all AttributEtendu
	 */
	public List<AttributEtendu> findAll ();
	
	/**
	 * 
	 * @return the list of all AttributEtendu
	 */
	public List<List<AttributEtendu>> findAllAttributEtendu (Integer idMetier);
	
	public Integer insertAndUpdate(List<AttributEtendu>attributEtendus, Integer idMetier);
	
	public Integer delete(AttributEtendu attributEtendu);

}
