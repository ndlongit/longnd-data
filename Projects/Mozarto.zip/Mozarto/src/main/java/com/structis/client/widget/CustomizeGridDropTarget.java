package com.structis.client.widget;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.TreeStore;
import com.sencha.gxt.dnd.core.client.DndDragMoveEvent;
import com.sencha.gxt.dnd.core.client.DndDropEvent;
import com.sencha.gxt.dnd.core.client.GridDropTarget;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.service.ClientReferenceServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.reference.TreeNodeModel;

public class CustomizeGridDropTarget<M> extends GridDropTarget<M> {

	protected final Messages messages = GWT.create(Messages.class);

	protected SimpleEventBus bus;

	private ListStore<MdlCarateristiqueReference> gridStore;
	private Integer referenceId;
	private String referenceName;

	
	@SuppressWarnings("unchecked")
	public CustomizeGridDropTarget(Grid<M> grid, SimpleEventBus bus, Integer referenceId) {
		super(grid);
		gridStore = (ListStore<MdlCarateristiqueReference>)grid.getStore();
		this.bus = bus;
		this.referenceId = referenceId;
	}
	

	@SuppressWarnings("unchecked")
	  @Override
	  protected void onDragDrop(DndDropEvent e) {
		@SuppressWarnings("rawtypes")
		List models = (List) e.getData();
		TreeStore.TreeNode<TreeNodeModel> tm = (TreeStore.TreeNode<TreeNodeModel>)models.get(0);
		final TreeNodeModel tnm = tm.getData();
		
		final MdlCarateristiqueReference cr =  gridStore.get(grid.getStore().size() - 1);
		cr.setStatus(ImagesCell.CARACTERISTIC_SELECTED);
		cr.setIdCaracteristique(tnm.getId());
		cr.setCaracteristiqueLibelle(tnm.getLibelle());
		if (referenceId != null) {
		ClientReferenceServiceAsync.Util.getInstance().checkSatisfyRule( tnm,
				referenceId, new AsyncCallbackWithErrorResolution<Boolean>() {
					@Override
					public void onSuccess(Boolean result) {									
						if (result) {
							gridStore.update(cr);
						} else {
							AppUtil.showMessageBox(messages.modelisateurReferenceViolateRules(referenceName, tnm.getLibelle()));
						}
					}					
				});
		} else {
			gridStore.update(cr);
		}
	  }
	
	@SuppressWarnings("unchecked")
	@Override
	  protected void showFeedback(DndDragMoveEvent event) {
		if (event.getData() instanceof List) {
			 @SuppressWarnings("rawtypes")
			List models = (List) event.getData();
			 if (models == null || models.size() <= 0) {
					event.getStatusProxy().setStatus(false);
			 } else {
				 TreeStore.TreeNode<TreeNodeModel> tm = (TreeStore.TreeNode<TreeNodeModel>)models.get(0);
				 TreeNodeModel tnm = tm.getData();
					if (tnm.getModelType() != ModelNodeType.CARACTERISTIQUE) {
						event.getStatusProxy().setStatus(false);
						return;
					}  else if (isCaracteristiqueExistInGrid(tnm.getId())){
						event.getStatusProxy().setStatus(false);
						return;
					}
			 }
		}		
		super.showFeedback(event);						
	  }


	private boolean isCaracteristiqueExistInGrid(Integer id) {
		for (MdlCarateristiqueReference cr: gridStore.getAll()) {
			if (id != null && cr.getIdCaracteristique() != null  && id.intValue() == cr.getIdCaracteristique().intValue()) {
				return true;
			}
		}
		return false;
	}


	public String getReferenceName() {
		return referenceName;
	}


	public void setReferenceName(String referenceName) {
		this.referenceName = referenceName;
	}
	
	
}
