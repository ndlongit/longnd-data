package com.structis.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.MetierMzPzModel;

public interface MetierMzPzProperties extends PropertyAccess<MetierMzPzModel> {
	@Path("idMetier")
	ModelKeyProvider<MetierMzPzModel> idMetier();

	@Path("lLibelle")
	LabelProvider<MetierMzPzModel> nameLabel();

	ValueProvider<MetierMzPzModel, String> lLibelle();

	ValueProvider<MetierMzPzModel, Boolean> inActif();
}
