package com.structis.server.service.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlMessageMapper;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.MdlMessage;
import com.structis.shared.model.reference.TreeNodeModel;

@Service
public class MessageServiceImpl implements MessageService{
	
	@Autowired
	MdlMessageMapper mdlMessageMapper;

	@Autowired
	CaracteristiqueService caracteristiqueService;

	@Autowired
	ReferenceService referenceService;

	@Autowired
	LiencaracteristiqueService liencaracteristiqueService;

	@Autowired
	LienReferenceService lienReferenceService;

	@Autowired
	LienElementService lienElementService;

	@Autowired
	LienCommunService lienCommunService;
	
	@Autowired
	ModeleService modeleService;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<MdlMessage> findMessageByLienCommun(Integer idModeleVersion, List<Integer> idLienCommunList) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommunList", idLienCommunList);
		return mdlMessageMapper.findByLienCommun(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteMessageByidLienCommuns(Integer idModeleVersion,List<Integer> idLienCommuns) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("list", idLienCommuns);
		mdlMessageMapper.deleteByIdLienCommuns(mapParameter);
	}

	@Override
	public void insert(MdlMessage message) {
		mdlMessageMapper.insert(message);
	}

	@Override
	public MdlMessage findById(Integer idMessage) {
		return mdlMessageMapper.findById(idMessage);
	}

	@Override
	public void update(MdlMessage message) {
		mdlMessageMapper.update(message);
	}

	@Override
	public void delete(Integer idUser, TreeNodeModel sourceNode, int idMessage) {
		MdlMessage message = mdlMessageMapper.findById(idMessage);
		List<MdlMessage> messageAnnulerChildrenList = new ArrayList<MdlMessage>();
		List<Integer> idLienCommunChildrens = findLienCommunsHierarchyDown(sourceNode,sourceNode.getIdModeleVersion());
		if(idLienCommunChildrens != null && idLienCommunChildrens.size() > 0)
			messageAnnulerChildrenList = findAnnulerMessageByLienCommun(sourceNode.getIdModeleVersion(),idLienCommunChildrens);
		List<Integer> idMessageToDeletes = new ArrayList<Integer>();
		if(messageAnnulerChildrenList.size() > 0){
			for(MdlMessage amessage:messageAnnulerChildrenList){
				if(amessage.getIdModeleVersion().intValue() == message.getIdModeleVersion()
						&& amessage.getCTypeLien().equals(message.getCTypeLien())
						&& (amessage.getNPriorite() + message.getNPriorite()) == 0
						&& amessage.getLLibelleLong().equals(message.getLLibelleLong()) ) {
					idMessageToDeletes.add(amessage.getIdMessage());
				}
			}
		}
		//delete list annuler of regle
		idMessageToDeletes.add(idMessage);
		deleteList(sourceNode.getIdModeleVersion(),idMessageToDeletes);
		modeleService.updateModifiedBy(idUser, sourceNode.getIdModeleVersion());
	}

	public List<Integer> findLienCommunsHierarchyDown(TreeNodeModel sourceNode, int idModeleVersion) {
		List<Integer> idLienCommunList = new ArrayList<Integer>();
		if( sourceNode.getModelType() == ModelNodeType.CARACTERISTIQUE ) {
			//get all carateristque children 
			List<Integer> idCarateristiqueChildrens = caracteristiqueService.findIdChidrensHierarchy(sourceNode.getId());
			
			if(idCarateristiqueChildrens.size()>0){
				
				// get all reference liencommun
				List<Integer> idLienCoummunReferences = lienReferenceService.findIdCommunsByCarateristique(idModeleVersion,idCarateristiqueChildrens);
				if( idLienCoummunReferences.size() > 0 ) {
					idLienCommunList.addAll(idLienCoummunReferences);
				}
				idCarateristiqueChildrens.remove(sourceNode.getId());
				// get all caracteristique liencommun
				if(idCarateristiqueChildrens.size()>0){
					List<Integer> idLienCommunCaracteristiqueList = liencaracteristiqueService.findLienCaracteristiqueIdsByCaracteristiqueList(
							idModeleVersion, idCarateristiqueChildrens);
					if( idLienCommunCaracteristiqueList != null && idLienCommunCaracteristiqueList.size() > 0 ) {
						idLienCommunList.addAll(idLienCommunCaracteristiqueList);
					}
				}
			}
		}
		return idLienCommunList;
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<MdlMessage> findAnnulerMessageByLienCommun(Integer idModeleVersion, List<Integer> idLienCommunList) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommunList", idLienCommunList);
		mapParameter.put("annuler", "annuler");
		return mdlMessageMapper.findByLienCommun(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteList(int idModeleVersion, List<Integer> idMessage) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("list", idMessage);
		mdlMessageMapper.deleteByListId(mapParameter);
	}

	@Override
	public void cancelInheritage(Integer idUser, TreeNodeModel sourceNode, int idMessage) {
		MdlMessage message = mdlMessageMapper.findById(idMessage);
		int idSourceLienCommun = lienCommunService.getIdLienCommmun(sourceNode.getIdModeleVersion(), sourceNode.getId(), sourceNode.getModelType().getLabel(), true);
		MdlMessage messageUnlink =  new MdlMessage();
		messageUnlink.setIdModeleVersion(sourceNode.getIdModeleVersion());
		messageUnlink.setIdSourceLienCommun(idSourceLienCommun);
		messageUnlink.setCTypeLien(message.getCTypeLien());
		messageUnlink.setLLibelleLong(message.getLLibelleLong());
		messageUnlink.setNPriorite((short) ((-1) * message.getNPriorite()));
		mdlMessageMapper.insert(messageUnlink);
		modeleService.updateModifiedBy(idUser, sourceNode.getIdModeleVersion());
	}

	@Override
	public List<MdlMessage> findMessageExludeAnnulerByLienCommun(Integer idModeleVersion, List<Integer> idLienCommunList) {
		List<MdlMessage> messageListResult = new ArrayList<MdlMessage>();
		List<MdlMessage> messageList = findMessageByLienCommun(idModeleVersion, idLienCommunList);
		List<MdlMessage> annulerMessageList = findAnnulerMessageByLienCommun(idModeleVersion, idLienCommunList);
		if(annulerMessageList != null && annulerMessageList.size() >0){
			for(MdlMessage message:messageList){
				boolean canceled = false;
				for(MdlMessage amessages:annulerMessageList){
					
					if(amessages.getIdModeleVersion().intValue() == message.getIdModeleVersion()
							&& amessages.getCTypeLien().equals(message.getCTypeLien())
							&& (amessages.getNPriorite() + message.getNPriorite()) == 0
							&& amessages.getLLibelleLong().equals(message.getLLibelleLong())){
						canceled = true;
					}
					
				}
				if(!canceled){
					messageListResult.add(message);
				}
			}
			return messageListResult;
		}
		return messageList;
	}
}
