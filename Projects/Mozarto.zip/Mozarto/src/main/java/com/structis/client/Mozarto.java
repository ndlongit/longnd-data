package com.structis.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.Window.ClosingEvent;
import com.google.gwt.user.client.Window.ClosingHandler;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.ModifyEvent;
import com.structis.client.event.ModifyHandler;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.Action;
import com.structis.client.navigation.ActionHelper;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.service.ClientAuthenticationServiceAsync;
import com.structis.shared.config.ApplicationContext;
import com.structis.shared.model.Metier;
import com.structis.shared.model.Utilisateur;
import com.structis.shared.security.Role;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Mozarto implements EntryPoint {
	private NavigationService navigation = NavigationFactory.getNavigation();
	
	@SuppressWarnings("unused")
	private Images images = GWT.create(Images.class);
	
	private Messages messages = GWT.create(Messages.class);
	
	
	
	public void onModuleLoad() {
		Window.addWindowClosingHandler(new ClosingHandler() {
			@Override
			public void onWindowClosing(ClosingEvent event) {
				if(navigation.getContext().getIsChanged() > 0){
					event.setMessage(messages.commonConfigmDisconnection());
				}
			}
		});
		navigation.getBus().addHandler(ModifyEvent.getType(),new ModifyHandler() {
			@Override
			public void onLoad(ModifyEvent modifyingEvent) {
				if(modifyingEvent.isFinished()){
					if(navigation.getContext().getIsChanged() > 0){
						navigation.getContext().setIsChanged(navigation.getContext().getIsChanged() - 1);
					}
				}else{
					navigation.getContext().setIsChanged(navigation.getContext().getIsChanged() + 1);
				}
			}
		});
		final Map<String, String> params = new HashMap<String, String>();
		String token = History.getToken();
		String action = "";
		if (token.contains("&")){
			String paramsString = token.substring(token.indexOf("&"));
			action = token.substring(0,token.indexOf("&"));
			for (String string : paramsString.split("&")) {
				String[] text = string.split("=");
				if (text.length == 2){
					params.put(text[0], text[1]);
				}
			}
		}else{
			action = token;
		}
		
		if( !"".equals(action) ){
			params.put(ConstantClient.Parameters.ACTION,action);
		}
		
		//for testing
		//initFortest(params);
		//navigation.goToEcran(Action.ACTION_ACCEUIL,new NavigationEvent(params, false));
		
		checkLogin(params);
	}

	private void checkLogin(final Map<String, String> params){
		ClientAuthenticationServiceAsync.Util.getInstance().getCurrentLogin(new AsyncCallbackWithErrorResolution<ApplicationContext>() {
			@Override
			public void onSuccess(ApplicationContext result) {
				if(result != null){
					navigation.setApplicationContext(result);
					navigation.goToEcran(Action.ACTION_ACCEUIL,new NavigationEvent(params, false));
				}else{
					navigation.goToEcran(Action.ACTION_LOGIN);
				}
			}
		});
	}
	/**
	 * Action pendant le changement de historique
	 */
	public void onValueChange(ValueChangeEvent<String> event) {
		String rawEvent = event.getValue();
		String realEvent = rawEvent;
		Map<String, String> params = new HashMap<String, String>();
		if (realEvent.contains("&")) {
			realEvent = rawEvent.substring(0, rawEvent.indexOf("&"));
			String paramsString = rawEvent.substring(rawEvent.indexOf("&"));
			for (String string : paramsString.split("&")) {
				String[] text = string.split("=", 2);
				if (text.length == 2) {
					params.put(text[0], text[1]);
				}
			}
		}

		Action dest = ActionHelper.getActionFromLabel(realEvent);

		if (null == dest) {
			navigation.goToEcran(Action.ACTION_MODELISATEUR);
		} else {
			if (navigation.getActionActuelle() != dest) {
				navigation.goToEcran(dest, new NavigationEvent(params));
			} else if (!params.isEmpty()) {
				navigation.goToEcran(dest, new NavigationEvent(params, false));
			}
		}
	}

	private void initFortest(Map<String, String> params) {
		//for testing
		Metier metier = new Metier();
		if( params.get(ConstantClient.Parameters.METIER) != null ) {
			metier.setIdMetier(Integer.valueOf(params.get(ConstantClient.Parameters.METIER)));
		}
		else {
			params.put(ConstantClient.Parameters.METIER, "1");
			metier.setIdMetier(1);
		}
		navigation.getContext().setMetier(metier);
		Utilisateur user = new Utilisateur();
		if( params.get(ConstantClient.Parameters.UTILISATEUR) != null ) {
			user.setIdUtilisateur(Integer.valueOf(params.get(ConstantClient.Parameters.UTILISATEUR)));
		}
		else {
			params.put(ConstantClient.Parameters.UTILISATEUR, "1");
			user.setIdUtilisateur(1);
			
		}
		user.setLNom("Truchot");
		user.setLPrenom("Julien");
		navigation.getContext().setUtilisateur(user);
		List<Role> roles = new ArrayList<Role>();
		roles.add(Role.ANONYMOUS);
		roles.add(Role.ADMINISTRATEURMETIER);
		navigation.getContext().setRoles(roles);
		
	}
}
