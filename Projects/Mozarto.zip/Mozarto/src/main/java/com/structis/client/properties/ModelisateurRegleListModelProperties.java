package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;

public interface ModelisateurRegleListModelProperties extends PropertyAccess<ModelisateurRegleMessageListModel> {
	ValueProvider<ModelisateurRegleMessageListModel, String> cibleLibelle();

	ValueProvider<ModelisateurRegleMessageListModel, Integer> relation();

	ValueProvider<ModelisateurRegleMessageListModel, Integer> quantite();
}
