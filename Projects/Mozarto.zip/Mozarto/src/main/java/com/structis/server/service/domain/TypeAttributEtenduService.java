package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.TypeAttributEtendu;

/**
 * 
 * @author vu.dang
 *
 */

public interface TypeAttributEtenduService {
	public TypeAttributEtendu findById(String id);
		
	public Integer insert(TypeAttributEtendu record);
	
	public Integer update(TypeAttributEtendu record);
		
	public Integer delete(TypeAttributEtendu record);
	
	public Integer deleteById(String id);
	public List<TypeAttributEtendu> findAll();
}
