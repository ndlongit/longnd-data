package com.structis.client.panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.XTemplates;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.container.AbstractHtmlLayoutContainer.HtmlData;
import com.sencha.gxt.widget.core.client.container.HtmlLayoutContainer;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.navigation.Action;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.service.ClientAuthenticationServiceAsync;
import com.structis.client.util.AppUtil;

public class HeaderPanel extends ContentPanel {
	private final Messages messages = GWT.create(Messages.class);
	private Boolean isLoginPageHeader = false;
	private NavigationService navigation = NavigationFactory.getNavigation();
	private HTML currentLanguage;
	private HorizontalPanel menu1;
	public interface HtmlLayoutContainerTemplate extends XTemplates {
		@XTemplate("<div style=\"background-color: #f0f6fe; width: 100%; height: 66px;\">" +
					"<div style=\"float: left; vertical-align: text-bottom; padding-top: 2px;\">" +
					"<a href=\"mozarto.html\" onclick=\"blur()\""+
					"style=\"text-decoration: none;\"><img src=\"./images/mozarto_bandeau_gauche.png\" /></a></div>"+
					"<div style=\"float: right;\"><img src=\"./images/logo.gif\" /></div>" +
					" <div style=\"float: right;padding-right:2px;\" ><div style=\"float: right;padding-right:2px;\" class=\"menuClass1\"  >" +
					"</div><div style=\"float: right;padding-right:2px;padding-top:16px;clear:both;\" class=\"menuClass2\" ></div></div></div>" )
		SafeHtml getTemplate();
	}
	public HeaderPanel(boolean isLoginPage){
		isLoginPageHeader = isLoginPage;
	}
	@Override
	protected void onAfterFirstAttach() {
		setHeaderVisible(false);
		setHeight(66);
		setBodyBorder(false);
		setBorders(false);
		HtmlLayoutContainerTemplate templates = GWT.create(HtmlLayoutContainerTemplate.class);
	    HtmlLayoutContainer container = new HtmlLayoutContainer(templates.getTemplate());
	    HTML contactMenuLink = createHTMLLink(messages.commonContact());
	    HTML aideMenuLink = createHTMLLink(messages.commonAide());
	    final HTML language1MenuLink = createHTMLLink(messages.commonEnglish());
	    final HTML language2MenuLink = createHTMLLink(messages.commonDeutsch());
	    final HTML language3MenuLink = createHTMLLink(messages.commonFrancais());
	    currentLanguage = language3MenuLink;
	    menu1 = new HorizontalPanel();
	    menu1.add(contactMenuLink);
	    menu1.add(new Label(" | "));
	    menu1.add(aideMenuLink);
	    menu1.add(new Label(" | "));
	    menu1.add(language1MenuLink);
	    menu1.add(new Label(" | "));
	    menu1.add(language2MenuLink);
	    //menuContainer.setVBoxLayoutAlign(VBoxLayoutAlign.RIGHT);
	    container.add(menu1, new HtmlData(".menuClass1"));
	    HorizontalPanel menu2 = new HorizontalPanel();
	    HTML selectMetierMenuLink = createHTMLLink(messages.commonselectmetier());
	    HTML disconnectMenuLink = createHTMLLink(messages.commonDisconnection());
	    Label userNameLabel = new Label(); 
	    menu2.add(userNameLabel);
	    menu2.add(selectMetierMenuLink);
	    menu2.add(disconnectMenuLink);
	    container.add(menu2, new HtmlData(".menuClass2"));
	    setWidget(container);
	    if(isLoginPageHeader){
	    	menu2.getElement().getStyle().setProperty("visibility", "hidden");
	    }else{
	    	userNameLabel.setText(navigation.getContext().getUtilisateur().getLNom()+" "+navigation.getContext().getUtilisateur().getLPrenom());
	    }
	    disconnectMenuLink.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if(navigation.getContext().getIsChanged() > 0){
					final ConfirmMessageBox box1 = new ConfirmMessageBox(messages.commonConfirmChange(), messages.commonConfigmDisconnection());
					box1.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
					box1.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
					box1.addHideHandler(new HideHandler() {
						
						@Override
						public void onHide(HideEvent event) {
							if(box1.getHideButton().equals(box1.getButtonById(PredefinedButton.YES.name()))){
								showConfirmDisconnect();
							}
						}
					});
					box1.show();
				}
				else {
					showConfirmDisconnect();
				}
			}

			protected void showConfirmDisconnect() {
				final ConfirmMessageBox box = new ConfirmMessageBox(messages.commonConfirmChange(), messages.commonConfirmChangeMetier());
				box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
				box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
				box.addHideHandler(new HideHandler() {
					
					@Override
					public void onHide(HideEvent event) {
						if(box.getHideButton().equals(box.getButtonById(PredefinedButton.YES.name()))){
							logOut();
						}
					}
				});
				box.show();
			}
		});
	    selectMetierMenuLink.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if(navigation.getContext().getIsChanged() > 0){
					final ConfirmMessageBox box1 = new ConfirmMessageBox(messages.commonConfirmChange(), messages.commonConfigmDisconnection());
					box1.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
					box1.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
					box1.addHideHandler(new HideHandler() {
						
						@Override
						public void onHide(HideEvent event) {
							if(box1.getHideButton().equals(box1.getButtonById(PredefinedButton.YES.name()))){
								showConfirmChange();
							}
						}
					});
					box1.show();
				}
				else {
					showConfirmChange();
				}
			}

			protected void showConfirmChange() {
				final ConfirmMessageBox box = new ConfirmMessageBox(messages.commonConfirmChange(), messages.commonConfirmChangeMetier());
				box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
				box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
				box.addHideHandler(new HideHandler() {
					
					@Override
					public void onHide(HideEvent event) {
						if(box.getHideButton().equals(box.getButtonById(PredefinedButton.YES.name()))){
							navigation.goToEcran(Action.ACTION_LOGIN);
						}
					}
				});
				box.show();
			}
		});
	    contactMenuLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				Window.Location.assign("mailto:suong.nguyen@vsl.com?subject=Mozarto issues");
			}
		});
	    aideMenuLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				Window.Location.assign("http://google.fr");
			}
		});
	    language1MenuLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				changeLanguage(language1MenuLink);
			}
		});
	    language2MenuLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				changeLanguage(language2MenuLink);
			}
		});
	    language3MenuLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				changeLanguage(language3MenuLink);
			}
		});
	}
	private void logOut(){
		ClientAuthenticationServiceAsync.Util.getInstance().logout(new AsyncCallbackWithErrorResolution<Void>() {

			@Override
			public void onSuccess(Void result) {
				AppUtil.goToLoginPage();
			}
		});
	}
	
	private HTML createHTMLLink(String text){
		HTML link = new HTML();
		link.setHTML(text);
		link.getElement().getStyle().setProperty("paddingLeft","4px");
		link.addStyleName("htmlLink");
		return link;
	}
	
	private void changeLanguage(HTML newLanguage){
		int index = menu1.getWidgetIndex(newLanguage);
		menu1.remove(index);
		menu1.insert(currentLanguage, index);
		currentLanguage = newLanguage;
	}
}
