package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer.HBoxLayoutAlign;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.structis.client.message.Messages;

public class CustomizeConfirmBox  extends Dialog {
	private TextButton yesButton;
	private TextButton noButton;
	private final Messages messages = GWT.create(Messages.class);
	public CustomizeConfirmBox(String header,String message){
		setWidth(500);
		setHeight(150);
		setResizable(false);
		setModal(true);
		
		setPredefinedButtons(PredefinedButton.YES, PredefinedButton.NO);
		
		this.setHeadingHtml(header);
		HTML html = new HTML(message);
		//html.getElement().getStyle().setProperty("paddingBottom", "10px");
		HBoxLayoutContainer hPanel = new HBoxLayoutContainer();
		hPanel.setHBoxLayoutAlign(HBoxLayoutAlign.MIDDLE);
		hPanel.setPack(BoxLayoutPack.CENTER);
		hPanel.setPadding(new Padding(10, 0, 10, 0));
		final CheckBox checkBox = new CheckBox();
		checkBox.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
				if(checkBox.getValue())
					yesButton.setEnabled(true);
				else
					yesButton.setEnabled(false);
			}
		});
		checkBox.setBoxLabel(messages.metiersFormLumessage());
		hPanel.add(checkBox);
		add(hPanel);
		
		VerticalLayoutContainer container = new VerticalLayoutContainer();
		container.add(html);
		container.add(hPanel);
		
		add(container);
		
		setButtonAlign(BoxLayoutPack.CENTER);
		yesButton = getButtonById(PredefinedButton.YES.name());
		yesButton.setText(messages.commonValiderButton());
		yesButton.disable();
		yesButton.setEnabled(false);
		yesButton.addSelectHandler(new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				hide();
			}
		});
		noButton = getButtonById(PredefinedButton.NO.name());
		noButton.setText(messages.commonAnnulerButton());
		noButton.addSelectHandler(new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				hide();
			}
		});
	}
	public TextButton getButton(){
		return yesButton;
	}
	
}
