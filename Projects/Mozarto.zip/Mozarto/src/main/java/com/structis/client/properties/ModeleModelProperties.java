
package com.structis.client.properties;

import java.util.Date;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.ModeleModel;
/**
 * 
 * @author vinh.tong
 *
 */
public interface ModeleModelProperties extends PropertyAccess<ModeleModel> {
  ModelKeyProvider<ModeleModel> idModele();
	
  @Path("lLibelle")
  LabelProvider<ModeleModel> getLLibelle();

  ValueProvider<ModeleModel, Date> dDateheureCrea();

  ValueProvider<ModeleModel, String> lLibelle();

  ValueProvider<ModeleModel, String> cUtilisateur();

  ValueProvider<ModeleModel, Integer> pubVersion();
}
