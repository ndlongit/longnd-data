package com.structis.client.panel;


import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.CenterLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.structis.client.event.ModifyEvent;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.widget.HtmlButton;
import com.structis.shared.model.reference.TreeNodeModel;

public abstract class AbstractFieldsetEditForm extends FieldSet{
	protected SimpleEventBus bus;

	protected final Messages messages = GWT.create(Messages.class);

	//protected HorizontalPanel navigationPanel;

	protected boolean changed = false;

	protected HtmlButton annulerButton;

	protected TextButton validerButton;
	
//	protected TextButton detailButton;
//	
//	protected TextButton regleButton;
	
	protected boolean isInDetail = true;
	
	VerticalLayoutContainer detailContainer;
	
	private NavigationService navigation = NavigationFactory.getNavigation();
	
	public AbstractFieldsetEditForm(SimpleEventBus bus) {
		this.bus = bus;
		addStyleName("containerPadding");
		annulerButton = new HtmlButton(messages.commonAnnulerButton());
		annulerButton.setWidth(50);
		annulerButton.getElement().setPadding(new Padding(12, 0, 0, 0));
		validerButton = new TextButton(messages.commonValiderButton());
		validerButton.setEnabled(false);
		annulerButton.setEnable(false);
		CenterLayoutContainer buttonContainer = new CenterLayoutContainer();
		HorizontalPanel hpanel = new HorizontalPanel();
		hpanel.add(annulerButton);
		hpanel.add(validerButton);
		hpanel.setWidth("200px");
//		hpanel.setVerticalAlignment(HasVerticalAlignment.ALIGN_BOTTOM);
		buttonContainer.add(hpanel);
		detailContainer = buildPanel();
		VerticalLayoutContainer container = new VerticalLayoutContainer();          
//		BoxLayoutData flex = new BoxLayoutData(new Margins(0, 0, 5, 0));
//        flex.setFlex(1);
		container.add(detailContainer, new VerticalLayoutData(1, 0.80));
//		detailContainer.setHeight("auto");
//		BoxLayoutData flex2 = new BoxLayoutData(new Margins(0));
//		flex2.setFlex(1);
//		container.add(new Label(), flex);
		container.add(buttonContainer, new VerticalLayoutData(1,0.10));
//		container.setVBoxLayoutAlign(VBoxLayoutAlign.STRETCH);
		add(container);
		addHandler();
		//loadForm(item);		
	}
	
	protected void setStatusButtons() {	}
	
	abstract protected VerticalLayoutContainer buildPanel();

	abstract protected void addHandler();

	abstract protected void loadForm(TreeNodeModel item);

	
	protected void toggleSaveCancel(boolean enable) {
		changed = enable;
		navigation.getBus().fireEvent(new ModifyEvent(!changed));
		validerButton.setEnabled(enable);
		annulerButton.setEnable(enable);
	}
	public boolean isInDetail() {
		return isInDetail;
	}

	public void setInDetail(boolean isInDetail) {
		this.isInDetail = isInDetail;
	}

	public HtmlButton getAnnulerButton() {
		return annulerButton;
	}

	public void setAnnulerButton(HtmlButton annulerButton) {
		this.annulerButton = annulerButton;
	}

	public TextButton getValiderButton() {
		return validerButton;
	}

	public void setValiderButton(TextButton validerButton) {
		this.validerButton = validerButton;
	}
}
