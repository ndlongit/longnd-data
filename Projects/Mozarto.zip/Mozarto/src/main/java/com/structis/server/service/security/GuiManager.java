package com.structis.server.service.security;

import java.util.LinkedHashMap;

public interface GuiManager {
	LinkedHashMap<String, String> getVisibilityAction(String cRole);
}
