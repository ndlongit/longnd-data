package com.structis.client.panel.composition;
import java.util.List;

import com.sencha.gxt.data.shared.loader.PagingLoadConfigBean;
import com.structis.shared.model.reference.CompositionReferenceGridModel;

public class CompositionReferenceFilter extends PagingLoadConfigBean implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	private Integer idModeleVersion;
	private List<Integer> caracteristiqueIds;
	private List<CompositionReferenceGridModel> selectedList;
	public Integer getIdModeleVersion() {
		return idModeleVersion;
	}
	public void setIdModeleVersion(Integer idModeleVersion) {
		this.idModeleVersion = idModeleVersion;
	}
	public List<Integer> getCaracteristiqueIds() {
		return caracteristiqueIds;
	}
	public void setCaracteristiqueIds(List<Integer> caracteristiqueIds) {
		this.caracteristiqueIds = caracteristiqueIds;
	}
	public List<CompositionReferenceGridModel> getSelectedList() {
		return selectedList;
	}
	public void setSelectedList(List<CompositionReferenceGridModel> selectedList) {
		this.selectedList = selectedList;
	}
	
	
}
