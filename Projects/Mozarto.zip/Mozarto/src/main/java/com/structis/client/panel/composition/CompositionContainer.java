package com.structis.client.panel.composition;

import java.util.Arrays;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.widget.core.client.TabItemConfig;
import com.structis.client.constant.ConstantClient;
import com.structis.client.ecran.EcranLoadable;
import com.structis.client.event.LoadCompositionEvent;
import com.structis.client.message.ActionMessages;
import com.structis.client.message.Messages;
import com.structis.client.navigation.Action;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.panel.AbstractTabPanel;

public class CompositionContainer  extends AbstractTabPanel implements EcranLoadable {

	private SimpleEventBus bus = new SimpleEventBus();

	
	ActionMessages actionMessages = GWT.create(ActionMessages.class);

	private Messages messages = GWT.create(Messages.class);

	private CompositionPanel compositionPanel;

	//private TabPanel compositionTabPanel;

	private CompositionAccueilPanel itemHome;


	private TabItemConfig compositionTabConfig;

	private TabItemConfig compositionHomeTabConfig;
	
	@Override
	protected void onAfterFirstAttach() {
		Action[] actions = {Action.ACTION_COMPOSITEUR_ACCEUI,Action.ACTION_COMPOSITEUR};
		initTabSet(Arrays.asList(actions));
		tabSet.addStyleName("sub-tab-panel");
		itemHome = new CompositionAccueilPanel(bus);

		compositionPanel = new CompositionPanel(bus);
		compositionHomeTabConfig = new TabItemConfig( actionMessages.getString("actionCompositeurAccueil"));
		compositionHomeTabConfig.setEnabled(true);
		tabSet.add(itemHome, compositionHomeTabConfig);
		
		compositionTabConfig = new TabItemConfig(messages.compositeurLabel());
		compositionTabConfig.setEnabled(true);
		tabSet.add(compositionPanel, compositionTabConfig);
		tabSet.setActiveWidget(compositionPanel);
		add(tabSet);
	}
	
	@Override
	public void onLoadApplication(NavigationEvent event) {
		if(event != null){
			String idModele = event.getParameter(ConstantClient.Parameters.MODELISATION);
			if(idModele != null){
				tabSet.setActiveWidget(tabSet.getWidget(1));
				int idModeleVersion = Integer.valueOf(idModele);
				compositionPanel.getCompositionTreePanel().loadComposition(idModeleVersion);
				navigation.getBus().fireEvent(new LoadCompositionEvent(idModeleVersion));
			}
		}
		
	}

}
