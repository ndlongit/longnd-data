package com.structis.client.widget;

import java.util.List;

import com.sencha.gxt.data.shared.loader.ListLoadResultBean;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;

/**
 * A {@link ListLoadResultBean} that adds support for paging properties as described by
 * {@link PagingLoadResult}.
 * 
 * @param <Data> the type of data for this list load result
 */
@SuppressWarnings("serial")
public class CustomizePagingLoadResultBean<Data> extends ListLoadResultBean<Data> implements CustomizePagingLoadResult<Data> {

	private int totalLength;

	private int offset;
	
	private int realTotal;
	/**
	 * Creates an empty paging load result bean.
	 */
	public CustomizePagingLoadResultBean() {

	}

	/**
	 * Creates a new paging list load result.
	 * 
	 * @param list the data
	 * @param totalLength the total length
	 * @param offset the paging offset
	 */
	public CustomizePagingLoadResultBean(List<Data> list, int totalLength, int offset) {
		super(list);
		this.totalLength = totalLength;
		this.offset = offset;
	}

	@Override
	public int getOffset() {
		return offset;
	}

	@Override
	public int getTotalLength() {
		return totalLength;
	}

	@Override
	public void setOffset(int offset) {
		this.offset = offset;
	}

	@Override
	public void setTotalLength(int totalLength) {
		this.totalLength = totalLength;
	}

	@Override
	public int getfinalTotal() {
		return realTotal;
	}

	@Override
	public void setfinalTotal(int realTotal) {
		this.realTotal = realTotal;
	}

}
