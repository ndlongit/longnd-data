package com.structis.client.service;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.client.widget.CustomizePagingLoadResult;
import com.structis.shared.model.Element;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ElementFormModel;
import com.structis.shared.model.reference.ElementInsertResult;
import com.structis.shared.model.reference.TreeNodeModel;

@RemoteServiceRelativePath("springGwtServices/clientElementService")
public interface ClientElementService extends RemoteService {

	public Element insert(Element element, List<AttributEtenduMetierERValueModel> attributEtenduElements, boolean update);

	public Element findById(Integer idElement);

	public CustomizePagingLoadResult<Element> loadPaging(PagingLoadConfig loadConfig, Element element, String attribut, boolean rechAvancee);

	public ElementFormModel findElementFormModelByElementId(Integer idModeleVersion, Integer elementId);

	public ElementFormModel findElementFormModelByElementCodeAndModelVersion(String text, Integer idModeleVersion);

	public void updateElement(ElementFormModel elementForm);

	public void updateElementInRules(TreeNodeModel parentNode, ElementFormModel elementForm);

	public void insertReferenceElementList(Integer nodeParentId, List<TreeNodeModel> list);

	public ElementInsertResult insertReferenceElementListInRules(TreeNodeModel parentInfo, List<TreeNodeModel> list);

	public Element deleteById(Integer idElement);
	
	PagingLoadResult<MdlReferenceElement> loadParentPaging(Integer idElement, Integer idModelVersion, PagingLoadConfig loadConfig);
}
