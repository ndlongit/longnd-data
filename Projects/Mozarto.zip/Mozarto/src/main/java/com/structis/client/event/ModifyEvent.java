package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class ModifyEvent  extends GwtEvent<ModifyHandler>{

	private static Type<ModifyHandler> TYPE = new Type<ModifyHandler>();
	private boolean finished = false;
	public static Type<ModifyHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModifyHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModifyHandler handler) {
		handler.onLoad(this);
	}
	
	public ModifyEvent(boolean isFinished) {
		this.finished = isFinished;
	}

	public boolean isFinished() {
		return finished;
	}

	public void setFinished(boolean finished) {
		this.finished = finished;
	}

}
