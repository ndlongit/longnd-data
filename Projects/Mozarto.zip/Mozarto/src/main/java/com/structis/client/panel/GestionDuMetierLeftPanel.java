package com.structis.client.panel;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.client.event.GestionDuMetierAddTabEvent;
import com.structis.client.properties.MetierMzPzProperties;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.MetierMzPzModel;

public class GestionDuMetierLeftPanel extends AbstractGestionMetierLeftPanel {

	public GestionDuMetierLeftPanel(final SimpleEventBus bus) {
		super(bus);
	}

	public void addHandler() {
	}

	@Override
	public void afterLoadMetier(Metier result) {
		metierLabel.setHTML(messages.commonMetier() + ": " + result.getLLibelle());
		MetierMzPzModel metierMzPzModel = new MetierMzPzModel();
		metierMzPzModel.setCMetier(result.getCMetier());
		metierMzPzModel.setIdMetier(result.getIdMetier());
		metierMzPzModel.setInActif(result.getInActif());
		metierMzPzModel.setLLibelle(result.getLLibelle());
		
		metiers.add(metierMzPzModel);
		listMetiers.getSelectionModel().selectAll();
		listMetiers.getSelectionModel().setLocked(true);
		bus.fireEvent(new GestionDuMetierAddTabEvent(metierMzPzModel));
		addHandler();
	}

	@Override
	public void buildFieldSet() {
		MetierMzPzProperties props = GWT.create(MetierMzPzProperties.class);
		metiers = new ListStore<MetierMzPzModel>(props.idMetier());
		ColumnConfig<MetierMzPzModel, String> libelle = new ColumnConfig<MetierMzPzModel, String>(
				props.lLibelle());
		libelle.setColumnStyle(SafeStylesUtils.forBorderStyle(BorderStyle.HIDDEN));
		List<ColumnConfig<MetierMzPzModel, ?>> l = new ArrayList<ColumnConfig<MetierMzPzModel, ?>>();
		l.add(libelle);
		ColumnModel<MetierMzPzModel> cm = new ColumnModel<MetierMzPzModel>(l);
		
		listMetiers = new Grid<MetierMzPzModel>(metiers,cm);
		listMetiers.setHideHeaders(true);
		listMetiers.getView().setAutoFill(true);
		listMetiers.setBorders(false);
		
		metiersFieldset.add(listMetiers);
	}
}
