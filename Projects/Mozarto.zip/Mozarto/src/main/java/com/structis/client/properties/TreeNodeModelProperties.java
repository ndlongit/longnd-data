package com.structis.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.TreeNodeModel;

public interface TreeNodeModelProperties extends PropertyAccess<TreeNodeModel> {
	
	@Path("id")
	ModelKeyProvider<TreeNodeModel> key();
	
	ValueProvider<TreeNodeModel, String> libelle();

	ValueProvider<TreeNodeModel, Integer> id();
}
