package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ModelisateurTreeCopyHandler extends EventHandler {
	void onLoad(ModelisateurTreeCopyEvent event);
}
