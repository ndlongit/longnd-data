package com.structis.server.service.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.persistence.MdlRegleMapper;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.Element;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlLienCommun;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.MdlRegle;
import com.structis.shared.model.reference.RuleConflictInfo;
import com.structis.shared.model.reference.TreeNodeModel;

@Service
public class RegleServiceImpl implements RegleService {

	@Autowired
	LiencaracteristiqueService liencaracteristiqueService;

	@Autowired
	LienReferenceService lienReferenceService;

	@Autowired
	LienElementService lienElementService;

	@Autowired
	LienCommunService lienCommunService;

	@Autowired
	MdlRegleMapper mdlRegleMapper;

	@Autowired
	TypeRegleService typeRegleService;

	@Autowired
	CarateristiqueReferenceService carateristiqueReferenceService;

	@Autowired
	CaracteristiqueService caracteristiqueService;

	@Autowired
	ReferenceService referenceService;

	@Autowired
	ElementService elementService;
	
	@Autowired
	ModeleService modeleService;
	
	/**
	 * step 1: get idlienCommun of source Node, idlienCommun of target Node step 2: get idlienCommun
	 * of parent and children of source Node step 3: get all direct current relge of source Node
	 * include : regle of parent, regle of children and regle of sourceNode step 4: check conflict
	 * and return the conflict info
	 */
	public RuleConflictInfo checkConflict(TreeNodeModel sourceNode, TreeNodeModel targetNode, int priorite, int quantite, boolean isUdate) {
		RuleConflictInfo conflictInfo = new RuleConflictInfo();
		if( sourceNode != null && targetNode != null ) {
			int idModeleVersion = sourceNode.getIdModeleVersion();
			int sourceId = sourceNode.getId();
			int cibleId = targetNode.getId();
			int idSourceLienCommun;
			int idCibleLienCommun;
			String typeSourceLien = sourceNode.getModelType().getLabel();
			String typeCibledLien = targetNode.getModelType().getLabel();
			/**
			 * step 1: get idlienCommun of source Node, idlienCommun of target Node
			 */
			idSourceLienCommun = lienCommunService.getIdLienCommmun(idModeleVersion, sourceId, typeSourceLien, true);
			idCibleLienCommun = lienCommunService.getIdLienCommmun(idModeleVersion, cibleId, typeCibledLien, true);
			/**
			 * step 2: get idlienCommun of parent and children of source Node
			 */
			List<MdlRegle> currentRegles = new ArrayList<MdlRegle>();
			List<Integer> idLienCommunList = new ArrayList<Integer>();
			if(!isUdate){ 
				idLienCommunList.add(idSourceLienCommun);
			}
			idLienCommunList.addAll(findLienCommunsHierarchyUp(sourceNode, idModeleVersion));
			if( typeSourceLien.equals(ModelNodeType.CARACTERISTIQUE.getLabel()) ) {
				idLienCommunList.addAll(findLienCommunsHierarchyDown(sourceNode, idModeleVersion));
			}
			/**
			 * step 3: get all direct current relge of source Node include : regle of parent, regle
			 * of children and regle of sourceNode
			 */
			if( idLienCommunList.size() > 0 ) {
				currentRegles = findRegleListExcludeAnnuler(idModeleVersion, idLienCommunList);
			}
			/**
			 * check conflict
			 */
			if( currentRegles.size() > 0 ) {
				for( MdlRegle regle : currentRegles ) {
					if( idCibleLienCommun == regle.getIdCibleLienCommun().intValue() ) {
						/**
						 * Compare priorite Interdite = 1 conseillée = 2 indispensable = 3
						 */
						String conflictCode = priorite + "" + regle.getNPriorite();

						String[] arrError = { "11", "12", "13", "21", "31" };
						List<String> errorList = Arrays.asList(arrError);
						if( errorList.contains(conflictCode) ) {
							conflictInfo.setCode(RuleConflictInfo.ERROR + conflictCode);
							conflictInfo.setType(RuleConflictInfo.ERROR);
						}
						else {
							conflictInfo.setCode(RuleConflictInfo.INFO + conflictCode);
							conflictInfo.setType(RuleConflictInfo.INFO);
						}
						//TODO:query performance
						//TreeNodeModel nodeTargetConflicted = findNodeByIdLienCommun(idModeleVersion, regle.getIdCibleLienCommun());
						TreeNodeModel nodeSourceOfPreviousRule = findNodeByIdLienCommun(
								idModeleVersion, regle.getIdSourceLienCommun());
						//conflictInfo.setNodeTargetBeConflicted(nodeTargetConflicted);
						conflictInfo.setNodeSourceOfPreviousRule(nodeSourceOfPreviousRule);
						return conflictInfo;
					}
				}
			}
		}
		return null;
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<MdlRegle> findRegleByLienCommun(Integer idModeleVersion, List<Integer> idLienCommunList) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("list", idLienCommunList);
		return mdlRegleMapper.findRegleByIdSourceLienCommuns(mapParameter);
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<MdlRegle> findAnnulerRegleByLienCommun(Integer idModeleVersion, List<Integer> idLienCommunList) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("list", idLienCommunList);
		mapParameter.put("annuler", "annuler");
		return mdlRegleMapper.findRegleByIdSourceLienCommuns(mapParameter);
	}

	@Override
	public List<MdlRegle> findRegleListExcludeAnnuler(Integer idModeleVersion, List<Integer> idLienCommunList) {
		List<MdlRegle> regleList = findRegleByLienCommun(idModeleVersion, idLienCommunList);
		List<MdlRegle> finalRegleList = new ArrayList<MdlRegle>();
		List<MdlRegle> annulerRegleList = findAnnulerRegleByLienCommun(idModeleVersion, idLienCommunList);
		//remove annuler regle from the list
		if(annulerRegleList.size()>0){
			for( MdlRegle regle : regleList ) {
				boolean canceled = false;
				for( MdlRegle aregle : annulerRegleList ) {
					if( aregle.getIdCibleLienCommun().intValue() == regle.getIdCibleLienCommun().intValue() && ((aregle.getNPriorite() + regle.getNPriorite()) == 0) ) {
						canceled = true;
					}
					
				}
				if(!canceled){
					finalRegleList.add(regle);
				}
			}
			return finalRegleList;
		}
		return regleList;
	}

	public List<Integer> findLienCommunsHierarchyUp(TreeNodeModel sourceNode, int idModeleVersion) {
		List<Integer> idLienCommunList = new ArrayList<Integer>();
		List<Integer> idCarateristiqueList = new ArrayList<Integer>();

		/**
		 * Get list id_lien_commun of SourceNode (Carateristique ,Reference + parent Hierarchy of
		 * Carateristique)
		 */
		String idString = "";
		if( sourceNode.getModelType().equals(ModelNodeType.REFERENCE) ) {
			//find all Carateristique that references depend to
			List<MdlCarateristiqueReference> carateristiqueReferences = carateristiqueReferenceService.findByModeleVersionAndReference(
					idModeleVersion, sourceNode.getId());
			if( carateristiqueReferences != null && carateristiqueReferences.size() > 0 ) {
				for( MdlCarateristiqueReference cr : carateristiqueReferences ) {
					idCarateristiqueList.add(cr.getIdCaracteristique());
					idString += cr.getIdCaracteristique() + ",";
				}
			}
		}
		else {
			idString += sourceNode.getId() + ",";
		}

		//find all Hierarchy parent of list carateristique
		List<Integer> parentParentHierarchy = caracteristiqueService.findIdParentsHierarchy(idString);
		if( parentParentHierarchy != null && parentParentHierarchy.size() > 0 ) {
			idCarateristiqueList.addAll(parentParentHierarchy);
		}
		//find idLienCommun List from id Carateristique List -> add to idLienCommunList
		List<Integer> idLienCommunCaracteristiqueList = new ArrayList<Integer>();
		if(idCarateristiqueList.size() >0 ){
			idLienCommunCaracteristiqueList = liencaracteristiqueService.findLienCaracteristiqueIdsByCaracteristiqueList(
				idModeleVersion, idCarateristiqueList);
		}
		//add idLienCommun to idLienCommunList
		idLienCommunList.addAll(idLienCommunCaracteristiqueList);

		return idLienCommunList;
	}

	public List<Integer> findLienCommunsHierarchyDown(TreeNodeModel sourceNode, int idModeleVersion) {
		List<Integer> idLienCommunList = new ArrayList<Integer>();
		if( sourceNode.getModelType() == ModelNodeType.CARACTERISTIQUE ) {
			//get all carateristque children 
			List<Integer> idCarateristiqueChildrens = caracteristiqueService.findIdChidrensHierarchy(sourceNode.getId());
			
			if(idCarateristiqueChildrens.size()>0){
				
				// get all reference liencommun
				List<Integer> idLienCoummunReferences = lienReferenceService.findIdCommunsByCarateristique(idModeleVersion,idCarateristiqueChildrens);
				if( idLienCoummunReferences.size() > 0 ) {
					idLienCommunList.addAll(idLienCoummunReferences);
				}
				idCarateristiqueChildrens.remove(sourceNode.getId());
				// get all caracteristique liencommun
				if(idCarateristiqueChildrens.size()>0){
					List<Integer> idLienCommunCaracteristiqueList = liencaracteristiqueService.findLienCaracteristiqueIdsByCaracteristiqueList(
							idModeleVersion, idCarateristiqueChildrens);
					if( idLienCommunCaracteristiqueList != null && idLienCommunCaracteristiqueList.size() > 0 ) {
						idLienCommunList.addAll(idLienCommunCaracteristiqueList);
					}
				}
			}
		}
		return idLienCommunList;
	}

	@Override
	public TreeNodeModel findNodeByIdLienCommun(Integer idModeleVersion, Integer idLienCommun) {
		//check type of LienCommun
		MdlLienCommun lienCommun = lienCommunService.findById(idLienCommun);
		if( lienCommun.getCTypeLien().equals(ModelNodeType.CARACTERISTIQUE.getLabel()) ) {
			MdlCaracteristique caracteristique = caracteristiqueService.findByIdLienCommun(idModeleVersion, idLienCommun);
			if( caracteristique != null ) {
				return createTreeNodeModel(
						caracteristique.getIdCaracteristique(), ModelNodeType.CARACTERISTIQUE, idModeleVersion,
						caracteristique.getLLibelleLong());
			}

		}
		else if( lienCommun.getCTypeLien().equals(ModelNodeType.REFERENCE.getLabel()) ) {
			MdlReference reference = referenceService.findByIdLienCommun(idModeleVersion, idLienCommun);
			if( reference != null ) {
				return createTreeNodeModel(
						reference.getIdReference(), ModelNodeType.REFERENCE, idModeleVersion, reference.getLLibelleLong());
			}
		}
		else if( lienCommun.getCTypeLien().equals(ModelNodeType.ELEMENT.getLabel()) ) {
			Element element = elementService.findByIdLienCoummun(idModeleVersion, idLienCommun);
			if( element != null ) {
				String label = element.getCElement() + " - " + element.getLLibelleLong();
				return createTreeNodeModel(
						element.getIdElement(), ModelNodeType.ELEMENT, idModeleVersion, label);
			}
		}

		return null;
	}

	private TreeNodeModel createTreeNodeModel(Integer id, ModelNodeType type, Integer idModeleVersion, String libele) {
		TreeNodeModel node = new TreeNodeModel();
		node.setId(id);
		node.setModelType(type);
		node.setIdModeleVersion(idModeleVersion);
		node.setLibelle(libele);
		return node;
	}


	
	@Override
	@Transactional
	public void cancelInheritage(Integer idUser,TreeNodeModel sourceNode, int idRegle) {
		MdlRegle regle = mdlRegleMapper.findById(idRegle);
		int idSourceLienCommun = lienCommunService.getIdLienCommmun(sourceNode.getIdModeleVersion(), sourceNode.getId(), sourceNode.getModelType().getLabel(), true);
		MdlRegle regleUnlink =  new MdlRegle();
		regleUnlink.setIdModeleVersion(sourceNode.getIdModeleVersion());
		regleUnlink.setIdSourceLienCommun(idSourceLienCommun);
		regleUnlink.setIdCibleLienCommun(regle.getIdCibleLienCommun());
		regleUnlink.setCTypeRegle(regle.getCTypeRegle());
		regleUnlink.setNQuantite((short) regle.getNQuantite());
		regleUnlink.setNPriorite((short) (0-regle.getNPriorite()));
		mdlRegleMapper.insert(regleUnlink);
		modeleService.updateModifiedBy(idUser, sourceNode.getIdModeleVersion());
	}
	@Override
	@Transactional
	public void delete(Integer idUser,TreeNodeModel sourceNode,int idRegle) {
		MdlRegle regle = mdlRegleMapper.findById(idRegle);
		List<MdlRegle> regleAnnulerChildrenList = new ArrayList<MdlRegle>();
		List<Integer> idLienCommunChildrens = findLienCommunsHierarchyDown(sourceNode,sourceNode.getIdModeleVersion());
		if(idLienCommunChildrens != null && idLienCommunChildrens.size() > 0)
			regleAnnulerChildrenList = findAnnulerRegleByLienCommun(sourceNode.getIdModeleVersion(),idLienCommunChildrens);
		List<Integer> idRegleToDeletes = new ArrayList<Integer>();
		if(regleAnnulerChildrenList.size() > 0){
			for(MdlRegle aregle:regleAnnulerChildrenList){
				if( aregle.getIdCibleLienCommun().intValue() == regle.getIdCibleLienCommun().intValue() && (aregle.getNPriorite() + regle.getNPriorite() == 0) ) {
					idRegleToDeletes.add(aregle.getIdRegle());
				}
			}
		}
		//delete list annuler of regle
		idRegleToDeletes.add(idRegle);
		deleteList(sourceNode.getIdModeleVersion(),idRegleToDeletes);
		modeleService.updateModifiedBy(idUser, sourceNode.getIdModeleVersion());
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteList(int idModeleVersion, List<Integer> idRegle) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("list", idRegle);
		mdlRegleMapper.deleteByListId(mapParameter);
	}

	@Override
	public MdlRegle findById(int idRegle) {
		return mdlRegleMapper.findById(idRegle);
	}

	@Override
	public void update(MdlRegle regle) {
		mdlRegleMapper.update(regle);
	}

	@Override
	public void insert(MdlRegle regle) {
		mdlRegleMapper.insert(regle);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteByIdLienCommun(int idModeleVersion, List<Integer> idLienCommuns) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommuns", idLienCommuns);
		mdlRegleMapper.deleteByIdLienCommuns(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<MdlRegle> findRegleByIdCibleLienCommun(int idModeleVersion, Integer idLienCommun) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idCibleLienCommun", idLienCommun);
		return mdlRegleMapper.findRegleByIdCibleLienCommun(mapParameter);
	}
	
}
