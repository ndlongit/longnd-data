package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GestionElementCompositionRenameElementEvent extends GwtEvent<GestionElementCompositionRenameElementHandler> {

	private static Type<GestionElementCompositionRenameElementHandler> TYPE = new Type<GestionElementCompositionRenameElementHandler>();
	private String tabId;
	private String newLabel;

	public static Type<GestionElementCompositionRenameElementHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionElementCompositionRenameElementHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionElementCompositionRenameElementHandler handler) {
		handler.onLoad(this);
	}	

	public GestionElementCompositionRenameElementEvent(String tabId, String newLabel) {
		this.newLabel = newLabel;
		this.tabId = tabId;
	}

	public String getNewLabel() {
		return newLabel;
	}

	public void setNewLabel(String newLabel) {
		this.newLabel = newLabel;
	}

	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

}
