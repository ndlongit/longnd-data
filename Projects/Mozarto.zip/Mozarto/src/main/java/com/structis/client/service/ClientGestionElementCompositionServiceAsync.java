package com.structis.client.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.GestionElementCompositionReference;

public interface ClientGestionElementCompositionServiceAsync {
	public static class Util {

		private static ClientGestionElementCompositionServiceAsync instance = GWT
				.create(ClientGestionElementCompositionService.class);
	
		public static ClientGestionElementCompositionServiceAsync getInstance() {
			return instance;
		}
		
	}

	void getGestionElementCompositionReference(Integer elementId, Integer metierId, AsyncCallback<GestionElementCompositionReference> callback);
	
	void getMetier (Integer idMetier, AsyncCallback<Metier> callback);
}
