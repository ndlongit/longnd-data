package com.structis.client.event;

import java.util.List;

import com.google.gwt.event.shared.GwtEvent;

public class CompositionCaracteristiqueChangeEvent extends GwtEvent<CompositionCaracteristiqueChangeHandler> {

	private static Type<CompositionCaracteristiqueChangeHandler> TYPE = new Type<CompositionCaracteristiqueChangeHandler>();

	private List<Integer> idCaracteristiques;
	private Integer idModelVersion;
	public static Type<CompositionCaracteristiqueChangeHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<CompositionCaracteristiqueChangeHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(CompositionCaracteristiqueChangeHandler handler) {
		handler.onLoad(this);
	}

	public List<Integer> getIdCaracteristiques() {
		return idCaracteristiques;
	}

	public void setIdCaracteristiques(List<Integer> idCaracteristiques) {
		this.idCaracteristiques = idCaracteristiques;
	}

	public Integer getIdModelVersion() {
		return idModelVersion;
	}

	public void setIdModelVersion(Integer idModelVersion) {
		this.idModelVersion = idModelVersion;
	}

}
