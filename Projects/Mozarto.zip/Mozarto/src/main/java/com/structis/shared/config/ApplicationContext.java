package com.structis.shared.config;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import com.structis.shared.model.Metier;
import com.structis.shared.model.Utilisateur;
import com.structis.shared.security.Role;

public class ApplicationContext implements Serializable {
	private static final long serialVersionUID = 1L;
	// Load application
	private List<Role> roles;
	
	private LinkedHashMap<String,String> actions;
	
	private Date date;
	
	private Utilisateur utilisateur;
	
	
	
	public Utilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	private Metier metier;
	
	public Metier getMetier() {
		return metier;
	}

	public void setMetier(Metier metier) {
		this.metier = metier;
	}

	/*private int modelisation;*/
	private int idModeleVersionComposition;
	
	private String languageCode = "fr";	
	
	private int isChanged = 0;
	
	public ApplicationContext() {
		
	}

	public ApplicationContext(List<Role> roles, Date date) {
		super();
		this.roles = roles;
		this.date = date;
	}

	// ### Load application
	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public Date getDate() {
		return date;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

	public String getLanguageCode() {
		
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public int getIdModeleVersionComposition() {
		return idModeleVersionComposition;
	}

	public void setIdModeleVersionComposition(int idModeleVersionComposition) {
		this.idModeleVersionComposition = idModeleVersionComposition;
	}

	public int getIsChanged() {
		return isChanged;
	}

	public void setIsChanged(int isChanged) {
		this.isChanged = isChanged;
	}

	public LinkedHashMap<String, String> getActions() {
		return actions;
	}

	public void setActions(LinkedHashMap<String, String> actions) {
		this.actions = actions;
	}

	/*public int getModelisation() {
		return modelisation;
	}

	public void setModelisation(int modelisation) {
		this.modelisation = modelisation;
	}*/
	
}
