package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.reference.ModeleModel;


public interface ModeleService {
	
	public List<ModeleModel> findAllByMetier (Integer idModele, Integer idMetier, String sortField, String sortDir);
	
	public int updateByIdModele (Integer idModele, boolean actif);
	
	public void updateModifiedBy(Integer utilisatuerId, Integer idModeleVersion);
	
	public List<ModeleModel> findAllLastPublicVersionByMetier(Integer idMetier);
	
	public int findNVersionByIdModele(Integer idModeleVersion);
}
