package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurTreeReloadAddElementEvent extends GwtEvent<ModelisateurTreeReloadAfterAddElementHandler> {

	private static Type<ModelisateurTreeReloadAfterAddElementHandler> TYPE = new Type<ModelisateurTreeReloadAfterAddElementHandler>();

	public static Type<ModelisateurTreeReloadAfterAddElementHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModelisateurTreeReloadAfterAddElementHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModelisateurTreeReloadAfterAddElementHandler handler) {
		handler.onLoad(this);
	}

	private TreeNodeModel treeNode;

	public ModelisateurTreeReloadAddElementEvent(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}

	public TreeNodeModel getTreeNode() {
		return treeNode;
	}

	public void setTreeNode(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}

}
