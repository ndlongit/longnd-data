package com.structis.client.widget;

import com.sencha.gxt.widget.core.client.grid.Grid;

public class OneColumnGrid<M> extends Grid<M> {
	
}
