package com.structis.client.panel.composition;

import com.sencha.gxt.core.client.Style.Side;
import com.sencha.gxt.widget.core.client.tips.ToolTipConfig;

public class InformationToolTip extends ToolTipConfig {
	public InformationToolTip(){
		setCloseable(true);
		setMouseOffset(new int[] { 0, 0 });
		setAnchor(Side.LEFT);
		setAutoHide(true);
	}
}
