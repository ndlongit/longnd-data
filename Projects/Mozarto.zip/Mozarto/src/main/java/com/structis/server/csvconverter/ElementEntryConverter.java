package com.structis.server.csvconverter;

import java.util.List;

import com.googlecode.jcsv.writer.CSVEntryConverter;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.Element;
import com.structis.shared.model.Famille;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ElementWithFamillesAndAttributsModel;

public class ElementEntryConverter implements CSVEntryConverter<ElementWithFamillesAndAttributsModel> {

	@Override
	public String[] convertEntry(ElementWithFamillesAndAttributsModel e) {
		String[] columns = null;
		if (e != null){
			List<AttributEtenduMetierERValueModel> attributEtenduMetierERValueModels = e.getAttributEtenduMetierERValueModels();
			columns  = new String [attributEtenduMetierERValueModels.size() *2 + 9];
	
			List<Famille> familles = e.getFamilles();
			for (int i = 0; i < 4; i++){
				if (i < familles.size() && familles.get(i) != null)
					columns[i] = familles.get(i).getLLibelle();
				else 
					columns[i] = "";
			}
			Element element = e.getElement();
			if (element.getCTypeElement() != null){
				if (element.getCTypeElement().equals(Constant.TYPE_ELEMENT_ARTICLE))
					columns[4] = "A";
				else
					columns[4] = "P";
			}
			else
				columns[4] = "";
			if (element.getCElement() != null)
				columns[5] = element.getCElement();
			else
				columns[5] = "";
			if (element.getLLibelleLong() != null)
				columns[6] = element.getLLibelleLong();
			else 
				columns[7] = "";
			if (element.getLNomenclatureFournisseur() != null)
				columns[7] = element.getLNomenclatureFournisseur();
			else 
				columns[7] = "";
			if (element.getInActif())
				columns[8] = "1";
			else
				columns[8] = "0";
			for (int i = 0; i < attributEtenduMetierERValueModels.size(); i++){
				AttributEtenduMetierERValueModel attributEtenduMetierERValueModel = attributEtenduMetierERValueModels.get(i);
				if (attributEtenduMetierERValueModel.getAttributEtenduLibelle() != null)
					columns[9+2*i] = attributEtenduMetierERValueModel.getAttributEtenduLibelle();
				else
					columns[9+2*i] = "";
				if (attributEtenduMetierERValueModel.getValeur() != null)
					columns[9+2*i+1] = attributEtenduMetierERValueModel.getValeur();
				else
					columns[9+2*i+1] = "";
			}
		}
		return columns;
	}

	

}
