package com.structis.client.panel;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.grid.Grid.GridCell;
import com.structis.client.event.ModifyEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.service.ClientAttributEtenduServiceAsync;
import com.structis.client.widget.AttributActionCell;
import com.structis.client.widget.AttributReferenceElementGrid;
import com.structis.client.widget.HtmlButton;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.reference.MetierMzPzModel;

public abstract class AbstractGestionMetierForm extends ContentPanel {

	public final static String ALL = "A"; 

	public final static String REF = "R"; 

	public final static String ELT = "E"; 
	
	protected final Messages messages = GWT.create(Messages.class);

	protected FieldSet attrefFieldSet;

	protected FieldSet atteltFieldSet;

	protected VerticalLayoutContainer infoSet;

	protected int idMetier;

	protected MetierMzPzModel metier;

	protected AttributReferenceElementGrid attributReferenceGrid;

	protected AttributReferenceElementGrid attributElementGrid;

	protected TextButton validerButton;

	protected HtmlButton annulerButton;

	protected VerticalLayoutContainer container;

	protected boolean adminGeneral = false;

	protected boolean editable = true;
	
	protected boolean isChanged = false;

	protected SimpleEventBus bus;

	public AbstractGestionMetierForm(SimpleEventBus bus) {
		this.bus = bus;
		buildForm();
		addHandler();
	}

	protected void buildForm() {
		container = new VerticalLayoutContainer();
		add(container);
		infoSet = new VerticalLayoutContainer();
		attrefFieldSet = new FieldSet();
		attrefFieldSet.setHeadingText(messages.metiersFormReference());
		atteltFieldSet = new FieldSet();
		atteltFieldSet.setHeadingText(messages.metiersFormElement());
		container.add(infoSet);
		container.add(attrefFieldSet);
		container.add(atteltFieldSet, new VerticalLayoutData(1, 1));
		buildInfoSet();

		attributReferenceGrid = new AttributReferenceElementGrid();
		attrefFieldSet.add(attributReferenceGrid, new VerticalLayoutData(1, 1));

		attributElementGrid = new AttributReferenceElementGrid();
		atteltFieldSet.add(attributElementGrid, new VerticalLayoutData(1, 1));
		annulerButton = new HtmlButton(messages.commonAnnulerButton());
		annulerButton.setStyleName("htmlLink");
		addButton(annulerButton);
		validerButton = new TextButton(messages.commonValiderButton());
		addButton(validerButton);
		setButtonAlign(BoxLayoutPack.CENTER);
		setHeaderVisible(false);
		getButtonBar().setSpacing(30);
		enableButtons(false);
	}

	public abstract void buildInfoSet();
	
	protected abstract void addHandler();

	public void fillGrids() {
		attributReferenceGrid.setParent(this);
		attributElementGrid.setParent(this);
		attributElementGrid.getGrid().disable();
		attributReferenceGrid.getGrid().disable();
		loadData(ALL);
		if( (!metier.getInActif() && !adminGeneral) || !editable ) {
			attributReferenceGrid.getEditing().setEditableGrid(null);
			attributReferenceGrid.setEditable(false);
			attributElementGrid.getEditing().setEditableGrid(null);
			attributElementGrid.setEditable(false);
		}
	}

	public void loadData(final String gridTobeLoad) {
		ClientAttributEtenduServiceAsync.Util.getInstance().findAllAttributEtendu(
				idMetier, new AsyncCallbackWithErrorResolution<List<List<AttributEtendu>>>() {

					@Override
					public void onSuccess(List<List<AttributEtendu>> result) {
						if(gridTobeLoad.equals(ALL) || gridTobeLoad.equals(REF)){
							attributReferenceGrid.getGrid().getStore().replaceAll(result.get(0));
							if( (adminGeneral|| metier.getInActif()) && editable) {
								AttributEtendu newAttributEtendu = attributReferenceGrid.newAttributEtendu(AttributActionCell.EMPTY_NEW);
								attributReferenceGrid.getGrid().getStore().add(newAttributEtendu);
							}
							attributReferenceGrid.getGrid().enable();
							attributReferenceGrid.setType(REF);
						}
						if(gridTobeLoad.equals(ALL) || gridTobeLoad.equals(ELT)){
							attributElementGrid.getGrid().getStore().replaceAll(result.get(1));
							if( (adminGeneral || metier.getInActif()) && editable) {
								AttributEtendu newAttributEtendu = attributElementGrid.newAttributEtendu(AttributActionCell.EMPTY_NEW);
								attributElementGrid.getGrid().getStore().add(newAttributEtendu);
							}
							attributElementGrid.getGrid().enable();
							attributElementGrid.setType(ELT);
						}
					}
				});
	}

	public void loadNewGrids() {
		attributReferenceGrid.setParent(this);
		attributElementGrid.setParent(this);
		AttributEtendu newAttributEtenduRef = attributReferenceGrid.newAttributEtendu(AttributActionCell.EMPTY_NEW);
		attributReferenceGrid.setType(REF);
		attributReferenceGrid.getGrid().getStore().add(newAttributEtenduRef);
		attributReferenceGrid.getGrid().enable();
		AttributEtendu newAttributEtenduElt = attributElementGrid.newAttributEtendu(AttributActionCell.EMPTY_NEW);
		attributElementGrid.setType(ELT);
		attributElementGrid.getGrid().getStore().add(newAttributEtenduElt);
		attributElementGrid.getGrid().enable();
	}

	public int getIdMetier() {
		return idMetier;
	}

	public void setIdMetier(int idMetier) {
		this.idMetier = idMetier;
	}

	public void enableButtons(boolean enable) {
		annulerButton.setEnable(enable);
		validerButton.setEnabled(enable);
	}

	public void setMetier(MetierMzPzModel metier) {
		this.metier = metier;
	}

	public MetierMzPzModel getMetier() {
		return metier;
	}

	public void addAttributs(final AttributReferenceElementGrid from, List<AttributEtendu> to) {
		List<AttributEtendu> allAttrib = from.getGrid().getStore().getAll();
		for (int i = 0; i < allAttrib.size(); i++){
			AttributEtendu att = allAttrib.get(i);
			if(att.getStatus() != AttributActionCell.EMPTY_NEW){
				final int k = i;
				if(att.getLLibelle() == null || "".equals(att.getLLibelle())){
					MessageBox messageBox = new MessageBox(messages.commonInfoHeader(), messages.metiersFormObligatoire());
					messageBox.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
					messageBox.addHideHandler(new HideHandler() {
						
						@Override
						public void onHide(HideEvent event) {
							from.getEditing().startEditing(new GridCell(k, 0));
						}
					});
					messageBox.show();
					return;
				}
				else {
					for (int j = 0; j < i-1; j++){
						AttributEtendu attr = allAttrib.get(j);
						if (j != i && attr.getLLibelle().equalsIgnoreCase(att.getLLibelle())){
							String message;
							if ("R".equals(from.getType())){
								message = messages.metiersFormLibelleUnique(messages.metiersFormRef());
							}
							else {
								message = messages.metiersFormLibelleUnique(messages.metierFormElt());
							}
							MessageBox box = new MessageBox(messages.commonInfoHeader(), message);
							box.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
							box.addHideHandler(new HideHandler() {
								
								@Override
								public void onHide(HideEvent event) {
									from.getEditing().startEditing(new GridCell(k, 0));
								}
							});
							box.show();
							return;
						}
					}
				}
				to.add(att);
			}
		}
	}

	public abstract void validerForm();

	public abstract void annulerForm();

	public abstract void resizeForm();

	public boolean isAdminGeneral() {
		return adminGeneral;
	}

	public void setAdminGeneral(boolean adminGeneral) {
		this.adminGeneral = adminGeneral;
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public boolean isChanged() {
		return isChanged;
	}

	public void setChanged(boolean isChanged) {
		this.isChanged = isChanged;
	}

	public void toggleChange(boolean changed) {
		enableButtons(changed);
		if(isChanged != changed){
			bus.fireEvent(new ModifyEvent(!changed));
		}
		isChanged = changed;
	}
}
