package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.client.service.ClientModelisateurService;
import com.structis.server.service.domain.AttributEtenduReferenceService;
import com.structis.server.service.domain.CaracteristiqueService;
import com.structis.server.service.domain.CarateristiqueReferenceService;
import com.structis.server.service.domain.ElementService;
import com.structis.server.service.domain.MetierService;
import com.structis.server.service.domain.ModelisateurRegleMessageService;
import com.structis.server.service.domain.ReferenceElementService;
import com.structis.server.service.domain.ReferenceService;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.Element;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.TreeNodeModel;
import com.structis.shared.model.reference.TreeNodeRegleModel;

@Service("clientModelisateurService")
public class ClientModelisateurServiceImpl implements ClientModelisateurService {
	@Autowired
	CaracteristiqueService caracteristiqueService;
	@Autowired
	ReferenceService referenceService;
	@Autowired
	ElementService elementService;
	@Autowired
	ModelisateurRegleMessageService  modelisateurRegleMessageService;
	@Autowired
	MetierService metierService;
	@Autowired
	ReferenceElementService referenceElementService;
	@Autowired
	CarateristiqueReferenceService carateristiqueReferenceService;
	@Autowired
	AttributEtenduReferenceService attributEtenduReferenceService;
	
	@Override
	public List<TreeNodeModel> getFolderChildren(TreeNodeModel node, boolean includeRegle) {
		List<TreeNodeModel> models = new ArrayList<TreeNodeModel>();
		if( node != null ) {
			
			if( ModelNodeType.CARACTERISTIQUE.getLabel() == node.getModelType().getLabel() ) {
				//get list regle 
				
				//get all characteristic children
				List<MdlCaracteristique> caracteristiques = caracteristiqueService.findCaracteristiqueByIdModeleVersion(
						node.getIdModeleVersion(), node.getId());
				//get number children of each Caracteristique
				//List<ValuePlaceHolder> cchildNumber = caracteristiqueService.findChildrenNumberCaracteristiqueByIdModeleVersion(node.getIdModeleVersion(), node.getId());
				
				//get number reference of each Caracteristique
				//List<ValuePlaceHolder> rchildNumber = caracteristiqueService.findReferenceNumberOfCaracteristiqueByModeleVersionAndCaracteristiqueParent(node.getIdModeleVersion(), node.getId());
				
				if(caracteristiques != null && caracteristiques.size() >0 ){
					models.addAll(getListTreeNode(node,caracteristiques/*, cchildNumber, rchildNumber*/));
				}
				//get all reference
				List<MdlReference> listReference = referenceService.findReferenceByModeleVersionAndCaracteristique(node.getIdModeleVersion(), node.getId());
				// get number element of reference
				//List<ValuePlaceHolder> listNumberElementOfReference = referenceService.findElementNumberOfReferenceByModeleVersionAndCaracteristique(node.getIdModeleVersion(), node.getId());
				
				
				if(listReference != null && listReference.size()>0){
					//int i=0;
					for(MdlReference r:listReference){
						TreeNodeModel nodeModel = createTreeNodeModel(
								r.getIdReference(), r.getLLibelleLong(), r.getIdModeleVersion(),
								ModelNodeType.REFERENCE, node);
						//if(listNumberElementOfReference.get(i).elementId.intValue() == r.getIdReference().intValue() && (i < listNumberElementOfReference.size() && listNumberElementOfReference.get(i).valueId > 0 )){
							nodeModel.setHasChildren(true);
							nodeModel.setSousRef(r.getInSousReference());
						/*}else{
							nodeModel.setHasChildren(false);
						}*/
						models.add(nodeModel);
						//i++;
					}
				}
			}
			else if( ModelNodeType.REFERENCE.getLabel() == node.getModelType().getLabel() ) {
				if(includeRegle){
					List<TreeNodeRegleModel> regles = modelisateurRegleMessageService.findElementRegleList(node);
					if(regles != null && regles.size() > 0){
						models.addAll(regles);
					}
				}
				//get all element of reference
				List<Element> elements = elementService.findElementByModelVersionAndReference(node.getIdModeleVersion(), node.getId());
				for(Element e:elements){
					TreeNodeModel nodeModel = createTreeNodeModel(
							e.getIdElement(), e.getCElement()+" - "+e.getLLibelleLong(), node.getIdModeleVersion(), ModelNodeType.ELEMENT, node);
					nodeModel.setQuantite(e.getQte());
					models.add(nodeModel);
				}
			}
		}

		return models;
	}

	private List<TreeNodeModel> getListTreeNode(TreeNodeModel parentNode,List<MdlCaracteristique> caracteristiques
			/*,List<ValuePlaceHolder> cchildNumber,List<ValuePlaceHolder> referenceChidlNumber*/) {
		List<TreeNodeModel> models = new ArrayList<TreeNodeModel>();
		//int i = 0;
		for( MdlCaracteristique c : caracteristiques ) {
			//check if Caracteristique have children or not
			TreeNodeModel nodeModel = createTreeNodeModel(
					c.getIdCaracteristique(), c.getLLibelleLong(), c.getIdModeleVersion(),
					ModelNodeType.CARACTERISTIQUE, parentNode);
			//if( (c.getIdCaracteristique() == cchildNumber.get(i).elementId && cchildNumber.get(i).valueId > 0) ||  ( i <referenceChidlNumber.size() && referenceChidlNumber.get(i).valueId>0)) {
				nodeModel.setHasChildren(true);
			/*}
			else {
				nodeModel.setHasChildren(false);
			}*/
			models.add(nodeModel);
			//i++;
		}
		return models;
	}

	private TreeNodeModel createTreeNodeModel(Integer id, String label, Integer idModelVersion, ModelNodeType nodeType,
			TreeNodeModel parentNode) {
		TreeNodeModel nodeModel = new TreeNodeModel();
		nodeModel.setId(id);
		nodeModel.setLibelle(label);
		nodeModel.setIdModeleVersion(idModelVersion);
		nodeModel.setModelType(nodeType);
		nodeModel.setParentId(parentNode.getId());
		return nodeModel;
	}

	@Override
	public List<TreeNodeModel> getParent(TreeNodeModel node) {
		return null;
	}
	@Override
	public List<MdlCaracteristique> findAll() {
		return null;
	}

	@Override
	public void deleteModelisateurNode(TreeNodeModel sourceNode, boolean isDeleteRegle, boolean isDeleteMessage,
			boolean isDeleteAll) {
		modelisateurRegleMessageService.deleteModelisateurNode(sourceNode, isDeleteRegle, isDeleteMessage, isDeleteAll);
	}

	@Override
	public String validateToDelete(TreeNodeModel sourceNode, boolean isDeleteRegle, boolean isDeleteMessage,
			boolean isDeleteAll) {
		return modelisateurRegleMessageService.validateToDelete(sourceNode, isDeleteRegle, isDeleteMessage, isDeleteAll);
	}

	@Override
	public Metier getMetier(Integer idMetier) {
		return metierService.findById(idMetier);
	}

	@Transactional
	@Override
	public TreeNodeModel duplicateNode(TreeNodeModel nodeToBeCopied, TreeNodeModel target, boolean isCopyRegle,
			boolean isCopyMessage, boolean isCopyChildren, Integer idUtilisateur, Integer idMetier) {
		if(nodeToBeCopied.getModelType() == ModelNodeType.CARACTERISTIQUE){
			MdlCaracteristique tmp = caracteristiqueService.findById(nodeToBeCopied.getId());
			if(tmp != null){
				return modelisateurRegleMessageService.copyCaracteristique(tmp, target.getId(), isCopyRegle, isCopyMessage, isCopyChildren, idUtilisateur, idMetier);
				
			}
		}
		else if(nodeToBeCopied.getModelType() == ModelNodeType.REFERENCE){
			MdlReference tmp = referenceService.findById(nodeToBeCopied.getId());
			if(tmp != null)
				return modelisateurRegleMessageService.copyReference(tmp, target.getId(), isCopyRegle, isCopyMessage, isCopyChildren, idUtilisateur, idMetier, true);
		}
		return null;
	}
	
}
