package com.structis.client.panel.composition;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer.HBoxLayoutAlign;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.structis.client.message.Messages;

public class AlertMessageWindow  extends Dialog {
	private TextButton button;
	private final Messages messages = GWT.create(Messages.class);
	public AlertMessageWindow(String header,String message){
		setWidth(300);
		setMinHeight(140);
		setMinWidth(300);
		setClosable(false);
		setModal(true);
		
		this.setHeadingHtml(header);
		HTML html = new HTML(message);
		//html.getElement().getStyle().setProperty("paddingBottom", "10px");
		HBoxLayoutContainer hPanel = new HBoxLayoutContainer();
		hPanel.setHBoxLayoutAlign(HBoxLayoutAlign.MIDDLE);
		hPanel.setPack(BoxLayoutPack.CENTER);
		hPanel.setPadding(new Padding(10, 0, 10, 0));
		final CheckBox checkBox = new CheckBox();
		checkBox.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
				button.setEnabled(checkBox.getValue());
			}
		});
		checkBox.setBoxLabel(messages.compositionRightReferenceConfirmMessage());
		hPanel.add(checkBox);
		add(hPanel);
		
		VerticalLayoutContainer container = new VerticalLayoutContainer();
		container.add(html);
		container.add(hPanel);
		
		add(container);
		
		setButtonAlign(BoxLayoutPack.CENTER);
		button = getButtonById(PredefinedButton.OK.name());
		button.setText(messages.commonValiderButton());
		button.disable();
		button.setEnabled(false);
		button.addSelectHandler(new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				hide();
			}
		});
	}
	public TextButton getButton(){
		return button;
	}
	
}
