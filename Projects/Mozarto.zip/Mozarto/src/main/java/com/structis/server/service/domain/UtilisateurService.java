package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.Utilisateur;

public interface UtilisateurService {
	Utilisateur findUtilisateurById(Integer idUtilisateur);

	Utilisateur findUtilisateurByAccount(String cUtilisateur);
	
	List<Utilisateur> findAll();
	
	List<Utilisateur> findAllPegaz();
	
	List<Utilisateur> findAllByMetier(Integer idMetier);
	
	List<Integer> findAllIdUtilisateur();
	
	int update (Utilisateur u);
	
	int insert (Utilisateur u);
}
