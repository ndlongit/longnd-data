package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlAttributEtenduReferenceMapper;
import com.structis.shared.model.MdlAttributEtenduReference;
import com.structis.shared.model.MdlAttributEtenduReferenceKey;

@Service
public class AttributEtenduReferenceServiceImpl implements AttributEtenduReferenceService {

	@Autowired
	MdlAttributEtenduReferenceMapper mdlAttributEtenduReferenceMapper;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteByModelVersionAndReference(Integer idReference, Integer idModeleVersion) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);
		mdlAttributEtenduReferenceMapper.deleteByParameters(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void insertList(List<MdlAttributEtenduReference> listAttr) {
		if(listAttr != null && listAttr.size() > 0){
			Map mapParameter = new HashMap();
			mapParameter.put("attributEtenduReferenceList", listAttr);
			mdlAttributEtenduReferenceMapper.insertList(mapParameter);
		}
	}

	@Override
	public void insert(MdlAttributEtenduReference record) {
		mdlAttributEtenduReferenceMapper.insert(record);
	}

	@Override
	public List<MdlAttributEtenduReference> findByBaseCriteria(MdlAttributEtenduReference criteria) {
		return mdlAttributEtenduReferenceMapper.findByBaseCriteria(criteria);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteByIdReferences(Integer idModeleVersion, List<Integer> idReferences) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReferences", idReferences);
		mdlAttributEtenduReferenceMapper.deleteByIdReferences(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteByReferenceIdsAndAttributeIds(Integer idModeleVersion, List<Integer> idReferences, List<Integer> attributeIds) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReferences", idReferences);
		mapParameter.put("attributeIds", attributeIds);
		mdlAttributEtenduReferenceMapper.deleteByReferenceIdsAndAttributeIds(mapParameter);
	}

	@Override
	public void update(MdlAttributEtenduReference sa) {
		mdlAttributEtenduReferenceMapper.update(sa);
	}

	@Override
	public void deleteById(MdlAttributEtenduReferenceKey id) {
		mdlAttributEtenduReferenceMapper.deleteById(id);
		
	}

	@Override
	public int deleteByIdAttribut(Integer idAttribut) {
		return mdlAttributEtenduReferenceMapper.deleteByIdAttribut(idAttribut);
	}
}
