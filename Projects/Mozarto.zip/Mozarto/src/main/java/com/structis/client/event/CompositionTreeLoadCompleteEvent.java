package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class CompositionTreeLoadCompleteEvent  extends GwtEvent<CompositionTreeLoadCompleteHandler>{
	
	private static Type<CompositionTreeLoadCompleteHandler> TYPE = new Type<CompositionTreeLoadCompleteHandler>();
	
	private String libelleModele;
	
	public static Type<CompositionTreeLoadCompleteHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<CompositionTreeLoadCompleteHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(CompositionTreeLoadCompleteHandler handler) {
		handler.onLoad(this);
	}
	
	public CompositionTreeLoadCompleteEvent(String libelleModele) {
		this.setLibelleModele(libelleModele);
	}

	public void setLibelleModele(String libelleModele) {
		this.libelleModele = libelleModele;
	}

	public String getLibelleModele() {
		return libelleModele;
	}

}
