package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ReferenceFormModel;
import com.structis.shared.model.reference.TreeNodeModel;

public interface ClientReferenceServiceAsync {
	public static class Util {

		private static ClientReferenceServiceAsync instance = GWT.create(ClientReferenceService.class);

		public static ClientReferenceServiceAsync getInstance() {
			return instance;
		}

	}

	void findReferenceFormModelById(Integer idModeleVersion, Integer idReference, Integer idMetier,
			AsyncCallback<ReferenceFormModel> callback);

	void updateReference(ReferenceFormModel referenceForm, AsyncCallback<Void> callback);

	void insert(Integer idParent, ModelNodeType typeParent, MdlReference reference, AsyncCallback<Integer> callback);

	void remove(Integer idParent, MdlReference referenceModel, AsyncCallback<Void> callback);

	void insertOrUpdate(Integer utilisateurId, Integer caracteristiqueId, ReferenceFormModel referenceForm,
			AsyncCallback<Integer> callback);

	void insertOrUpdateInRules(TreeNodeModel parentNode, Integer utilisateurId, Integer parentId,
			ReferenceFormModel referenceForm, AsyncCallback<Integer> callback);

	void checkSatisfyRule(TreeNodeModel tnm, Integer referenceId, AsyncCallback<Boolean> callback);

	void getListAttributEtenduByModelVersion(Integer idModeleVersion,
			AsyncCallback<List<AttributEtenduMetierERValueModel>> asyncCallback);

	void loadElementPaging(Integer idModeleVersion, Integer idReference, PagingLoadConfig loadConfig,
			AsyncCallback<PagingLoadResult<MdlReferenceElement>> callback);

	void loadCaracteristiquePaging(Integer idModeleVersion, Integer idReference, PagingLoadConfig loadConfig,
			AsyncCallback<PagingLoadResult<MdlCarateristiqueReference>> callback);

}
