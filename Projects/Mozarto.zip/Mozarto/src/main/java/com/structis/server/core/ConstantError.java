package com.structis.server.core;

public class ConstantError {
	
	/**
	 * Technical error commence par t
	 */
	public final static String ERR_TRANSACTION = "t001";
	public final static String ERR_DATA_ACCESS = "t002";
	public final static String ERR_SMB_URL = "t003";
	public final static String ERR_SMB_CONN = "t004";
	public final static String ERR_REFERENCE = "t005";
	public static final String ERR_NEMO_URL = "t006";
	public static final String ERR_NEMO_CONN = "t007";
	public final static String ERR_SESSION_EXPIRE = "t008";
	public static final String ERR_INIES_CONN = "t009";
	public static final String ERR_DONNES_INCORRECT = "t010";
	public static final String ERR_INCONNU = "t011";
	
	
	
	/**
	 * COMMON
	 */
	public static final String ERR_DUPLICATED = "f009";
	public static final String ERR_IN_USING = "f010";
	public static final String ERR_DUPLICATED_CODIFICATION = "f011";
	public static final String SAVE_FALSE = "f012";
	public static final String ERR_EXISTED = "f013";
	public static final String ERR_DUPLICATED_NFOURNISSEUR = "f014";
	public static final String ERR_NOT_SATISFY_RULE = "f100";
	
	//Import Element
	public static final String ERR_IMPORT_INPROGRESS = "f014";
	public static final String ERR_IMPORT_FIELD_REQUIRED = "f015";
	public static final String ERR_IMPORT_ELEMENT_UNIQUE = "f016";
	public static final String ERR_IMPORT_INVALID_DATA = "f017";
	public static final String ERR_IMPORT_INVALID_TYPE = "f018";
	public static final String ERR_IMPORT_ELEMENT_NAME_REQUIRED = "f019";
	public static final String ERR_IMPORT_ATTRIBUTE_NOT_EXIST = "f020";
	public static final String ERR_IMPORT_INVALID_FAMILY_STRUCTURE = "f021";
	
	/**
	 * Authentication
	 */
	public static final String ERR_WRONG_IDENTIFY = "f019";
	public static final String ERR_WRONG_PASS = "f020";

}
