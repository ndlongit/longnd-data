package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.persistence.AttributEtenduElementMapper;
import com.structis.shared.model.AttributEtenduElement;
import com.structis.shared.model.AttributEtenduElementKey;
import com.structis.shared.model.Element;
import com.structis.shared.model.reference.AttributElementModel;

/**
 * 
 * @author vu.dang
 *
 */
@Service("attributEtenduElementService")
public class AttributEtenduElementServiceImpl implements AttributEtenduElementService {
	@Autowired
	private AttributEtenduElementMapper mapper;
	
	public AttributEtenduElement findById(AttributEtenduElementKey id) {
		return mapper.findById(id);	
	}
	
	@Transactional
	public Integer insert(AttributEtenduElement record) {
		 return mapper.insert(record);	
	}
	
	@Transactional
	public Integer update(AttributEtenduElement record) {
		return mapper.update(record);	
	}
		
	@Transactional
	public Integer delete(AttributEtenduElement record) {
		return mapper.delete(record);	
	}
	
	@Transactional
	public Integer deleteById(AttributEtenduElementKey id) {
		return mapper.deleteById(id);	
	}
	public List<AttributEtenduElement> findAll() {
		return mapper.findAll();		
	}

	public List<AttributEtenduElement> findByIdElement(Integer idElement) {
		return mapper.findByIdElement(idElement);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Integer insertList(List<AttributEtenduElement> attributEtenduElements) {
		if(attributEtenduElements != null && attributEtenduElements.size() > 0){
			Map map = new HashMap ();
			map.put("attributEtenduElementList", attributEtenduElements);
			return mapper.insertList(map);
		}
		else
			return null;
	}

	@Transactional
	public int deleteByIdElement(Integer idElement) {
		return mapper.deleteByIdElement (idElement);		
	}
	
	@Override
	public List<AttributElementModel> findAttributEtenduByElement(Integer idElement) {
		return mapper.findAttributEtenduByElementId(idElement);
	}

	@Override
	public List<Element> findByBaseCriteria(AttributEtenduElement criteria) {
		return mapper.findByBaseCriteria(criteria);
	}
	
	@Override
	public int deleteByIdAttribut(Integer idAttribut) {
		return mapper.deleteByIdAttribut(idAttribut);
	}
}
