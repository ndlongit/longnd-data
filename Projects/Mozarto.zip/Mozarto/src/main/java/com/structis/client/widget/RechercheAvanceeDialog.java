package com.structis.client.widget;

import java.util.LinkedList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.text.shared.AbstractSafeHtmlRenderer;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.sencha.gxt.cell.core.client.form.ComboBoxCell.TriggerAction;
import com.sencha.gxt.core.client.XTemplates;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.FramedPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.BeforeShowEvent;
import com.sencha.gxt.widget.core.client.event.BeforeShowEvent.BeforeShowHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.event.ShowEvent;
import com.sencha.gxt.widget.core.client.event.ShowEvent.ShowHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.form.ComboBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.properties.FamilleProperties;
import com.structis.client.properties.TypeElementProperties;
import com.structis.client.service.ClientGestionElementCompositionServiceAsync;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.Famille;
import com.structis.shared.model.TypeElement;
import com.structis.shared.model.reference.GestionElementCompositionReference;

public class RechercheAvanceeDialog extends Window {
	@SuppressWarnings("unused")
	private SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private TextButton rechercherButton;

	private HTML annulerButton;

	private ElementCompositionGrid parent;

	private VerticalLayoutContainer container;

	private ComboBox<TypeElement> type;

	private CheckBox actif;

	private TextField code;

	private TextField libelle;

	private TextField nomenclatureFournisseur;

	private TextField attribut;

	private FieldLabel labelfamille;

	private ComboBox<Famille> famille;

	private ComboBox<Famille> sousfamille;

	private FieldLabel labelsousfamille;

	private ComboBox<Famille> groupe;

	private FieldLabel labelgroupe;

	private ComboBox<Famille> sousgroupe;

	private FieldLabel labelsousgroupe;

	private ComboBox<Famille> typeprestation;

	private FieldLabel labeltypeprestation;
	
	private boolean codeChanged = false;
	
	private boolean nomenclatureChanged = false;
	
	private boolean libelleChanged = false;
	
	private boolean typeChanged = false;
	
	private boolean familleChanged = false;
	
	private boolean sousfamilleChanged = false;
	
	private boolean groupeChanged = false;
	
	private boolean sousgroupeChanged = false;
	
	private boolean typeprestationChanged = false;
	
	private boolean attributChanged = false;

	private List<Famille> familles;

	private VerticalLayoutContainer familleContainer;

	private HTML familleLabel;
	
	interface ComboBoxTemplates extends XTemplates {
		
	    @XTemplate("<div  style = \"height:11px;\" >&nbsp;{lLibelle}</div>")
	    SafeHtml state(String lLibelle);
	 
	  }

	public RechercheAvanceeDialog(SimpleEventBus bus, ElementCompositionGrid parent) {
		this.bus = bus;
		this.parent = parent;
		buildPanel();
		addHandler();
	}

	private void buildPanel() {
		setPixelSize(350, 415);
		setResizable(false);
		setHeadingText(messages.gestionelemcompoLeftRechavancee());

		FramedPanel panel = new FramedPanel();
		add(panel, new VerticalLayoutData(1, 1));

		container = new VerticalLayoutContainer();
		panel.add(container);
		VerticalLayoutContainer infoContainer = new VerticalLayoutContainer();
		container.add(infoContainer);
		infoContainer.getElement().setPadding(new Padding(0, 10, 0, 10));

		TypeElementProperties props = GWT.create(TypeElementProperties.class);
		ListStore<TypeElement> typeselt = new ListStore<TypeElement>(props.cTypeElement());

		type = new ComboBox<TypeElement>(typeselt, props.lLibelle());
		type.setEmptyText(messages.gestionelemcompoRightType());
		infoContainer.add(new FieldLabel(type, messages.gestionelemcompoRightType()), new VerticalLayoutData(1, -1));
		type.setTypeAhead(true);
		type.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationType(type, props.lLibelle());

		code = new TextField();
		code.setEmptyText(messages.gestionelemcompoRightCode());
		code.setValidateOnBlur(false);
		infoContainer.add(new FieldLabel(code, messages.gestionelemcompoRightCode()), new VerticalLayoutData(1, -1));

		libelle = new TextField();
		libelle.setEmptyText(messages.gestionelemcompoRightLibelle());
		infoContainer.add(new FieldLabel(libelle, messages.gestionelemcompoRightLibelle()), new VerticalLayoutData(1, -1));

		actif = new CheckBox();
		actif.setValue(true);
		HorizontalPanel hp = new HorizontalPanel();
		hp.add(actif);
		hp.setBorderWidth(0);
		hp.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
		infoContainer.add(new FieldLabel(hp, messages.gestionelemcompoRightActif()));

		nomenclatureFournisseur = new TextField();
		nomenclatureFournisseur.setEmptyText(messages.gestionelemcompoRightNomclematureFournisseur());
		infoContainer.add(
				new FieldLabel(nomenclatureFournisseur, messages.gestionelemcompoRightNomclematureFournisseur()),
				new VerticalLayoutData(1, -1));

		attribut = new TextField();
		attribut.setEmptyText(messages.gestionelemcompoRightAttributVide());
		infoContainer.add(
				new FieldLabel(attribut, messages.gestionelemcompoRightAttribut()),
				new VerticalLayoutData(1, -1));

		FieldSet fieldSet = new FieldSet();
		fieldSet.setHeadingText(messages.gestionelemcompoRightFamille());
		fieldSet.setHeight(145);
		container.add(fieldSet, new VerticalLayoutData(1, -1));
		
		familleContainer = new VerticalLayoutContainer();
		fieldSet.add(familleContainer);
		
		familleLabel = new HTML(messages.gestionelemcompoLeftSelectionnertype());
		familleLabel.setStyleName("grayItem");
		familleContainer.add(familleLabel, new VerticalLayoutData(1, 1));
		
		FamilleProperties fprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> fam = new ListStore<Famille>(fprops.idFamille());
		famille = new ComboBox<Famille>(fam, fprops.lLibelle(), new AbstractSafeHtmlRenderer<Famille>() {

			@Override
			public SafeHtml render(Famille item) {
				final ComboBoxTemplates comboBoxTemplates = GWT.create(ComboBoxTemplates.class);
		         return comboBoxTemplates.state(item.getLLibelle());
			}
		});
		famille.setEmptyText(messages.gestionelemcompoRightFamilleFamille());
		labelfamille = new FieldLabel(famille, messages.gestionelemcompoRightFamilleFamille());
		famille.setWidth("auto");

		FamilleProperties sfprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> sfam = new ListStore<Famille>(sfprops.idFamille());
		sousfamille = new ComboBox<Famille>(sfam, sfprops.lLibelle());
		sousfamille.setEmptyText(messages.gestionelemcompoRightFamilleSousFamille());
		labelsousfamille = new FieldLabel(sousfamille, messages.gestionelemcompoRightFamilleSousFamille());
		sousfamille.setWidth("auto");

		FamilleProperties gprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> gpe = new ListStore<Famille>(gprops.idFamille());
		groupe = new ComboBox<Famille>(gpe, gprops.lLibelle());
		groupe.setEmptyText(messages.gestionelemcompoRightFamilleGroupe());
		labelgroupe = new FieldLabel(groupe, messages.gestionelemcompoRightFamilleGroupe());
		groupe.setWidth("auto");

		FamilleProperties sgprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> sgpe = new ListStore<Famille>(sgprops.idFamille());
		sousgroupe = new ComboBox<Famille>(sgpe, sgprops.lLibelle());
		sousgroupe.setEmptyText(messages.gestionelemcompoRightFamilleSousGroupe());
		labelsousgroupe = new FieldLabel(sousgroupe, messages.gestionelemcompoRightFamilleSousGroupe());
		sousgroupe.setWidth("auto");
		
		FamilleProperties pprops = GWT.create(FamilleProperties.class);
		ListStore<Famille> prest = new ListStore<Famille>(pprops.idFamille());
		typeprestation = new ComboBox<Famille>(prest, pprops.lLibelle(), new AbstractSafeHtmlRenderer<Famille>() {

			@Override
			public SafeHtml render(Famille item) {
				final ComboBoxTemplates comboBoxTemplates = GWT.create(ComboBoxTemplates.class);
		         return comboBoxTemplates.state(item.getLLibelle());
			}
		});
		typeprestation.setEmptyText(messages.gestionelemcompoRightFamilleTypePrestation());
		labeltypeprestation = new FieldLabel(typeprestation, messages.gestionelemcompoRightFamilleTypePrestation());
		typeprestation.setWidth("auto");

		famille.setTypeAhead(true);
		famille.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(famille, fprops.lLibelle(), Constant.TYPE_FAMILLE_FAMILLE);

		sousfamille.setTypeAhead(true);
		sousfamille.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(sousfamille, sfprops.lLibelle(), Constant.TYPE_FAMILLE_SOUSFAMILLE);

		groupe.setTypeAhead(true);
		groupe.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(groupe, gprops.lLibelle(), Constant.TYPE_FAMILLE_GROUPE);
		sousgroupe.setTypeAhead(true);
		sousgroupe.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(sousgroupe, sgprops.lLibelle(), Constant.TYPE_FAMILLE_SOUSGROUPE);

		typeprestation.setTypeAhead(true);
		typeprestation.setTriggerAction(TriggerAction.ALL);
		addHandlersForEventObservationFamille(typeprestation, pprops.lLibelle(), Constant.TYPE_FAMILLE_TYPEPRESTATION);

		annulerButton = new HTML(messages.commonAnnulerButton());
		annulerButton.setStyleName("htmlLink");
		rechercherButton = new TextButton(messages.commonRechercheButton());
		panel.addButton(annulerButton);
		panel.addButton(rechercherButton);
		panel.setHeaderVisible(false);
		panel.setButtonAlign(BoxLayoutPack.END);
		panel.getButtonBar().setSpacing(20);
		
		onLoad();

	}

	private void addHandlersForEventObservationFamille(final ComboBox<Famille> combo,
			final LabelProvider<Famille> labelProvider, final String typeFam) {
		combo.addSelectionHandler(new SelectionHandler<Famille>() {
			@Override
			public void onSelection(SelectionEvent<Famille> event) {
				if( Constant.TYPE_FAMILLE_FAMILLE.equals(typeFam) ) {
					sousfamille.getStore().replaceAll(
							listFamille(false, event.getSelectedItem().getIdFamille(), Constant.TYPE_FAMILLE_SOUSFAMILLE));
					sousfamille.reset();
					sousfamille.enable();
					sousfamille.setWidth("auto");
					groupe.reset();
					groupe.disable();
					groupe.setWidth("auto");
					sousgroupe.reset();
					sousgroupe.disable();
					sousgroupe.setWidth("auto");
				}
				else {
					if( Constant.TYPE_FAMILLE_SOUSFAMILLE.equals(typeFam) ) {
						groupe.getStore().replaceAll(
								listFamille(false, event.getSelectedItem().getIdFamille(), Constant.TYPE_FAMILLE_GROUPE));
						groupe.reset();
						groupe.enable();
						groupe.setWidth("auto");
						sousgroupe.reset();
						sousgroupe.disable();
						sousgroupe.setWidth("auto");
					}
					else {
						if( Constant.TYPE_FAMILLE_GROUPE.equals(typeFam) ) {
							sousgroupe.getStore().replaceAll(
									listFamille(
											false, event.getSelectedItem().getIdFamille(), Constant.TYPE_FAMILLE_SOUSGROUPE));
							sousgroupe.reset();
							sousgroupe.enable();
							sousgroupe.setWidth("auto");
						}
					}
				}

			}
		});
	}

	private void addHandlersForEventObservationType(ComboBox<TypeElement> combo,
			final LabelProvider<TypeElement> labelProvider) {

		combo.addSelectionHandler(new SelectionHandler<TypeElement>() {
			@Override
			public void onSelection(SelectionEvent<TypeElement> event) {
				familleContainer.remove(familleLabel);
				if( Constant.TYPE_ARTICLE.equals(event.getSelectedItem().getLLibelle()) ) {
					familleContainer.remove(labeltypeprestation);
					familleContainer.add(labelfamille, new VerticalLayoutData(1, 1));
					familleContainer.add(labelsousfamille, new VerticalLayoutData(1, 1));
					familleContainer.add(labelgroupe, new VerticalLayoutData(1, 1));
					familleContainer.add(labelsousgroupe, new VerticalLayoutData(1, 1));
					disableFamilles();
					famille.getStore().replaceAll(listFamille(false, null, Constant.TYPE_FAMILLE_FAMILLE));
					famille.enable();
				}
				else {
					if( Constant.TYPE_PRESTATION.equals(event.getSelectedItem().getLLibelle()) ) {
						familleContainer.remove(labelfamille);
						familleContainer.remove(labelsousfamille);
						familleContainer.remove(labelgroupe);
						familleContainer.remove(labelsousgroupe);
						familleContainer.add(labeltypeprestation, new VerticalLayoutData(1, 1));
						disableFamilles();
						typeprestation.getStore().replaceAll(listFamille(true, null, Constant.TYPE_FAMILLE_TYPEPRESTATION));
						typeprestation.enable();
					}
				}
			}
		});
	}
	
	protected List<Famille> listFamille(boolean isPrestation, Integer parent, String typeFam) {
		List<Famille> results = null;
		if( familles != null && familles.size() > 0 ) {
			if( isPrestation ) { //prestation
				results = new LinkedList<Famille>();
				for( int i = 0 ; i < familles.size() ; i++ ) {
					Famille tmp = familles.get(i);
					if( Constant.TYPE_ELEMENT_PRESTATION.equals(tmp.getCTypeElement()) && typeFam.equals(tmp.getCTypeFamille()) ){
						if(tmp
								.getLLibelle().equals(""))
							results.add(0, tmp);
						else
							results.add(tmp);
					}
				}
			}
			else { //article
				results = new LinkedList<Famille>();
				for( int i = 0 ; i < familles.size() ; i++ ) {
					Famille tmp = familles.get(i);
					if( Constant.TYPE_ELEMENT_ARTICLE.equals(tmp.getCTypeElement()) && tmp.getIdFamilleParent() == parent && typeFam.equals(tmp.getCTypeFamille()) ) {
						if(tmp.getLLibelle().equals(""))
							results.add(0, tmp);
						else
							results.add(tmp);
					}
				}
			}
		}
		return results;
	}



	public void onLoad() {
		ClientGestionElementCompositionServiceAsync.Util.getInstance().getGestionElementCompositionReference(
				null, parent.getIdMetier(), new AsyncCallbackWithErrorResolution<GestionElementCompositionReference>() {

					@Override
					public void onSuccess(GestionElementCompositionReference result) {
						//create
						type.getStore().replaceAll(result.getTypeElements());
//						if (attributEtenduStore.getAll() != null && attributEtenduStore.getAll().size() > 0)
//							for(int i = 0; i < attributEtenduStore.getAll().size(); i++)
//								attributEtenduStore.remove(i);
						
						familles = result.getFamilles();

					}
				});
	}
	
	private void disableFamilles() {
		typeprestation.reset();
		typeprestation.disable();
		famille.reset();
		famille.disable();
		sousfamille.reset();
		sousfamille.disable();
		groupe.reset();
		groupe.disable();
		sousgroupe.reset();
		sousgroupe.disable();
	}


	private void addHandler() {

		addBeforeShowHandler(new BeforeShowHandler() {
			
			@Override
			public void onBeforeShow(BeforeShowEvent event) {
				type.reset();
				code.reset();
				libelle.reset();
				nomenclatureFournisseur.reset();
				attribut.reset();
				actif.setValue(true);
				disableFamilles();
				familleContainer.remove(labelfamille);
				familleContainer.remove(labelsousfamille);
				familleContainer.remove(labelgroupe);
				familleContainer.remove(labelsousgroupe);
				familleContainer.remove(labeltypeprestation);
				familleContainer.add(familleLabel, new VerticalLayoutData(1, 1));
				
				codeChanged = false;
				nomenclatureChanged = false;
				libelleChanged = false;
				typeChanged = false;
				familleChanged = false;
				sousfamilleChanged = false;
				groupeChanged = false;
				sousgroupeChanged = false;
				typeprestationChanged = false;
				attributChanged = false;
			}
		});
		
		addShowHandler(new ShowHandler() {
			
			@Override
			public void onShow(ShowEvent event) {
				setPixelSize(350, 415);
			}
		});
		
		annulerButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				hide();
			}
		});
		rechercherButton.addSelectHandler(new SelectHandler() {
			
			@Override
			public void onSelect(SelectEvent event) {
				parent.getEdcSearchTextField().reset();
				parent.getEdcSearchTextField().setEmptyText(messages.gestionelemcompoLeftRechavanceeencours());
				parent.setRechAvancee(true);
				if (!libelleChanged)
					libelle.setText("");
				if (!codeChanged)
					code.setText("");
				if (!nomenclatureChanged)
					nomenclatureFournisseur.setText("");
				if (!attributChanged)
					attribut.setText("");
				if (!familleChanged)
					famille.setValue(null);
				if (familleChanged && famille.getValue() == null)
					famille.setValue(findFamilleVide());
				if (!sousfamilleChanged)
					sousfamille.setValue(null);
				if (!groupeChanged)
					groupe.setValue(null);
				if (!sousgroupeChanged)
					sousgroupe.setValue(null);
				if (!typeChanged)
					type.setValue(null);
				if (!typeprestationChanged)
					typeprestation.setValue(null);
				if (typeprestationChanged && typeprestation.getValue() == null)
					typeprestation.setValue(findPrestationVide());
				parent.getEdcGrid().getLoader().load();
				hide();
			}
		});
		libelle.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if(!"".equals(libelle.getText()))
					libelleChanged = true;
			}
		});
		code.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if(!"".equals(code.getText()))
					codeChanged = true;
			}
		});
		nomenclatureFournisseur.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if(!"".equals(nomenclatureFournisseur.getText()))
					nomenclatureChanged = true;
			}
		});
		attribut.addKeyUpHandler(new KeyUpHandler() {

			@Override
			public void onKeyUp(KeyUpEvent arg0) {
				if(!"".equals(attribut.getText()))
					attributChanged = true;
			}
		});
		type.addSelectionHandler(new SelectionHandler<TypeElement>() {
			
			@Override
			public void onSelection(SelectionEvent<TypeElement> arg0) {
				typeChanged = true;
			}
		});
		famille.addSelectionHandler(new SelectionHandler<Famille>() {
			
			@Override
			public void onSelection(SelectionEvent<Famille> arg0) {
				familleChanged = true;
			}
		});
		sousfamille.addSelectionHandler(new SelectionHandler<Famille>() {
			
			@Override
			public void onSelection(SelectionEvent<Famille> arg0) {
				sousfamilleChanged = true;
			}
		});
		groupe.addSelectionHandler(new SelectionHandler<Famille>() {
			
			@Override
			public void onSelection(SelectionEvent<Famille> arg0) {
				groupeChanged = true;
			}
		});
		sousgroupe.addSelectionHandler(new SelectionHandler<Famille>() {
			
			@Override
			public void onSelection(SelectionEvent<Famille> arg0) {
				sousgroupeChanged = true;
			}
		});
		typeprestation.addSelectionHandler(new SelectionHandler<Famille>() {
			
			@Override
			public void onSelection(SelectionEvent<Famille> arg0) {
				typeprestationChanged = true;
			}
		});
	}

	public ComboBox<TypeElement> getType() {
		return type;
	}

	public void setType(ComboBox<TypeElement> type) {
		this.type = type;
	}

	public CheckBox getActif() {
		return actif;
	}

	public void setActif(CheckBox actif) {
		this.actif = actif;
	}

	public TextField getCode() {
		return code;
	}

	public void setCode(TextField code) {
		this.code = code;
	}

	public TextField getLibelle() {
		return libelle;
	}

	public void setLibelle(TextField libelle) {
		this.libelle = libelle;
	}

	public TextField getNomenclatureFournisseur() {
		return nomenclatureFournisseur;
	}

	public void setNomenclatureFournisseur(TextField nomenclatureFournisseur) {
		this.nomenclatureFournisseur = nomenclatureFournisseur;
	}

	public ComboBox<Famille> getFamille() {
		return famille;
	}

	public void setFamille(ComboBox<Famille> famille) {
		this.famille = famille;
	}

	public ComboBox<Famille> getSousfamille() {
		return sousfamille;
	}

	public void setSousfamille(ComboBox<Famille> sousfamille) {
		this.sousfamille = sousfamille;
	}

	public ComboBox<Famille> getGroupe() {
		return groupe;
	}

	public void setGroupe(ComboBox<Famille> groupe) {
		this.groupe = groupe;
	}

	public ComboBox<Famille> getSousgroupe() {
		return sousgroupe;
	}

	public void setSousgroupe(ComboBox<Famille> sousgroupe) {
		this.sousgroupe = sousgroupe;
	}

	public ComboBox<Famille> getTypeprestation() {
		return typeprestation;
	}

	public void setTypeprestation(ComboBox<Famille> typeprestation) {
		this.typeprestation = typeprestation;
	}

	public TextField getAttribut() {
		return attribut;
	}

	public void setAttribut(TextField attribut) {
		this.attribut = attribut;
	}

	public Famille findFamilleVide() {
		for( Famille fam : familles ) {
			if( fam.getLLibelle().equals("") && fam.getCTypeFamille().equals(Constant.TYPE_FAMILLE_FAMILLE) )
				return fam;
		}
		return null;
	}

	public Famille findPrestationVide() {
		for( Famille fam : familles ) {
			if( fam.getLLibelle().equals("") && fam.getCTypeFamille().equals(Constant.TYPE_FAMILLE_TYPEPRESTATION) )
				return fam;
		}
		return null;
	}
}
