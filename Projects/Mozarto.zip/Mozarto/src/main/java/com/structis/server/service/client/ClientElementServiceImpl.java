package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sencha.gxt.data.shared.SortDir;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoadResultBean;
import com.structis.client.service.ClientElementService;
import com.structis.client.widget.CustomizePagingLoadResult;
import com.structis.client.widget.CustomizePagingLoadResultBean;
import com.structis.server.core.ConstantError;
import com.structis.server.service.domain.AttributEtenduElementService;
import com.structis.server.service.domain.ElementService;
import com.structis.server.service.domain.ModelisateurRegleMessageService;
import com.structis.server.service.domain.ReferenceElementService;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.model.AttributEtenduElement;
import com.structis.shared.model.Element;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributElementModel;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ElementFormModel;
import com.structis.shared.model.reference.ElementInsertResult;
import com.structis.shared.model.reference.TreeNodeModel;

@Service("clientElementService")
public class ClientElementServiceImpl implements ClientElementService {

	@Autowired
	ElementService elementService;

	@Autowired
	AttributEtenduElementService attributEtenduElementService;

	@Autowired
	ReferenceElementService referenceElementService;

	@Autowired
	ModelisateurRegleMessageService modelisateurRegleMessageService;

	@Override
	public Element insert(Element element, List<AttributEtenduMetierERValueModel> attributEtenduMetierERValueModels,
			boolean update) {

		List<Element> elt = elementService.findByCode(element.getCElement(), element.getIdMetier());
		if( (!update && elt.size() > 0) || (update && elt.size() > 0 && !elt.get(0).getIdElement().equals(
				element.getIdElement())) ) {
			throw new FunctionalException(ConstantError.ERR_DUPLICATED);
		}
		else {
			String lNomenclatureFournisseur = element.getLNomenclatureFournisseur();
			if( lNomenclatureFournisseur != null && lNomenclatureFournisseur.length() > 0 ) {
				elt = elementService.findByNomenclatureFournisseur(lNomenclatureFournisseur, element.getIdMetier());
				if( (!update && elt.size() > 0) || (update && elt.size() > 0 && !elt.get(0).getIdElement().equals(
						element.getIdElement())) ) {
					throw new FunctionalException(ConstantError.ERR_DUPLICATED_NFOURNISSEUR);
				}
			}
			if( update ) {
				elementService.update(element);
				attributEtenduElementService.deleteByIdElement(element.getIdElement());
			}
			else {
				elementService.insert(element);
			}
			if( attributEtenduMetierERValueModels != null && attributEtenduMetierERValueModels.size() > 0 ) {
				List<AttributEtenduElement> attributEtenduElements = new ArrayList<AttributEtenduElement>();
				for( int i = 0 ; i < attributEtenduMetierERValueModels.size() ; i++ ) {
					AttributEtenduMetierERValueModel tmp = attributEtenduMetierERValueModels.get(i);
					if( tmp.getValeur() != null && !tmp.getValeur().equals("") ) {
						AttributEtenduElement attributEtenduElement = new AttributEtenduElement();
						attributEtenduElement.setIdElement(element.getIdElement());
						attributEtenduElement.setIdAttributEtendu(tmp.getIdAttributEtendu());
						attributEtenduElement.setLValeur(tmp.getValeur());
						attributEtenduElements.add(attributEtenduElement);
					}

				}
				if( attributEtenduElements.size() > 0 )
					attributEtenduElementService.insertList(attributEtenduElements);
			}
		}

		if( update )
			return element;
		return elementService.findByCode(element.getCElement(), element.getIdMetier()).get(0);
	}

	@Override
	public Element findById(Integer idElement) {
		return elementService.findById(idElement);
	}

	public CustomizePagingLoadResult<Element> loadPaging(final PagingLoadConfig loadConfig, Element element,
			String attribut, boolean rechAvancee) {
		String sortBy = "c_element";
		SortDir sortDir = SortDir.ASC;
		if( loadConfig.getSortInfo().size() > 0 ) {
			if( loadConfig.getSortInfo().get(0).getSortField().equals("lLibelleLong") ) {
				sortBy = "l_libelle_long";
			}
			else if( loadConfig.getSortInfo().get(0).getSortField().equals("lNomenclatureFournisseur") ) {
				sortBy = "l_nomenclature_fournisseur";
			}
			sortDir = loadConfig.getSortInfo().get(0).getSortDir();
		}
		if( rechAvancee ) {
			int total = elementService.findCountByCriteriaAdvanced(element, attribut);
			final List<Element> elements = elementService.findActifAndInactifByCriteriaAdvanced(
					element, attribut, loadConfig.getOffset(), loadConfig.getLimit(), sortBy, sortDir);
			CustomizePagingLoadResultBean<Element> pagingResult = new CustomizePagingLoadResultBean<Element>(
					elements, elements.size(), loadConfig.getOffset());
			pagingResult.setfinalTotal(total);
			return pagingResult;
		}
		else {
			if( element.getCElement() != null && !element.getCElement().endsWith("%%") ) {
				int total = elementService.findCountByCriteria(
						element, loadConfig.getOffset(), loadConfig.getLimit(), sortBy, sortDir);
				final List<Element> elements = elementService.findActifAndInactifByCriteria(
						element, loadConfig.getOffset(), loadConfig.getLimit(), sortBy, sortDir);
				CustomizePagingLoadResultBean<Element> pagingResult = new CustomizePagingLoadResultBean<Element>(
						elements, elements.size(), loadConfig.getOffset());
				pagingResult.setfinalTotal(total);
				return pagingResult;
			}
			else {
				int total = elementService.findCountAllElementByMetier(element.getIdMetier());
				final List<Element> elements = elementService.findAllActifAndInactifElementByMetier(
						element.getIdMetier(), loadConfig.getLimit(), sortBy, sortDir);
				//element = elements.get(0);
				CustomizePagingLoadResultBean<Element> pagingResult = new CustomizePagingLoadResultBean<Element>(
						elements, elements.size(), loadConfig.getOffset());
				pagingResult.setfinalTotal(total);
				return pagingResult;
			}
		}
	}

	@Override
	public ElementFormModel findElementFormModelByElementId(Integer idModeleVersion, Integer elementId) {
		Element element = findById(elementId);
		List<AttributElementModel> attrValues = attributEtenduElementService.findAttributEtenduByElement(elementId);
		List<MdlReferenceElement> referenceElements = referenceElementService.findByModeleVersionAndElement(
				idModeleVersion, elementId);

		ElementFormModel result = new ElementFormModel();
		result.setElement(element);
		result.setListAttributEtendu(attrValues);
		result.setListElementEntree(referenceElements);

		return result;
	}

	@Override
	public ElementFormModel findElementFormModelByElementCodeAndModelVersion(String code, Integer idModeleVersion) {
		Element element = findByCodeAndModelVersion(code, idModeleVersion);
		if( element != null ) {
			List<AttributElementModel> attrValues = attributEtenduElementService.findAttributEtenduByElement(element.getIdElement());
			List<MdlReferenceElement> referenceElements = referenceElementService.findByModeleVersionAndElement(
					idModeleVersion, element.getIdElement());
			ElementFormModel result = new ElementFormModel();
			result.setElement(element);
			result.setListAttributEtendu(attrValues);
			result.setListElementEntree(referenceElements);

			return result;
		}
		else {
			return null;
		}
	}

	public Element findByCodeAndModelVersion(String code, Integer modelVersion) {
		return elementService.findByCodeAndModelVersion(code, modelVersion);
	}

	@Override
	public void updateElement(ElementFormModel elementForm) {
		if( elementForm != null && elementForm.getListElementEntree().size() > 0 ) {
			List<MdlReferenceElement> elementList = elementForm.getListElementEntree();
			for( MdlReferenceElement relation : elementList ) {
				if( relation.isNew() ) {
					referenceElementService.insertOrIncreaseQuantity(relation);
				}
				else {
					referenceElementService.update(relation);
				}
			}
		}
	}

	@Override
	public void insertReferenceElementList(Integer nodeParentId, List<TreeNodeModel> list) {
		for( TreeNodeModel tnm : list ) {
			MdlReferenceElement re = new MdlReferenceElement();
			re.setIdElement(tnm.getId());
			re.setIdReference(nodeParentId);
			re.setIdModeleVersion(tnm.getIdModeleVersion());
			re.setNQuantite((short) 1);
			referenceElementService.insertOrIncreaseQuantity(re);
		}
	}

	@Override
	public void updateElementInRules(TreeNodeModel parentNode, ElementFormModel elementForm) {
		if( parentNode != null ) {
			if( elementForm != null && elementForm.getListElementEntree().size() > 0 ) {
				List<MdlReferenceElement> elementList = elementForm.getListElementEntree();
				for( MdlReferenceElement relation : elementList ) {
					if( relation.isNew() ) {
						if( modelisateurRegleMessageService.checkSatisfyRules(parentNode, relation.getIdElement()) ) {
							referenceElementService.insertOrIncreaseQuantity(relation);
						}
						else {
							throw new FunctionalException(ConstantError.ERR_NOT_SATISFY_RULE);
						}
					}
					else {
						referenceElementService.update(relation);
					}
				}
			}
		}
	}

	@Override
	public ElementInsertResult insertReferenceElementListInRules(TreeNodeModel parentNode, List<TreeNodeModel> list) {
		List<TreeNodeModel> existedNodes = new ArrayList<TreeNodeModel>();
		List<TreeNodeModel> conflictRulesList = new ArrayList<TreeNodeModel>();
		List<TreeNodeModel> validNodeList = new ArrayList<TreeNodeModel>();
		if( parentNode != null ) {
			for( TreeNodeModel tnm : list ) {
				if( existedInDB(parentNode.getId(), tnm) ) {
					MdlReferenceElement re = new MdlReferenceElement();
					re.setIdElement(tnm.getId());
					re.setIdReference(parentNode.getId());
					re.setIdModeleVersion(tnm.getIdModeleVersion());
					re.setNQuantite((short) 1);
					referenceElementService.insertOrIncreaseQuantity(re);
					existedNodes.add(tnm);
				}
				else if( modelisateurRegleMessageService.checkSatisfyRules(
						parentNode, tnm.getId(), tnm.getIdModeleVersion(), "E") ) {
					MdlReferenceElement re = new MdlReferenceElement();
					re.setIdElement(tnm.getId());
					re.setIdReference(parentNode.getId());
					re.setIdModeleVersion(tnm.getIdModeleVersion());
					re.setNQuantite((short) 1);
					referenceElementService.insertOrIncreaseQuantity(re);
					validNodeList.add(tnm);
				}
				else {
					conflictRulesList.add(tnm);
				}
			}
		}
		ElementInsertResult ret = new ElementInsertResult();
		ret.setNodeConflictRulesList(conflictRulesList);
		ret.setNodeExistedList(existedNodes);
		ret.setValidNodeList(validNodeList);
		return ret;
	}

	private boolean existedInDB(Integer referenceId, TreeNodeModel node) {
		return referenceElementService.isExistedRecord(node.getIdModeleVersion(), node.getId(), referenceId);
	}

	@Override
	public Element deleteById(Integer idElement) {
		Element elt = elementService.findById(idElement);
		elt.setInActif(false);
		elementService.update(elt);
		attributEtenduElementService.deleteByIdElement(idElement);
		return elt;
	}

	@Override
	public PagingLoadResult<MdlReferenceElement> loadParentPaging(Integer idElement, Integer idModelVersion, PagingLoadConfig loadConfig) {
		List<MdlReferenceElement> allReferenceElements = referenceElementService.findByModeleVersionAndElement(
				idModelVersion, idElement);
		List<MdlReferenceElement> resullist = new ArrayList<MdlReferenceElement>();
	    int start = loadConfig.getOffset();
	    int limit = allReferenceElements.size();
	    if (loadConfig.getLimit() > 0) {
	      limit = Math.min(start + loadConfig.getLimit(), limit);
	    }
	 
	    for(int i=loadConfig.getOffset(); i< limit ; i++){
	    	resullist.add(allReferenceElements.get(i));
	    }
		return new PagingLoadResultBean<MdlReferenceElement>(resullist, allReferenceElements.size(), loadConfig.getOffset());
	}

}
