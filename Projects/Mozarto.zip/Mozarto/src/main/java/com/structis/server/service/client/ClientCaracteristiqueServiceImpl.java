package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoadResultBean;
import com.structis.client.service.ClientCaracteristiqueService;
import com.structis.server.service.domain.CaracteristiqueService;
import com.structis.server.service.domain.ModeleService;
import com.structis.server.service.domain.ReferenceService;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.reference.CarateristiqueFormModel;
import com.structis.shared.model.reference.TreeNodeModel;

@Service
public class ClientCaracteristiqueServiceImpl implements ClientCaracteristiqueService {
	
	@Autowired
	CaracteristiqueService caracteristiqueService;
	
	@Autowired
	ReferenceService referenceService;
	
	@Autowired
	ModeleService modelService;
	
	@Override
	public MdlCaracteristique findById(Integer idCaracteristique) {
		return caracteristiqueService.findById(idCaracteristique);
	}

	@Override
	public void updateCaracteristique(MdlCaracteristique record,Integer metierId) {
		caracteristiqueService.updateCaracteristique(record, metierId);
	}

	@Override
	public CarateristiqueFormModel findCarateristiqueFormReferenceById(Integer idCaracteristique) {
		CarateristiqueFormModel result = new CarateristiqueFormModel();
		MdlCaracteristique carac = caracteristiqueService.findById(idCaracteristique);
		result.setCaracteristique(carac);
		List<TreeNodeModel> listElementEntree = new ArrayList<TreeNodeModel>();
		//List<TreeNodeModel> listElementSortie = new ArrayList<TreeNodeModel>();
		if(carac.getIdCaracteristiqueParent() != null){
			MdlCaracteristique caracParent = caracteristiqueService.findById(carac.getIdCaracteristiqueParent());
			
			TreeNodeModel node = createTreeNodeModel(caracParent.getIdCaracteristique(),caracParent.getLLibelleLong(),ModelNodeType.CARACTERISTIQUE);
			listElementEntree.add(node);			
		}
		/*List<MdlCaracteristique> caracChildren = caracteristiqueService.findCaracteristiqueByIdModeleVersion(carac.getIdModeleVersion(), carac.getIdCaracteristique());
		
		List<MdlReference> referenceChidren = referenceService.findReferenceByModeleVersionAndCaracteristique(carac.getIdModeleVersion(), carac.getIdCaracteristique());
		
		if(caracChildren != null && caracChildren.size()>0){
			for(MdlCaracteristique c:caracChildren){
				TreeNodeModel node = createTreeNodeModel(c.getIdCaracteristique(),c.getLLibelleLong(),ModelNodeType.CARACTERISTIQUE);
				listElementSortie.add(node);
			}
		}
		if(referenceChidren != null && referenceChidren.size()>0){
			for(MdlReference r:referenceChidren){
				TreeNodeModel node = createTreeNodeModel(r.getIdReference(), r.getLLibelleLong(), ModelNodeType.REFERENCE);
				listElementSortie.add(node);
			}
		}*/
		result.setListElementEntree(listElementEntree);
		//result.setListElementSortie(listElementSortie);
		
		return result;
	}
	private TreeNodeModel createTreeNodeModel(Integer id, String libelle, ModelNodeType nodeType){
		TreeNodeModel node = new TreeNodeModel();
		node.setId(id);
		node.setLibelle(libelle);
		node.setModelType(nodeType);
		return node;
	}

	@Override
	public Integer insert(MdlCaracteristique record, Integer metierId, Integer utilisatuerId) {		
		caracteristiqueService.insert(record, metierId, utilisatuerId);
		return record.getIdCaracteristique();
	}

	@Override
	public MdlCaracteristique findByIdModele(Integer idModele) {
		MdlCaracteristique findByIdModele = caracteristiqueService.findByIdModele(idModele);
		return findByIdModele;
	}
	
	@Override
	public void remove(MdlCaracteristique record) {
		caracteristiqueService.remove(record);
	}

	@Override
	public Integer insertOrUpdate(Integer utilisatuerId,Integer metierId, MdlCaracteristique record) {
		modelService.updateModifiedBy(utilisatuerId, record.getIdModeleVersion());
		if (record.getIdCaracteristique() != null) {
			//updateCaracteristique(record,metierId);
			caracteristiqueService.updateCaracteristique(record, metierId);
		} else {					
			insert(record, metierId, utilisatuerId);
		}
		return record.getIdCaracteristique();
	}

	@Override
	public PagingLoadResult<TreeNodeModel> loadChildrenPaging(Integer idModeleVersion, Integer idCaracteristique,
			PagingLoadConfig loadConfig) {
		List<TreeNodeModel> allElementSortie = new ArrayList<TreeNodeModel>();
		
		List<MdlCaracteristique> caracChildren = caracteristiqueService.findCaracteristiqueByIdModeleVersion(idModeleVersion, idCaracteristique);
		
		List<MdlReference> referenceChidren = referenceService.findReferenceByModeleVersionAndCaracteristique(idModeleVersion, idCaracteristique);
		
		if(caracChildren != null && caracChildren.size()>0){
			for(MdlCaracteristique c:caracChildren){
				TreeNodeModel node = createTreeNodeModel(c.getIdCaracteristique(),c.getLLibelleLong(),ModelNodeType.CARACTERISTIQUE);
				allElementSortie.add(node);
			}
		}
		if(referenceChidren != null && referenceChidren.size()>0){
			for(MdlReference r:referenceChidren){
				TreeNodeModel node = createTreeNodeModel(r.getIdReference(), r.getLLibelleLong(), ModelNodeType.REFERENCE);
				allElementSortie.add(node);
			}
		}
		
		List<TreeNodeModel> resullist = new ArrayList<TreeNodeModel>();
	    int start = loadConfig.getOffset();
	    int limit = allElementSortie.size();
	    if (loadConfig.getLimit() > 0) {
	      limit = Math.min(start + loadConfig.getLimit(), limit);
	    }
	 
	    for(int i=loadConfig.getOffset(); i< limit ; i++){
	    	resullist.add(allElementSortie.get(i));
	    }
		return new PagingLoadResultBean<TreeNodeModel>(resullist, allElementSortie.size(), loadConfig.getOffset());
	}


}
