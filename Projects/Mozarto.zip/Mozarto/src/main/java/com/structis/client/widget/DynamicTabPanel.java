package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.widget.core.client.Component;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.TabItemConfig;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.BeforeCloseEvent;
import com.sencha.gxt.widget.core.client.event.BeforeCloseEvent.BeforeCloseHandler;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.structis.client.event.GestionElementCompositionDisableElementEvent;
import com.structis.client.event.GestionElementCompositionDisableElementHandler;
import com.structis.client.event.GestionElementCompositionRenameElementEvent;
import com.structis.client.event.GestionElementCompositionRenameElementHandler;
import com.structis.client.event.GestionMetierRenameMetierEvent;
import com.structis.client.event.GestionMetierRenameMetierHandler;
import com.structis.client.event.GestionUtilisateurRenameUtilisateurEvent;
import com.structis.client.event.GestionUtilisateurRenameUtilisateurHandler;
import com.structis.client.event.ModifyEvent;
import com.structis.client.event.RenameTreeNodeEvent;
import com.structis.client.event.RenameTreeNodeHandler;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.panel.AbstractModelisateurEditForm;
import com.structis.client.panel.GestionDesUtilisateursForm;
import com.structis.client.panel.ModelisateurCaracteristiqueForm;
import com.structis.client.panel.ModelisateurElementForm;
import com.structis.client.panel.ModelisateurReferenceForm;
import com.structis.client.panel.NavigationModelisateurForm;
import com.structis.client.panel.admin.GestionDesElementDeCompositionForm;
import com.structis.client.panel.admin.GestionDesMetiersForm;
import com.structis.client.panel.admin.GestionDesUtilisateursAdminForm;

public class DynamicTabPanel extends VerticalLayoutContainer {
	private SimpleEventBus bus;
	private TabPanel tabPanel;
	private int numberTabs = 0;
	private final Messages messages = GWT.create(Messages.class);
	private NavigationService navigation = NavigationFactory.getNavigation();
	public DynamicTabPanel(SimpleEventBus thebus) {
		this.bus = thebus;
		setBorders(false);
		addStyleName("whiteBackGround");
		tabPanel = new TabPanel();		
		tabPanel.setAnimScroll(true);
		tabPanel.setTabScroll(true);
		tabPanel.setCloseContextMenu(true);	
		tabPanel.getElement().getStyle().setProperty("border", "0px");
		add(tabPanel,new VerticalLayoutData(1,1));
		numberTabs++;
		tabPanel.setVisible(false);
		
		
		
		addHandlers();
	}

	private void addHandlers() {		
		bus.addHandler(RenameTreeNodeEvent.getType(), new RenameTreeNodeHandler() {
			@Override
			public void onLoad(RenameTreeNodeEvent event) {				
				NavigationModelisateurForm tabItem = (NavigationModelisateurForm) getTabPanel().findItem(
						event.getTabId(), false);	
				tabPanel.update(tabItem,  new TabItemConfig(event.getNewLabel(), true));							
			}
		});		
		bus.addHandler(GestionElementCompositionRenameElementEvent.getType(), new GestionElementCompositionRenameElementHandler() {
			@Override
			public void onLoad(GestionElementCompositionRenameElementEvent event) {				
				GestionDesElementDeCompositionForm form = (GestionDesElementDeCompositionForm) getTabPanel().findItem(
						event.getTabId(), false);	
				tabPanel.update(form,  new TabItemConfig(event.getNewLabel(), true));							
			}
		});		
		bus.addHandler(GestionMetierRenameMetierEvent.getType(), new GestionMetierRenameMetierHandler() {
			@Override
			public void onLoad(GestionMetierRenameMetierEvent event) {				
				GestionDesMetiersForm form = (GestionDesMetiersForm) getTabPanel().findItem(
						event.getTabId(), false);	
				tabPanel.update(form,  new TabItemConfig(event.getNewLabel(), true));							
			}
		});
		bus.addHandler(GestionUtilisateurRenameUtilisateurEvent.getType(), new GestionUtilisateurRenameUtilisateurHandler() {
			
			@Override
			public void onLoad(GestionUtilisateurRenameUtilisateurEvent event) {
				GestionDesUtilisateursAdminForm form = (GestionDesUtilisateursAdminForm) getTabPanel().findItem(
						event.getTabId(), false);	
				tabPanel.update(form,  new TabItemConfig(event.getNewLabel(), true));	
			}
		});
			
		bus.addHandler(GestionElementCompositionDisableElementEvent.getType(), new GestionElementCompositionDisableElementHandler() {
			
			@Override
			public void onLoad(GestionElementCompositionDisableElementEvent event) {
				if (event.getTabLabel() != null){
					GestionDesElementDeCompositionForm form = getFormByLabel(event.getTabLabel());
					if(form != null){
						form.getActif().setValue(false);
						form.enableButtons(true);
					}
				}
				else if (event.getIdElement() != null){
					GestionDesElementDeCompositionForm form = getFormByIdElement(event.getIdElement());
					form.getActif().setValue(false);
					form.enableButtons(true);
//					if (form !=null && form.isChanged()){
//						MessageBox messageBox = new MessageBox(messages.commonInfoHeader(), messages.gestionelemcompoLeftDesactiverinfo());
//						messageBox.getButtonById(PredefinedButton.OK.name()).setText("Fermer");
//						messageBox.show();
//					}
//					else {
//						bus.fireEvent(new DisableElementPossibleEvent(event.getIdElement()));
//					}
				}
				
			}
		});
		tabPanel.addBeforeCloseHandler(new BeforeCloseHandler<Widget>() {
			@Override
			public void onBeforeClose(final BeforeCloseEvent<Widget> eventTab) {
				boolean isChanged = true;
				
				String confirmMessage = null;
				
				Object obj = tabPanel.getWidget(tabPanel.getWidgetIndex(eventTab.getItem()));
				
				if (obj instanceof NavigationModelisateurForm) {					
					String itemName = "";
					if (!((NavigationModelisateurForm) obj).isChanged()) {
						isChanged = false;
					} else {						
						Object detailTab = ((NavigationModelisateurForm) obj).getDetailForm();
						if (detailTab instanceof ModelisateurCaracteristiqueForm) {							
							itemName = messages.modelisateurCaracteristiqueLabel();
						} else if (detailTab instanceof ModelisateurReferenceForm) {
							itemName = messages.modelisateurReferenceLabel();
						} else {
							itemName = messages.modelisateurElementLabel();
						}
						confirmMessage = messages.modelisateurConfirmationCloseTab(itemName);
					}
				} else {
					 confirmMessage = messages.commonConfirmationClosetab();
				}
				if (obj instanceof GestionDesElementDeCompositionForm){
					if (! ((GestionDesElementDeCompositionForm)obj).isChanged())
						isChanged = false;
				}
				if (obj instanceof GestionDesMetiersForm){
					if (! ((GestionDesMetiersForm)obj).isChanged())
						isChanged = false;
				}
				if(obj instanceof GestionDesUtilisateursForm){
					if(! ((GestionDesUtilisateursForm)obj).isChanged())
						isChanged = false;
				}
				if(obj instanceof GestionDesUtilisateursAdminForm){
					if(! ((GestionDesUtilisateursAdminForm)obj).isChanged())
						isChanged = false;
				}
					
				if (isChanged) {					
					eventTab.setCancelled(true);
					final ConfirmMessageBox confirmBox = new ConfirmMessageBox(
							messages.commonConfirmation(), confirmMessage);
					confirmBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
					confirmBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
					confirmBox.addHideHandler(new HideHandler() {
						public void onHide(HideEvent event) {
							if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {								
								eventTab.setCancelled(false);
								tabPanel.remove(tabPanel.getWidgetIndex(eventTab.getItem()));
								numberTabs--;
								navigation.getBus().fireEvent(new ModifyEvent(true));
							}
							else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {								
							}
							
						}
					});
					confirmBox.show();
					
				}
				if (obj instanceof NavigationModelisateurForm) {		
					AbstractModelisateurEditForm detailTab = ((NavigationModelisateurForm) obj).getDetailForm();
					detailTab.prepareCloseTab();
				}
				((Component)obj).clearSizeCache();
			}
			
		});
		tabPanel.addSelectionHandler(new SelectionHandler<Widget>() {
			
			@Override
			public void onSelection(SelectionEvent<Widget> arg0) {
				if (arg0.getSelectedItem() instanceof NavigationModelisateurForm){
					AbstractModelisateurEditForm form = ((NavigationModelisateurForm) arg0.getSelectedItem()).getDetailForm();
					if (form instanceof ModelisateurElementForm){
						((ModelisateurElementForm)form).reloadGridEds();
					}
				}
			}
		});
	}

	public void addItem(Widget widget, String label) {

		if( !tabPanel.isVisible() ) {
			tabPanel.setVisible(true);
		}
		if( tabPanel.getWidgetCount() >= 5 ) {
			MessageBox messageBox = new MessageBox(messages.commonInfoHeader(), messages.modelisateurFormMaximuntabMessage());
			messageBox.getButtonById(PredefinedButton.OK.name()).setText("Fermer");
			messageBox.show();
		}
		tabPanel.add(widget, new TabItemConfig(label, true));
		
		tabPanel.setActiveWidget(widget);
		forceLayout();
	}
	
	public GestionDesElementDeCompositionForm getFormByLabel(String label) {
		for (int i = 0; i < tabPanel.getWidgetCount(); i++){
			Object tmp = tabPanel.getWidget(i);
			if (tmp instanceof GestionDesElementDeCompositionForm){
				GestionDesElementDeCompositionForm form = (GestionDesElementDeCompositionForm) tmp;
				if (form.getLabel().equals(label)){

					return form;
				}
			}
		}
		return null;
	}
	
	public GestionDesElementDeCompositionForm getFormByIdElement(Integer idElement) {
		for (int i = 0; i < tabPanel.getWidgetCount(); i++){
			Object tmp = tabPanel.getWidget(i);
			if (tmp instanceof GestionDesElementDeCompositionForm){
				GestionDesElementDeCompositionForm form = (GestionDesElementDeCompositionForm) tmp;
				if (form.getIdElement() != null && form.getIdElement().equals(idElement)){
					return form;
				}
			}
		}
		return null;
	}
	
	public NavigationModelisateurForm getTabByIdNodeAndType(Integer id, String type) {
		for (int i = 0; i < tabPanel.getWidgetCount(); i++){
			Object tmp = tabPanel.getWidget(i);
			if (tmp instanceof NavigationModelisateurForm){
				NavigationModelisateurForm form = (NavigationModelisateurForm) tmp;
				if (id != null && form.getCurrentItem().getId() != null  && form.getCurrentItem().getId().equals(id) && type.equals(form.getCurrentItem().getModelType().getLabel())){
					return form;
				}
			}
		}
		return null;
	}
	public TabPanel getTabPanel(){
		return tabPanel;
	}

	public int getNumberTabs() {
		return numberTabs;
	}

	public void setNumberTabs(int numberTabs) {
		this.numberTabs = numberTabs;
	}
	public void closeAll(){
		int totalTab = tabPanel.getWidgetCount();
		for(int i=0; i< totalTab;i++){
			//tabPanel.getWidget(i);
			if(tabPanel.getWidget(i) != null){
				tabPanel.remove(tabPanel.getWidget(i));
			}
		}
		
	}
}
