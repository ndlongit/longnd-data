package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlLienReference;

public interface LienReferenceService {
	/**
	 * return list of MdlLienReference from idReference
	 * @param idModeleVersion
	 * @param idReference
	 * @return
	 */
	MdlLienReference findLienReferenceByReference(int idModeleVersion, int idReference);
	
	List<Integer> findIdCommunsByCarateristique(int idModeleVersion,List<Integer> idCarateristiques);
	
	int insert(MdlLienReference record);
	/**
	 * find list idLienCoummun by list idReferences
	 * @param idModeleVersion
	 * @param idReferences
	 * @return
	 */
	List<Integer> findByIdReferences(int idModeleVersion,List<Integer> idReferences);
	
	void deleteByIdLienCommuns(int idModeleVersion,List<Integer> idLienCommuns);
	
	List<MdlLienReference> findIncludeReferenceByIdLienCommuns(int idModeleVersion,List<Integer> idLienCommuns);
}
