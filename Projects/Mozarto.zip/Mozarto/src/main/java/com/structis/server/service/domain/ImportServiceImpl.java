package com.structis.server.service.domain;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.constant.ConstantServer;
import com.structis.server.persistence.ImportMapper;
import com.structis.shared.model.Import;

@Service(ImportService.SERVIECE_NAME)
public class ImportServiceImpl implements ImportService {

	@Autowired
	private ImportMapper mapper;
	
	@Autowired
	ImportElementService importElementService;

	@Autowired
	ImportElementErrorService importElementErrorService;

	@Override
	public Import findById(Integer id) {
		return mapper.findById(id);
	}

	@Override
	public Integer insert(Import record) {
		return mapper.insert(record);
	}

	@Override
	@Transactional
	public Integer update(Import record) {
		return mapper.update(record);
	}

	@Override
	public Integer delete(Import record) {
		return mapper.delete(record);
	}

	@Override
	public Integer deleteById(Integer id) {
		return mapper.deleteById(id);
	}

	@Override
	public List<Import> findAll() {
		return mapper.findAll();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Import> findByCriteria(String importType, List<String> statusList) {
		Map mapParameter = new HashMap();

		mapParameter.put("importType", importType);
		mapParameter.put("statusList", statusList);
		return mapper.findByImportTypeAndStatus(mapParameter);
	}

	@Override
	public List<Import> findIdsByImportType(String typeImport) {
		return mapper.findByImportType(typeImport);
	}
	
	@Override
	public Import insertNewImportItem(Integer metierId, Integer userId, String importType) {
		//Insert new record into mz_sas_import table
		Import newImport = new Import();
		newImport.setCEtatImport(ConstantServer.IMPORT_SAS_BEGIN);
		newImport.setCTypeImport(importType);
		newImport.setDDateheureCrea(new Date());
		newImport.setIdModeleVersion(null);
		newImport.setIdUtilisateurCrea(userId);
		newImport.setIdMetier(metierId);

		insert(newImport);
		return newImport;
	}

	@Override
	public void deletePreviousImportedData(int importId) {
		mapper.deleteImportedData(importId);
	}
}
