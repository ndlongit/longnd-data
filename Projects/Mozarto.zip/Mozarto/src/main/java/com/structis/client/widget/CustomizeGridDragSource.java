package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.sencha.gxt.dnd.core.client.DndDropEvent;
import com.sencha.gxt.dnd.core.client.GridDragSource;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.client.message.Messages;

public class CustomizeGridDragSource<M> extends GridDragSource<M> {
	
	private final Messages messages = GWT.create(Messages.class);

	public CustomizeGridDragSource(Grid<M> grid) {
		super(grid);
	}

	@Override
	protected void onDragDrop(DndDropEvent event) {
		
	}
	protected class DefaultGridDragSourceMessages implements GridDragSourceMessages {

		@Override
		public String itemsSelected(int items) {
			if (items < 2)
				return messages.commonElemcompogridDragdropSelectioneditem();
			else {
				return messages.commonElemcompogridDragdropSelectioneditems(items);
			}
		}

	}

	@Override
	public GridDragSourceMessages getMessages() {
		return new DefaultGridDragSourceMessages();
	}
}
