package com.structis.server.service.domain;

import java.util.List;
import java.util.Map;

import org.springframework.context.support.ResourceBundleMessageSource;

import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.reference.ValuePlaceHolder;

public interface CaracteristiqueService {
	/**
	 * find caracteristeque by id
	 * 
	 * @param id
	 * @return
	 */
	public MdlCaracteristique findById(Integer idCaracteristique);
	public MdlCaracteristique findByIdModele(Integer idModele);

	/**
	 * @param record
	 */
	public void updateCaracteristique(MdlCaracteristique record,Integer idMetier);

	/**
	 * find Caracteristique by IdModeleVersion
	 * 
	 * @param id
	 * @return list Caracteristique
	 */
	public List<MdlCaracteristique> findCaracteristiqueByIdModeleVersion(Integer idModeleVersion,
			Integer idCaracteristiqueParent);

	/**
	 * find number of children of Caracteristique by IdModeleVersion under Caracteristique Parent
	 * 
	 * @param idModeleVersion
	 * @param idCaracteristiqueParent
	 * @return list Caracteristique
	 */
	public List<ValuePlaceHolder> findChildrenNumberCaracteristiqueByIdModeleVersion(Integer idModeleVersion,
			Integer idCaracteristiqueParent);

	/**
	 * find number of Reference of Caracteristique by IdModeleVersion under Caracteristique Parent
	 * 
	 * @param idModeleVersion
	 * @param idCaracteristiqueParent
	 * @return
	 */
	public List<ValuePlaceHolder> findReferenceNumberOfCaracteristiqueByModeleVersionAndCaracteristiqueParent(
			Integer idModeleVersion, Integer idCaracteristiqueParent);

	/**
	 * find number of Caracteristique by ModeleVersion,CaracteristiqueParent and Libelle
	 * 
	 * @param idModeleVersion
	 * @param idCaracteristiqueParent
	 * @param lLibelle
	 * @return
	 */
	public int findCaracteristiqueNumberByModeleVersionCaracteristiqueParentAndLibelle(Integer idModeleVersion,
			String lLibelle, Integer idCaracteristique);

	/**
	 * this use to find all the caracteristique parent of reference
	 * 
	 * @param idModeleVersion
	 * @param idReference
	 * @return
	 */
	public List<MdlCaracteristique> findCaracteristiqueByModeleVersionAndReference(Integer idModeleVersion,
			Integer idReference);
	/**
	 * find all children of carateritque
	 * @param idParent
	 * @return
	 */
	public List<MdlCaracteristique> findByHierarchy(Integer idModeleVersion);
	
	/**
	 * 
	 * @param idParent
	 * @return
	 */
	public List<Integer> findIdChidrensHierarchy(Integer idParent);
	
	/**
	 * find all distinct parent of children list ,example wiht idChildrenList=1,2..
	 * @param listChildren
	 * @return list of idCarateristque
	 */
	public List<Integer> findIdParentsHierarchy(String idChildren);
	
	/**
	 * 
	 * @param idModeleVersion
	 * @param idLienCommun
	 * @return
	 */
	public MdlCaracteristique findByIdLienCommun(Integer idModeleVersion, Integer idLienCommun);
	
	public void insert(MdlCaracteristique record);
	public void insert(MdlCaracteristique record, Integer idMetier, Integer idUser);

	List<MdlCaracteristique> findByBaseCriteria(MdlCaracteristique criteria);

	public void remove(MdlCaracteristique record);
	
	List<MdlCaracteristique> findByModelVersionAndLabelList(Integer modelVersionId, List<String> labelList);
	
	void deleteByIds(List<Integer> idCaracteristiques);
	
	List<MdlCaracteristique> findCharacteristicHierarchyByLevel(Integer modelVersion, Integer level, String label);
	
	List<MdlCaracteristique> findCharacteristicHierarchy(Integer modelVersion);

	void importCharacteristicsToMozarto(Integer importId, Integer modelVersion, List<String[]> csvData,
			Map<Integer, List<Integer>> dataColumnIndexes, ResourceBundleMessageSource messageSource, Integer userId) throws Exception;
	
	public MdlCaracteristique getRootNode(Integer idModelVersion);
	
	List<Integer> findNodesBeforeLastNode(Integer modelVersion);
	
	List<String> getCharacteristicNamesOrderByLevelAndRang(Integer modelVersion, List<String> labelList);
	
	List<MdlCaracteristique> findByCompositionId(Integer compositionId);
	
	List<MdlCaracteristique> findCaracteristiqueChildrenHierarchy(Integer idParent);
	
	List<String> findLibelleInList(List<String> list, Integer idModeleVersion);
}
