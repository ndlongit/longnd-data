package com.structis.server.service.exportcsv;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.structis.server.core.SpringGetter;
import com.structis.server.service.domain.CarateristiqueReferenceService;
import com.structis.server.service.domain.ReferenceElementService;
import com.structis.server.service.domain.ReferenceService;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.Famille;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ReferenceAttributsCaracteristiquesElementsModel;
import com.structis.shared.model.reference.SousReferenceModel;

@SuppressWarnings("serial")
public class ExportSousReferencesServlet extends RemoteServiceServlet {
	public final static String FILE_NAME = "Mozarto";

	public final static String FILE_TYPE = ".csv";

	@Autowired
	ReferenceService referenceService;

	@Autowired
	CarateristiqueReferenceService carateristiqueReferenceService;

	@Autowired
	ReferenceElementService referenceElementService;

	protected SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-HHmmss");

	protected List<Famille> allFamilles;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		referenceService = (ReferenceService) SpringGetter.getBean(getServletContext(), "referenceService");
		referenceElementService = (ReferenceElementService) SpringGetter.getBean(
				getServletContext(), "referenceElementService");
		carateristiqueReferenceService = (CarateristiqueReferenceService) SpringGetter.getBean(
				getServletContext(), "carateristiqueReferenceService");

	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {

			String idModeleVersion = request.getParameter(Constant.CARACTERISTIQUE_IDMODELEVERSION_STR);
			String libelleMetier = request.getParameter(Constant.LIBELLE_METIER);
			int timezoneOffsetClient = Integer.parseInt(request.getParameter(Constant.CLIENT_TIMEZONEOFFSET));
			TimeZone timeZone = TimeZone.getTimeZone("GMT");
			timeZone.setRawOffset((int) (timezoneOffsetClient * DateUtils.MILLIS_PER_MINUTE));
			sdf.setTimeZone(timeZone);

			String filename = FILE_NAME + "_" + libelleMetier + "_Sous-References_" + sdf.format(Calendar.getInstance().getTime()) + FILE_TYPE;

			Integer idMetier = Integer.parseInt(request.getParameter(Constant.ID_METIER));

			List<SousReferenceModel> references = referenceService.findAllSousReferenceByIdModeleVersion(Integer.valueOf(idModeleVersion));

			List<ReferenceAttributsCaracteristiquesElementsModel> referenceAttributsCaracteristiquesElementsModels = new ArrayList<ReferenceAttributsCaracteristiquesElementsModel>();

			int numAttr = 0;
			
			int numCaractMax = 0;
			
			int numElemMax = 0;

			for( SousReferenceModel ref : references ) {
				ReferenceAttributsCaracteristiquesElementsModel tmp = new ReferenceAttributsCaracteristiquesElementsModel();
				List<AttributEtenduMetierERValueModel> attributEtenduMetierERValueModels = referenceService.findAttributEtenduMetierERValueByIdAndMetier(
						ref.getIdModeleVersion(), ref.getIdReference(), idMetier);
				List<MdlCarateristiqueReference> carateristiqueReferences = carateristiqueReferenceService.findByModeleVersionAndReference(
						ref.getIdModeleVersion(), ref.getIdReference());
				if (numCaractMax < carateristiqueReferences.size())
					numCaractMax = carateristiqueReferences.size();
				List<MdlReferenceElement> referenceElements = referenceElementService.findByModeleVersionAndReference(ref.getIdModeleVersion(), ref.getIdReference());
				if (numElemMax < referenceElements.size())
					numElemMax = referenceElements.size();
				numAttr = attributEtenduMetierERValueModels.size();
				tmp.setReference(ref);
				tmp.setAttributEtenduMetierERValueModels(attributEtenduMetierERValueModels);
				tmp.setCaracteristiques(carateristiqueReferences);
				tmp.setReferenceElements(referenceElements);
				referenceAttributsCaracteristiquesElementsModels.add(tmp);
			}
			for (ReferenceAttributsCaracteristiquesElementsModel tmp : referenceAttributsCaracteristiquesElementsModels){
				tmp.setNumCaractMax(numCaractMax);
				tmp.setNumElemtMax(numElemMax);
			}
			ExportSousReferences exportReferences = new ExportSousReferences();
			exportReferences.setReferenceList(referenceAttributsCaracteristiquesElementsModels);
			Writer writer = exportReferences.export(getServletContext().getRealPath(filename), numAttr, numCaractMax, numElemMax);
			PrintWriter printWriter = new PrintWriter(writer);
			printWriter.flush();
			printWriter.close();
			FileInputStream fileToDownload = new FileInputStream(
					getServletContext().getRealPath(filename));
			response.setContentType("application/msexcel");
			response.setHeader("Content-Disposition",
					"attachment; filename=" + filename);
			response.setContentLength(fileToDownload.available());
			int c;
			ServletOutputStream output = response.getOutputStream();
			while ((c = fileToDownload.read()) != -1) {
				output.write(c);
			}

		}
		catch( Exception e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
}
