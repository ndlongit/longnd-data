package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.MdlReferenceElementKey;

public interface ReferenceElementService {
	List<MdlReferenceElement> findByModeleVersionAndReference(Integer idModeleVersion, Integer idReference);

	void update(MdlReferenceElement referenceElement);

	List<MdlReferenceElement> findByModeleVersionAndElement(Integer idModeleVersion, Integer idElement);

	void insert(MdlReferenceElement relation);

	void insertOrIncreaseQuantity(MdlReferenceElement re);
	
	void insertList(List<MdlReferenceElement> list);
	
	void deleteByReferenceIdAndModelVersionId(Integer idReference, Integer modeleVersion);

	void deleteByIdModeleVersionAndIdReferences(Integer idModeleVersion, List<Integer> idReferences);
	
	void deleteById(MdlReferenceElementKey key);
	
	void deleteSousElementsByIdElementAndIdReferences(Integer idModeleVersion,Integer idElment, Integer idReferences);

	boolean isExistedRecord(
			Integer idModeleVersion, Integer elementId, Integer referenceId);
	
	void deleteByReferenceIdsAndElementIds(Integer idModeleVersion, List<Integer> idReferences, List<Integer> elementIds);
		
}
