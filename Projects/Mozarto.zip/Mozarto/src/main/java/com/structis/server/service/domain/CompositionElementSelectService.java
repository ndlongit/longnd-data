package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.CmpElementSelect;

public interface CompositionElementSelectService {
	void insertList(List<CmpElementSelect> cmpElementSelects);
	
	void deleteByIdComposition(Integer idComposition);
}
