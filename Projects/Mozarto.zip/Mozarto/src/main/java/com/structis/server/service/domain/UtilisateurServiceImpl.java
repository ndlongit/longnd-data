package com.structis.server.service.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.UtilisateurMapper;
import com.structis.shared.model.Utilisateur;

@Service
public class UtilisateurServiceImpl implements UtilisateurService {
	
	@Autowired
	UtilisateurMapper utilisateurMapper;
	
	@Override
	public Utilisateur findUtilisateurById(Integer idUtilisateur) {
		return utilisateurMapper.findById(idUtilisateur);
	}

	@Override
	public Utilisateur findUtilisateurByAccount(String cUtilisateur) {
		return utilisateurMapper.findByCUtilisateur(cUtilisateur);
	}

	@Override
	public List<Utilisateur> findAll() {
		return utilisateurMapper.findAll();
	}

	@Override
	public List<Utilisateur> findAllByMetier(Integer idMetier) {
		return utilisateurMapper.findAllByMetier(idMetier);
	}

	@Override
	public List<Utilisateur> findAllPegaz() {
		return utilisateurMapper.findAllPegaz();
	}

	@Override
	public List<Integer> findAllIdUtilisateur() {
		return utilisateurMapper.findAllIdUtilisateur();
	}

	@Override
	public int update(Utilisateur u) {
		return utilisateurMapper.update(u);
	}

	@Override
	public int insert(Utilisateur u) {
		return utilisateurMapper.insert(u);
	}

}
