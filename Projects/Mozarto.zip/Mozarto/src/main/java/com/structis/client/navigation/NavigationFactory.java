package com.structis.client.navigation;

/**
 * Class manufacturing NavigationManager
 *
 */
public class NavigationFactory {
	
	private static NavigationManager instance = new NavigationManager();

	public static NavigationService getNavigation() {
		return instance;
	}

}
