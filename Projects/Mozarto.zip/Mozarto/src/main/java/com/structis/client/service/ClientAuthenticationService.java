package com.structis.client.service;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.structis.shared.config.ApplicationContext;
import com.structis.shared.model.Metier;
/**
 * The client side stub for the RPC service.
 */
@RemoteServiceRelativePath("springGwtServices/clientAuthenticationService")
public interface ClientAuthenticationService extends RemoteService {
	ApplicationContext getCurrentLogin();
	
	ApplicationContext login(String userName, String passWord, Integer idMetier);
	
	ApplicationContext changeMetier(Integer metierId);
	
	void logout();
	
	List<Metier> getAllMetier();
}
