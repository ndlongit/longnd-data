package com.structis.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.Metier;

public interface MetierProperties extends PropertyAccess<Metier> {
	@Path("idMetier")
	ModelKeyProvider<Metier> idMetier();

	@Path("lLibelle")
	LabelProvider<Metier> nameLabel();

	ValueProvider<Metier, String> lLibelle();

	ValueProvider<Metier, Boolean> inActif();
}
