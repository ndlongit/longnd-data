package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.structis.client.message.Messages;

public class CustomizeConfirmMessageBox extends ConfirmMessageBox {
	private final Messages messages = GWT.create(Messages.class);
	public CustomizeConfirmMessageBox(String title, String message) {
		super(title, message);
		setWidth(300);
		getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
		getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
	}

}
