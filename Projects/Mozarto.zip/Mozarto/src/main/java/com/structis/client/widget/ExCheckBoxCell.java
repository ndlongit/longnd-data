package com.structis.client.widget;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.sencha.gxt.cell.core.client.AbstractEventCell;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.HasSelectHandlers;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.image.Images;
import com.structis.shared.constant.Niveau;
import com.structis.shared.model.reference.CompositionReferenceGridModel;

public abstract class ExCheckBoxCell extends AbstractEventCell<CompositionReferenceGridModel> implements HasSelectHandlers  {
		
	/*interface Templates extends SafeHtmlTemplates {
		@SafeHtmlTemplates.Template("<div name=\"{0}\" style=\"{1}\">{2}</div>")
		SafeHtml cell(String name, SafeStyles styles, SafeHtml value);
	}*/
	//private static Templates templates = GWT.create(Templates.class);
	private static final SafeHtml INPUT_CHECKED = makeImage(Images.RESOURCES.checkIcon());
	private static final SafeHtml INPUT_UNCHECKED = makeImage(Images.RESOURCES.uncheckIcon());
	private static final SafeHtml INPUT_CHECKED_DISABLE = makeImage(Images.RESOURCES.checkDisabledIcon());
	private static final SafeHtml INPUT_UNCHECKED_DISABLE = makeImage(Images.RESOURCES.uncheckDisabledIcon());
	
	public ExCheckBoxCell() {
		super("click", "keydown");			
	}

	@Override
	public void onBrowserEvent(com.google.gwt.cell.client.Cell.Context context,
	Element parent, CompositionReferenceGridModel value, NativeEvent event,
	com.google.gwt.cell.client.ValueUpdater<CompositionReferenceGridModel> valueUpdater) {
		// Let AbstractCell handle the keydown event.
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
		// Handle the click event.
		if( "click".equals(event.getType()) ) {				
			onClick(value);
		}
	};


	@Override
    public void render(Context context, CompositionReferenceGridModel value, SafeHtmlBuilder sb) {
		 if (value == null) {
	            return;
	     }	        
	     SafeHtml rendered = INPUT_UNCHECKED;
	        	        
	     if (value.getStatus() == null || value.getStatus() == 0 ){
	    	 if (value.getRelation().equals(Niveau.INDISPENSABLE) || value.getRelation().equals(Niveau.INTERDITE)) {
	    		 rendered = INPUT_UNCHECKED_DISABLE;
	    	 } else {
	    		 rendered = INPUT_UNCHECKED;
	    	 }
	       		        	
	 	    sb.append(rendered);
	     } else {	      	
	      	if (value.getRelation().equals(Niveau.INDISPENSABLE) || value.getRelation().equals(Niveau.INTERDITE)) {
	      		rendered = INPUT_CHECKED_DISABLE;
	      	} else {
	      		rendered = INPUT_CHECKED;
	      	}
	 	    sb.append(rendered);
	      }
    }

	
	@Override
	public HandlerRegistration addSelectHandler(SelectHandler handler) {
		return addHandler(handler, SelectEvent.getType());
	}
	
	private static SafeHtml makeImage(ImageResource resource) {
		AbstractImagePrototype proto = AbstractImagePrototype.create(resource);
		return proto.getSafeHtml();
	}
	//add delete handler
	public abstract void onClick(CompositionReferenceGridModel node);	
}
