package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.sencha.gxt.cell.core.client.AbstractEventCell;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.HasSelectHandlers;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.image.Images;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.shared.model.reference.CompositionElementGridModel;
import com.structis.shared.security.Role;
import com.structis.shared.security.RoleHelper;

public abstract class CompositionElementCheckBoxCell extends AbstractEventCell<CompositionElementGridModel> implements HasSelectHandlers  {	
//	private static final SafeHtml INPUT_CHECKED = SafeHtmlUtils.fromSafeConstant("<input type=\"checkbox\" tabindex=\"-1\" checked/>");	 
//	private static final SafeHtml INPUT_UNCHECKED = SafeHtmlUtils.fromSafeConstant("<input type=\"checkbox\" tabindex=\"-1\"/>");
//	private static final SafeHtml INPUT_CHECKED_DISABLE = SafeHtmlUtils.fromSafeConstant("<input type=\"checkbox\" tabindex=\"-1\" checked  disabled />");
//	private static final SafeHtml INPUT_UNCHECKED_DISABLE = SafeHtmlUtils.fromSafeConstant("<input type=\"checkbox\" tabindex=\"-1\" disabled />");
	interface Templates extends SafeHtmlTemplates {
		@SafeHtmlTemplates.Template("<div name=\"{0}\" style=\"{1}\">{2}</div>")
		SafeHtml cell(String name, SafeStyles styles, SafeHtml value);
	}
	@SuppressWarnings("unused")
	private static Templates templates = GWT.create(Templates.class);
	private static final SafeHtml INPUT_CHECKED = makeImage(Images.RESOURCES.checkIcon());
	private static final SafeHtml INPUT_UNCHECKED = makeImage(Images.RESOURCES.uncheckIcon());
	private static final SafeHtml INPUT_CHECKED_DISABLE = makeImage(Images.RESOURCES.checkDisabledIcon());
	private static final SafeHtml INPUT_UNCHECKED_DISABLE = makeImage(Images.RESOURCES.uncheckDisabledIcon());
	private NavigationService navigation = NavigationFactory.getNavigation();
	
	public CompositionElementCheckBoxCell() {
		super("click", "keydown");			
	}

	@Override
	public void onBrowserEvent(com.google.gwt.cell.client.Cell.Context context,
	Element parent, CompositionElementGridModel value, NativeEvent event,
	com.google.gwt.cell.client.ValueUpdater<CompositionElementGridModel> valueUpdater) {
		// Let AbstractCell handle the keydown event.
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
		
		// Handle the click event.
		if( "click".equals(event.getType()) ) {		
			if (value.getRelation() != 1 && value.getRelation()!=3 && !Role.UTILISATEURINVITE.getCode().equals( navigation.getContext().getRoles().get(1).getCode()) ) {
				onClick(value);
			}			
		}
	};


	@Override
    public void render(Context context, CompositionElementGridModel value, SafeHtmlBuilder sb) {
		 if (value == null) {
	            return;
	        }	        		 
	        SafeHtml rendered; 	
	        if (value.getRelation() != null && !RoleHelper.isRestricted()) {
	        	if (value.getRelation().intValue() != 1 && value.getRelation().intValue() != 3) {
		        	if ( value.getStatus() == null || value.getStatus().intValue() == 0 ){
			        	rendered = INPUT_UNCHECKED;	        	
			 	        sb.append(rendered);
			        } else {
			        	rendered = INPUT_CHECKED;
			 	        sb.append(rendered);
			        }
		        } else {
		        	if ( value.getStatus() == null || value.getStatus().intValue() == 0 ){
			        	rendered = INPUT_UNCHECKED_DISABLE;	        	
			 	        sb.append(rendered);
			        } else {
			        	rendered = INPUT_CHECKED_DISABLE;
			 	        sb.append(rendered);
			        }
		        }
	        } else {
	        	rendered = INPUT_UNCHECKED_DISABLE;	        	
	 	        sb.append(rendered);
	        }
    }

	private static SafeHtml makeImage(ImageResource resource) {
		AbstractImagePrototype proto = AbstractImagePrototype.create(resource);
		return proto.getSafeHtml();
	}
	
	@Override
	public HandlerRegistration addSelectHandler(SelectHandler handler) {
		return addHandler(handler, SelectEvent.getType());
	}
	
	//add delete handler
	public abstract void onClick(CompositionElementGridModel node);	
}
