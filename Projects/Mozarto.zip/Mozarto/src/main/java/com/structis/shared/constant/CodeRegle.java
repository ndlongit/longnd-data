package com.structis.shared.constant;

public enum CodeRegle {
	CARACTERISTIQUE_VS_CARACTERISTIQUE("M"), CARACTERISTIQUE_VS_REFERENCE("O"), CARACTERISTIQUE_VS_ELEMENT("Z"), 
	REFERENCE_VS_CARACTERISTIQUE("A"), REFERENCE_VS_REFERENCE("R"), REFERENCE_VS_ELEMENT("T");
	private CodeRegle(String code) {
		this.code = code;
	}

	private final String code;

	public String getLabel() {
		return code;
	}
}
