package com.structis.shared.comparator;

import java.util.Comparator;

import com.structis.shared.model.reference.TreeNodeRegleModel;


public class TreeNodeRegleModelComparator implements Comparator<TreeNodeRegleModel> { 
	public int column; // 0= Nom + Prenom
	@Override
	public int compare(TreeNodeRegleModel node1, TreeNodeRegleModel node2) {
		boolean value1 = false;
		boolean value2 = false;
		switch(column){		
			case 0:
				value1 = node1.isInherited();
				value2 = node2.isInherited();
		}
		int result = 0;
		
		if(value1 == false){
			if(value2 == false){
				//result = 0;
				if(node1.getRelation() < node2.getRelation()){
					result = 0;
				}else{
					result = -1;
				}
				
			} else {
				result = -1;
			}
		} 
	
		return result;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	};
}


