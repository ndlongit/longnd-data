package com.structis.client.panel.composition;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.event.BeforeHideEvent;
import com.sencha.gxt.widget.core.client.event.BeforeHideEvent.BeforeHideHandler;
import com.sencha.gxt.widget.core.client.event.BeforeShowEvent;
import com.sencha.gxt.widget.core.client.event.BeforeShowEvent.BeforeShowHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.message.Messages;

public class ConfirmChangeReferenceQuantiteWindow  extends Window {
	private TextButton yesButton;
	private TextButton nonButton;
	private TextButton annulerButton;
	private final Messages messages = GWT.create(Messages.class);
	private static boolean show = false;
	public ConfirmChangeReferenceQuantiteWindow(String header,String message,
			SelectHandler callbackYes, SelectHandler callbackNon, SelectHandler callbackAnnuler){
		this.setHeadingHtml(header);
		setButtonAlign(BoxLayoutPack.CENTER);
		setClosable(false);
		HTML html = new HTML(message);
		setWidth(300);
		add(html);
		yesButton = new TextButton(messages.commonOui());
		yesButton.addSelectHandler(callbackYes);
		yesButton.addSelectHandler(new SelectHandler() {
			
			@Override
			public void onSelect(SelectEvent event) {
				hide();
			}
		});
		nonButton = new TextButton(messages.commonNon());
		nonButton.addSelectHandler(callbackNon);
		nonButton.addSelectHandler(new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				hide();
			}
		});
		annulerButton = new TextButton(messages.commonAnnulerButton());
		annulerButton.addSelectHandler(callbackAnnuler);
		annulerButton.addSelectHandler(new SelectHandler() {
			
			@Override
			public void onSelect(SelectEvent event) {
				hide();
			}
		});
		addBeforeShowHandler(new BeforeShowHandler() {
			
			@Override
			public void onBeforeShow(BeforeShowEvent event) {
				show = true;
				
			}
		});
		addBeforeHideHandler(new BeforeHideHandler() {
			
			@Override
			public void onBeforeHide(BeforeHideEvent event) {
				show = false;
			}
		});
		addButton(yesButton);
		addButton(nonButton);
		addButton(annulerButton);
	}
	public static boolean isShow() {
		return show;
	}
	public static void setShow(boolean show) {
		ConfirmChangeReferenceQuantiteWindow.show = show;
	}
}
