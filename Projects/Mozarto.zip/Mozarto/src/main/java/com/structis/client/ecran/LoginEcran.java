package com.structis.client.ecran;

import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.structis.client.constant.ConstantClient;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.panel.HeaderPanel;
import com.structis.client.panel.LoginPanel;
import com.structis.client.widget.SizeLimitViewPort;
/**
 * AccueilEcran contain the tab list
 * @author vinh.tong
 *
 */
public class LoginEcran  extends SimpleContainer  implements EcranLoadable {
	private HeaderPanel header;
	private SimpleEventBus bus = new SimpleEventBus();
	//private NavigationService navigation = NavigationFactory.getNavigation();
	private LoginPanel loginPanel;
	@Override
	protected void onAfterFirstAttach() {
	    SizeLimitViewPort viewPort = new SizeLimitViewPort();
	    header = new HeaderPanel(true);
	    VerticalLayoutContainer container = new VerticalLayoutContainer();
	    container.add(header,new VerticalLayoutData(1, ConstantClient.ScreenSize.HEADERHEIGHT, new Margins(0)));
	    loginPanel = new LoginPanel(bus);
	    loginPanel.setStyleName("grayBackGround");
	    container.add(loginPanel,new VerticalLayoutData(1, 1, new Margins(0)));
	    viewPort.add(container);
	    add(viewPort);
	}
	
	@Override
	public void onLoadApplication(NavigationEvent event) {
		loginPanel.showLoginWindow();
	}
	
}
