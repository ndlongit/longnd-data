package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.CompositionReferenceGridModel;

public class CompositionChangeQuantiteReferenceEvent extends GwtEvent<CompositionChangeQuantiteReferenceHandler> {
	
	
	private static Type<CompositionChangeQuantiteReferenceHandler> TYPE = new Type<CompositionChangeQuantiteReferenceHandler>();

	private CompositionReferenceGridModel reference;
	
	private boolean overwrite = false;
	
	public CompositionChangeQuantiteReferenceEvent(CompositionReferenceGridModel model,boolean overwrite){
		this.reference = model;
		this.overwrite = overwrite;
	}
	
	public static Type<CompositionChangeQuantiteReferenceHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<CompositionChangeQuantiteReferenceHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(CompositionChangeQuantiteReferenceHandler handler) {
		handler.onLoad(this);
	}

	public CompositionReferenceGridModel getReference() {
		return reference;
	}

	public void setReference(CompositionReferenceGridModel reference) {
		this.reference = reference;
	}

	public boolean isOverwrite() {
		return overwrite;
	}

	public void setOverwrite(boolean overwrite) {
		this.overwrite = overwrite;
	}

}
