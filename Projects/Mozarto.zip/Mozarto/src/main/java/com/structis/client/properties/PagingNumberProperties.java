package com.structis.client.properties;

import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.PagingNumber;

public interface PagingNumberProperties extends PropertyAccess<PagingNumber> {
	ModelKeyProvider<PagingNumber> id();

	LabelProvider<PagingNumber> label();
}
