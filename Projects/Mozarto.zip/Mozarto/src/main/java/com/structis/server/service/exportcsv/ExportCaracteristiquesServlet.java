package com.structis.server.service.exportcsv;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.structis.server.core.SpringGetter;
import com.structis.server.service.domain.CaracteristiqueService;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.MdlCaracteristique;

@SuppressWarnings("serial")
public class ExportCaracteristiquesServlet extends RemoteServiceServlet {
	public final static String FILE_NAME = "Mozarto";

	public final static String FILE_TYPE = ".csv";

	@Autowired
	CaracteristiqueService caracteristiqueService;

	protected SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-HHmmss");

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		caracteristiqueService = (CaracteristiqueService) SpringGetter.getBean(getServletContext(), "caracteristiqueService");

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {
			String idModeleVersion = request.getParameter(Constant.CARACTERISTIQUE_IDMODELEVERSION_STR);
			String libelleMetier = request.getParameter(Constant.LIBELLE_METIER);
			int timezoneOffsetClient = Integer.parseInt(request.getParameter(Constant.CLIENT_TIMEZONEOFFSET));
			TimeZone timeZone = TimeZone.getTimeZone("GMT");
			timeZone.setRawOffset((int) (timezoneOffsetClient * DateUtils.MILLIS_PER_MINUTE));
			sdf.setTimeZone(timeZone);
			String filename = FILE_NAME + "_" + libelleMetier + "_Caracteristiques_" + sdf.format(Calendar.getInstance().getTime()) + FILE_TYPE;

			ExportCaracteristiques exportCaracteristique = new ExportCaracteristiques();
			List<MdlCaracteristique> findAll = caracteristiqueService.findByHierarchy(Integer.valueOf(idModeleVersion));
			int size = 0;
			if( findAll != null && findAll.size() > 0 ) {
				List<List<MdlCaracteristique>> lists = new LinkedList<List<MdlCaracteristique>>();
				Map<Integer, List<MdlCaracteristique>> map = new HashMap<Integer, List<MdlCaracteristique>>();
				List<MdlCaracteristique> list0 = new ArrayList<MdlCaracteristique>();
				list0.add(findAll.get(0));
				map.put(findAll.get(0).getIdCaracteristique(), list0);
				lists.add(list0);
				size++;
				int indexParent = 0;
				for (int i = 1; i < findAll.size(); i++){
					MdlCaracteristique car = findAll.get(i);
					List<MdlCaracteristique> listparent = map.get(car.getIdCaracteristiqueParent());

					List<MdlCaracteristique> list = new ArrayList<MdlCaracteristique>(listparent);
					list.add(car);
					map.put(car.getIdCaracteristique(), list);
					if (lists.contains(listparent)){
						indexParent = lists.indexOf(listparent);
						lists.remove(listparent);
						lists.add(indexParent, list);
					}
					else {
						lists.add(++ indexParent, list);
					}
					if (size < list.size())
						size = list.size();
				}
				exportCaracteristique.setCaracteristiques(lists);
				Writer export = exportCaracteristique.export(getServletContext().getRealPath(filename), size);
				PrintWriter printWriter = new PrintWriter(export);
				printWriter.flush();
				printWriter.close();
				FileInputStream fileToDownload = new FileInputStream(getServletContext().getRealPath(filename));
				response.setContentType("application/msexcel");
				response.setHeader("Content-Disposition", "attachment; filename=" + filename);
				response.setContentLength(fileToDownload.available());
				int c;
				ServletOutputStream output = response.getOutputStream();
				while( (c = fileToDownload.read()) != -1 ) {
					output.write(c);
				}
			}

		}
		catch( Exception e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
