package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class LoadCompositionEvent  extends GwtEvent<LoadCompositionHandler>{
	
	private static Type<LoadCompositionHandler> TYPE = new Type<LoadCompositionHandler>();
	
	private Integer idModeleVersion;
	
	public static Type<LoadCompositionHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<LoadCompositionHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(LoadCompositionHandler handler) {
		handler.onLoad(this);
	}
	
	public LoadCompositionEvent(Integer idModeleVersion) {
		this.idModeleVersion = idModeleVersion;
	}

	public void setIdModeleVersion(Integer idModeleVersion) {
		this.idModeleVersion = idModeleVersion;
	}

	public Integer getIdModeleVersion() {
		return idModeleVersion;
	}

}
