package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.CmpRegleElementMapper;
import com.structis.shared.model.CmpRegleElement;

@Service
public class CompositionRegleElementServiceImpl implements CompositionRegleElementService {
	
	@Autowired
	CmpRegleElementMapper cmpRegleElementMapper;
	
	@SuppressWarnings({ "rawtypes",  "unchecked" })
	@Override
	public void insertList(List<CmpRegleElement> cmpRegleElements) {
		Map parameters = new HashMap();
		parameters.put("cmpRegleElements", cmpRegleElements);
		cmpRegleElementMapper.insertList(parameters);
	}

	@Override
	public void deleteIdComposition(Integer idComposition) {
		cmpRegleElementMapper.deleteIdComposition(idComposition);
	}

}
