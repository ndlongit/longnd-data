package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sencha.gxt.data.shared.SortDir;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoadResultBean;
import com.structis.client.panel.composition.CompositionReferenceFilter;
import com.structis.client.service.ClientCompositionService;
import com.structis.client.widget.CustomizePagingLoadResult;
import com.structis.client.widget.CustomizePagingLoadResultBean;
import com.structis.server.service.domain.CaracteristiqueService;
import com.structis.server.service.domain.CompositionService;
import com.structis.server.service.domain.MetierService;
import com.structis.server.service.domain.ModeleService;
import com.structis.server.service.domain.ReferenceService;
import com.structis.server.service.domain.TmpCompositionDataElementUtil;
import com.structis.shared.model.Element;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.CompositionAccueilModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionAndMessageModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionModel;
import com.structis.shared.model.reference.CompositionCarateristiqueSelectAbleModel;
import com.structis.shared.model.reference.CompositionElementGridModel;
import com.structis.shared.model.reference.CompositionModel;
import com.structis.shared.model.reference.CompositionReferenceGridModel;
import com.structis.shared.model.reference.CompositionTreeComboboxModel;
import com.structis.shared.model.reference.ModeleModel;

@Service("clientCompositionService")
public class ClientCompositionServiceImpl implements ClientCompositionService {

	@Autowired
	CompositionService compositionService;
	
	@Autowired
	CaracteristiqueService caracteristiqueService;
	
	@Autowired
	ReferenceService referenceService;
	
	@Autowired
	MetierService metierService;
	
	@Autowired
	TmpCompositionDataElementUtil tmpCompositionDataElementUtil;
	
	
	@Autowired
	ModeleService modeleService;
	
	@Override
	public List<CompositionCarateristiqueSelectAbleModel> findCaracteristiquesBeforeLeafNode(Integer idModeleVersion) {
		return compositionService.findCompositionCarateristiqueSelectAbleBeforeLastNode(idModeleVersion);
	}

	@Override
	public List<CompositionReferenceGridModel> findCompositionReferenceByCaracteristiques(List<Integer> idCaracteristiques,Integer idModeleVersion) {
		return compositionService.findCompositionReferenceByCaracteristique(idCaracteristiques, idModeleVersion);
	}
	
	@Override
	public CustomizePagingLoadResult<CompositionReferenceGridModel> findCompositionReferenceByCaracteristiquesPaging(CompositionReferenceFilter loadConfig
			) {
		int total = 0;
		List<CompositionReferenceGridModel> finalResult = new ArrayList<CompositionReferenceGridModel>();
		List<CompositionReferenceGridModel> result = null;
		if (loadConfig.getCaracteristiqueIds() == null || loadConfig.getCaracteristiqueIds().size() == 0) {
			result = compositionService.findAllCompositionReferenceByCaracteristiquesLimit(loadConfig.getLimit(), loadConfig.getIdModeleVersion());	
			total = referenceService.countReferenceByIdModeleVersion(loadConfig.getIdModeleVersion());
		} else {
			result = compositionService.findCompositionReferenceByCaracteristique(loadConfig.getCaracteristiqueIds(), loadConfig.getIdModeleVersion());
			total = result.size();
		}		
		
		
		int minValue = 0;
		int quota = loadConfig.getLimit();
				
		if (loadConfig.getSelectedList() != null && loadConfig.getSelectedList().size()>0) {
			minValue = quota;
			if (loadConfig.getSelectedList().size() < minValue) {
				minValue = loadConfig.getSelectedList().size();
			}
			copyNTopList(finalResult, loadConfig.getSelectedList(), minValue);
		}
		
		quota = loadConfig.getLimit() - minValue;
				

		if (total > quota) {
			copyNTopList(finalResult, result, quota);
		} else {
			copyNTopList(finalResult, result, total);
		}
		CustomizePagingLoadResultBean<CompositionReferenceGridModel> pagingResult = new CustomizePagingLoadResultBean<CompositionReferenceGridModel>(finalResult, finalResult.size(),loadConfig.getOffset());
		pagingResult.setfinalTotal(total);
		return pagingResult;
	}
	
	private void copyNTopList(List<CompositionReferenceGridModel> ret,			
			List<CompositionReferenceGridModel> result, int to) {
			int i = 0;
			int total = 0;
			while (i < result.size() && total < to) {
				if (!exist(ret, result.get(i))) {
					ret.add(result.get(i));
					total++;
				}	
				i++;
			}							
	}

	private boolean exist(List<CompositionReferenceGridModel> ret,
			CompositionReferenceGridModel compositionReferenceGridModel) {
		for (CompositionReferenceGridModel e: ret) {
			if (e.getIdReference().intValue() == compositionReferenceGridModel.getIdReference().intValue()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<CompositionElementGridModel> findCompositionElementByReferences(List<Integer> idReferences,Integer idModeleVersion) {
		return compositionService.findCompositionElementByReferences(idReferences, idModeleVersion);
	}

	@Override
	public CompositionCarateristiqueFilterActionAndMessageModel checkActionAfterFilter(Integer idCaracteristiqueSelected,Integer idModeleVersion) {
		return compositionService.checkActionAfterFilter( idCaracteristiqueSelected, idModeleVersion);
	}

	@Override
	public List<CompositionCarateristiqueFilterActionModel> checkActionBeforeFilter(Integer idCaracteristiqueSelected,
			Integer idModeleVersion) {
		return compositionService.checkActionBeforeFilter(idCaracteristiqueSelected, idModeleVersion);
	}

	@Override
	public List<CompositionReferenceGridModel> findAllCompositionReferenceByCaracteristiques(Integer limit,
			Integer idModeleVersion) {
		
		return compositionService.findAllCompositionReferenceByCaracteristiquesLimit(limit, idModeleVersion);
	}
	
	@Override
	public CompositionTreeComboboxModel getCompositionTreeAndComboboxBeforeLastNode(Integer idModeleVersion){
		return compositionService.getCompositionTreeAndComboboxLastNode(idModeleVersion);
	}

	@Override
	public Metier getMetier(Integer idMetier) {
		return metierService.findById(idMetier);
	}

	@Override
	public Map<Integer, List<String[]>> findMessageByIdReference(Integer idModeleVersion, Integer idReference) {
		return compositionService.findMessageByIdReference(idModeleVersion, idReference);
	}

	@Override
	@Transactional
	public Integer saveCompostion(CompositionModel composition) {
		return compositionService.insertUpdateComposition(composition);
	}

	@Override
	public void doAction() {
		
	}

	@Override
	public void changeReferenceQuantieTMPData(Integer idReference, Integer quantite, boolean isOverwrite) {
		//LinkedHashMap<Integer, CompositionElementGridModel> currentElement = tmpCompositionDataElementUtil.getElementData(tmpCompositionDataElementUtil.CDRELEMENT);
		tmpCompositionDataElementUtil.changeReferenceQuantie(idReference, quantite, isOverwrite);
	}

	@Override
	public void onSelectReferenceTMPData(Map<Integer, Integer> mapReferences, Integer idModeleVersion) {
		List<CompositionElementGridModel> elements = findCompositionElementByReferences(new ArrayList<Integer>(mapReferences.keySet()) , idModeleVersion);
		for( CompositionElementGridModel element : elements ) {
			element.setQuantite(mapReferences.get(element.getIdReference()) * element.getDefaultQuantite());
		}
		tmpCompositionDataElementUtil.addUpdateCdrElements(elements);
	}

	@Override
	public void updateCElementTMPData(CompositionElementGridModel element) {
		List<CompositionElementGridModel> elements = new ArrayList<CompositionElementGridModel>();
		elements.add(element);
		tmpCompositionDataElementUtil.addUpdateCdrElements(elements);
	}


	@Override
	public PagingLoadResult<CompositionElementGridModel> loadCeElementPagingTMPData(PagingLoadConfig loadConfig) {
		List<CompositionElementGridModel> allCurrentElments =  tmpCompositionDataElementUtil.getCdrElementData();
		List<CompositionElementGridModel> resullist = new ArrayList<CompositionElementGridModel>();
		//List<CompositionElementGridModel> allCurrentElments = new ArrayList<CompositionElementGridModel>();
		if( allCurrentElments != null ) {
			int start = loadConfig.getOffset();
			int limit = allCurrentElments.size();
			if( loadConfig.getLimit() > 0 ) {
				limit = Math.min(start + loadConfig.getLimit(), limit);
			}
			//List<Integer> idReferencs = new ArrayList<Integer>();
			for( int i = loadConfig.getOffset() ; i < limit ; i++ ) {
				//MdlReference reference = referenceService.findById(allCurrentElments.get(i).getIdReference());
				//allCurrentElments.get(i).setLibeleReference("Reference");
				resullist.add(allCurrentElments.get(i));
			}
		}
		return new PagingLoadResultBean<CompositionElementGridModel>(resullist, allCurrentElments.size(), loadConfig.getOffset());
	}

	@Override
	public void clearElementTMPData() {
		tmpCompositionDataElementUtil.resetData();
	}

	@Override
	public void onUnSelectReferenceTMPData(List<Integer> idReferences) {
		tmpCompositionDataElementUtil.unSelectRerence(idReferences);
	}
	
	@Override
	public void addUpdateEsElementTMPData(List<Element> elements) {
		tmpCompositionDataElementUtil.addUpdateEsElements(elements);
	}

	@Override
	public PagingLoadResult<Element> loadEsElementPagingTMPData(PagingLoadConfig loadConfig) {
		LinkedHashMap<Integer, Element> allCurrentMap =  tmpCompositionDataElementUtil.getEsElementData();
		List<Element> resullist = new ArrayList<Element>();
		List<Element> allCurrentElments = new ArrayList<Element>();
		if( allCurrentMap != null ) {
			allCurrentElments = new ArrayList<Element>(allCurrentMap.values());
			int start = loadConfig.getOffset();
			int limit = allCurrentElments.size();
			if( loadConfig.getLimit() > 0 ) {
				limit = Math.min(start + loadConfig.getLimit(), limit);
			}
			//List<Integer> idReferencs = new ArrayList<Integer>();
			for( int i = loadConfig.getOffset() ; i < limit ; i++ ) {
				resullist.add(allCurrentElments.get(i));
			}
		}
		return new PagingLoadResultBean<Element>(resullist, allCurrentElments.size(), loadConfig.getOffset());
	}

	@Override
	public void removeEsElment(List<Element> elements) {
		tmpCompositionDataElementUtil.removeEsElment(elements);
	}
		
	@Override
	public List<ModeleModel> findAllLastPublicVersionByMetier(Integer idMetier) {
		return modeleService.findAllLastPublicVersionByMetier(idMetier);
	}

	@Override
	public PagingLoadResult<CompositionAccueilModel> loadCompoByModele(ModeleModel modele, PagingLoadConfig loadConfig) {

		String sortField = "dDateheureDmaj";
		SortDir sortDir = SortDir.DESC;
		if (loadConfig.getSortInfo().size() > 0){
			sortField = loadConfig.getSortInfo().get(0).getSortField();
			sortDir = loadConfig.getSortInfo().get(0).getSortDir();
		}
		List<CompositionAccueilModel> findAll = compositionService.findCompositionByModeleVersion(modele.getIdModele(), sortField, sortDir);
		ArrayList<CompositionAccueilModel> sublist = new ArrayList<CompositionAccueilModel>();
	    int start = loadConfig.getOffset();
	    int limit = findAll.size();
	    if (loadConfig.getLimit() > 0) {
	      limit = Math.min(start + loadConfig.getLimit(), limit);
	    }
	    for (int i = loadConfig.getOffset(); i < limit; i++) {
	    	CompositionAccueilModel m = findAll.get(i);
	    	sublist.add(m);
	    }
		return new PagingLoadResultBean<CompositionAccueilModel>(sublist, findAll.size(), loadConfig.getOffset());
	}

	@Override
	public Integer deleteById(Integer idComposition) {
		return compositionService.deleteById(idComposition);
	}

}
