package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.Famille;

public interface FamilleService {
	public Famille findById(Integer id) ;
	
	public Integer insert(Famille famille) ;
	
	public void update(Famille famille);
		
	public void delete(Famille famille) ;
	
	public void deleteById(Integer id) ;
	
	public List<Famille> findAll();

	public List<Famille> findByMetier(Integer idMetier);
	
	public List<Famille> findByMetierAndLabel(Integer idMetier, String label);
	
	public List<Famille> findEmptyFamily(Integer metierId, String elementType);
	
	public List<Famille> findByBaseCriteria(Famille criteria);
}
