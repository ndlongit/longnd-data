package com.structis.server.service.importcsv;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;

import com.googlecode.jcsv.reader.internal.CSVReaderBuilder;
import com.structis.client.util.ImportUtil;
import com.structis.server.constant.ConstantServer;
import com.structis.server.core.ConstantError;
import com.structis.server.core.SpringGetter;
import com.structis.server.service.domain.ImportElementErrorService;
import com.structis.server.service.domain.ImportElementService;
import com.structis.server.service.domain.ImportService;
import com.structis.server.util.StringUtils;
import com.structis.shared.constant.Constant;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.exception.TechnicalException;
import com.structis.shared.model.Import;
import com.structis.shared.model.ImportElement;
import com.structis.shared.model.ImportElementError;

@SuppressWarnings("serial")
public class ImportElementsServlet extends CSVImport {

	private static final Logger LOGGER = Logger.getLogger(ImportElementsServlet.class);

	private ImportService importService;

	private ImportElementService importElementService;

	private ImportElementErrorService importElementErrorService;

	private static final String[] FIXED_ELEMENT_TYPES = { "", "FAM", "SFA", "GRP", "SGR", "TEL", "CEL", "ELT", "NFO", "ACT" };
	
	private static final List<String> FIXED_HEADER_COLUMNS = Arrays.asList(
			"FAMILLE-1", "FAMILLE-2", "FAMILLE-3", "FAMILLE-4", "TYPE ELEMENT", CODE_ELEMENT, "LIBELLE ELEMENT",
			"NOMENCLATURE FOURNISSEUR", "ACTIF", ATTRIBUT, VALUE);

	private Integer metierId = null;

	private Integer userId = null;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		importService = (ImportService) SpringGetter.getBean(getServletContext(), ImportService.SERVIECE_NAME);
		importElementService = (ImportElementService) SpringGetter.getBean(
				getServletContext(), ImportElementService.SERVIECE_NAME);
		importElementErrorService = (ImportElementErrorService) SpringGetter.getBean(
				getServletContext(), ImportElementErrorService.SERVIECE_NAME);
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		String importType = ConstantServer.IMPORT_TYPE_ELEMENT;

		String errorMessage = "";
		String outputFile = null;
		List<String[]> csvData = null;

		Import newImport = null;
		File f = null;

		try {

			f = writeFile(request);

			if( f != null ) {
				outputFile = ImportUtil.buildOutputFile(f);
				List<String> statusList = new ArrayList<String>();
				statusList.add(ConstantServer.IMPORT_SAS_BEGIN);
				statusList.add(ConstantServer.IMPORT_SAS_VERIFICATION);

				Import importObject = null;
				List<Import> results = importService.findIdsByImportType(importType);

				if( results == null || results.size() == 0 ) {
					newImport = ImportUtil.createNewImport(metierId, userId, importType, null);
					importService.insert(newImport);
				}
				else {
					importObject = results.get(0);
					String importStatus = importObject.getCEtatImport();

					if( ConstantServer.IMPORT_SAS_BEGIN.equalsIgnoreCase(importStatus) || ConstantServer.IMPORT_SAS_VERIFICATION.equalsIgnoreCase(importStatus) ) {
						Object[] params = { importObject.getUser().getCUtilisateur() };
						errorMessage = messageSource.getMessage("import.element.error.importing", params, locale);
						throw new FunctionalException(null, ConstantError.ERR_IMPORT_INPROGRESS, errorMessage);
					}

					Integer importId = importObject.getIdImport();
					importService.deletePreviousImportedData(importId);
					newImport = ImportUtil.createNewImport(metierId, userId, importType, null);
					importService.insert(newImport);
				}

				Integer importId = newImport.getIdImport();
				if( importId == null ) {
					return;
				}

				csvData = importDataToSas(newImport, metierId, f.getAbsolutePath());

				if( ImportUtil.hasErrors(csvData) ) {

					newImport.setCEtatImport(ConstantServer.IMPORT_DATA_FUNCTIONAL_ERROR);

					//Update Import Status
					importService.update(newImport);
				}
				else {
					List<ImportElementError> errors = importElementErrorService.findByImportedId(importId);
					if( errors == null || errors.size() == 0 ) {
						newImport.setCEtatImport(ConstantServer.IMPORT_SAS_VERIFICATION);

						//Update Import Status
						importService.update(newImport);
						try {
							importElementService.importElementToMozarto(importId, metierId, csvData, messageSource);

							//Import done
							newImport.setCEtatImport(ConstantServer.IMPORT_DATA_DONE);
						}
						catch( Exception e ) {
							newImport.setCEtatImport(ConstantServer.IMPORT_DATA_TECHNICAL_ERROR);
							throw e;
						}
						finally {

							//Update Import Status
							importService.update(newImport);
						}
					}
					else {
						newImport.setCEtatImport(ConstantServer.IMPORT_DATA_FUNCTIONAL_ERROR);

						//Update Import Status
						importService.update(newImport);
					}
				}
			}
		}
		catch( Exception e ) {
			if( newImport != null ) {
				newImport.setCEtatImport(ConstantServer.IMPORT_DATA_FUNCTIONAL_ERROR);
			}

			if( e instanceof FunctionalException || e instanceof TechnicalException ) {
				errorMessage = e.getMessage();
			}
			else {
				errorMessage =  messageSource.getMessage("import.error", null, locale);
			}
			LOGGER.error(e.getMessage(), e);
		}
		finally {

			if( newImport != null ) {

				//Update Import Status
				importService.update(newImport);
			}
			
			ImportUtil.processImportOutput(request, out, csvData, outputFile, errorMessage);

			out.flush();
			out.close();
		}
	}

	@SuppressWarnings("rawtypes")
	private File writeFile(HttpServletRequest request) throws Exception {

		File uploadFile = null;
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);

		if( isMultipart ) {
			FileOutputStream out = null;

			// Create a factory for disk-based file items
			try {
				FileItemFactory factory = new DiskFileItemFactory();

				// Create a new file upload handler
				ServletFileUpload upload = new ServletFileUpload(factory);

				// Parse the request
				List items = upload.parseRequest(request);
				if( items != null && items.size() > 0 ) {
					for( Object object : items ) {

						FileItem item = (FileItem) object;
						String fieldName = item.getFieldName();

						if( item.isFormField() ) {
							if( Constant.ID_METIER.equalsIgnoreCase(fieldName) ) {
								metierId = Integer.parseInt(item.getString());
							}

							if( ConstantServer.PARAM_USER_ID.equalsIgnoreCase(fieldName) ) {
								userId = Integer.parseInt(item.getString());
							}
						}
						else {
							String clientFileLocation = item.getName();
							clientFileLocation = clientFileLocation.replaceAll("\\\\", "/");

							int lastSeperatorIndex = clientFileLocation.lastIndexOf("/");
							String clientFileName = clientFileLocation.substring(lastSeperatorIndex + 1);

							byte[] data = item.get();

							File fileFolder = new File(getServletContext().getRealPath("/files"));
							if( !fileFolder.exists() ) {
								fileFolder.mkdir();
							}

							String uploadFileName = fileFolder.getAbsolutePath() + "/" + clientFileName;
							uploadFile = new File(uploadFileName);

							if( uploadFile.exists() ) {
								uploadFile.delete();
							}

							uploadFile.createNewFile();

							out = new FileOutputStream(uploadFile);
							out.write(data);
							out.close();
						}
					}
				}
			}
			catch( Exception e ) {
				if( out != null ) {
					out.close();
				}
				throw e;
			}
			finally {
				out = null;
			}
			return uploadFile;
		}
		else {
			return null;
		}
	}

	private List<String[]> importDataToSas(Import importData, int metierId, String file) throws IOException {
		Reader reader = new FileReader(file);

		List<String[]> csvData = CSVReaderBuilder.newDefaultReader(reader).readAll();
		csvData = ImportUtil.addErrorColumns(csvData);

		String[] row = null;
		
		//Verify required fields
		List<Integer> requiredColumns = Arrays.asList(5, 6, 7);

		Map<String, String> typeCodeMap = new HashMap<String, String>();

		String csvError = null;
		String dbError = null;
		String[] headerColums = csvData.get(0);
		
		String allRowsError = validateHeaderColumnNames(FIXED_HEADER_COLUMNS, headerColums);
		
		Integer idImport = importData.getIdImport();

		for( int i = 1 ; i < csvData.size() ; i++ ) {
			row = csvData.get(i);
			if(ImportUtil.isNullOrEmpty(row)) {
				continue;
			}
			
			csvError = "";
			dbError = "";
			
			ImportElement data = null;
			String cellValue = null;

			ImportElementError elementError = null;

			//Fixed order columns
			for( int j = 1 ; j < FIXED_ELEMENT_TYPES.length ; j++ ) {
				data = new ImportElement();
				data.setCTypeElementImport(FIXED_ELEMENT_TYPES[j]);
				data.setIdImport(idImport);
				cellValue = row[j];
				data.setLValeur(cellValue);
				data.setNColonne(j - 1); // Dont count first column (Error column)
				data.setNLigne(i);

				elementError = checkMaxLength(j, data, headerColums); // Check max-length and truncate if needed				
				importElementService.insert(data);
				
				if( elementError != null ) { // Violate max-length rule
					csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
					elementError.setIdElementImport(data.getIdElementImport());
					importElementErrorService.insert(elementError);
				}

				if( requiredColumns.contains(j) ) {

					//Required column
					if( StringUtils.isNullOrEmtpy(cellValue) ) {
						dbError = buildRequiredErrorMessage(headerColums[j]);
						csvError = ImportUtil.appendError(csvError, dbError);

						elementError = new ImportElementError();
						elementError.setIdElementImport(data.getIdElementImport());
						elementError.setLLibelleLong(dbError);
						importElementErrorService.insert(elementError);
					}
				}

				if( j == 4 ) {

					//Check Family hierarchical
					int lowestLevel = getLowestLevel(row, 4);
					if( lowestLevel >= 2 ) { //Sub-family was defined
						for( int k = lowestLevel - 1 ; k >= 1 ; k-- ) {
							if( StringUtils.isNullOrEmtpy(row[k]) ) {
								Object[] params = {headerColums[k]};
								dbError = messageSource.getMessage("import.reference.error.mustSpecifyFamily", params, locale);
								csvError = ImportUtil.appendError(csvError, dbError);
								elementError = new ImportElementError();
								elementError.setIdElementImport(data.getIdElementImport());
								elementError.setLLibelleLong(dbError);
								importElementErrorService.insert(elementError);
							}
						}
					}
				}

				if( j == 5 ) {
					if( !"A".equalsIgnoreCase(cellValue) && !"P".equalsIgnoreCase(cellValue) ) {
						Object[] params = {headerColums[j]};
						dbError = messageSource.getMessage("import.element.error.elementTypeIsAOrP", params, locale);
						csvError = ImportUtil.appendError(csvError, dbError);
						elementError = new ImportElementError();
						elementError.setIdElementImport(data.getIdElementImport());
						elementError.setLLibelleLong(dbError);
						importElementErrorService.insert(elementError);
					}
				}

				if( j == 6 ) { //Element code
					String elementCode = cellValue;
					String elementType = row[j - 1];
					if( typeCodeMap.containsKey(elementCode) ) {
						String t = typeCodeMap.get(elementCode);
						if( elementType != null && elementType.equalsIgnoreCase(t) ) {
							csvError = ImportUtil.appendError(
									csvError, messageSource.getMessage("import.reference.error.manyElementsInFile", null, locale));
						}
					}
					else {
						typeCodeMap.put(elementCode, elementType);
					}
				}
			}

			//Attribut, Valeur pair columns
			int startAttributeValueIndex = FIXED_ELEMENT_TYPES.length;
			int endAttributeValueIndex = row.length - 1;

			csvError = importElementService.saveAttributeValuePairs(
					startAttributeValueIndex, endAttributeValueIndex, headerColums, row, i, metierId, idImport,
					ImportUtil.ATTRIBUTE_VALUE_TYPES[0], ImportUtil.ATTRIBUTE_VALUE_TYPES[1], "E", csvError, null, null, messageSource);

			//Append errors to first column
			if( !ImportUtil.isNullOrEmpty(allRowsError) ) {
				csvError = allRowsError + ", " + csvError;
			}
			csvData.get(i)[0] = csvError;
		}

		return csvData;
	}

	private static ImportElementError checkMaxLength(int columnIndex, ImportElement data, String[] headerColums) {

		ImportElementError elementError = null;
		String value = data.getLValeur();
		int length = -1;
		String errorStr = null;

		switch( columnIndex ) {
			case 1 :
			case 2 :
			case 3 :
			case 4 :
			case 8 :
				length = 50;
				break;
			case 6 :
				length = 10;
				break;
			case 7 :
				length = 500;
				break;
			default :
				break;
		}

		if( length > 0 ) {
			if( !ImportUtil.checkMaxLength(value, length) ) {
				value = StringUtils.truncate(value, length);
				errorStr = buildMaxLengthErrorMessage(headerColums[columnIndex], length);
				elementError = new ImportElementError();
				elementError.setLLibelleLong(errorStr);
			}
		}

		data.setLValeur(value);

		return elementError;
	}

	private int getLowestLevel(String[] row, int max) {
		for( int i = max ; i >= 1 ; i-- ) {
			if( !StringUtils.isNullOrEmtpy(row[i]) ) {
				return i;
			}
		}
		return 0;
	}
}
