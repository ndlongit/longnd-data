package com.structis.client.panel;


import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutData;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer.HBoxLayoutAlign;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.structis.client.event.ModelisateurAnnulerCreerModeleEvent;
import com.structis.client.event.ModelisateurCloseTabEvent;
import com.structis.client.event.ModifyEvent;
import com.structis.client.event.RemoveNodeEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.service.ClientRegleMessageServiceAsync;
import com.structis.client.widget.HtmlButton;
import com.structis.shared.constant.Niveau;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;
import com.structis.shared.model.reference.TreeNodeModel;

public abstract class AbstractModelisateurEditForm extends VerticalLayoutContainer {
	protected SimpleEventBus bus;

	protected final Messages messages = GWT.create(Messages.class);

	//protected HorizontalPanel navigationPanel;

	protected boolean changed = false;

	protected HtmlButton annulerButton;

	protected TextButton validerButton;
	
//	protected TextButton detailButton;
//	
//	protected TextButton regleButton;
	
	protected TreeNodeModel treeNode;
	protected TreeNodeModel parentNode;
	protected String tabId;
	protected String nodeKey;
	protected Integer parentNodeId;
	protected HBoxLayoutContainer buttonContainer;
	
	protected boolean isInDetail = true;
	protected boolean createModele = false;
	protected boolean create = false;
	
	VerticalLayoutContainer detailContainer;
	public static boolean  firstTime = true;
	protected NavigationService navigation = NavigationFactory.getNavigation();
	//protected Integer utilisateurId /*= navigation.getContext().getUtilisateur().getIdUtilisateur()*/;
	//protected Integer metierId /*= navigation.getContext().getUtilisateur().getIdUtilisateur()*/;
	
	public AbstractModelisateurEditForm(SimpleEventBus bus, TreeNodeModel item, TreeNodeModel parent) {
		this.parentNode = parent;
		this.bus = bus;
		this.treeNode = item;
		addStyleName("containerPadding");
		buttonContainer = new HBoxLayoutContainer();
		BoxLayoutData layoutData = new BoxLayoutData(new Margins(0, 50, 0, 0));
		buttonContainer.setHBoxLayoutAlign(HBoxLayoutAlign.MIDDLE);
		buttonContainer.setPack(BoxLayoutPack.CENTER);
		annulerButton = new HtmlButton(messages.commonAnnulerButton());
		validerButton = new TextButton(messages.commonValiderButton());
		validerButton.setEnabled(false);
		annulerButton.setEnable(false);
		buttonContainer.add(annulerButton, layoutData);
		buttonContainer.add(validerButton, layoutData);
		buttonContainer.setPadding(new Padding(5, 0, 0, 0));
		detailContainer = buildPanel();

		add(detailContainer, new VerticalLayoutData(1, 1));
		add(buttonContainer, new VerticalLayoutData(1, 30));

		addHandler();
		loadForm();	
		
	}
	public AbstractModelisateurEditForm(SimpleEventBus bus, TreeNodeModel item) {
		this.bus = bus;
		this.treeNode = item;
		addStyleName("containerPadding");
		buttonContainer = new HBoxLayoutContainer();
		BoxLayoutData layoutData = new BoxLayoutData(new Margins(0, 50, 0, 0));
		buttonContainer.setHBoxLayoutAlign(HBoxLayoutAlign.MIDDLE);
		buttonContainer.setPack(BoxLayoutPack.CENTER);
		annulerButton = new HtmlButton(messages.commonAnnulerButton());
		validerButton = new TextButton(messages.commonValiderButton());
		validerButton.setEnabled(false);
		annulerButton.setEnable(false);
		buttonContainer.add(annulerButton, layoutData);
		buttonContainer.add(validerButton, layoutData);
		buttonContainer.setPadding(new Padding(5, 0, 0, 0));
		detailContainer = buildPanel();

		add(detailContainer, new VerticalLayoutData(1, 1, new Margins(0)));
		add(buttonContainer, new VerticalLayoutData(1, 34, new Margins(0)));

		addHandler();
		loadForm();
		addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent event) {
				if(firstTime){
					firstTime = false;
				}else{
					setHeight(getParent().getOffsetHeight()-15);
				}
			}
		});
	}

	protected void setStatusButtons() {	}
	
	abstract protected VerticalLayoutContainer buildPanel();

	abstract protected void addHandler();

	abstract protected void loadForm();

	
	protected void toggleSaveCancel(boolean enable) {
		changed = enable;
		navigation.getBus().fireEvent(new ModifyEvent(!changed));
		validerButton.setEnabled(enable);
		annulerButton.setEnable(enable);
	}
	public boolean isInDetail() {
		return isInDetail;
	}

	public void setInDetail(boolean isInDetail) {
		this.isInDetail = isInDetail;
	}
	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

	public Integer getParentNodeId() {
		return parentNodeId;
	}

	public void setParentNodeId(Integer parentNodeId) {
		this.parentNodeId = parentNodeId;
	}

	public boolean isChanged() {
		return changed;
	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}
	
	protected void showConfirmCloseMessage(String itemName) {
		if (isChanged()) {
			String confirmMessage = messages.modelisateurConfirmationCloseTab(itemName);
			final ConfirmMessageBox confirmBox = new ConfirmMessageBox(
					messages.commonConfirmation(), confirmMessage);
			confirmBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
			confirmBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
			confirmBox.addHideHandler(new HideHandler() {
				public void onHide(HideEvent event) {
					if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
						resetForm();
						toggleSaveCancel(false);
						if(create){
							bus.fireEvent(new ModelisateurCloseTabEvent(treeNode));
							bus.fireEvent(new RemoveNodeEvent(treeNode));
						}
						if(createModele){
							bus.fireEvent(new ModelisateurAnnulerCreerModeleEvent());
						}
						navigation.getBus().fireEvent(new ModifyEvent(true));
					}
				}
			});
			confirmBox.show();
		}
	}

	abstract protected void resetForm();

	public TreeNodeModel getTreeNode() {
		return treeNode;
	}

	public void setTreeNode(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}

	public void prepareCloseTab() {		
		if (treeNode.getLibelle().trim().equals(messages.commontreenewnode())) {
			removeRecord(getParentNodeId(), treeNode.getId());
			RemoveNodeEvent event = new RemoveNodeEvent(treeNode);
			bus.fireEvent(event);
		}
	}
	
	protected void removeRecord(Integer parentId, Integer id) {
			RemoveNodeEvent removeNodeEvent = new RemoveNodeEvent(treeNode);									
			bus.fireEvent(removeNodeEvent);						
	}

	public TreeNodeModel getParentNode() {
		return parentNode;
	}

	public void setParentNode(TreeNodeModel parentNode) {
		this.parentNode = parentNode;
	}
	/*public Integer getUtilisateurId() {
		return utilisateurId;
	}
	public void setUtilisateurId(Integer utilisateurId) {
		this.utilisateurId = utilisateurId;
	}
	public Integer getMetierId() {
		return metierId;
	}
	public void setMetierId(Integer metierId) {
		this.metierId = metierId;
	}*/
	
	@SuppressWarnings("unused")
	private void checkRules(TreeNodeModel source, final TreeNodeModel target) {		
		if( source.getId() != null ) {
			ClientRegleMessageServiceAsync.Util.getInstance().findMessageRegleList(
					source, new AsyncCallbackWithErrorResolution<List<ModelisateurRegleMessageListModel>>() {
						@Override
						public void onSuccess(List<ModelisateurRegleMessageListModel> result) {
							if( result != null ) {
								for (ModelisateurRegleMessageListModel rule: result) {
									if (rule.getTargetNode().getId().intValue() == target.getId().intValue()) {
										if (rule.getRelation() == Niveau.INTERDITE.getIndex()) {
											// invalid  
										}
									}
								}
							}
						}
					});
		}		
	}
	public boolean isCreateModele() {
		return createModele;
	}
	public void setCreateModele(boolean createModele) {
		this.createModele = createModele;
	}
	public boolean isCreate() {
		return create;
	}
	public void setCreate(boolean create) {
		this.create = create;
	}
	
}
