package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.MdlReferenceElement;

public interface ReferenceElementProperties extends PropertyAccess<MdlReferenceElement>{
	 
	 ModelKeyProvider<MdlReferenceElement> getIdElement();

	 ValueProvider<MdlReferenceElement, String> elementLibelle();

	 ValueProvider<MdlReferenceElement, Short> nQuantite();
	 
	 ValueProvider<MdlReferenceElement, String> referenceLibelle();
}
