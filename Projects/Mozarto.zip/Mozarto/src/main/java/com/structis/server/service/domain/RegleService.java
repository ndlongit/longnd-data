package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlRegle;
import com.structis.shared.model.reference.RuleConflictInfo;
import com.structis.shared.model.reference.TreeNodeModel;

public interface RegleService {
	
	
	/**
	 * Find regle list include annuler regle
	 * @param idLienCommunList
	 * @return
	 */
	List<MdlRegle> findRegleByLienCommun(Integer idModeleVersion,List<Integer> idLienCommunList);
	/**
	 * Find  list of annuler regle
	 * @param idLienCommunList
	 * @return
	 */
	List<MdlRegle> findAnnulerRegleByLienCommun(Integer idModeleVersion,List<Integer> idLienCommunList);
	/**
	 * find list of regle =  regle - annuler
	 * @param idModeleVersion
	 * @param idLienCommunList
	 * @return
	 */
	List<MdlRegle> findRegleListExcludeAnnuler(Integer idModeleVersion, List<Integer> idLienCommunList);
	/**
	 * check rule conflict int the tree modelisateur
	 * 
	 * @param sourceNode
	 * @param targetNode
	 * @param priorite
	 * @param quantite
	 * @return
	 */
	RuleConflictInfo checkConflict(TreeNodeModel sourceNode, TreeNodeModel targetNode, int priorite, int quantite, boolean isUdate);

	/**
	 * find object from idLienCommunList from mz_mdl_regle table
	 * 
	 * @param idLienCommunList
	 * @return
	 */
	TreeNodeModel findNodeByIdLienCommun(Integer idModeleVersion, Integer idLienCommun);

	/**
	 * Find idLienCommun of parents Node Hierarchy of source Node
	 * 
	 * @param sourceNode
	 * @param idModeleVersion
	 * @return
	 */
	List<Integer> findLienCommunsHierarchyUp(TreeNodeModel sourceNode, int idModeleVersion);

	/**
	 * find idLienCommun of children node Hierarchy of source Node
	 * 
	 * @param sourceNode
	 * @param idModeleVersion
	 * @return
	 */
	List<Integer> findLienCommunsHierarchyDown(TreeNodeModel sourceNode, int idModeleVersion);
	
	/**
	 * 
	 * @param sourceNode
	 * @param idRegle
	 */
	void cancelInheritage(Integer idUser,TreeNodeModel sourceNode, int idRegle);
	/**
	 * delete regle in the source node and annuler regle in the children node
	 * @param sourceNode
	 * @param idRegle
	 */
	void delete(Integer idUser,TreeNodeModel sourceNode,int idRegle);
	/**
	 * delete regle that have the id in the idRegle list
	 */
	void deleteList(int idModeleVersion, List<Integer> igRegle);
	
	MdlRegle findById(int idRegle);
	
	void update(MdlRegle regle);
	
	void insert(MdlRegle regle);
	
	/**
	 * Delete regle that have source or target in the idLienCoummuns List
	 * @param idLienCommuns
	 */
	void deleteByIdLienCommun(int idModeleVersion, List<Integer> idLienCommuns);
	
	List<MdlRegle> findRegleByIdCibleLienCommun(int idModeleVersion, Integer idLienCommun);
}
