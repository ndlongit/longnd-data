package com.structis.client.panel;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.FocusEvent;
import com.sencha.gxt.widget.core.client.event.FocusEvent.FocusHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FormPanel.LabelAlign;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.form.Validator;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.RenameTreeNodeEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.panel.validator.NonExisteValidator;
import com.structis.client.properties.AttributElementModelProperties;
import com.structis.client.properties.ReferenceElementProperties;
import com.structis.client.service.ClientElementServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.client.widget.PagingToolBarWithoutDisplayText;
import com.structis.shared.model.Element;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.reference.AttributElementModel;
import com.structis.shared.model.reference.ElementFormModel;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurElementForm extends AbstractModelisateurEditForm {

	private TextField libele;

	private TextField code;
	
	private String libelleActuel = "";
	
	private String codeActuel = "";

	private Element elementModel;

	private Grid<AttributElementModel> attrElementGrid;

	private ListStore<AttributElementModel> attrElementStore;


	private Grid<MdlReferenceElement> gridEds;

	private ListStore<MdlReferenceElement> storeEds;	
	
	private VerticalLayoutContainer labelCommentContainer;
	
	private PagingLoader<PagingLoadConfig, PagingLoadResult<MdlReferenceElement>> loader;
	

	@SuppressWarnings("unused")
	private NavigationService navigation = NavigationFactory.getNavigation();

	@SuppressWarnings("unchecked")
	private Validator<String> nonExisteValidation = new NonExisteValidator();
	
	public ModelisateurElementForm(SimpleEventBus bus, TreeNodeModel item, TreeNodeModel parent) {
		super(bus, item, parent);		
	}
	
	public ModelisateurElementForm(SimpleEventBus bus, TreeNodeModel item) {
		super(bus, item);
	}

	@Override
	protected VerticalLayoutContainer buildPanel() {
		Label titleLable = new Label(messages.modelisateurElementDeComposition());
		titleLable.addStyleName("editFormTitle");

		VerticalLayoutContainer mainContainer = new VerticalLayoutContainer();
		labelCommentContainer = new VerticalLayoutContainer();
		labelCommentContainer.add(titleLable);
		labelCommentContainer.add(new HTML("<hr/>"));
		
		libele = new TextField();
		libele.setEnabled(false);
		code = new TextField();		
		code.setEnabled(false);
		code.setAllowBlank(false);
		code.setEmptyText(messages.commonSaisirCode());

		FieldLabel libeleFieldLabel = new FieldLabel(libele, messages.modelisateurFormLibelle());
		libeleFieldLabel.setLabelSeparator("");
		libeleFieldLabel.setLabelAlign(LabelAlign.LEFT);
		FieldLabel codeFieldLabel = new FieldLabel(code, messages.modelisateurFormCode());
		codeFieldLabel.setLabelSeparator("");
		codeFieldLabel.setLabelAlign(LabelAlign.LEFT);

		//attribute grid
		buildAttrElementGrid();

		//relations grid
		buildGridEds();
		
		labelCommentContainer.add(libeleFieldLabel, new VerticalLayoutData(1, -1));
		labelCommentContainer.add(codeFieldLabel, new VerticalLayoutData(1, -1));
		labelCommentContainer.add(new Label(messages.modelisateurFormAttributsElement()));
		mainContainer.add(labelCommentContainer, new VerticalLayoutData(.98, -1));
		
		mainContainer.add(attrElementGrid, new VerticalLayoutData(.98, 100));		
		mainContainer.add(new Label(messages.modelisateurFormRelations()));
		PagingToolBarWithoutDisplayText gridEdeToolBar = new PagingToolBarWithoutDisplayText(ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
		gridEdeToolBar.bind(loader);
		gridEdeToolBar.getElement().getStyle().setProperty("borderBottom", "none");
		VerticalLayoutContainer gridEdsContainer = AppUtil.createGridWidthPagingContainer(gridEds, gridEdeToolBar) ;
		mainContainer.add(gridEdsContainer, new VerticalLayoutData(.98, .98));

		return mainContainer;
	}

	@Override
	protected void addHandler() {
		addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent paramResizeEvent) {
				libele.clearInvalid();
			}
		});
		libele.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				libelleActuel = libele.getText();
			}
		});
		libele.addKeyUpHandler(new KeyUpHandler() {			
			@Override
			public void onKeyUp(KeyUpEvent paramKeyUpEvent) {
				if(!libelleActuel.equals(libele.getText()))
					toggleSaveCancel(true);
			}
		});
		
		code.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				codeActuel = code.getText();
			}
		});
		code.addKeyUpHandler(new KeyUpHandler() {			
			@Override
			public void onKeyUp(KeyUpEvent paramKeyUpEvent) {
				if(!codeActuel.equals(code.getText()))							
					toggleSaveCancel(true);
			}
		});		

		validerButton.addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				if( libele.isValid() && code.isValid()) {										
					storeEds.commitChanges();

					ElementFormModel elementForm = new ElementFormModel();
					elementForm.setElement(elementModel);
					
					List<MdlReferenceElement> elementReferencez = new ArrayList<MdlReferenceElement>();
					elementReferencez.addAll(storeEds.getAll());
					elementForm.setListElementEntree(elementReferencez);
					ClientElementServiceAsync.Util.getInstance().updateElementInRules( parentNode,
							elementForm, new AsyncCallbackWithErrorResolution<Void>() {

								@Override
								public void onSuccess(Void paramT) {									
									RenameTreeNodeEvent renameTreeNodeEvent = new RenameTreeNodeEvent(getTabId(),elementModel.getCElement()+" - "+elementModel.getLLibelleLong());
									renameTreeNodeEvent.setNewId(elementModel.getIdElement());
									renameTreeNodeEvent.setNewVersionId(parentNode.getIdModeleVersion());
									bus.fireEvent(renameTreeNodeEvent);									
									toggleSaveCancel(false);
									code.setEnabled(false);
									treeNode.setId(elementModel.getIdElement());
									loadForm();
								}

								@Override
								public void onFailure(Throwable caught){									
									AppUtil.showMessageBox(messages.modelisateurElementViolateRules(parentNode.getLibelle(), elementModel.getCElement()));
								}
							});
					
//					ClientElementServiceAsync.Util.getInstance().updateElement(
//							elementForm, new AsyncCallbackWithErrorResolution<Void>() {
//
//								@Override
//								public void onSuccess(Void paramT) {									
//									RenameTreeNodeEvent renameTreeNodeEvent = new RenameTreeNodeEvent(getTabId(), elementModel.getLLibelleLong());
//									renameTreeNodeEvent.setNewId(elementModel.getIdElement());
//									bus.fireEvent(renameTreeNodeEvent);									
//									Info.display(messages.commonInfoHeader(), messages.commonMajSucces());
//									toggleSaveCancel(false);
//									code.setEnabled(false);
//									treeNode.setId(elementModel.getIdElement());
//									loadForm(treeNode);
//								}
//							});
				}
			}
		});
		annulerButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				showConfirmCloseMessage(messages.modelisateurElementLabel());
			}
		});
	}

	protected void resetForm() {
		loadForm();
		toggleSaveCancel(false);
	}

	@Override
	protected void loadForm() {
		if (treeNode.getId() != null || treeNode.getTempId() != null ) {
			Integer id = treeNode.getId() != null ? treeNode.getId() : treeNode.getTempId();
			ClientElementServiceAsync.Util.getInstance().findElementFormModelByElementId(
					treeNode.getIdModeleVersion(), id,
					new AsyncCallbackWithErrorResolution<ElementFormModel>() {
						@Override
						public void onSuccess(ElementFormModel result) {
							if( result != null ) {
								elementModel = result.getElement();
								libele.setValue(elementModel.getLLibelleLong());
								code.setValue(elementModel.getCElement());
								attrElementStore.clear();
								if( result.getListAttributEtendu() != null ) {
									attrElementStore.addAll(result.getListAttributEtendu());
								}
								storeEds.clear();
								/*if( result.getListElementEntree() != null ) {
									storeEds.addAll(result.getListElementEntree());
								}	*/
								loader.load();
							}
						}
					});
		} else {
			storeEds.clear();
			code.clear();
			code.removeValidator(nonExisteValidation);
			libele.clear();
			code.setEnabled(true);			
			code.addChangeHandler(new ChangeHandler() {
				@Override
				public void onChange(ChangeEvent paramChangeEvent) {
					ClientElementServiceAsync.Util.getInstance().findElementFormModelByElementCodeAndModelVersion(code.getText(),treeNode.getIdModeleVersion(), new AsyncCallbackWithErrorResolution<ElementFormModel>() {

						@Override
						public void onSuccess(ElementFormModel result) {
							
							if (result == null ) {	
								code.addValidator(nonExisteValidation);
								code.validate();															
							} else {
								code.removeValidator(nonExisteValidation);
								code.validate();
								elementModel = result.getElement();
								libele.setValue(elementModel.getLLibelleLong());
								code.setValue(elementModel.getCElement());
								attrElementStore.clear();
								if( result.getListAttributEtendu() != null ) {
									attrElementStore.addAll(result.getListAttributEtendu());
								}
								storeEds.clear();
								if( result.getListElementEntree() != null ) {
									storeEds.addAll(result.getListElementEntree());
								}					
								Integer parentId = parentNode.getId();
								if (parentId == null) {
									parentId = parentNode.getTempId();
								}
								if (!isExisted(storeEds, parentId)) {
									storeEds.add(createNewRelationReferenceElement(elementModel.getIdElement(), treeNode.getIdModeleVersion()));
								}
							}							
						}

						private boolean isExisted(ListStore<MdlReferenceElement> storeEds, Integer idReferenceParent) {
							for (MdlReferenceElement e: storeEds.getAll()) {
								if (e.getIdReference() == idReferenceParent) {
									return true;
								}
							}
							return false;
						}

						
						
					});
				}

				
			});
		}
	}

	private MdlReferenceElement createNewRelationReferenceElement(Integer idElement, Integer idVersion) {
		MdlReferenceElement relation = new MdlReferenceElement();
		relation.setIdElement(idElement);
		relation.setIdModeleVersion(idVersion);
		relation.setIdReference(parentNode.getId());
		relation.setReferenceLibelle(parentNode.getLibelle());		
		relation.setNQuantite((short)1);
		relation.setNew(true);
		return relation;
	}
	
	private void buildAttrElementGrid() {
		AttributElementModelProperties attprops = GWT.create(AttributElementModelProperties.class);
		ColumnConfig<AttributElementModel, String> libAttr = new ColumnConfig<AttributElementModel, String>(
				attprops.attributEtenduLibelle());
		libAttr.setHeader(messages.modelisateurFormLibelle());

		ColumnConfig<AttributElementModel, String> valAttr = new ColumnConfig<AttributElementModel, String>(
				attprops.valeur());
		valAttr.setHeader(messages.modelisateurFormValeur());
		List<ColumnConfig<AttributElementModel, ?>> l = new ArrayList<ColumnConfig<AttributElementModel, ?>>();
		libAttr.setMenuDisabled(true);
		valAttr.setMenuDisabled(true);
		l.add(libAttr);
		l.add(valAttr);
		ColumnModel<AttributElementModel> cm = new ColumnModel<AttributElementModel>(l);
		attrElementStore = new ListStore<AttributElementModel>(attprops.getIdElement());
		attrElementGrid = new Grid<AttributElementModel>(attrElementStore, cm);
		attrElementGrid.getView().setAutoExpandColumn(libAttr);
		attrElementGrid.getView().setAutoFill(true);
		attrElementGrid.setBorders(true);
		attrElementGrid.setHeight(100);

	}

	
	private void buildGridEds() {
		ReferenceElementProperties elementValueProperties = GWT.create(ReferenceElementProperties.class);
		RpcProxy<PagingLoadConfig, PagingLoadResult<MdlReferenceElement>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<MdlReferenceElement>>() {
			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<MdlReferenceElement>> callback) {
				ClientElementServiceAsync.Util.getInstance().loadParentPaging(treeNode.getId(), treeNode.getIdModeleVersion(), loadConfig, callback);
			}
	    };
	    
		storeEds = new ListStore<MdlReferenceElement>(elementValueProperties.getIdElement());
		
		loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<MdlReferenceElement>>(proxy);
		loader.setRemoteSort(true);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, MdlReferenceElement, PagingLoadResult<MdlReferenceElement>>(
				storeEds));
		
		ColumnConfig<MdlReferenceElement, String> ccEdeLibelle = new ColumnConfig<MdlReferenceElement, String>(
				elementValueProperties.referenceLibelle());
		ccEdeLibelle.setHeader(SafeHtmlUtils.fromString(messages.modelisateurFormRelationElementEntree()));
		ccEdeLibelle.setSortable(false);
		ccEdeLibelle.setMenuDisabled(true);

		ColumnConfig<MdlReferenceElement, Short> ccQuantite = new ColumnConfig<MdlReferenceElement, Short>(elementValueProperties.nQuantite());

		ccQuantite.setHeader(messages.modelisateurFormRelationQte());
//		ccQuantite.setWidth(70);

		List<ColumnConfig<MdlReferenceElement, ?>> lEds = new ArrayList<ColumnConfig<MdlReferenceElement, ?>>();
		lEds.add(ccEdeLibelle);
		lEds.add(ccQuantite);
		gridEds = new Grid<MdlReferenceElement>(storeEds, new ColumnModel<MdlReferenceElement>(lEds));
		gridEds.setBorders(false);
		gridEds.setLoadMask(true);
		gridEds.setLoader(loader);
		gridEds.getView().setAutoExpandColumn(ccQuantite);
		gridEds.getView().setAutoFill(true);
		//gridEds.getView().setForceFit(true);
		gridEds.getView().setAutoExpandColumn(ccEdeLibelle);
	}

	public Grid<MdlReferenceElement> getGridEds() {
		return gridEds;
	}

	public void setGridEds(Grid<MdlReferenceElement> gridEds) {
		this.gridEds = gridEds;
	}

	public void reloadGridEds(){
		gridEds.disable();
		if (code.getText() != null && !code.getText().equals("")){
			ClientElementServiceAsync.Util.getInstance().findElementFormModelByElementCodeAndModelVersion(code.getText(),treeNode.getIdModeleVersion(), new AsyncCallbackWithErrorResolution<ElementFormModel>() {
	
				@Override
				public void onSuccess(ElementFormModel result) {
					if (result != null ) {	
						storeEds.clear();
						if( result.getListElementEntree() != null ) {
							storeEds.addAll(result.getListElementEntree());
						}			
						if (parentNode != null){
							Integer parentId = parentNode.getId();
							if (parentId == null) {
								parentId = parentNode.getTempId();
							}
							if (!isExisted(storeEds, parentId)) {
								storeEds.add(createNewRelationReferenceElement(elementModel.getIdElement(), treeNode.getIdModeleVersion()));
							}
						}
						storeEds.commitChanges();
					}
					gridEds.enable();							
				}
	
				private boolean isExisted(ListStore<MdlReferenceElement> storeEds, Integer idReferenceParent) {
					for (MdlReferenceElement e: storeEds.getAll()) {
						if (e.getIdReference() == idReferenceParent) {
							return true;
						}
					}
					return false;
				}
			});
		}
	}
		
	

//	@Override
//	protected void removeRecord(Integer parentNodeId, Integer id) {
//		// no remove in db
//		RemoveNodeEvent removeNodeEvent = new RemoveNodeEvent(treeNode);									
//		bus.fireEvent(removeNodeEvent);		
//	}
	

}
