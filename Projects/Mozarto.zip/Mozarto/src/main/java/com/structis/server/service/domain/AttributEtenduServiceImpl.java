package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.persistence.AttributEtenduMapper;
import com.structis.shared.model.AttributEtendu;

/**
 * 
 * @author vu.dang
 *
 */
@Service("attributEtenduService")
public class AttributEtenduServiceImpl implements AttributEtenduService{
	@Autowired
	private AttributEtenduMapper mapper;
	
	public AttributEtendu findById(Integer id) {
		return mapper.findById(id);	
	}
	
	@Transactional
	public Integer insert(AttributEtendu record) {
		 return mapper.insert(record);	
	}
	
	@Transactional
	public Integer update(AttributEtendu record) {
		return mapper.update(record);	
	}
		
	@Transactional
	public Integer delete(AttributEtendu record) {
		return mapper.delete(record);	
	}
	
	@Transactional
	public Integer deleteById(Integer id) {
		return mapper.deleteById(id);	
	}
	public List<AttributEtendu> findAll() {
		return mapper.findAll();		
	}

	@Override
	public List<AttributEtendu> findAttributElementByMetier(Integer idMetier) {
		return mapper.findAttributElementByMetier (idMetier);
	}

	@Override
	public List<AttributEtendu> findAttributReferenceByMetier(Integer idMetier) {
		return mapper.findAttributReferenceByMetier (idMetier);
	}

	@Override
	public List<AttributEtendu> findByMetierAndType(String type, Integer idMetier) {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("idMetier", idMetier);
		params.put("cTypeAttributEtendu", type);
		return mapper.findByMetierAndType(params);
	}

	@Override
	public List<AttributEtendu> findByModelVersionAndType(String type, Integer idModeleVersion) {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("idModeleVersion", idModeleVersion);
		params.put("cTypeAttributEtendu", type);
		return mapper.findByModelVersionAndType(params);
	}

	@Override
	public List<AttributEtendu> findByCriteria(AttributEtendu criteria) {
		return mapper.findByCriteria(criteria);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<AttributEtendu> findByMetierAndTypeAndLabelList(String type, Integer idMetier, List<String> labelList) {
		Map params = new HashMap();
		params.put("type", type);
		params.put("idMetier", idMetier);
		params.put("labelList", labelList);
		return mapper.findByMetierAndTypeAndLabelList(params);
	}

	@Override
	public List<AttributEtendu> findByReferenceId(Integer referenceId) {
		return mapper.findByReferenceId(referenceId);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<AttributEtendu> findElementAttributeByElementId(Integer metierId, Integer elementId) {
		Map params = new HashMap();
		params.put("metierId", metierId);
		params.put("elementId", elementId);
		return mapper.findElementAttributeByElementId(params);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Integer insertList(List<AttributEtendu> attributEtendus) {
		if(attributEtendus != null && attributEtendus.size() > 0){
			Map map = new HashMap ();
			map.put("attributEtenduList", attributEtendus);
			return mapper.insertList(map);
		}
		else
			return null;
	}

	@Override
	public short findMaxRang() {
		return mapper.findMaxRang().shortValue();
	}

	@Override
	public List<AttributEtendu> findAllByMetier(Integer idMetier) {
		return mapper.findAllByMetier(idMetier);
	}
}
