package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.sencha.gxt.cell.core.client.AbstractEventCell;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.HasSelectHandlers;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.image.Images;

public abstract class CheckBoxCell extends AbstractEventCell<com.structis.shared.model.Element> implements HasSelectHandlers  {
	interface Templates extends SafeHtmlTemplates {
		@SafeHtmlTemplates.Template("<div name=\"{0}\" style=\"{1}\">{2}</div>")
		SafeHtml cell(String name, SafeStyles styles, SafeHtml value);
	}
	public CheckBoxCell() {
		super("click", "keydown");	
	}
	/**
	 * Create a singleton instance of the templates used to render the cell.
	 */
	private static Templates templates = GWT.create(Templates.class);
	private static final SafeHtml ICON_CHECKED = makeImage(Images.RESOURCES.checkIcon());
	private static final SafeHtml ICON_UNCHECKED = makeImage(Images.RESOURCES.uncheckIcon());
	@Override
	public void onBrowserEvent(com.google.gwt.cell.client.Cell.Context context,
	Element parent, com.structis.shared.model.Element value, NativeEvent event,
	com.google.gwt.cell.client.ValueUpdater<com.structis.shared.model.Element> valueUpdater) {
		// Let AbstractCell handle the keydown event.
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
		
		// Handle the click event.
		if( "click".equals(event.getType()) ) {
			// Ignore clicks that occur outside of the outermost element.
			EventTarget eventTarget = event.getEventTarget();
			if( parent.isOrHasChild(Element.as(eventTarget)) ) {
				// if (parent.getFirstChildElement().isOrHasChild(
				// Element.as(eventTarget))) {
				// use this to get the selected element!!
				Element el = Element.as(eventTarget);
				// check if we really click on the image
				if( el.getNodeName().equalsIgnoreCase("IMG") ) {
					//Window.alert(el.getParentElement().getAttribute("name"));
					if(el.getParentElement().getAttribute("name").equals("ICON_CHECKED"))
						onCheck(value);
					if(el.getParentElement().getAttribute("name").equals("ICON_UNCHECKED")){
						onUncheck(value);
					}
				}
			}
		}
	};


	@Override
    public void render(Context context, com.structis.shared.model.Element value, SafeHtmlBuilder sb) {
		 if (value == null) {
	            return;
	        }
	        SafeStyles imgStyle = SafeStylesUtils
	                .fromTrustedString("float:left;cursor:hand;cursor:pointer;");
	        SafeHtml rendered;
	        if (value.getAdded()){
	        	rendered = templates.cell("ICON_CHECKED", imgStyle, ICON_CHECKED);
	 	        sb.append(rendered);
	        } else {     		        	
		        rendered = templates.cell("ICON_UNCHECKED", imgStyle, ICON_UNCHECKED);
		        sb.append(rendered);
	        }
    }

	
	private static SafeHtml makeImage(ImageResource resource) {
		AbstractImagePrototype proto = AbstractImagePrototype.create(resource);
		return proto.getSafeHtml();
	}
	@Override
	public HandlerRegistration addSelectHandler(SelectHandler handler) {
		return addHandler(handler, SelectEvent.getType());
	}
	
	public abstract void onCheck(com.structis.shared.model.Element node);
	public abstract void onUncheck(com.structis.shared.model.Element node);

}
