package com.structis.client.ecran;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.LoadCompositionEvent;
import com.structis.client.event.ModelisateurExecuterModeleEvent;
import com.structis.client.event.ModelisateurExecuterModeleHandler;
import com.structis.client.message.ActionMessages;
import com.structis.client.navigation.Action;
import com.structis.client.navigation.ActionHelper;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.panel.AbstractTabPanel;
import com.structis.client.panel.HeaderPanel;
import com.structis.client.widget.SizeLimitViewPort;
import com.structis.shared.model.Metier;
/**
 * AccueilEcran contain the tab list
 * @author vinh.tong
 *
 */
public class AccueilEcran  extends AbstractTabPanel  implements EcranLoadable {
	
	private HeaderPanel header;
	Action[] actionsData = {Action.ACTION_MODELISATEUR,Action.ACTION_COMPOSITEUR,Action.ACTION_GESTION_DES_METIERS,Action.ACTION_GESTION_DU_METIER,
			Action.ACTION_GESTION_DES_UTILISATEURS_ADMINGENERAL,Action.ACTION_GESTION_DES_UTILISATEURS,Action.ACTION_GESTION_DES_ELEMENTS_DE_COMPOSITION};
	
	private List<Action> actions = Arrays.asList(actionsData);
	private Metier metier;
	private  VerticalLayoutContainer container;
	private ActionMessages actionMessages =  GWT.create(ActionMessages.class);;
	
	@Override
	protected void onAfterFirstAttach() {
		
		//initTabSet(actions);
		ActionMessages actionMessages = GWT.create(ActionMessages.class);
		LinkedHashMap<String, String> actionRules = navigation.getContext().getActions();
		actions = new ArrayList<Action>();
		
		for(String idAction:actionRules.keySet()){
			actions.add(ActionHelper.getActionFromLabel(idAction));
		}
		initTabSet(actions);
		metier = navigation.getContext().getMetier();
	    for(Action action:tabActionList){
	    	SimpleContainer container = new SimpleContainer();
	    	container.setBorders(false);
	    	container.setBorders(false);
	    	tabSet.add(container, actionMessages.getString(action.getLabel()));
	    }
	    tabSet.addSelectionHandler(new SelectionHandler<Widget>() {
			
			@Override
			public void onSelection(SelectionEvent<Widget> event) {
			    //get action
		        Widget w = event.getSelectedItem();
		        tabSet.getWidgetIndex(w);
		        Action action = tabActionList.get(tabSet.getWidgetIndex(w));
			    navigation.goToTabEcran(action,new NavigationEvent());
			    loadTabContent(action,null);
			}
		});
	    navigation.getBus().addHandler(ModelisateurExecuterModeleEvent.getType(), new ModelisateurExecuterModeleHandler() {
			@Override
			public void onLoad(ModelisateurExecuterModeleEvent modifierModeleEvent) {
				navigation.getContext().setIdModeleVersionComposition(modifierModeleEvent.getIdModeleVersion());
				tabSet.setActiveWidget( tabSet.getWidget(1));
				navigation.getBus().fireEvent(new LoadCompositionEvent(modifierModeleEvent.getIdModeleVersion()));
				Map<String, String> params = new HashMap<String, String>();
				params.put(ConstantClient.Parameters.MODELISATION, modifierModeleEvent.getIdModeleVersion()+"");
				NavigationEvent navigationEvent = new NavigationEvent(params);
				navigation.goToTabEcran(Action.ACTION_COMPOSITEUR,navigationEvent);
			}
		});
	    SizeLimitViewPort viewPort = new SizeLimitViewPort();
	    
	    header = new HeaderPanel(false);
	    container = new VerticalLayoutContainer();
	    container.add(header,new VerticalLayoutData(1, ConstantClient.ScreenSize.HEADERHEIGHT, new Margins(0)));
	    container.add(tabSet,new VerticalLayoutData(1, 1, new Margins(0)));
	    viewPort.add(container);
	    add(viewPort);
	}
	private void initUserTab(){
		LinkedHashMap<String, String> actionRules = navigation.getContext().getActions();
		actions = new ArrayList<Action>();
		
		for(String idAction:actionRules.keySet()){
			actions.add(ActionHelper.getActionFromLabel(idAction));
		}
		tabSet.removeFromParent();
		initTabSet(actions);
		for(Action action:tabActionList){
	    	SimpleContainer container = new SimpleContainer();
	    	container.setBorders(false);
	    	container.setBorders(false);
	    	tabSet.add(container, actionMessages.getString(action.getLabel()));
	    }
		container.add(tabSet,new VerticalLayoutData(1, 1, new Margins(0)));
	    tabSet.addSelectionHandler(new SelectionHandler<Widget>() {
			@Override
			public void onSelection(SelectionEvent<Widget> event) {
			    //get action
		        Widget w = event.getSelectedItem();
		        tabSet.getWidgetIndex(w);
		        Action action = tabActionList.get(tabSet.getWidgetIndex(w));
			    navigation.goToTabEcran(action,new NavigationEvent());
			    loadTabContent(action,null);
			}
		});
	    
	}
	public void loadTabContent(Action action,NavigationEvent event){
		SimpleContainer container = (SimpleContainer) tabSet.getActiveWidget();
		container.clear();
		EcranLoadable ecran = navigation.getMapNavigation().get(action).getEcran();
		if(ecran != null){
			container.add(ecran);
			if(event != null)
				ecran.onLoadApplication(event);
		}
	}
	@Override
	public void onLoadApplication(NavigationEvent event) {
		if(metier.getIdMetier().intValue() != navigation.getContext().getMetier().getIdMetier().intValue()){
			metier = navigation.getContext().getMetier();
			initUserTab();
		}
		//get action
		String action = event.getParameter(ConstantClient.Parameters.ACTION);
		//get tab correlative with action
		if( action != null && tabActionList.indexOf(ActionHelper.getActionFromLabel(action)) > 0 && !Action.ACTION_ACCEUIL.getLabel().equals(
				action)){
			tabSet.setActiveWidget(tabSet.getWidget(tabActionList.indexOf(ActionHelper.getActionFromLabel(action))));
			loadTabContent(ActionHelper.getActionFromLabel(action),event);
		}else {
			tabSet.setActiveWidget(tabSet.getWidget(0));
			loadTabContent(actions.get(0),event);
		}
	}
}
