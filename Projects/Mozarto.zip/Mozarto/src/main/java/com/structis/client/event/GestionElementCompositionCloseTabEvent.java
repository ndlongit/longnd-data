package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GestionElementCompositionCloseTabEvent extends GwtEvent<GestionElementCompositionCloseTabHandler> {

	private static Type<GestionElementCompositionCloseTabHandler> TYPE = new Type<GestionElementCompositionCloseTabHandler>();

	public static Type<GestionElementCompositionCloseTabHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionElementCompositionCloseTabHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionElementCompositionCloseTabHandler handler) {
		handler.onLoad(this);
	}
	
	public GestionElementCompositionCloseTabEvent() {
	}

}
