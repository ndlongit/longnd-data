package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface GestionDuMetierAddTabHandler extends EventHandler {
	void onLoad(GestionDuMetierAddTabEvent metiersAddTabEvent);
}
