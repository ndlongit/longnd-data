package com.structis.server.service.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.ImportElementErrorMapper;
import com.structis.shared.model.ImportElementError;

@Service(ImportElementErrorService.SERVIECE_NAME)
public class ImportElementErrorServiceImpl implements ImportElementErrorService {

	@Autowired
	private ImportElementErrorMapper mapper;

	@Override
	public void deleteByImportElementIds(List<Integer> importElementIds) {
		mapper.deleteByImportElementIds(importElementIds);
	}

	@Override
	public ImportElementError findById(Integer id) {
		return mapper.findById(id);
	}

	@Override
	public Integer insert(ImportElementError record) {
		return mapper.insert(record);
	}

	@Override
	public Integer update(ImportElementError record) {
		return mapper.update(record);
	}

	@Override
	public Integer delete(ImportElementError record) {
		return mapper.delete(record);
	}

	@Override
	public Integer deleteById(Integer id) {
		return mapper.deleteById(id);
	}

	@Override
	public List<ImportElementError> findAll() {
		return mapper.findAll();
	}

	@Override
	public List<ImportElementError> findByImportedId(Integer importedId) {
		return mapper.findByImportedId(importedId);
	}

}
