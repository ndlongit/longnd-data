package com.structis.client.panel.admin;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.structis.client.constant.ConstantClient.ScreenSize;
import com.structis.client.ecran.EcranLoadable;
import com.structis.client.event.GestionMetierAddTabEvent;
import com.structis.client.event.GestionMetierAddTabHandler;
import com.structis.client.event.GestionMetierCloseTabEvent;
import com.structis.client.event.GestionMetierCloseTabHandler;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.widget.CustomizeBorderlayoutContainer;
import com.structis.client.widget.DynamicTabPanel;
import com.structis.shared.model.reference.MetierMzPzModel;

/**
 * administrator screen Gestion Des Element De Composition
 * 
 * @author vinh.tong
 */
public class GestionDesMetiersContainer extends SimpleContainer implements EcranLoadable {

	private DynamicTabPanel centerPanel;

	private SimpleEventBus bus = new SimpleEventBus();

	private final Messages messages = GWT.create(Messages.class);

	private GestionDesMetiersLeftPanel west;

	private static int tabNum = -1;
	
//	private NavigationService navigation = NavigationFactory.getNavigation();
	
	public GestionDesMetiersContainer() {

	}

	/**
	 * 
	 */
	@Override
	protected void onAfterFirstAttach() {
		super.onAfterFirstAttach();
		CustomizeBorderlayoutContainer container = new CustomizeBorderlayoutContainer();
		west = new GestionDesMetiersLeftPanel(bus);

		BorderLayoutData westData = new BorderLayoutData(ScreenSize.MINLEFT);
		westData.setCollapsible(true);
		westData.setSplit(true);
		westData.setCollapseMini(true);
		westData.setMargins(new Margins(0, 5, 0, 0));
		westData.setMinSize(ScreenSize.MINLEFT);
		
		ContentPanel leftPanel = new ContentPanel();
		leftPanel.setHeaderVisible(false);
		leftPanel.setBorders(false);
		leftPanel.setBodyBorder(false);
		leftPanel.add(west);
		container.setWestWidget(leftPanel, westData);
		centerPanel = new DynamicTabPanel(bus);
		
		MarginData centerData = new MarginData();

		container.setCenterWidget(centerPanel, centerData);
		container.setLeftTitle(messages.commonPanneauAction());

		add(container);
		
		bus.addHandler(GestionMetierAddTabEvent.getType(), new GestionMetierAddTabHandler() {
			
			@Override
			public void onLoad(GestionMetierAddTabEvent metiersAddTabEvent) {
				MetierMzPzModel metier = metiersAddTabEvent.getMetier();
				if(metier != null){
					GestionDesMetiersForm form = (GestionDesMetiersForm) centerPanel.getTabPanel().findItem(
						getTabId(metier), false);
					if( form != null ) {
						centerPanel.getTabPanel().setActiveWidget(form);
					}
					else {
						form = new GestionDesMetiersForm(bus);
						form.setId(getTabId(metier));
						form.setTabLabel(metier.getLLibelle());
						centerPanel.addItem(form, metier.getLLibelle());
						form.fillInfo(metier);
						form.setIdMetier(metier.getIdMetier());
						form.setMetier(metier);
						form.fillGrids();
					}
				}
				else {
					GestionDesMetiersForm form = new GestionDesMetiersForm(bus);
					form.setId(getTabId(metier));
					form.setTabLabel(messages.commonNouveaumetier());
					form.loadNewGrids();
					centerPanel.addItem(form, messages.commonNouveaumetier());
				}

			}
		});
		bus.addHandler(GestionMetierCloseTabEvent.getType(), new GestionMetierCloseTabHandler() {
			
			@Override
			public void onLoad(GestionMetierCloseTabEvent gestionMetierCloseTabEvent) {
				TabPanel tabPanel = centerPanel.getTabPanel();
				tabPanel.remove(tabPanel.getActiveWidget());
				
			}
		});

	}

	@Override
	public void onLoadApplication(NavigationEvent event) {
	}
	
	private String getTabId(MetierMzPzModel metier) {
		if( metier != null )
			return "tab-" + metier.getLLibelle() + "-" + metier.getIdMetier();
		else {
			tabNum++;
			return "tab-" + tabNum;
		}
	}
}
