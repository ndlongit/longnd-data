package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;

public interface AttributEtenduMetierERValueProperties extends PropertyAccess<AttributEtenduMetierERValueModel> {
	ModelKeyProvider<AttributEtendu> getIdAttributEtendu();

	ValueProvider<AttributEtendu, String> lLibelle();

	ValueProvider<AttributEtendu, String> lValeur();

}
