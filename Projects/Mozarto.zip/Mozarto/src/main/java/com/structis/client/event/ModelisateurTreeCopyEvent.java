package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class ModelisateurTreeCopyEvent extends GwtEvent<ModelisateurTreeCopyHandler> {

	private static Type<ModelisateurTreeCopyHandler> TYPE = new Type<ModelisateurTreeCopyHandler>();

	public static Type<ModelisateurTreeCopyHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModelisateurTreeCopyHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModelisateurTreeCopyHandler handler) {
		handler.onLoad(this);
	}
	
	private Boolean confirmCopy;
	private Boolean copyRegles;
	private Boolean copyMessages;
	private Boolean copyChildren;

	public ModelisateurTreeCopyEvent(Boolean confirmCopy, Boolean copyRegles, Boolean copyMessages, Boolean copyChildren) {
		this.confirmCopy = confirmCopy;
		this.copyChildren = copyChildren;
		this.copyMessages = copyMessages;
		this.copyRegles = copyRegles;
	}

	public Boolean isConfirmCopy() {
		return confirmCopy;
	}

	public void setConfirmCopy(Boolean confirmCopy) {
		this.confirmCopy = confirmCopy;
	}

	public Boolean isCopyRegles() {
		return copyRegles;
	}

	public void setCopyRegles(Boolean copyRegles) {
		this.copyRegles = copyRegles;
	}

	public Boolean isCopyMessages() {
		return copyMessages;
	}

	public void setCopyMessages(Boolean copyMessages) {
		this.copyMessages = copyMessages;
	}

	public Boolean isCopyChildren() {
		return copyChildren;
	}

	public void setCopyChildren(Boolean copyChildren) {
		this.copyChildren = copyChildren;
	}

}
