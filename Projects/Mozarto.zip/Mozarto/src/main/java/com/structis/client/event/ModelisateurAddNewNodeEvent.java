package com.structis.client.event;

import java.util.List;
import java.util.Stack;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurAddNewNodeEvent extends GwtEvent<ModelisateurAddNewNodeHandler> {

	private static Type<ModelisateurAddNewNodeHandler> TYPE = new Type<ModelisateurAddNewNodeHandler>();

	public static Type<ModelisateurAddNewNodeHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModelisateurAddNewNodeHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModelisateurAddNewNodeHandler handler) {
		handler.onLoad(this);
	}

	private Integer nodeParentId;
	private String nodeParentLibele;
	private ModelNodeType parentType;
	//private TreeNodeModel treeNode;
	private List<TreeNodeModel> treeNodes;

	Stack<TreeNodeModel> itemsPath;

	public ModelisateurAddNewNodeEvent(List<TreeNodeModel> treeNodes, Stack<TreeNodeModel> itemsPath) {
		this.treeNodes = treeNodes;
		this.itemsPath = itemsPath;
	}

	public List<TreeNodeModel> getTreeNodes() {
		return treeNodes;
	}

	public void setTreeNodes(List<TreeNodeModel> treeNodes) {
		this.treeNodes = treeNodes;
	}

	public Stack<TreeNodeModel> getItemsPath() {
		return itemsPath;
	}

	public void setItemsPath(Stack<TreeNodeModel> itemsPath) {
		this.itemsPath = itemsPath;
	}

	public Integer getNodeParentId() {
		return nodeParentId;
	}

	public void setNodeParentId(Integer nodeParentId) {
		this.nodeParentId = nodeParentId;
	}

	public ModelNodeType getParentType() {
		return parentType;
	}

	public void setParentType(ModelNodeType parentType) {
		this.parentType = parentType;
	}

	public String getNodeParentLibele() {
		return nodeParentLibele;
	}

	public void setNodeParentLibele(String nodeParentLibele) {
		this.nodeParentLibele = nodeParentLibele;
	}
	
		
}
