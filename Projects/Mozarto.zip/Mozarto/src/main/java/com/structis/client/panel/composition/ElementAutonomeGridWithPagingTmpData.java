package com.structis.client.panel.composition;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.SortDir;
import com.sencha.gxt.data.shared.Store.StoreSortInfo;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.CompositionHaveChangeEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.service.ClientCompositionServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.client.widget.ElementAutonomeGrid;
import com.structis.client.widget.PagingToolBarWithoutDisplayText;
import com.structis.shared.model.Element;

public class ElementAutonomeGridWithPagingTmpData extends ElementAutonomeGrid{
	
	public ElementAutonomeGridWithPagingTmpData(SimpleEventBus bus) {
		super(bus);
	}

	@Override
	protected Grid<Element> createGrid(ColumnModel<Element> cm ) {
		RpcProxy<PagingLoadConfig, PagingLoadResult<Element>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<Element>>() {
			@Override
			public void load(PagingLoadConfig loadConfig, final AsyncCallback<PagingLoadResult<Element>> callback) {
				//ClientReferenceServiceAsync.Util.getInstance().loadCaracteristiquePaging(treeNode.getIdModeleVersion(), treeNode.getId(), loadConfig, callback);
				//ClientCompositionServiceAsync.Util.getInstance().loadCeElementPagingTMPData(loadConfig, callback);
				ClientCompositionServiceAsync.Util.getInstance().loadEsElementPagingTMPData(loadConfig, callback);
			}
	    };
		ListStore<Element> store = new ListStore<Element>(props.idElement());
	    store.addSortInfo(new StoreSortInfo<Element>(props.lLibelleLong(), SortDir.ASC));
	    loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<Element>>(proxy);
		loader.setRemoteSort(false);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, Element, PagingLoadResult<Element>>(
				store));
		Grid<Element> grid = new Grid<Element>(store, cm);
		grid.setLoader(loader);
		
		return new Grid<Element>(store, cm);
	}
	
	@Override
	protected void updateChangeQuantiteNode(Element node){
		List<Element> elements = new ArrayList<Element>();
		elements.add(node);
		ClientCompositionServiceAsync.Util.getInstance().addUpdateEsElementTMPData(elements, new AsyncCallbackWithErrorResolution<Void>() {
			@Override
			public void onSuccess(Void result) {
				bus.fireEvent(new CompositionHaveChangeEvent());
			}
		});
	}
	
	@Override
	protected void updateCheck(final Element node){
		final ConfirmMessageBox box = new ConfirmMessageBox(messages.commonConfirmheader(), messages.compositionRightElementgridUncheckconfirm());
		box.setWidth(450);
		box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
		box.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				box.hide();
				/*node.setAdded(false);
				elementAutonomeGrid.getGrid().getStore().remove(node);*/
				List<Element> elements = new ArrayList<Element>();
				elements.add(node);
				ClientCompositionServiceAsync.Util.getInstance().removeEsElment(elements, new AsyncCallbackWithErrorResolution<Void>() {
					@Override
					public void onSuccess(Void result) {
						getLoader().load();
						bus.fireEvent(new CompositionHaveChangeEvent());
					}
				});
			}
		});
		box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
		box.getButtonById(PredefinedButton.NO.name()).addSelectHandler(new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				node.setAdded(true);
				grid.getStore().update(node);
				box.hide();
			}
		});
		box.show();
	}
	
	@Override
	protected void addGrid(){
		PagingToolBarWithoutDisplayText gridEdeToolBar = new PagingToolBarWithoutDisplayText(ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
		gridEdeToolBar.bind(loader);
		gridEdeToolBar.getElement().getStyle().setProperty("borderBottom", "none");
		VerticalLayoutContainer  gridEdeContainer = AppUtil.createGridWidthPagingContainer(grid, gridEdeToolBar);
		add(gridEdeContainer, new VerticalLayoutData(1, .98));
	}
	
}
