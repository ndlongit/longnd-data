package com.structis.client.service;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.RoleUtilisateur;
import com.structis.shared.model.Utilisateur;
import com.structis.shared.model.reference.UtilisateurMetierRoleModel;

@RemoteServiceRelativePath("springGwtServices/gestionUtilisateursService")
public interface ClientGestionUtilisateursService extends RemoteService {

	public PagingLoadResult<Utilisateur> findAllByMetier(Integer idMetier, PagingLoadConfig loadConfig);
	
	public List<RoleUtilisateur> findAllRole();

	public RoleUtilisateur findRoleByUtilisateurAndMetier(Integer idUtilisateur, Integer idMetier);
	
	public Integer updateRoleUtilisateur(Integer idUtilisateur, Integer idMetier, String cRole);
	
	public List<UtilisateurMetierRoleModel> getAllMetier(Integer idUtilisateur);
	
	public Utilisateur insertOrUpdate(Utilisateur utilisateur, List<UtilisateurMetierRoleModel> list);
	
//	public Metier insertOrUpdate(Utilisateur utilisateur, List<Metier>);
}
