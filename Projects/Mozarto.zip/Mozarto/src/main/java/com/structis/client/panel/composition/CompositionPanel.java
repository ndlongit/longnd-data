package com.structis.client.panel.composition;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.Style.LayoutRegion;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.FramedPanel;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer.HorizontalLayoutData;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.ExpandItemEvent;
import com.sencha.gxt.widget.core.client.event.ExpandItemEvent.ExpandItemHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.structis.client.constant.ConstantClient.ScreenSize;
import com.structis.client.event.CompositionHaveChangeEvent;
import com.structis.client.event.CompositionHaveChangeHandler;
import com.structis.client.event.CompositionTreeLoadCompleteEvent;
import com.structis.client.event.CompositionTreeLoadCompleteHandler;
import com.structis.client.event.LoadCompositionEvent;
import com.structis.client.event.LoadCompositionHandler;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.service.ClientCompositionServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.client.util.NameValuePair;
import com.structis.client.util.ReportUtil;
import com.structis.client.widget.CustimizeMessageBox;
import com.structis.client.widget.CustomizeBorderlayoutContainer;
import com.structis.server.constant.ConstantServer;
import com.structis.shared.constant.ApplicationOrigineConstant;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.CmpComposition;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.CompositionModel;
import com.structis.shared.model.reference.CompositionReferenceGridModel;
import com.structis.shared.security.RoleHelper;

public class CompositionPanel extends SimpleContainer {

	private SimpleEventBus bus;

	private Messages messages = GWT.create(Messages.class);
	
	private Integer idModeleVersion;
	
	private HorizontalLayoutContainer headerPanel;

	private CompositionTreePanel compositionTreePanel;

	private CompositionCaracteristiqueListForm caracteristiqueListPanel;

	private CompositionReferenceListForm referenceListPanel;

	private CompositionElementSupplementaire elementSupplementairePanel;

	private CompositionElementDeReference elementDeReferencePanel;

	private BorderLayoutContainer mainContainer;

	private CustomizeBorderlayoutContainer bodyPanel;

	private ContentPanel elementPanel;

	private BorderLayoutContainer elementLayout;

	private Integer idMetier;

	private Images images = GWT.create(Images.class);

	private NavigationService navigation = NavigationFactory.getNavigation();

	private VerticalLayoutContainer buttonPanel;

	private VerticalLayoutContainer refContainer;

	private VerticalLayoutContainer eltsupContainer;

	private VerticalLayoutContainer cmprefContainer;

	private ContentPanel eltsupPanel;

	private TextButton saveButton;
	
	private TextButton pegazButton;
	
	private  TextField titreComposition;
	
	@SuppressWarnings("unused")
	private boolean eltsupcollapsed = false; 
	
	private HTML metierHtml;
	
	private Integer idComposition = 0;
	
	private ContentPanel leftPanel;

	private CustomizeBorderlayoutContainer elementGrids;

	private VerticalLayoutContainer buttonPanel2;

	private Metier metier;
	
	private boolean isModifyingCompostion = false;
	
	public CompositionPanel(SimpleEventBus bus) {
		metier = navigation.getContext().getMetier();
		this.idMetier = metier.getIdMetier();
		this.bus = bus;
		setBorders(true);
		buildPanel();
		addHandler();
	}

	private void buildPanel() {

		mainContainer = new BorderLayoutContainer();
		mainContainer.setBorders(true);
		bodyPanel = new CustomizeBorderlayoutContainer();
		bodyPanel.setBorders(true);

		buttonPanel = createButtonPanel();
		buttonPanel2 = createButtonPanel();

		headerPanel = new HorizontalLayoutContainer();

		metierHtml = new HTML();
		metierHtml.setHTML((messages.commonMetier() + ": " + metier.getLLibelle()));
		headerPanel.add(metierHtml, new HorizontalLayoutData(300, 1, new Margins(4)));
		headerPanel.add(new Label(), new HorizontalLayoutData(0.5, 1, new Margins(4, 0, 4, 0)));
	
		HorizontalLayoutContainer container = new HorizontalLayoutContainer();
		titreComposition = new TextField();
		titreComposition.setWidth(headerPanel.getElement().getWidth(true));
		titreComposition.setEmptyText(messages.compositionTopTitre());
		titreComposition.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
				isModifyingCompostion = true;
			}
		});
		container.add(titreComposition, new HorizontalLayoutData(0.5, 1, new Margins(0, 5, 0, 0)));

		HTML goButton = new HTML();
		Image rightArrow = new Image();
		rightArrow.setResource(images.rightArrow());
		goButton.setHTML(rightArrow + "");
		container.add(goButton, new HorizontalLayoutData(0.1, 1, new Margins(0, 5, 0, 0)));

		CheckBox multiple = new CheckBox();
		multiple.setBoxLabel(messages.compositionTopCompositionmultiple());
		container.add(multiple, new HorizontalLayoutData(0.4, 1, new Margins(0, 5, 0, 0)));
		headerPanel.add(container, new HorizontalLayoutData(0.4, 1, new Margins(4)));
		
		headerPanel.setWidth(getElement().getWidth(true));
		

		BorderLayoutContainer caracReferPanel = new BorderLayoutContainer();

		leftPanel = new ContentPanel();
		leftPanel.setHeaderVisible(false);
		compositionTreePanel = new CompositionTreePanel(bus);
		leftPanel.add(compositionTreePanel);
		leftPanel.setId("compositionTreePanel");
		caracteristiqueListPanel = new CompositionCaracteristiqueListForm(bus);
		compositionTreePanel.setCompositionCaracteristiqueListForm(caracteristiqueListPanel);
		referenceListPanel = new CompositionReferenceListForm(bus);
		refContainer = new VerticalLayoutContainer();
		refContainer.add(referenceListPanel, new VerticalLayoutData(1, 1));
		elementSupplementairePanel = new CompositionElementSupplementaire(bus);
		eltsupContainer = new VerticalLayoutContainer();
		eltsupContainer.add(elementSupplementairePanel, new VerticalLayoutData(1, 1));
		eltsupPanel = new ContentPanel();
		eltsupPanel.setHeaderVisible(false);
		eltsupPanel.add(eltsupContainer);
		elementDeReferencePanel = new CompositionElementDeReference(bus);
		cmprefContainer = new VerticalLayoutContainer();
		cmprefContainer.add(elementDeReferencePanel, new VerticalLayoutData(1, 1));
		
		
		referenceListPanel.setElementForm(elementDeReferencePanel);
		
		
		final BorderLayoutData caracReferEastData = new BorderLayoutData(.625);
		caracReferEastData.setMinSize(ScreenSize.COMPOSITEUR_MINRIGHTCENTER);
		final BorderLayoutData caracReferWestData = new BorderLayoutData(.375);
		caracReferWestData.setMinSize(ScreenSize.COMPOSITEUR_MINLEFTCENTER);
		caracReferWestData.setSplit(true);

		caracReferPanel.setWestWidget(caracteristiqueListPanel, caracReferWestData);
		caracReferPanel.setCenterWidget(refContainer, caracReferEastData);

		final BorderLayoutData bodyWestData = new BorderLayoutData(.16);
		bodyWestData.setMargins(new Margins(0, 5, 0, 5));
		bodyWestData.setMinSize(ScreenSize.COMPOSITEUR_MINLEFT);
		bodyWestData.setSplit(true);

		final BorderLayoutData bodyEastData = new BorderLayoutData(.40);
		bodyEastData.setMinSize(ScreenSize.COMPOSITEUR_MINRIGHT);
		bodyEastData.setMargins(new Margins(0, 5, 0, 5));
		bodyEastData.setSplit(true);

		final BorderLayoutData bodyCenterData = new BorderLayoutData(.43);
		bodyCenterData.setMinSize(ScreenSize.COMPOSITEUR_MINLEFTCENTER + ScreenSize.COMPOSITEUR_MINRIGHTCENTER);

		bodyPanel.setWestWidget(leftPanel, bodyWestData);
		bodyPanel.setCenterWidget(caracReferPanel, bodyCenterData);
		bodyPanel.setRightTitle(messages.modelisateurElementDeComposition());

		elementPanel = new ContentPanel();
//		elementPanel.getButtonBar().getElement().disable();
		elementPanel.setHeaderVisible(false);
		elementLayout = new BorderLayoutContainer();
		elementPanel.add(elementLayout);
		bodyPanel.setEastWidget(elementPanel, bodyEastData);
		elementGrids = new CustomizeBorderlayoutContainer();
		elementGrids.setCenterWidget(cmprefContainer);
		elementGrids.setBottomTitle(messages.compositionRightElementgridEltsup());
		BorderLayoutData layoutData = new BorderLayoutData(0.375);
		layoutData.setMinSize(200);
		layoutData.setSplit(true);
		layoutData.setCollapseMini(false);
		elementGrids.setSouthWidget(eltsupPanel, layoutData);

		final BorderLayoutData northData = new BorderLayoutData(.06);
		northData.setMinSize(ScreenSize.MINCENTER);

		final BorderLayoutData centerData = new BorderLayoutData(0.94);
		centerData.setMinSize(ScreenSize.COMPOSITEUR_MINLEFTCENTER + ScreenSize.COMPOSITEUR_MINRIGHTCENTER + ScreenSize.COMPOSITEUR_MINRIGHT + ScreenSize.COMPOSITEUR_MINLEFT);

		mainContainer.setNorthWidget(headerPanel, northData);
		mainContainer.setCenterWidget(bodyPanel, centerData);

		add(mainContainer);

		elementLayout.setCenterWidget(elementGrids);
		BorderLayoutData southLayoutData = new BorderLayoutData(0.05);
		southLayoutData.setSize(40);
		elementLayout.setSouthWidget(buttonPanel, southLayoutData);
	}
	
	@Override
	protected void onAfterFirstAttach() {
//		loadHeaderPanel();
		if(navigation.getContext().getIdModeleVersionComposition() != 0){		
			idModeleVersion = navigation.getContext().getIdModeleVersionComposition();
		}
	}
	
	private void addHandler() {
		compositionTreePanel.getCollapseButton().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				bodyPanel.collapse(LayoutRegion.WEST);
			}
		});
		bodyPanel.addExpandHandler(new ExpandItemHandler<ContentPanel>() {

			@Override
			public void onExpand(ExpandItemEvent<ContentPanel> event) {
				
				if(event.getItem().getId() != null && leftPanel.getId().equals(event.getItem().getId())){
					compositionTreePanel.reLoadComposition();
				}
			}
		});
		elementSupplementairePanel.getCollapseButtonTop().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				elementDeReferencePanel.getCollapseButtonBottom().setVisible(true);
				eltsupcollapsed = true;
				elementGrids.collapse(LayoutRegion.SOUTH);
			}
		});
		elementSupplementairePanel.getCollapseButtonBottom().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				bodyPanel.collapse(LayoutRegion.EAST);
				refContainer.add(buttonPanel2/*, new VerticalLayoutData(1, 1)*/);

			}
		});
		bodyPanel.addExpandHandler(new ExpandItemHandler<ContentPanel>() {

			@Override
			public void onExpand(ExpandItemEvent<ContentPanel> event) {
				refContainer.remove(buttonPanel2);
				buttonPanel2.setWidth("auto");
//				buttonPanel2.setHeight("auto");

			}
		});
		elementGrids.addExpandHandler(new ExpandItemHandler<ContentPanel>() {

			@Override
			public void onExpand(ExpandItemEvent<ContentPanel> event) {
				elementDeReferencePanel.getCollapseButtonBottom().setVisible(false);
				eltsupcollapsed = false;
			}
		});
		
		elementDeReferencePanel.getCollapseButtonBottom().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				bodyPanel.collapse(LayoutRegion.EAST);
				refContainer.remove(referenceListPanel);
				refContainer.add(referenceListPanel, new VerticalLayoutData(1, 1));
				refContainer.add(buttonPanel2/*, new VerticalLayoutData(1, 1)*/);
				buttonPanel2.setWidth("auto");
//				buttonPanel2.setHeight("auto");

			}
		});
		navigation.getBus().addHandler(LoadCompositionEvent.getType(), new LoadCompositionHandler() {
			@Override
			public void onLoad(LoadCompositionEvent loadCompositionEvent) {
				isModifyingCompostion = false;
				
				idModeleVersion = loadCompositionEvent.getIdModeleVersion();
				
				elementSupplementairePanel.getElementAutonomeGrid().getGrid().getStore().clear();
				
				if(!RoleHelper.isRestricted()){
					elementSupplementairePanel.toogleAddElementLink(false);
				}else{
					elementSupplementairePanel.toogleAddElementLink(true);
				}
				if(idModeleVersion != null && idModeleVersion != 0){
					compositionTreePanel.loadComposition(idModeleVersion);
				}
			}
		});
		
		addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent event) {
				headerPanel.setWidth(event.getWidth());
				buttonPanel.setWidth("auto");
			}
		});
		bus.addHandler(CompositionTreeLoadCompleteEvent.getType(), new CompositionTreeLoadCompleteHandler() {
			
			@Override
			public void onLoad(CompositionTreeLoadCompleteEvent handler) {
				bodyPanel.setLeftTitle(handler.getLibelleModele());
			}
		});
		
		bus.addHandler(CompositionHaveChangeEvent.getType(), new CompositionHaveChangeHandler() {
			
			@Override
			public void onLoad(CompositionHaveChangeEvent compositionHaveChangeEvent) {
				isModifyingCompostion = true;
			}
		});
	}
	
	/*private void loadHeaderPanel(){
		metierHtml.setHTML((messages.commonMetier() + ": " + metier.getLLibelle()));
		ClientCompositionServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

			@Override
			public void onSuccess(Metier result) {
				metierHtml.setHTML((messages.commonMetier() + ": " + result.getLLibelle()));

			}
		});
	}*/
	private VerticalLayoutContainer createButtonPanel() {

		saveButton = new TextButton(messages.commonEnregistrer());
		saveButton.addSelectHandler(new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				saveComposition(false);
			}
		});
		pegazButton = new TextButton(messages.commonRetourPegaz());
		pegazButton.setEnabled(false);
		HTML cancelButton = new HTML(messages.commonAnnulerButton());
		cancelButton.setStyleName("htmlLink");
		HTML printButton = new HTML();
		Image printIcon = new Image();
		printIcon.setResource(images.printIcon());
		printButton.setHTML(printIcon + "");
		
		printButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				confirmBeforePrint();
			}
		});

		final FramedPanel panel = new FramedPanel();
		panel.addButton(cancelButton);
		panel.addButton(saveButton);
		panel.addButton(pegazButton);
		panel.addButton(printButton);
		panel.setButtonAlign(BoxLayoutPack.CENTER);
		panel.getButtonBar().setHorizontalSpacing(30);
//		panel.setWidth("auto");
		panel.getBody().disable();
		panel.setBorders(false);
		panel.setHeaderVisible(false);
		panel.getButtonBar().setStyleName("whiteBackGround");
		panel.setStyleName("whiteBackGround");
		VerticalLayoutContainer con = new VerticalLayoutContainer();
		con.add(panel);
		con.setStyleName("whiteBackGround");
		con.addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent arg0) {
				panel.getButtonBar().setWidth(arg0.getWidth());
				panel.getButtonBar().setHeight(arg0.getHeight());
			}
		});
		return con;
	}
	private void confirmBeforePrint(){
		if(idComposition == null || idComposition == 0 || isModifyingCompostion){
			String content = "<table><tr><td style='line-height:100%' >"+messages.compositionSaveConfirm()+"</td></tr></table>";
			AppUtil.showConfirmInfoBox(
					content, messages.commonInfoHeader(), new SelectHandler() {
						@Override
						public void onSelect(SelectEvent event) {
							saveComposition(true);
						}
					}, null);
		}else{
			donwloadComposition();
		}
	}
	private void saveComposition(final boolean download){
		String compositionLabel = titreComposition.getValue() !=null ? titreComposition.getValue():"";
		String messageError = "";
		if(compositionLabel == ""){
			messageError = messages.gestionelemcompoRightObligatoire(messages.compositionTopTitre());
			titreComposition.markInvalid(messages.gestionelemcompoRightObligatoire(messages.compositionTopTitre()));
		}else if(compositionLabel.length() > 500){
			messageError =  messages.commonLongeurMaxError(500);
			titreComposition.markInvalid(messages.commonLongeurMaxError(500));
		}
		if(!"".equals(messageError)){
			CustimizeMessageBox messageBox = new CustimizeMessageBox(messages.commonInfoHeader(), messageError+" ");
			messageBox.show();
			return ;
		}
		CmpComposition cmpComposition = new CmpComposition();
		cmpComposition.setIdModeleVersion(idModeleVersion);
		cmpComposition.setIdComposition(idComposition);
		cmpComposition.setCApplicationOrigine(ApplicationOrigineConstant.MOZARTO.getCode());
		cmpComposition.setIdUtilisateurCrea(navigation.getContext().getUtilisateur().getIdUtilisateur());
		cmpComposition.setIdUtilisateurDmaj(navigation.getContext().getUtilisateur().getIdUtilisateur());
		
		cmpComposition.setLLibelleLong(compositionLabel);
		
		List<Integer> cmpCaracteristiquesSelect =  caracteristiqueListPanel.getSelectedIds();
		
		List<CompositionReferenceGridModel> cmpReference = referenceListPanel.getSelectItems();
		
		//List<CompositionElementGridModel> cmpReferenceRegleElement = elementDeReferencePanel.getSelectItems();
		
		//List<Element> cmpElementSelect =  elementSupplementairePanel.getElementAutonomeGrid().getSelectedItems();
		
		CompositionModel composition = new CompositionModel();
		
		composition.setComposition(cmpComposition);
		composition.setCmpCaracteristiquesSelect(cmpCaracteristiquesSelect);
		composition.setCmpReference(cmpReference);
		//composition.setCmpReferenceRegleElement(cmpReferenceRegleElement);
		//composition.setCmpElementSelect(cmpElementSelect);
		
		ClientCompositionServiceAsync.Util.getInstance().saveCompostion(composition, new AsyncCallbackWithErrorResolution<Integer>() {
			@Override
			public void onSuccess(Integer result) {
				//Info.display(messages.commonInfoHeader(), messages.commonMajSucces());
				idComposition = result;
				isModifyingCompostion = false;
				if(download){
					//donwloadComposition();
				}
			}
		});
		
	}
	private void donwloadComposition(){
		List<NameValuePair> values = new ArrayList<NameValuePair>();
		values.add(new NameValuePair(ConstantServer.PARAM_REPORT_NAME, "composition-report.rptdesign"));
		values.add(new NameValuePair(ConstantServer.PARAM_COMPOSITION_ID, idComposition + ""));
		values.add(new NameValuePair(ConstantServer.PARAM_MODEL_EVERSION_ID, idModeleVersion + ""));
		values.add(new NameValuePair(Constant.ID_METIER, idMetier + ""));
		values.add(new NameValuePair(Constant.ID_USER, navigation.getContext().getUtilisateur().getIdUtilisateur() + ""));
		String url = GWT.getHostPageBaseURL() + "showBirtReport";
		ReportUtil.showReport(url, values.toArray(new NameValuePair[values.size()]));
	}
	
	public CompositionTreePanel getCompositionTreePanel() {
		return compositionTreePanel;
	}

	public void setCompositionTreePanel(CompositionTreePanel compositionTreePanel) {
		this.compositionTreePanel = compositionTreePanel;
	}

	public void expandElementSupplementairePanel(){
		elementSupplementairePanel.getMainPanel().setVisible(true);
		elementSupplementairePanel.getCollapsePanel().setVisible(false);
		cmprefContainer.setLayoutData(new VerticalLayoutData(1, 0.65));
		eltsupPanel.setLayoutData(new VerticalLayoutData(1, 0.35));
//		elementLayout.setHeight("auto");
		elementDeReferencePanel.getCollapseButtonBottom().setVisible(false);
	}
}
