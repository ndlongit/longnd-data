package com.structis.server.core;

import org.apache.log4j.Level;


public class Logger {

	private String FQCN = Logger.class.getName();
	private org.apache.log4j.Logger logger;
	
	public static Logger getLogger(Class<?> clazz){
		org.apache.log4j.Logger loggerTemp = 
			org.apache.log4j.Logger.getLogger(clazz);
		return new Logger(loggerTemp);
	}
	
	private Logger(org.apache.log4j.Logger logger){
		this.logger = logger;
	}
	
	public void debug(Object message){
		logger.log(FQCN, Level.DEBUG, message, null);
	}
	
	public void info(Object message){
		logger.log(FQCN, Level.INFO, message, null);
	}
	
	public void error(Object message){
		logger.log(FQCN, Level.ERROR, message, null);
	}
	
	public void error(Object message, Throwable t){
		logger.log(FQCN, Level.ERROR, message, t);
	}
	
	public boolean isDebugEnabled() {
		return logger.isDebugEnabled();
	}
}
