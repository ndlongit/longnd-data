package com.structis.server.service.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.client.navigation.NavigationFactory;
import com.structis.client.util.ImportUtil;
import com.structis.server.constant.ConstantServer;
import com.structis.server.persistence.ImportElementMapper;
import com.structis.server.util.StringUtils;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.AttributEtenduElement;
import com.structis.shared.model.AttributEtenduElementKey;
import com.structis.shared.model.Element;
import com.structis.shared.model.Famille;
import com.structis.shared.model.ImportElement;
import com.structis.shared.model.ImportElementError;

@Service(ImportElementService.SERVIECE_NAME)
public class ImportElementServiceImpl implements ImportElementService {

	private static final String[] FIXED_ELEMENT_TYPES = { "", "FAM", "SFA", "GRP", "SGR", "TEL", "CEL", "ELT", "NFO", "ACT" };

	@Autowired
	private ImportElementMapper mapper;

	@Autowired
	FamilleService familleService;

	@Autowired
	ElementService elementService;

	@Autowired
	ImportElementErrorService importElementErrorService;

	@Autowired
	AttributEtenduService attributEtenduService;

	@Autowired
	AttributEtenduElementService attributEtenduElementService;
	
	private static Locale locale;

	static {
		locale = new Locale(NavigationFactory.getNavigation().getContext().getLanguageCode());
	}

	@Override
	public ImportElement findById(Integer id) {
		return mapper.findById(id);
	}

	@Override
	public Integer insert(ImportElement record) {
		return mapper.insert(record);
	}

	@Override
	public Integer update(ImportElement record) {
		return mapper.update(record);
	}

	@Override
	public Integer delete(ImportElement record) {
		return mapper.delete(record);
	}

	@Override
	public Integer deleteById(Integer id) {
		return deleteById(id);
	}

	@Override
	public List<ImportElement> findAll() {
		return mapper.findAll();
	}

	@Override
	public List<Integer> getAllLinesByImportId(Integer importId) {
		return mapper.getAllLinesByImportId(importId);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<Map> findByImportIdAndLineNumber(Integer importId, Integer lineNumber) {
		Map<String, Integer> params = new HashMap<String, Integer>();
		params.put("importId", importId);
		params.put("lineNumber", lineNumber);
		return mapper.findByImportIdAndLineNumber(params);
	}

	@Override
	public String saveAttributeValuePairs(int startAttributeValueIndex, int endAttributeValueIndex, String[] headerColums,
			String[] row, int line, int metierId, int idImport, String attributeType, String valueType,
			String attributEtenduType, String csvError, String currentSubModel,
			Map<String, List<String>> subModelAttributeMap, ResourceBundleMessageSource messageSource) {
		
		if( startAttributeValueIndex < 0 || endAttributeValueIndex < 0 || endAttributeValueIndex <= startAttributeValueIndex ) {
			return csvError;
		}

		if( (endAttributeValueIndex - startAttributeValueIndex + 1) % 2 != 0 ) {
			csvError = messageSource.getMessage("import.element.error.attributeAndValueMustBeFullyPresent", null, locale);
		}
		else {

			//Attribute/Value pairs
			String attribute = null;
			String value = null;
			ImportElement data = null;
			ImportElementError elementError = null;
			String dbError = "";

			List<String> attributeValueList = new ArrayList<String>();
			
			boolean attributeDuplicated = false;

			for( int k = startAttributeValueIndex ; k < endAttributeValueIndex ; k = k + 2 ) {

				attribute = row[k];
				value = row[k + 1];
				
				dbError = "";
				if( StringUtils.isNullOrEmtpy(attribute) ) {
					if( !StringUtils.isNullOrEmtpy(value) ) {

						//Save Attribute
						data = new ImportElement();
						data.setCTypeElementImport(attributeType);
						data.setIdImport(idImport);
						data.setLValeur(attribute);
						data.setNColonne(k - 1);
						data.setNLigne(line);
						insert(data);

						dbError = messageSource.getMessage("import.element.error.attributeIsRequiredForValue", null, locale);
						csvError = ImportUtil.appendError(csvError, dbError);
						elementError = new ImportElementError();
						elementError.setIdElementImport(data.getIdElementImport());
						elementError.setLLibelleLong(dbError);
						importElementErrorService.insert(elementError);

						//Save Value
						data = new ImportElement();
						data.setCTypeElementImport(valueType);
						data.setIdImport(idImport);

						data.setLValeur(value);
						data.setNColonne(k);
						data.setNLigne(line);
						
						//Check data format of Value
						elementError = checkMaxLength2(k + 1, data, headerColums, messageSource); // Check max-length and truncate if needed				
						insert(data);
						
						if( elementError != null ) { // Violate max-length rule
							csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
							elementError.setIdElementImport(data.getIdElementImport());
							importElementErrorService.insert(elementError);
						}
					}
				}
				else {

					// Attribute is not null
					//Save Attribute
					data = new ImportElement();
					data.setCTypeElementImport(attributeType);
					data.setIdImport(idImport);

					data.setLValeur(attribute);
					data.setNColonne(k - 1);
					data.setNLigne(line);
					
					//Check data format of Attribute
					elementError = checkMaxLength(k, data, headerColums, messageSource); // Check max-length and truncate if needed	
					insert(data);
					
					if( elementError != null ) { // Violate max-length rule
						csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
						elementError.setIdElementImport(data.getIdElementImport());
						importElementErrorService.insert(elementError);
					}	
					
					if(currentSubModel != null && subModelAttributeMap != null) { // In case of import reference by sub-reference
						if(isInAnotherSubModel(attribute, currentSubModel, subModelAttributeMap)) {
							dbError = messageSource.getMessage("import.element.error.eachAttributeForSubModelInFile", null, locale);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
							csvError = ImportUtil.appendError(csvError, dbError);
						}
					}		

					if("R".equalsIgnoreCase(attributEtenduType)) { // Only check this rule in case of save Attribute when importing Reference
						if( attributeValueList.contains(attribute) ) {
							Object[] params = {attribute};
							if( !attributeDuplicated ) { // print only one error per line for this kind of error.
								attributeDuplicated = true;
								dbError = messageSource.getMessage(
										"import.element.error.manyAttributesPerLine", params, locale);
								csvError = ImportUtil.appendError(csvError, dbError);
								elementError = new ImportElementError();
								elementError.setIdElementImport(data.getIdElementImport());
								elementError.setLLibelleLong(dbError);
								importElementErrorService.insert(elementError);
							}
						}
						else {
							attributeValueList.add(attribute);
						}
					}

					// Check if the Attribute exists in Metier
					AttributEtendu criteria2 = new AttributEtendu();
					criteria2.setIdMetier(metierId);
					criteria2.setLLibelle(attribute);
					criteria2.setCTypeAttributEtendu(attributEtenduType);
					List<AttributEtendu> results = attributEtenduService.findByCriteria(criteria2);
					if( results == null || results.size() == 0 ) {
						if( "E".equalsIgnoreCase(attributEtenduType) ) { // Element
							Object[] params = {attribute};
							dbError = messageSource.getMessage("import.element.error.attributeNotExistsInMetier", params, locale);
						}
						else { //Reference
							Object[] params = {attribute};
							dbError = messageSource.getMessage("import.element.error.attributeNotExistsForReference", params, locale);
						}
						elementError = new ImportElementError();
						elementError.setIdElementImport(data.getIdElementImport());
						elementError.setLLibelleLong(dbError);
						importElementErrorService.insert(elementError);
						csvError = ImportUtil.appendError(csvError, dbError);
					}

					if( !StringUtils.isNullOrEmtpy(value) ) {

						//Save Value
						data = new ImportElement();
						data.setCTypeElementImport(valueType);
						data.setIdImport(idImport);

						data.setLValeur(value);
						data.setNColonne(k);
						data.setNLigne(line);
						
						//Check data format of Value
						elementError = checkMaxLength2(k + 1, data, headerColums, messageSource); // Check max-length and truncate if needed				
						insert(data);
						
						if( elementError != null ) { // Violate max-length rule
							csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
							elementError.setIdElementImport(data.getIdElementImport());
							importElementErrorService.insert(elementError);
						}
					}
				}
			}
		}

		return csvError;
	}

	@SuppressWarnings({"rawtypes" })
	private static boolean isInAnotherSubModel(String attribute, String currentSubModel,
			Map<String, List<String>> subModelMap) {
		
		List<String> values = subModelMap.get(currentSubModel.toUpperCase());

		if( !values.contains(attribute.toUpperCase()) ) {
			values.add(attribute.toUpperCase());
		}

		Set keySet = subModelMap.keySet();
		for( Object key : keySet ) {
			values = subModelMap.get(key);
			if( values.contains(attribute.toUpperCase()) ) {
				if(!currentSubModel.equalsIgnoreCase(key.toString().toUpperCase())) {
					return true;
				}
			}
		}

		return false;
	}

	@SuppressWarnings("rawtypes")
	@Override
	@Transactional
	public void importElementToMozarto(Integer importId, int metierId, List<String[]> csvData, ResourceBundleMessageSource messageSource) throws Exception {

		int maxColumn = csvData.get(0).length - 1;

		List<Integer> lines = getAllLinesByImportId(importId);
		ImportElementError elementError = null;

		List<Map> allRecords = null;

		for( Integer lineNumber : lines ) {
			allRecords = findByImportIdAndLineNumber(importId, lineNumber);

			String family = findValueByType(allRecords, FIXED_ELEMENT_TYPES[1]);
			String subFamily = findValueByType(allRecords, FIXED_ELEMENT_TYPES[2]);
			String group = findValueByType(allRecords, FIXED_ELEMENT_TYPES[3]);
			String subGroup = findValueByType(allRecords, FIXED_ELEMENT_TYPES[4]);
			String elementType = findValueByType(allRecords, FIXED_ELEMENT_TYPES[5]);
			if( "A".equalsIgnoreCase(elementType) ) {
				elementType = ConstantServer.TYPE_ATTRIBUTE;
			}
			else {
				elementType = ConstantServer.TYPE_PRESTATION;
			}

			String elementCode = findValueByType(allRecords, FIXED_ELEMENT_TYPES[6]);
			String elementLabel = findValueByType(allRecords, FIXED_ELEMENT_TYPES[7]);
			String supplierCode = findValueByType(allRecords, FIXED_ELEMENT_TYPES[8]);
			String active = findValueByType(allRecords, FIXED_ELEMENT_TYPES[9]);

			Integer familyId = null;
			if( !StringUtils.isNullOrEmtpy(family) || !StringUtils.isNullOrEmtpy(subFamily) || !StringUtils.isNullOrEmtpy(group) || !StringUtils.isNullOrEmtpy(subGroup) ) {
				String[] hierarchicalFamily = { family, subFamily, group, subGroup };
				familyId = retrieveFamilyId(hierarchicalFamily, metierId, elementType);
			}
			else {

				//Insert to empty Family
				List<Famille> families = familleService.findEmptyFamily(metierId, elementType);
				if( families != null && families.size() > 0 ) {
					Famille aFamily = families.get(0);
					if( aFamily != null ) {
						familyId = aFamily.getIdFamille();
					}
				}
			}

			Element criteria1 = new Element();
			criteria1.setCElement(elementCode);
			criteria1.setCTypeElement(elementType);
			criteria1.setIdMetier(metierId);

			List<Element> elements = elementService.findByBaseCriteria(criteria1);

			Element element = null;
			if( elements != null && elements.size() > 0 ) {
				element = elements.get(0);
			}
			else {
				element = new Element();
				element.setCElement(elementCode);
				element.setCTypeElement(elementType);
			}

			element.setIdFamille(familyId);
			element.setIdMetier(metierId);
			element.setInActif(!"0".equals(active));
			element.setLLibelleLong(elementLabel);
			element.setLNomenclatureFournisseur(supplierCode);

			int mode = 0;

			if( element != null && element.getIdElement() != null && element.getIdElement() > 0 ) {
				mode = 2; //update
			}
			else {
				mode = 1; //insert
			}

			//Check if SupplierCde/MetierId is unique
			Element criteria3 = new Element();
			criteria1.setIdMetier(metierId);
			criteria3.setLNomenclatureFournisseur(supplierCode);

			List<Element> elements3 = elementService.findByBaseCriteria(criteria1);

			Element e = null;
			if( elements3 != null && elements3.size() > 0 ) {
				e = elements3.get(0);
			}

			if( mode == 2 ) {
				//				if( e != null && e.getIdElement() != element.getIdElement() ) {
				//					String error = "Le Nomenclature fournisseur de l’élément de composition libelle_saisi existe déjà pour ce métier";
				//					throw new FunctionalException(null, "", error);
				//				}
				//				else {
				//					elementService.update(element);
				//				}
				elementService.update(element);
			}
			else {
				//				if( e != null ) {
				//					String error = "Le Nomenclature fournisseur de l’élément de composition libelle_saisi existe déjà pour ce métier";
				//					throw new FunctionalException(null, "", error);
				//				}
				//				else {
				//					elementService.insert(element);
				//				}
				elementService.insert(element);
			}

			Integer elementId = element.getIdElement();

			List<String[]> attribyteValueList = findAttributeValueList(allRecords, FIXED_ELEMENT_TYPES.length - 1, maxColumn);
			for( String[] attributeValuePair : attribyteValueList ) {
				String attribute = attributeValuePair[0];
				String value = attributeValuePair[1];

				AttributEtendu criteria2 = new AttributEtendu();
				criteria2.setIdMetier(metierId);
				criteria2.setLLibelle(attribute);
				criteria2.setCTypeAttributEtendu("E");
				List<AttributEtendu> results = attributEtenduService.findByCriteria(criteria2);
				if( results == null || results.size() == 0 ) {
					Object[] params = {attribute};
					String dbError = messageSource.getMessage("import.element.error.attributeNotExistsInMetier", params, locale);
					ImportUtil.addErrorToRow(csvData, lineNumber, dbError);
					elementError = new ImportElementError();
					elementError.setIdElementImport(elementId);
					elementError.setLLibelleLong(dbError);
					importElementErrorService.insert(elementError);
					throw new RuntimeException();
				}

				AttributEtendu attributEtendu = results.get(0);

				AttributEtenduElementKey id = new AttributEtenduElementKey();
				id.setIdAttributEtendu(attributEtendu.getIdAttributEtendu());
				id.setIdElement(elementId);

				if( StringUtils.isNullOrEmtpy(value) ) {

					if( mode == 2 ) {

						//Delete value (in case of updating Element)
						attributEtenduElementService.deleteById(id);
					}
				}
				else {

					//Update value
					AttributEtenduElement record = new AttributEtenduElement();
					record.setId(id);
					record.setLValeur(value);
					if( mode == 1 ) {

						//Insert new value
						attributEtenduElementService.insert(record);
					}
					else {
						AttributEtenduElement criteria = new AttributEtenduElement();
						criteria.setId(id);
						List<Element> results3 = attributEtenduElementService.findByBaseCriteria(criteria);

						if( results3 == null || results3.size() == 0 ) {

							//Insert new value
							attributEtenduElementService.insert(record);
						}
						else {
							//Update existing value
							attributEtenduElementService.update(record);
						}
					}

				}
			}
		}
	}

	@SuppressWarnings("rawtypes")
	private String findValueByType(List<Map> allRecords, String type) {
		Map record = null;
		for( int i = 0 ; i < allRecords.size() ; i++ ) {
			record = allRecords.get(i);
			String importElementType = record.get("c_type_element_import").toString();
			if( type.equalsIgnoreCase(importElementType) ) {
				return record.get("l_valeur").toString();
			}
		}
		return null;
	}

	private Integer retrieveFamilyId(String[] hierarchicalFamily, int metierId, String elementType) {

		Integer parentFamilyId = null;
		Integer familyId = null;
		String familyLabel = null;

		for( int i = 0 ; i < hierarchicalFamily.length ; i++ ) {
			familyLabel = hierarchicalFamily[i];
			if( !StringUtils.isNullOrEmtpy(familyLabel) ) {
				Famille criteria = new Famille();
				criteria.setCTypeElement(elementType);
				criteria.setIdMetier(metierId);
				criteria.setLLibelle(familyLabel.toUpperCase());
				criteria.setIdFamilleParent(parentFamilyId);
				String familyType = FIXED_ELEMENT_TYPES[i + 1];
				criteria.setCTypeFamille(familyType);

				List<Famille> families = familleService.findByBaseCriteria(criteria);

				if( families == null || families.size() == 0 ) {
					Famille family = new Famille();
					family.setCTypeElement(elementType);
					if( ConstantServer.TYPE_ATTRIBUTE.equalsIgnoreCase(elementType) ) {
						family.setCTypeFamille(FIXED_ELEMENT_TYPES[i + 1]);
					}
					else {
						family.setCTypeFamille("TPR");
					}
					
					family.setIdMetier(metierId);
					family.setIdFamilleParent(parentFamilyId);
					family.setLLibelle(familyLabel);
					familleService.insert(family);
					parentFamilyId = family.getIdFamille();
					familyId = family.getIdFamille();
				}
				else {
					Famille aFamily = families.get(0);
					if( aFamily != null ) {
						familyId = aFamily.getIdFamille();
						parentFamilyId = aFamily.getIdFamille();
					}
				}
			}
		}
		return familyId;
	}

	@SuppressWarnings({ "rawtypes" })
	private List<String[]> findAttributeValueList(List<Map> allRecords, int startIndex, int endIndex) {

		List<String[]> results = new ArrayList<String[]>();
		String[] attributeValuePair = null;
		for( int i = startIndex ; i < endIndex ; i += 2 ) {
			String attribute = getValue(allRecords, i);
			if( !StringUtils.isNullOrEmtpy(attribute) ) {
				String value = getValue(allRecords, i + 1);
				attributeValuePair = new String[2];
				attributeValuePair[0] = attribute;
				attributeValuePair[1] = value;
				results.add(attributeValuePair);
			}
		}
		return results;
	}

	@SuppressWarnings("rawtypes")
	private String getValue(List<Map> allRecords, int index) {
		Map record = null;
		for( int j = 0 ; j < allRecords.size() ; j++ ) {
			record = allRecords.get(j);
			int column = Integer.parseInt(record.get("n_colonne").toString());
			if( column == index ) {
				return record.get("l_valeur").toString();
			}
		}
		return "";
	}

	private static ImportElementError checkMaxLength(int columnIndex, ImportElement data, String[] headerColums, ResourceBundleMessageSource messageSource) {

		ImportElementError elementError = null;
		String value = data.getLValeur();
		int length = 50;
		String errorStr = null;	

		if( length > 0 ) {
			if( !ImportUtil.checkMaxLength(value, length) ) {
				value = StringUtils.truncate(value, length);
				errorStr = buildMaxLengthErrorMessage(headerColums[columnIndex], length, messageSource);
				elementError = new ImportElementError();
				elementError.setLLibelleLong(errorStr);
			}
		}

		data.setLValeur(value);

		return elementError;
	}

	private static ImportElementError checkMaxLength2(int columnIndex, ImportElement data, String[] headerColums, ResourceBundleMessageSource messageSource) {

		ImportElementError elementError = null;
		String value = data.getLValeur();
		int length = 2000;
		String errorStr = null;	

		if( length > 0 ) {
			if( !ImportUtil.checkMaxLength(value, length) ) {
				value = StringUtils.truncate(value, length);
				errorStr = buildMaxLengthErrorMessage(headerColums[columnIndex], length, messageSource);
				elementError = new ImportElementError();
				elementError.setLLibelleLong(errorStr);
			}
		}

		data.setLValeur(value);

		return elementError;
	}

	public static String buildMaxLengthErrorMessage(String fieldName, int length, ResourceBundleMessageSource messageSource) {
		Object[] params = {fieldName, length};
		return messageSource.getMessage("import.error.common.maxLength", params, locale);
	}

	@Override
	public List<ImportElement> findByBaseCriteria(ImportElement criteria) {
		return mapper.findByBaseCriteria(criteria);
	}
}
