package com.structis.client.service;

import java.util.List;
import java.util.Map;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.client.panel.composition.CompositionReferenceFilter;
import com.structis.client.widget.CustomizePagingLoadResult;
import com.structis.shared.model.Element;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.CompositionAccueilModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionAndMessageModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionModel;
import com.structis.shared.model.reference.CompositionCarateristiqueSelectAbleModel;
import com.structis.shared.model.reference.CompositionElementGridModel;
import com.structis.shared.model.reference.CompositionModel;
import com.structis.shared.model.reference.CompositionReferenceGridModel;
import com.structis.shared.model.reference.CompositionTreeComboboxModel;
import com.structis.shared.model.reference.ModeleModel;

@RemoteServiceRelativePath("springGwtServices/clientCompositionService")
public interface ClientCompositionService extends RemoteService {

	List<CompositionCarateristiqueSelectAbleModel> findCaracteristiquesBeforeLeafNode(Integer idModeleVersion);
	
	List<CompositionReferenceGridModel> findAllCompositionReferenceByCaracteristiques(Integer limit,Integer idModeleVersion);
	
	List<CompositionReferenceGridModel> findCompositionReferenceByCaracteristiques(List<Integer> idCaracteristiques,Integer idModeleVersion);
	
	List<CompositionElementGridModel> findCompositionElementByReferences(List<Integer> idReferences,Integer idModeleVersion);
	
	CompositionCarateristiqueFilterActionAndMessageModel checkActionAfterFilter(Integer idCaracteristiqueSelected, Integer idModeleVersion);
	
	List<CompositionCarateristiqueFilterActionModel> checkActionBeforeFilter(Integer idCaracteristiqueSelected, Integer idModeleVersion);
	
	CustomizePagingLoadResult<CompositionReferenceGridModel> findCompositionReferenceByCaracteristiquesPaging(CompositionReferenceFilter loadConfig);
	
	CompositionTreeComboboxModel getCompositionTreeAndComboboxBeforeLastNode(Integer idModeleVersion);
	
	Metier getMetier(Integer idMetier);

	Map<Integer,List<String[]>> findMessageByIdReference(Integer idModeleVersion, Integer idReference);
	
	Integer saveCompostion(CompositionModel composition);
	
	public List<ModeleModel> findAllLastPublicVersionByMetier(Integer idMetier);
	
	public PagingLoadResult<CompositionAccueilModel> loadCompoByModele(ModeleModel modele, PagingLoadConfig loadConfig);
	
	public Integer deleteById(Integer idComposition);
	
	void doAction();
	
	void changeReferenceQuantieTMPData(Integer idReference, Integer quantite, boolean isOverwrite);
	
	void onSelectReferenceTMPData(Map<Integer, Integer> mapReferences, Integer idModeleVersion);
	
	void onUnSelectReferenceTMPData(List<Integer> idReferences);
	
	void updateCElementTMPData(CompositionElementGridModel element);
	
	void clearElementTMPData();
	
	PagingLoadResult<CompositionElementGridModel> loadCeElementPagingTMPData(PagingLoadConfig loadConfig);
	
	PagingLoadResult<Element> loadEsElementPagingTMPData(PagingLoadConfig loadConfig);
	
	void addUpdateEsElementTMPData(List<Element> elements);
	
	void removeEsElment(List<Element> elements);
}
