package com.structis.client.panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.MetierMzPzModel;

public abstract class AbstractGestionMetierLeftPanel extends VerticalLayoutContainer {
	
	protected SimpleEventBus bus;

	protected Images images = GWT.create(Images.class);

	protected final Messages messages = GWT.create(Messages.class);

	protected NavigationService navigation = NavigationFactory.getNavigation();

	protected HTML metierLabel;
	
	protected Integer idMetier;

	protected Grid<MetierMzPzModel> listMetiers;

	protected ListStore<MetierMzPzModel> metiers;

	protected FieldSet metiersFieldset;

	protected Metier metier;

	public AbstractGestionMetierLeftPanel(final SimpleEventBus bus) {
		metier = navigation.getContext().getMetier();
		idMetier = metier.getIdMetier();
		this.bus = bus;
		setStyleName("whiteBackGround");
		
		metierLabel = new HTML();

		add(metierLabel);

		metiersFieldset = new FieldSet();
		metiersFieldset.setHeadingText(messages.commonMetiers());
		metiersFieldset.setStyleName("fieldsetPadding");
		add(metiersFieldset, new VerticalLayoutData(1, 1));
		buildFieldSet();

		afterLoadMetier(metier);
		/*ClientAccueilModelisateurServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

			@Override
			public void onSuccess(Metier result) {
				afterLoadMetier(result);
			}
		});*/
	}

	public abstract void buildFieldSet();

	public abstract void addHandler();

	public abstract void afterLoadMetier(Metier result);
}
