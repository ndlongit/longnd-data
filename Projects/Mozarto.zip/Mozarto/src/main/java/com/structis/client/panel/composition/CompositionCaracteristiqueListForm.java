package com.structis.client.panel.composition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.BeforeSelectionEvent;
import com.google.gwt.event.logical.shared.BeforeSelectionHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.text.shared.AbstractSafeHtmlRenderer;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.cell.core.client.form.ComboBoxCell.TriggerAction;
import com.sencha.gxt.core.client.dom.ScrollSupport.ScrollMode;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.container.AbstractHtmlLayoutContainer.HtmlData;
import com.sencha.gxt.widget.core.client.container.HtmlLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.event.ShowEvent;
import com.sencha.gxt.widget.core.client.event.ShowEvent.ShowHandler;
import com.sencha.gxt.widget.core.client.form.ComboBox;
import com.structis.client.event.CompositionCaracteristiqueChangeEvent;
import com.structis.client.event.LoadCompositionEvent;
import com.structis.client.event.LoadCompositionHandler;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.CompositionCaracteristiqueProperties;
import com.structis.client.service.ClientCompositionServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.client.widget.CustimizeMessageBox;
import com.structis.client.widget.HtmlButton;
import com.structis.shared.constant.Niveau;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionAndMessageModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionModel;
import com.structis.shared.model.reference.CompositionCarateristiqueModel;
import com.structis.shared.model.reference.CompositionCarateristiqueSelectAbleModel;

public class CompositionCaracteristiqueListForm extends VerticalLayoutContainer {
	private SimpleEventBus bus;

	private Images images = GWT.create(Images.class);

	private final Messages messages = GWT.create(Messages.class);

	private CompositionCaracteristiqueProperties compositionCaracteristiqueProps = GWT.create(CompositionCaracteristiqueProperties.class);

	private List<CompositionCarateristiqueSelectAbleModel> caracteristiques = new ArrayList<CompositionCarateristiqueSelectAbleModel>();

	private final static String PREFIX_ID_ROW = "row_";

	private final static String PREFIX_ID_COMBOBOX = "cb_";

	private final static String PREFIX_ID_BUTTON = "btn_";

	private Integer idModeleVersion = 1;

	private Map<String, CompositionCarateristiqueModel> oldConfig = new HashMap<String, CompositionCarateristiqueModel>();

	private Stack<CompositionCarateristiqueFilterActionModel> ruleStack = new Stack<CompositionCarateristiqueFilterActionModel>();

	private NavigationService navigation = NavigationFactory.getNavigation();

	private VerticalLayoutContainer comboboxContainer;

	private CustimizeMessageBox adverMessageBox;

	private AlertMessageWindow alertMessageBox;

	private Stack<MessageDisplayModel> stackMessage = new Stack<MessageDisplayModel>();
	
	private Stack<MessageDisplayModel> stackMessageInfo = new Stack<MessageDisplayModel>();
	
	public static List<String> alreadyDisplayMessage = new ArrayList<String>();
	
	private boolean isMessageBoxDisplaying = false;

	private HtmlButton btnCancel;

	private Label header;
	
	private boolean resetAll = false;
	
	public CompositionCaracteristiqueListForm(SimpleEventBus bus) {
		super();
		//this.setScrollMode(ScrollMode.AUTOY);
		addStyleName("whiteBackGround");
		setBorders(true);
		this.bus = bus;
		buildPanel();
		addHandlers();
	}

	private void addHandlers() {
		// TODO Auto-generated method stub
	}

	private native String getTableMarkupTop() /*-{
	return [
			'<table width=100% cellpadding=0 cellspacing=5>',
			'<tr><td class=compositionf1 width=90% style="text-align:right;"></td><td class=compositionf2 width=10% align=style="text-align:left"></td></tr>',
			'</table>'

	].join("");
	}-*/;
	private native String getTableMarkup() /*-{
		return [
				'<table  width=100% cellpadding=0 cellspacing=5 >',
				'<tr><td class=compositionf1 style="text-align:left;"></td><td class=compositionf2 width=50 style="text-align:left"></td></tr>',
				'</table>'
		].join("");
	}-*/;
	
	private void buildPanel() {
		
		HtmlLayoutContainer row = new HtmlLayoutContainer(getTableMarkupTop());
		header = new Label(messages.compositionFilterHeader());
		header.setStyleName("inactiveItem");
		row.add(header, new HtmlData(".compositionf1"));
		btnCancel = new HtmlButton("", images.resetAll());

		btnCancel.getHtml().addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				if(resetAll)
					resetAll();
			}
		});
		header.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				if(resetAll)
					resetAll();
			}
		});
		//final VerticalLayoutContainer layout = this;
		
		row.add(btnCancel, new HtmlData(".compositionf2"));
		VerticalLayoutData layoutData = new VerticalLayoutData();
		layoutData.setMargins(new Margins(0, 5, 0, 0));
		add(row, layoutData);
		comboboxContainer = new VerticalLayoutContainer();
		comboboxContainer.setScrollMode(ScrollMode.AUTOY);
		add(comboboxContainer,new VerticalLayoutData(1,1));
		addResizeHandler(new ResizeHandler() {
			@SuppressWarnings("unchecked")
			@Override
			public void onResize(ResizeEvent event) {
				for( CompositionCarateristiqueSelectAbleModel item : caracteristiques ) {
					HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(PREFIX_ID_ROW + item.getIdCaracteristique());
					ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(PREFIX_ID_COMBOBOX + item.getIdCaracteristique());
					cb.setWidth((int) (Math.round(event.getWidth() * 0.9)) - 30);
				}
			}
		});

	}

	@Override
	protected void onAfterFirstAttach() {
		
		navigation.getBus().addHandler(LoadCompositionEvent.getType(), new LoadCompositionHandler() {
			@Override
			public void onLoad(LoadCompositionEvent loadCompositionEvent) {
				reset();
			}
		});
	}
	public void loadCombobox(Integer idModeleVersion,List<CompositionCarateristiqueSelectAbleModel> result){
		this.idModeleVersion = idModeleVersion;
		reset();
		caracteristiques.addAll(result);
		for( CompositionCarateristiqueSelectAbleModel item : result ) {
			buildCombobox(item);
		}
	}
	private void reset(){
		caracteristiques.clear();
		comboboxContainer.clear();
		alreadyDisplayMessage.clear();
	}
	protected void buildCombobox(final CompositionCarateristiqueSelectAbleModel item) {
		//HtmlLayoutContainer row = new HtmlLayoutContainer(getTableMarkup());		
		HtmlLayoutContainer row = new HtmlLayoutContainer(getTableMarkup());
		row.setId(PREFIX_ID_ROW + item.getIdCaracteristique());
		
		ListStore<CompositionCarateristiqueModel> lst = new ListStore<CompositionCarateristiqueModel>(
				compositionCaracteristiqueProps.idCaracteristique());
		lst.addAll(item.getCarateristiqueList());
		/*final ComboBox<CompositionCarateristiqueModel> cb = new ComboBox<CompositionCarateristiqueModel>(
				lst, compositionCaracteristiqueProps.lLibelleLong());*/
		final ComboBox<CompositionCarateristiqueModel> cb = new ComboBox<CompositionCarateristiqueModel>(lst, compositionCaracteristiqueProps.lLibelleLong(),new AbstractSafeHtmlRenderer<CompositionCarateristiqueModel>() {
			@SuppressWarnings("serial")
			@Override
			public SafeHtml render(final CompositionCarateristiqueModel item) {
				return new SafeHtml() {
					@Override
					public String asString() {
						return "<div style='font-size:11px;font-family: arial' >"+item.getLLibelleLong()+"</div>";
					}
				};
			}
		});
		
		cb.setEmptyText(item.getLLibelleLong());
		cb.setText(item.getLLibelleLong());
		cb.setAllowTextSelection(false);
		cb.setEditable(false);
		cb.setTriggerAction(TriggerAction.ALL);
		cb.setId(PREFIX_ID_COMBOBOX + item.getIdCaracteristique());
		
		//cb.setWidth("100%");
		int width = (int) (Math.round(comboboxContainer.getOffsetWidth() * 0.9)) - 30;
		if(width > 0){
			cb.setWidth(width);
		}
		
		cb.addBeforeSelectionHandler(new BeforeSelectionHandler<CompositionCarateristiqueModel>() {
			@Override
			public void onBeforeSelection(final BeforeSelectionEvent<CompositionCarateristiqueModel> paramBeforeSelectionEvent) {
				getOldConfig();
			}
		});
		cb.addChangeHandler(new ChangeHandler() {
			@SuppressWarnings("unchecked")
			@Override
			public void onChange(ChangeEvent event) {
				ComboBox<CompositionCarateristiqueModel> source = (ComboBox<CompositionCarateristiqueModel>) event.getSource();
				
				if( source.getCurrentValue() != null ) {
					doFilter(source.getValue(), source.getCurrentValue(), cb.getId());
				}
				enableResetButton();
				
			}
		});
		//row.add(cb);
		
		row.add(cb, new HtmlData(".compositionf1"));

		HtmlButton btnCancel = new HtmlButton("", images.reset());

		btnCancel.setId(PREFIX_ID_BUTTON + item.getIdCaracteristique());
		btnCancel.getHtml().addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				HtmlButton sButton = (HtmlButton)((HTML)arg0.getSource()).getParent();
				String id = sButton.getId();
				ComboBox<CompositionCarateristiqueModel> cb = getCombo(id, PREFIX_ID_BUTTON); 
				if (cb.getValue() != null || cb.getCurrentValue() != null ){
					Integer oldId = (cb.getValue() != null) ? cb.getValue().getIdCaracteristique() : cb.getCurrentValue().getIdCaracteristique();
					checkActionBeforeReset(cb, oldId);
				}
				//reset(cb);
			}
		});
		row.add(btnCancel, new HtmlData(".compositionf2"));
		
		VerticalLayoutData layoutData = new VerticalLayoutData();
		layoutData.setMargins(new Margins(0, 10, 0, 0));
		comboboxContainer.add(row, new VerticalLayoutData(1,-1));
	}

	

	@SuppressWarnings("unused")
	private void doFilter(final CompositionCarateristiqueModel oldSource, final CompositionCarateristiqueModel newSource,
			String idCb) {
		ruleStack.clear();
		final String newSourceName = newSource.getLLibelleLong();
		final Integer idSource = newSource.getIdCaracteristique();
		checkActionAfterFilter(newSource.getIdCaracteristique(), newSource.getLLibelleLong(), idCb);
	}

	private void checkActionAfterFilter(final Integer idNewSource, final String newSourceName, final String idCb) {
		ClientCompositionServiceAsync.Util.getInstance().checkActionAfterFilter(
				idNewSource, idModeleVersion,
				new AsyncCallbackWithErrorResolution<CompositionCarateristiqueFilterActionAndMessageModel>() {
					@Override
					public void onSuccess(CompositionCarateristiqueFilterActionAndMessageModel result) {
						if( result != null ) {
							List<CompositionCarateristiqueFilterActionModel> listAction = result.getActionList();
							//processMessage(result.getMessagesMap(),idCb);
							pushMessage(result.getMessagesMap(), idCb);
							for( CompositionCarateristiqueFilterActionModel item : listAction ) {
								ruleStack.push(item);
							}
							if( !ruleStack.empty() ) {
								changeItemStatusesOnCombobox(idNewSource, newSourceName);
							}
							else {
								updateReferenceFormList(idNewSource);
							}
						}
					}
				});
	}

	@SuppressWarnings("unchecked")
	public List<Integer> getSelectedIds() {
		List<Integer> ids = new ArrayList<Integer>();
		for( CompositionCarateristiqueSelectAbleModel item : caracteristiques ) {
			HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(PREFIX_ID_ROW + item.getIdCaracteristique());
			ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(PREFIX_ID_COMBOBOX + item.getIdCaracteristique());
			/*if( cb.getValue() != null ) {
				if( cb.getCurrentValue() == cb.getValue() ) {
					ids.add(cb.getValue().getIdCaracteristique());
				}
			}*/
			if( cb.getCurrentValue() != null ){
				ids.add(cb.getCurrentValue().getIdCaracteristique());
			}
		}
		return ids;
	}

	private void updateReferenceFormList(Integer idSource) {
		List<Integer> ids = getSelectedIds();
		if( idSource != null ) {
			ids.add(idSource);
		}
		CompositionCaracteristiqueChangeEvent event = new CompositionCaracteristiqueChangeEvent();
		event.setIdCaracteristiques(ids);
		event.setIdModelVersion(idModeleVersion);
		bus.fireEvent(event);
	}

	@SuppressWarnings("unchecked")
	private void changeItemStatusesOnCombobox(Integer idSource,
	/* CompositionCarateristiqueFilterActionModel item, */String newSource) {
		// find the combobox		
		if( !ruleStack.empty() ) {
			CompositionCarateristiqueFilterActionModel item = ruleStack.pop();
			//VerticalLayoutContainer layout = this;
			HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(PREFIX_ID_ROW + item.getIdCarateristiqueComboboxTarget());
			ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(PREFIX_ID_COMBOBOX + item.getIdCarateristiqueComboboxTarget());
			Map<Integer, Integer> rules = item.getActions();
			for( Integer itemKey : rules.keySet() ) {
				configItemWithRule(idSource, cb, itemKey, rules.get(itemKey), newSource);
			}
		}
		else {
			updateReferenceFormList(idSource);
		}
	}

	//INTERDITE(1), CONSEILLEE(2), INDISPENSABLE(3)
	private void configItemWithRule(Integer idSource, final ComboBox<CompositionCarateristiqueModel> cb,
			final Integer itemKey, Integer rule, String newSource) {
		final CompositionCarateristiqueModel item = findItem(cb, itemKey);
		switch( rule ) {
			case 1 : //Niveau.INTERDITE.getIndex():
				processRuleInterdite(idSource, cb, item, newSource);
				break;
			case 3 : //Niveau.INDISPENSABLE.getIndex():			
				processRuleIndispensable(idSource, cb, item, newSource);
				break;
			case 2 : //Niveau.CONSEILLEE.getIndex():			
				processRuleConseillee(idSource, cb, item, newSource);
				break;
		}
	}

	//CONSEILLEE 2: select ->if selected before just propose to use
	private void processRuleConseillee(Integer idSource, final ComboBox<CompositionCarateristiqueModel> cb,
			final CompositionCarateristiqueModel item, String newSource) {
		if( cb.getValue() != null ) {
			if( cb.getValue() != item ) {
				String confirmMessage = messages.compositionChangeCaracterSourceRuleConseillee(
						cb.getValue().getLLibelleLong(), newSource, item.getLLibelleLong());
				AppUtil.showConfirmMessageBox(confirmMessage, new SelectHandler() {
					@Override
					public void onSelect(SelectEvent event) {
						if( item != null ) {
							cb.select(item);
							cb.setValue(item);
						}
					}

				}, null);
			}
		}
		else {
			if( item != null ) {
				cb.select(item);
				cb.setValue(item);
			}
		}
		changeItemStatusesOnCombobox(idSource, newSource);
	}

	//INDISPENSABLE 3: select -> if selected before -> confirm before select
	private void processRuleIndispensable(final Integer idSource, final ComboBox<CompositionCarateristiqueModel> cb,
			final CompositionCarateristiqueModel item, final String newSource) {
		if( cb.getValue() != null ) {
			if( cb.getValue() != item ) {
				String confirmMessage = messages.compositionChangeCaracterSourceRuleObligatoire(
						cb.getValue().getLLibelleLong(), newSource, item.getLLibelleLong());
				AppUtil.showConfirmMessageBox(confirmMessage, new SelectHandler() {
					@Override
					public void onSelect(SelectEvent event) {
						if( item != null ) {
							cb.select(item);
							cb.setValue(item);
						}
						checkActionAfterFilter(item.getIdCaracteristique(), item.getLLibelleLong(), cb.getId());
						//						changeItemStatusesOnCombobox(idSource, newSource);						
					}

				}, new SelectHandler() {
					@Override
					public void onSelect(SelectEvent event) {
						// reset old value
						revertChanges();

					}
				});
			}
			else {
				changeItemStatusesOnCombobox(idSource, newSource);
			}
		}
		else {
			if( item != null ) {
				cb.select(item);
				cb.setValue(item);
				checkActionAfterFilter(item.getIdCaracteristique(), item.getLLibelleLong(), cb.getId());
				//				changeItemStatusesOnCombobox(idSource, newSource);				
			}
		}
	}

	//INTERDITE 1: deselect ->  if selected  confirm before deselect
	private void processRuleInterdite(final Integer idSource, final ComboBox<CompositionCarateristiqueModel> cb,
			final CompositionCarateristiqueModel item, final String newSource) {
		if( cb.getValue() != null ) { // selected
			if( cb.getValue() == item ) {
				String confirmMessage = messages.compositionChangeCaracterSourceRuleInterdite(
						cb.getValue().getLLibelleLong(), newSource);
				AppUtil.showConfirmMessageBox(confirmMessage, new SelectHandler() {
					@Override
					public void onSelect(SelectEvent event) {
						cb.reset();
						changeItemStatusesOnCombobox(idSource, newSource);
					}
				}, new SelectHandler() {
					@Override
					public void onSelect(SelectEvent event) {
						revertChanges();
					}
				});
			}
			else {
				changeItemStatusesOnCombobox(idSource, newSource);
			}
		}
		else {
			changeItemStatusesOnCombobox(idSource, newSource);
		}
	}

	@SuppressWarnings("unchecked")
	private void getOldConfig() {
		oldConfig.clear();
		for( CompositionCarateristiqueSelectAbleModel item : caracteristiques ) {
			HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(PREFIX_ID_ROW + item.getIdCaracteristique());
			ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(PREFIX_ID_COMBOBOX + item.getIdCaracteristique());
			oldConfig.put(cb.getId(), cb.getValue());
		}
	}

	@SuppressWarnings({ "unchecked" })
	private void revertChanges() {
		ruleStack.clear();
		for( String key : oldConfig.keySet() ) {
			HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(key.replaceFirst(
					PREFIX_ID_COMBOBOX, PREFIX_ID_ROW));
			ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(key);
			cb.setValue(oldConfig.get(key));
		}
	}

	private CompositionCarateristiqueModel findItem(ComboBox<CompositionCarateristiqueModel> cb, Integer itemKey) {
		for( CompositionCarateristiqueModel item : cb.getStore().getAll() ) {
			if( item.getIdCaracteristique().equals(itemKey) ) {
				return item;
			}
		}
		return null;
	}

	private void setVisibleItem(ComboBox<CompositionCarateristiqueModel> cb, Integer itemKey, boolean isVisibled) {
		for( int i = 0 ; i < cb.getStore().getAll().size() ; i++ ) {
			CompositionCarateristiqueModel itemCarateristiqueModel = cb.getStore().get(i);
			if( itemCarateristiqueModel.getIdCaracteristique().equals(itemKey) ) {
				if( cb.getListView().getElement(i) != null ) {
					cb.getListView().getElement(i).setVisible(isVisibled);
				}
			}
		}
	}

	private void checkActionBeforeReset(final ComboBox<CompositionCarateristiqueModel> cb, final Integer idOldSource ) {
		ClientCompositionServiceAsync.Util.getInstance().checkActionBeforeFilter(idOldSource, idModeleVersion, new AsyncCallbackWithErrorResolution<List<CompositionCarateristiqueFilterActionModel>>() {
			@Override
			public void onSuccess(List<CompositionCarateristiqueFilterActionModel> result) {	
				if(result != null){
					String sourceName= existSourceRequireTarget(result);
					if (sourceName!=null) {
						AppUtil.showMessageBox(messages.compositionResetCaracteristiqueComboBreakRule(sourceName));
					} else {
						reset(cb);
					}											
				}
			}
		});
	}
	
	@SuppressWarnings("unchecked")
	protected String existSourceRequireTarget(
			List<CompositionCarateristiqueFilterActionModel> result) {
		String sourceName;
		List<CompositionCarateristiqueFilterActionModel> listAction = result;
		
		for (CompositionCarateristiqueFilterActionModel item: listAction) {											
			Map<Integer, Integer> rules = item.getActions();
			for (Integer key: rules.keySet()) {
				if (rules.get(key).equals(Niveau.INDISPENSABLE.getIndex())) {
					HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(PREFIX_ID_ROW + item.getIdCarateristiqueComboboxTarget());
					if (row != null) {
						ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(PREFIX_ID_COMBOBOX + item.getIdCarateristiqueComboboxTarget());
						if (cb != null) {
							if (cb.getValue()!= null && key.equals(cb.getValue().getIdCaracteristique())) {
								sourceName = cb.getValue().getLLibelleLong();
								return sourceName;
							} else {
								if (cb.getCurrentValue()!= null && key.equals(cb.getCurrentValue().getIdCaracteristique())) {
									sourceName = cb.getCurrentValue().getLLibelleLong();
									return sourceName;
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	protected void reset(ComboBox<CompositionCarateristiqueModel> cb) {
		cb.reset();
		updateReferenceFormList(null);
	}

	@SuppressWarnings("unchecked")
	private void resetAll() {
		for( CompositionCarateristiqueSelectAbleModel item : caracteristiques ) {
			HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(PREFIX_ID_ROW + item.getIdCaracteristique());
			ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(PREFIX_ID_COMBOBOX + item.getIdCaracteristique());
			cb.reset();
		}
		updateReferenceFormList(null);
		disableResetButton();
	}


	private void pushMessage(Map<Integer, List<String[]>> messageMap, String comboboxID) {

		for( Integer key : messageMap.keySet() ) {
			List<String[]> messageTexts = messageMap.get(key);
			if( messageTexts.size() > 0 ) {
				if( key == Niveau.INFORMATION.getIndex() ) {
					String messageInfos = "";
					int i = 0;
					for( String[] message : messageTexts ) {
						if( !alreadyDisplayMessage.contains(message[0]) ) {
							alreadyDisplayMessage.add(message[0]);
						}
						if( i > 0){
							messageInfos = messageInfos + "<hr/>" + message[1] ;
						}else{
							messageInfos = messageInfos + " " + message[1];
						}
						i++;
						
					}
					if( !messageInfos.equals("") ) {
						stackMessageInfo.push(new MessageDisplayModel(comboboxID, key, messageInfos));
					}
				}else if( key == Niveau.AVERTISSEMENT.getIndex() ) {
					String messageAdver = "";
					int i = 0;
					for( String[] message : messageTexts ) {
						if( !alreadyDisplayMessage.contains(message[0]) ) {
							alreadyDisplayMessage.add(message[0]);
						}
						if( i > 0){
							messageAdver =  messageAdver + "<hr style='width:298px'  />" + message[1] ;
						}else{
							messageAdver = messageAdver + " " + message[1];
						}
						i++;
					}
					if( !messageAdver.equals("") ) {
						stackMessage.push(new MessageDisplayModel(comboboxID, key, messageAdver));
					}
				}else if( key == Niveau.ALERTE.getIndex() ) {
					for( String[] message : messageTexts ) {
						if( !alreadyDisplayMessage.contains(message[0]) ) {
							alreadyDisplayMessage.add(message[0]);
						}
						stackMessage.push(new MessageDisplayModel(comboboxID, key, message[1]));
					}
				}
				Collections.sort(stackMessage, new MessageDisplayModelComparator());
			}
		}
		processDisplayMessage();
	}
	
	private void processDisplayMessage() {
		if( !isMessageBoxDisplaying) {
			if( !stackMessage.empty() ){
				MessageDisplayModel item = stackMessage.pop();
				if( item.getIdRelation() == Niveau.AVERTISSEMENT.getIndex() ) {
					processMessageAdverd(item);
				}
				else if( item.getIdRelation() == Niveau.ALERTE.getIndex() ) {
					processMessageAlert(item);
				}
			}else{
				if( !stackMessageInfo.empty() ){
					do{
						MessageDisplayModel item = stackMessageInfo.pop();
						if( item.getIdRelation() == Niveau.INFORMATION.getIndex() ) {
							processMessageInfo(item);
						}
					}while(!stackMessageInfo.empty());
				}
			}
		}
		
	}

	private void processMessageInfo(MessageDisplayModel item) {
		HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(item.getIdCBB().replace(
				PREFIX_ID_COMBOBOX, PREFIX_ID_ROW));
		@SuppressWarnings("unchecked")
		final ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(item.getIdCBB());
		final InformationToolTip config = new InformationToolTip();
		config.setTitleHtml(messages.modelisateurFormMessageImportanceInformation());
		config.setBodyHtml(item.getMessage());
		cb.setToolTipConfig(config);
		cb.getToolTip().addShowHandler(new ShowHandler() {
			@Override
			public void onShow(ShowEvent event) {
				Timer dismissTimer = new Timer() {
			        @Override
			        public void run() {
			        	if( cb.getToolTip() != null ){
				        	cb.getToolTip().hide();
				        	cb.setToolTipConfig(null);
				        	cb.removeToolTip();
			        	}
			        }
			      };
			      dismissTimer.schedule(config.getDismissDelay());
			}
		});
		cb.getToolTip().show();
	}

	private void processMessageAdverd(MessageDisplayModel item) {
		String content = "<table><tr><td style='line-height:100%' >" + item.getMessage() + "</td></tr></table>";
		adverMessageBox = new CustimizeMessageBox(messages.modelisateurFormMessageImportanceAvertissement(), content);
		adverMessageBox.setModal(false);
		adverMessageBox.addHideHandler(new HideHandler() {
			@Override
			public void onHide(HideEvent event) {
				isMessageBoxDisplaying = false;
				processDisplayMessage();
			}
		});
		adverMessageBox.show();
		isMessageBoxDisplaying = true;
	
	}

	private void processMessageAlert(MessageDisplayModel item) {
		alertMessageBox = new AlertMessageWindow(messages.modelisateurFormMessageImportanceAlerte(), item.getMessage());
		alertMessageBox.addHideHandler(new HideHandler() {

			@Override
			public void onHide(HideEvent event) {
				isMessageBoxDisplaying = false;
				processDisplayMessage();
			}
		});
		alertMessageBox.show();
		isMessageBoxDisplaying = true;

	}
	@SuppressWarnings("unchecked")
	private ComboBox<CompositionCarateristiqueModel> getCombo(Integer idCaracteristique) { 
		HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(PREFIX_ID_ROW + idCaracteristique);
		ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(PREFIX_ID_COMBOBOX + idCaracteristique);
		return cb;
	}
	@SuppressWarnings("unchecked")
	private ComboBox<CompositionCarateristiqueModel> getCombo(String textContainIdCaracteristique, String prefix) { 
		String idRow = textContainIdCaracteristique.replaceAll(prefix, PREFIX_ID_ROW);
		String idCombo = textContainIdCaracteristique.replaceAll(prefix, PREFIX_ID_COMBOBOX);
		HtmlLayoutContainer row = (HtmlLayoutContainer) comboboxContainer.getItemByItemId(idRow);
		ComboBox<CompositionCarateristiqueModel> cb = (ComboBox<CompositionCarateristiqueModel>) row.getItemByItemId(idCombo);
		return cb;
	}
	public void disableResetButton(){
		header.setStyleName("inactiveItem");
		resetAll = false;
		
	}
	public void enableResetButton(){
		header.setStyleName("htmlLink");
		resetAll = true;

	}
}
