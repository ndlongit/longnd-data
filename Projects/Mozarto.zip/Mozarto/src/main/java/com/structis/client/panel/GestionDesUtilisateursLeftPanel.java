package com.structis.client.panel;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.core.client.Style.SelectionMode;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.selection.SelectionChangedEvent;
import com.sencha.gxt.widget.core.client.selection.SelectionChangedEvent.SelectionChangedHandler;
import com.structis.client.event.GestionUtilisateursAddTabEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.UtilisateurProperties;
import com.structis.client.service.ClientGestionUtilisateursServiceAsync;
import com.structis.shared.model.Metier;
import com.structis.shared.model.RoleUtilisateur;
import com.structis.shared.model.Utilisateur;
import com.structis.shared.security.Role;

public class GestionDesUtilisateursLeftPanel extends VerticalLayoutContainer {
	
	private SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private NavigationService navigation = NavigationFactory.getNavigation();

	private HTML metierLabel;
	
	private Integer idMetier;

	private FieldSet utilisateursFieldset;
	
	private Grid<Utilisateur> gridUtilisateurs;
	
	private ListStore<Utilisateur> storeUtilisateurs;
	
	private List<RoleUtilisateur> roleUtilisateurs;

	private Utilisateur selectedUtilisateur;

	private Metier metier;

	private PagingLoader<PagingLoadConfig, PagingLoadResult<Utilisateur>> loader;

	public GestionDesUtilisateursLeftPanel(final SimpleEventBus bus) {
		metier = navigation.getContext().getMetier();
		idMetier = metier.getIdMetier();
		this.bus = bus;
		setStyleName("whiteBackGround");
		
		metierLabel = new HTML();
		metierLabel.setHTML(messages.commonMetier() + ": " + metier.getLLibelle());

		add(metierLabel);

		utilisateursFieldset = new FieldSet();
		utilisateursFieldset.setHeadingText(messages.commonUtilisateurs());
		utilisateursFieldset.setStyleName("fieldsetPadding");
		add(utilisateursFieldset, new VerticalLayoutData(1, 1));
		buildFieldSet();
		addHandler();
		
		/*ClientAccueilModelisateurServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

			@Override
			public void onSuccess(Metier result) {
				metierLabel.setHTML(messages.commonMetier() + ": " + result.getLLibelle());
				addHandler();
			}
		});*/
		
		loadUtilisateurs();
		loadAllRoles();
	}

	public void loadUtilisateurs() {
		RpcProxy<PagingLoadConfig, PagingLoadResult<Utilisateur>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<Utilisateur>>() {

			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<Utilisateur>> callback) {
				ClientGestionUtilisateursServiceAsync.Util.getInstance().findAllByMetier(idMetier, loadConfig, callback);
			}
		};
		loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<Utilisateur>>(proxy);
		loader.setRemoteSort(true);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, Utilisateur, PagingLoadResult<Utilisateur>>(
				storeUtilisateurs));
		gridUtilisateurs.setLoader(loader);
		loader.load();
		
	}

	public void addHandler() {
		gridUtilisateurs.addCellDoubleClickHandler(new CellDoubleClickHandler() {
			
			@Override
			public void onCellClick(CellDoubleClickEvent event) {
				bus.fireEvent(new GestionUtilisateursAddTabEvent(selectedUtilisateur, roleUtilisateurs));
			}
		});
	}
	
	public void buildFieldSet() {
		UtilisateurProperties props = GWT.create(UtilisateurProperties.class);
		storeUtilisateurs = new ListStore<Utilisateur>(props.idUtilisateur());
		ColumnConfig<Utilisateur, String> nom = new ColumnConfig<Utilisateur, String>(
				props.nomComplet());
		nom.setColumnStyle(SafeStylesUtils.forBorderStyle(BorderStyle.HIDDEN));
		List<ColumnConfig<Utilisateur, ?>> l = new ArrayList<ColumnConfig<Utilisateur, ?>>();
		l.add(nom);
		ColumnModel<Utilisateur> cm = new ColumnModel<Utilisateur>(l);
		
		gridUtilisateurs = new Grid<Utilisateur>(storeUtilisateurs,cm);
		
		gridUtilisateurs.setBorders(false);
		gridUtilisateurs.setHideHeaders(true);
		gridUtilisateurs.getView().setAutoFill(true);
		utilisateursFieldset.add(gridUtilisateurs, new VerticalLayoutData(1, 1));
		gridUtilisateurs.getSelectionModel().addSelectionChangedHandler(new SelectionChangedHandler<Utilisateur>() {

			@Override
			public void onSelectionChanged(SelectionChangedEvent<Utilisateur> event) {
				if (event.getSelection().size() > 0){
					selectedUtilisateur = event.getSelection().get(0);
				}
			}
		});
		gridUtilisateurs.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		buildPaging();
	}

	protected void buildPaging() {
		
	}

	protected void loadAllRoles() {
		ClientGestionUtilisateursServiceAsync.Util.getInstance().findAllRole(new AsyncCallbackWithErrorResolution<List<RoleUtilisateur>>() {

			@Override
			public void onSuccess(List<RoleUtilisateur> arg0) {
				roleUtilisateurs = new ArrayList<RoleUtilisateur>();
				RoleUtilisateur r = new RoleUtilisateur();
				r.setCRole("");
				r.setLLibelle("");
				roleUtilisateurs.add(r);
				if (arg0 != null && arg0.size() > 0){
					for(int i = 0; i < arg0.size(); i++){
						RoleUtilisateur roleUtilisateur = arg0.get(i);
						if(!Role.ADMINISTRATEURGENERAL.getCode().equals(roleUtilisateur.getCRole())){
							roleUtilisateurs.add(roleUtilisateur);
						}
					}
				}
			}
		});
	}
}
