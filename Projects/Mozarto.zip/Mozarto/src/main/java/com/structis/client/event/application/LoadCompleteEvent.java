package com.structis.client.event.application;

import com.google.gwt.event.shared.GwtEvent;

public class LoadCompleteEvent extends GwtEvent<LoadCompleteHandler> {
	
	private static Type<LoadCompleteHandler> TYPE = new Type<LoadCompleteHandler>();
	

	public static Type<LoadCompleteHandler> getType(){
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<LoadCompleteHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(LoadCompleteHandler handler) {
		handler.onLoad(this);
	}

}
