package com.structis.server.service.domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.PzMetierMapper;
import com.structis.shared.model.PzMetier;


@Service("pzMetierService")
public class PzMetierServiceImpl implements PzMetierService {

	@Autowired
	PzMetierMapper pzMetierMapper;
	
	@Override
	public Integer insert(PzMetier metier) {
		return pzMetierMapper.insert(metier);
	}

	@Override
	public Integer update(PzMetier metier) {
		return pzMetierMapper.update(metier);
	}

}
