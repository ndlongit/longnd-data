package com.structis.server.service.domain;

import java.util.LinkedHashMap;
import java.util.List;

import com.structis.shared.model.Element;
import com.structis.shared.model.reference.CompositionElementGridModel;

public interface TmpCompositionDataElementUtil {

	void addUpdateCdrElements(List<CompositionElementGridModel> elements);
	
	void changeReferenceQuantie(Integer idReference, Integer quantite, boolean isOverwrite);
	
	void unSelectRerence( List<Integer> idReferences);

	List<CompositionElementGridModel> getCdrElementData();
	
	void resetData();
	
	void addUpdateEsElements(List<Element> elements);
	
	LinkedHashMap<Integer, Element> getEsElementData();
	
	void removeEsElment(List<Element> elements);
}
