package com.structis.client.service;

import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.client.panel.composition.CompositionReferenceFilter;
import com.structis.client.widget.CustomizePagingLoadResult;
import com.structis.shared.model.Element;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.CompositionAccueilModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionAndMessageModel;
import com.structis.shared.model.reference.CompositionCarateristiqueFilterActionModel;
import com.structis.shared.model.reference.CompositionCarateristiqueSelectAbleModel;
import com.structis.shared.model.reference.CompositionElementGridModel;
import com.structis.shared.model.reference.CompositionModel;
import com.structis.shared.model.reference.CompositionReferenceGridModel;
import com.structis.shared.model.reference.CompositionTreeComboboxModel;
import com.structis.shared.model.reference.ModeleModel;

public interface ClientCompositionServiceAsync {
	public static class Util {

		private static ClientCompositionServiceAsync instance = GWT.create(ClientCompositionService.class);

		public static ClientCompositionServiceAsync getInstance() {
			return instance;
		}
	}

	void findCaracteristiquesBeforeLeafNode(Integer idModeleVersion,
			AsyncCallback<List<CompositionCarateristiqueSelectAbleModel>> callback);

	void findCompositionReferenceByCaracteristiques(List<Integer> idCaracteristiques, Integer idModeleVersion,
			AsyncCallback<List<CompositionReferenceGridModel>> callback);

	void findCompositionElementByReferences(List<Integer> idReferences, Integer idModeleVersion,
			AsyncCallback<List<CompositionElementGridModel>> callback);

	void checkActionAfterFilter(Integer idCaracteristiqueSelected, Integer idModeleVersion,
			AsyncCallback<CompositionCarateristiqueFilterActionAndMessageModel> callback);

	void checkActionBeforeFilter(Integer idCaracteristiqueSelected, Integer idModeleVersion,
			AsyncCallback<List<CompositionCarateristiqueFilterActionModel>> callback);

	void findAllCompositionReferenceByCaracteristiques(Integer limit, Integer idModeleVersion,
			AsyncCallback<List<CompositionReferenceGridModel>> callback);

	void findCompositionReferenceByCaracteristiquesPaging(CompositionReferenceFilter loadConfig, AsyncCallback<CustomizePagingLoadResult<CompositionReferenceGridModel>> callback);

	void getCompositionTreeAndComboboxBeforeLastNode(Integer idModeleVersion, AsyncCallback<CompositionTreeComboboxModel> callback);
	
	void getMetier(Integer idMetier, AsyncCallback<Metier> callback);

	void findMessageByIdReference(Integer idModeleVersion, Integer idReference,
			AsyncCallback<Map<Integer, List<String[]>>> callback);

	void saveCompostion(CompositionModel composition, AsyncCallback<Integer> callback);

	void doAction(AsyncCallback<Void> callback);

	void changeReferenceQuantieTMPData(Integer idReference, Integer quantite, boolean isOverwrite,
			AsyncCallback<Void> callback);

	void onSelectReferenceTMPData(Map<Integer, Integer> mapReferences, Integer idModeleVersion, AsyncCallback<Void> callback);

	void updateCElementTMPData(CompositionElementGridModel element, AsyncCallback<Void> callback);

	void loadCeElementPagingTMPData(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<CompositionElementGridModel>> callback);

	void clearElementTMPData(AsyncCallback<Void> callback);

	void onUnSelectReferenceTMPData(List<Integer> idReferences, AsyncCallback<Void> callback);

	void loadEsElementPagingTMPData(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<Element>> callback);
	
	void addUpdateEsElementTMPData(List<Element> elements, AsyncCallback<Void> callback);

	void removeEsElment(List<Element> elements, AsyncCallback<Void> callback);
	
	void findAllLastPublicVersionByMetier(Integer idMetier, AsyncCallback<List<ModeleModel>> callback);
	
	void loadCompoByModele(ModeleModel modele, PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<CompositionAccueilModel>> callback);
	
	void deleteById(Integer idComposition, AsyncCallback<Integer> callback);
}
