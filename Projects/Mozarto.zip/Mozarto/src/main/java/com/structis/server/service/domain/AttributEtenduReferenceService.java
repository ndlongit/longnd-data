package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlAttributEtenduReference;
import com.structis.shared.model.MdlAttributEtenduReferenceKey;

public interface AttributEtenduReferenceService {
	void deleteByModelVersionAndReference(Integer idReference, Integer idModeleVersion);

	void insertList(List<MdlAttributEtenduReference> listAttr);

	void insert(MdlAttributEtenduReference record);

	List<MdlAttributEtenduReference> findByBaseCriteria(MdlAttributEtenduReference criteria);
	
	void deleteByIdReferences(Integer idModeleVersion, List<Integer> idReferences);
	
	void deleteByReferenceIdsAndAttributeIds(Integer idModeleVersion, List<Integer> idReferences, List<Integer> attributeIds);

	void update(MdlAttributEtenduReference sa);

	void deleteById(MdlAttributEtenduReferenceKey id);		

	public int deleteByIdAttribut(Integer idAttribut);
}
