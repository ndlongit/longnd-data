package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.MetierMzPzModel;


public interface MetierService {
	
	public Metier findById(Integer id);
	
	public Integer insert(Metier metier);
	
	public Integer update(Metier metier);
		
	public Integer delete(Metier metier);
	
	public Integer deleteById(Integer id);
	
	public List<Metier> findAll();
	
	public List<MetierMzPzModel> findAllPegaz();
	
	public List<Metier> findByLibelle(String lLibelle);
}
