package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface LoadCompositionHandler extends EventHandler {
	void onLoad(LoadCompositionEvent handler);
}
