package com.structis.client.event.application;

import com.google.gwt.event.shared.GwtEvent;

public class LoadDataEvent extends GwtEvent<LoadDataHandler> {
	
	private static Type<LoadDataHandler> TYPE = new Type<LoadDataHandler>();
	
	public static Type<LoadDataHandler> getType(){
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<LoadDataHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(LoadDataHandler handler) {
		handler.onLoad(this);
	}

}
