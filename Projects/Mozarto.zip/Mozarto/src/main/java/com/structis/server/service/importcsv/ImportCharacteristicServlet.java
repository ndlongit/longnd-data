package com.structis.server.service.importcsv;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;

import com.googlecode.jcsv.reader.internal.CSVReaderBuilder;
import com.structis.client.util.ImportUtil;
import com.structis.server.constant.ConstantServer;
import com.structis.server.core.ConstantError;
import com.structis.server.core.SpringGetter;
import com.structis.server.service.domain.CaracteristiqueService;
import com.structis.server.service.domain.ImportElementErrorService;
import com.structis.server.service.domain.ImportElementService;
import com.structis.server.service.domain.ImportService;
import com.structis.server.util.StringUtils;
import com.structis.shared.constant.Constant;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.exception.TechnicalException;
import com.structis.shared.model.Import;
import com.structis.shared.model.ImportElement;
import com.structis.shared.model.ImportElementError;
import com.structis.shared.model.MdlCaracteristique;

@SuppressWarnings("serial")
public class ImportCharacteristicServlet extends CSVImport {
	private static final Logger LOGGER = Logger.getLogger(ImportCharacteristicServlet.class);
	
	private static final String LEVEL_PATTERN = "^(?i)Niveau\\s+\\d+$";

	private ImportService importService;

	private ImportElementService importElementService;

	private ImportElementErrorService importElementErrorService;

	private CaracteristiqueService caracteristiqueService;

	private Integer metierId = null;

	private Integer userId = null;

	private Integer modelVersion = null;

	Map<Integer, List<Integer>> dataColumnIndexes = new HashMap<Integer, List<Integer>>();

	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		importService = (ImportService) SpringGetter.getBean(getServletContext(), ImportService.SERVIECE_NAME);
		importElementService = (ImportElementService) SpringGetter.getBean(
				getServletContext(), ImportElementService.SERVIECE_NAME);
		importElementErrorService = (ImportElementErrorService) SpringGetter.getBean(
				getServletContext(), ImportElementErrorService.SERVIECE_NAME);
		caracteristiqueService = (CaracteristiqueService) SpringGetter.getBean(getServletContext(), "caracteristiqueService");
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String importType = ConstantServer.IMPORT_TYPE_CHARACTERISTIC;
		PrintWriter out = response.getWriter();

		String errorMessage = "";
		String outputFile = null;
		List<String[]> csvData = null;
		Import newImport = null;
		File f = null;

		try {

			f = writeFile(request);

			if( f != null ) {
				outputFile = ImportUtil.buildOutputFile(f);
				List<String> statusList = new ArrayList<String>();
				statusList.add(ConstantServer.IMPORT_SAS_BEGIN);
				statusList.add(ConstantServer.IMPORT_SAS_VERIFICATION);

				Import importObject = null;
				List<Import> results = importService.findIdsByImportType(importType);

				if( results == null || results.size() == 0 ) {
					newImport = ImportUtil.createNewImport(metierId, userId, importType, modelVersion);
					importService.insert(newImport);
				}
				else {
					importObject = results.get(0);
					String importStatus = importObject.getCEtatImport();

					if( ConstantServer.IMPORT_SAS_BEGIN.equalsIgnoreCase(importStatus) || ConstantServer.IMPORT_SAS_VERIFICATION.equalsIgnoreCase(importStatus) ) {
						Object[] params = { importObject.getUser().getCUtilisateur() };
						errorMessage = messageSource.getMessage("import.characteristic.error.importing", params, locale);
						throw new FunctionalException(null, ConstantError.ERR_IMPORT_INPROGRESS, errorMessage);
					}

					Integer importId = importObject.getIdImport();
					importService.deletePreviousImportedData(importId);
					newImport = ImportUtil.createNewImport(metierId, userId, importType, modelVersion);
					importService.insert(newImport);
				}

				Integer importId = newImport.getIdImport();
				if( importId == null ) {
					return;
				}

				csvData = importDataToSas(newImport, f.getAbsolutePath(), modelVersion);

				if( ImportUtil.hasErrors(csvData) ) {

					newImport.setCEtatImport(ConstantServer.IMPORT_DATA_FUNCTIONAL_ERROR);

					//Update Import Status
					importService.update(newImport);
				}
				else {
					List<ImportElementError> errors = importElementErrorService.findByImportedId(importId);
					if( errors == null || errors.size() == 0 ) {
						newImport.setCEtatImport(ConstantServer.IMPORT_SAS_VERIFICATION);

						//Update Import Status
						importService.update(newImport);
						try {
							caracteristiqueService.importCharacteristicsToMozarto(
									importId, modelVersion, csvData, dataColumnIndexes, messageSource, userId);

							//Import done
							newImport.setCEtatImport(ConstantServer.IMPORT_DATA_DONE);
						}
						catch( Exception e ) {
							newImport.setCEtatImport(ConstantServer.IMPORT_DATA_TECHNICAL_ERROR);
							throw e;
						}
						finally {

							//Update Import Status
							importService.update(newImport);
						}
					}
					else {
						newImport.setCEtatImport(ConstantServer.IMPORT_DATA_FUNCTIONAL_ERROR);

						//Update Import Status
						importService.update(newImport);
					}
				}
			}
		}
		catch( Exception e ) {
			if( newImport != null ) {
				newImport.setCEtatImport(ConstantServer.IMPORT_DATA_FUNCTIONAL_ERROR);
			}
			if( e instanceof FunctionalException || e instanceof TechnicalException ) {
				errorMessage = e.getMessage();
			}
			else {
				errorMessage = messageSource.getMessage("import.error", null, locale);
			}
			LOGGER.error(e.getMessage(), e);
		}
		finally {
			if( newImport != null ) {

				//Update Import Status
				importService.update(newImport);
			}

			ImportUtil.processImportOutput(request, out, csvData, outputFile, errorMessage);

			out.flush();
			out.close();
		}
	}

	@SuppressWarnings("rawtypes")
	private File writeFile(HttpServletRequest request) throws Exception {

		File uploadFile = null;
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);

		if( isMultipart ) {
			FileOutputStream out = null;

			// Create a factory for disk-based file items
			try {
				FileItemFactory factory = new DiskFileItemFactory();

				// Create a new file upload handler
				ServletFileUpload upload = new ServletFileUpload(factory);

				// Parse the request
				List items = upload.parseRequest(request);
				if( items != null && items.size() > 0 ) {
					for( Object object : items ) {

						FileItem item = (FileItem) object;
						String fieldName = item.getFieldName();

						if( item.isFormField() ) {
							if( Constant.ID_METIER.equalsIgnoreCase(fieldName) ) {
								metierId = Integer.parseInt(item.getString());
							}

							if( ConstantServer.PARAM_USER_ID.equalsIgnoreCase(fieldName) ) {
								userId = Integer.parseInt(item.getString());
							}

							else if( ConstantServer.PARAM_MODEL_EVERSION_ID.equalsIgnoreCase(fieldName) ) {
								modelVersion = Integer.parseInt(item.getString());
							}
						}
						else {
							String clientFileLocation = item.getName();
							clientFileLocation = clientFileLocation.replaceAll("\\\\", "/");

							int lastSeperatorIndex = clientFileLocation.lastIndexOf("/");
							String clientFileName = clientFileLocation.substring(lastSeperatorIndex + 1);

							byte[] data = item.get();

							File fileFolder = new File(getServletContext().getRealPath("/files"));
							if( !fileFolder.exists() ) {
								fileFolder.mkdir();
							}

							String uploadFileName = fileFolder.getAbsolutePath() + "/" + clientFileName;
							uploadFile = new File(uploadFileName);

							if( uploadFile.exists() ) {
								uploadFile.delete();
							}

							uploadFile.createNewFile();

							out = new FileOutputStream(uploadFile);
							out.write(data);
							out.close();
						}
					}
				}
			}
			catch( Exception e ) {
				if( out != null ) {
					out.close();
				}
				throw e;
			}
			finally {
				out = null;
			}
			return uploadFile;
		}
		else {
			return null;
		}
	}
	
	private static String validateHeaderColumnNames(String pattern, String[] csvHeaderColums) {
		String error = "";
		for( int i = 1 ; i < csvHeaderColums.length ; i++ ) {
			String headerColumn = csvHeaderColums[i];
			if( !headerColumn.matches(pattern) ) {
				Object[] params = { headerColumn };
				if( error == "" ) {
					error = "\"" + messageSource.getMessage("import.error.headerColumn.invalid", params, locale) + "\"";
				}
				else {
					error += ", \"" + messageSource.getMessage("import.error.headerColumn.invalid", params, locale) + "\"";
				}
			}
		}

		return error;
	}

	private List<String[]> importDataToSas(Import importData, String file, int modelVersion) throws IOException {
		Reader reader = new FileReader(file);
		List<String[]> csvData = CSVReaderBuilder.newDefaultReader(reader).readAll();

		csvData = ImportUtil.addErrorColumns(csvData);

		String[] row = null;
		String csvError = null;
		String dbError = null;
		Integer idImport = importData.getIdImport();

		Map<String, String> map = new HashMap<String, String>();
		List<String> firstLevelNodes = new ArrayList<String>();
		boolean addedErrorToFirstRow = false;
		List<String> finalNodes = new ArrayList<String>();
		int firstLevel0LineIndex = -1;

		String allRowsError = validateHeaderColumnNames(LEVEL_PATTERN, csvData.get(0));
		
		for( int i = 1 ; i < csvData.size() ; i++ ) {
			row = csvData.get(i);
			if( ImportUtil.isNullOrEmpty(row) ) {
				continue;
			}
			csvError = "";
			dbError = "";
			ImportElement data = null;
			String cellValue = null;

			List<String> characterristicOfColumn = new ArrayList<String>();

			int firstDataColumn = findFirstDataColumn(row);
			int lastDataColumn = findLastDataColumn(row);

			List<Integer> columnIndexes = new ArrayList<Integer>();
			columnIndexes.add(firstDataColumn);
			columnIndexes.add(lastDataColumn);

			dataColumnIndexes.put(i, columnIndexes);

			ImportElementError elementError = null;
			for( int j = firstDataColumn ; j <= lastDataColumn ; j++ ) {
				cellValue = row[j];
				if( cellValue != null ) {
					cellValue = cellValue.trim();
				}
				if( !ImportUtil.isNullOrEmpty(cellValue) ) {
					data = new ImportElement();
					data.setCTypeElementImport("CAR");
					data.setIdImport(idImport);
					data.setLValeur(cellValue);
					data.setNLigne(i);
					data.setNColonne(j - 1); // Dont count first column (Error column)

					elementError = checkMaxLengthCharacteristic(data); // Check max-length (and truncate if needed)

					// Save element (after truncate if needed)
					importElementService.insert(data);

					if( elementError != null ) { // Violate max-length rule
						csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
						elementError.setIdElementImport(data.getIdElementImport());
						importElementErrorService.insert(elementError);
					}

					if( j == 1 ) {
						if( ImportUtil.isNullOrEmpty(firstLevelNodes) ) {
							firstLevelNodes.add(cellValue);
							if( firstLevel0LineIndex == -1 ) {
								firstLevel0LineIndex = i;
							}
						}
						else {
							if( !firstLevelNodes.contains(cellValue) ) {
								dbError = messageSource.getMessage(
										"import.characteristic.error.characteristicsLevel0NotHaveSameLabel", null, locale);
								csvError = ImportUtil.prependError(csvError, dbError);
								elementError = new ImportElementError();
								elementError.setIdElementImport(data.getIdElementImport());
								elementError.setLLibelleLong(dbError);
								importElementErrorService.insert(elementError);
								if( !addedErrorToFirstRow ) {
									addedErrorToFirstRow = true;
									if( firstLevel0LineIndex > 0 ) {
										if( !ImportUtil.isNullOrEmpty(csvData.get(firstLevel0LineIndex)[1]) ) {
											ImportUtil.prependErrorToRow(csvData, firstLevel0LineIndex, dbError);
										}
									}
								}
							}
						}
					}

					if( characterristicOfColumn.contains(cellValue.toUpperCase()) ) {
						Object[] params = { cellValue };
						dbError = messageSource.getMessage(
								"import.characteristic.error.terminationCharacteristicNotUniqueInFile", params, locale);
						csvError = ImportUtil.appendError(csvError, dbError);
						elementError = new ImportElementError();
						elementError.setIdElementImport(data.getIdElementImport());
						elementError.setLLibelleLong(dbError);
						importElementErrorService.insert(elementError);
					}
					else {
						characterristicOfColumn.add(cellValue.toUpperCase());
					}

					if( j == firstDataColumn ) {
						List<MdlCaracteristique> list = caracteristiqueService.findCharacteristicHierarchyByLevel(
								modelVersion, j - 1, cellValue);
						if( ImportUtil.isNullOrEmpty(list) ) {
							Object[] params = { cellValue };
							dbError = messageSource.getMessage(
									"import.characteristic.error.rootCharacteristicNotExistsInModel", params, locale);
							csvError = ImportUtil.appendError(csvError, dbError);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
						}
					}

					if( j >= (firstDataColumn + 1) ) {
						String parentPath = map.get(cellValue);
						String currentParentPath = buildParentPath(row, firstDataColumn, j - 1);

						if( ImportUtil.isNullOrEmpty(parentPath) ) {
							map.put(cellValue, currentParentPath);
						}
						else {
							if( !parentPath.equals(currentParentPath) ) {
								Object[] params = { cellValue };
								dbError = messageSource.getMessage(
										"import.characteristic.error.terminationCharacteristicNotUniqueInFile", params,
										locale);
								csvError = ImportUtil.appendError(csvError, dbError);
								elementError = new ImportElementError();
								elementError.setIdElementImport(data.getIdElementImport());
								elementError.setLLibelleLong(dbError);
								importElementErrorService.insert(elementError);
							}
						}
					}

					if( j == lastDataColumn ) {
						if( finalNodes.contains(cellValue.toUpperCase()) ) {
							Object[] params = { cellValue };
							dbError = messageSource.getMessage(
									"import.characteristic.error.terminationCharacteristicNotUniqueInFile", params, locale);
							csvError = ImportUtil.appendError(csvError, dbError);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
						}
						else {
							finalNodes.add(cellValue.toUpperCase());
						}
					}
				}
			}

			//Append errors to first column
			if( !ImportUtil.isNullOrEmpty(allRowsError) ) {
				csvError = allRowsError + ", " + csvError;
			}
			csvData.get(i)[0] = csvError;
		}
		return csvData;
	}

	private String buildParentPath(String[] row, int startColumn, int endColumn) {
		String result = "";
		for( int i = startColumn ; i <= endColumn ; i++ ) {
			if( !ImportUtil.isNullOrEmpty(row[i]) ) {
				if( result == "" ) {
					result = row[i].toUpperCase();
				}
				else {
					result += "/" + row[i].toUpperCase();
				}
			}
		}
		return result;
	}

	private int findFirstDataColumn(String[] row) {
		int result = -1;
		if( !ImportUtil.isNullOrEmpty(row) ) {
			for( int i = 0 ; i < row.length ; i++ ) {
				if( !ImportUtil.isNullOrEmpty(row[i]) ) {
					result = i;
					break;
				}
			}
		}

		return result;
	}

	private static int findLastDataColumn(String[] row) {
		int result = -1;
		if( !ImportUtil.isNullOrEmpty(row) ) {
			for( int i = row.length - 1 ; i >= 0 ; i-- ) {
				if( !ImportUtil.isNullOrEmpty(row[i]) ) {
					result = i;
					break;
				}
			}
		}

		return result;
	}

	private static ImportElementError checkMaxLengthCharacteristic(ImportElement data) {

		ImportElementError elementError = null;
		String value = data.getLValeur();
		int length = 50;
		String errorStr = null;

		if( !ImportUtil.checkMaxLength(value, length) ) {
			errorStr = buildMaxLengthErrorMessage(value, length);
			value = StringUtils.truncate(value, length);
			elementError = new ImportElementError();
			elementError.setLLibelleLong(errorStr);
		}

		data.setLValeur(value);

		return elementError;
	}
}
