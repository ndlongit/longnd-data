package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.client.service.ClientGestionElementCompositionService;
import com.structis.server.service.domain.AttributEtenduElementService;
import com.structis.server.service.domain.AttributEtenduService;
import com.structis.server.service.domain.ElementService;
import com.structis.server.service.domain.FamilleService;
import com.structis.server.service.domain.MetierService;
import com.structis.server.service.domain.TypeElementService;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.Element;
import com.structis.shared.model.Famille;
import com.structis.shared.model.Metier;
import com.structis.shared.model.TypeElement;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.GestionElementCompositionReference;

@Service("gestionElementCompositionServiceImpl")
public class ClientGestionElementCompositionServiceImpl implements ClientGestionElementCompositionService {

	@Autowired
	TypeElementService typeElementService;
	
	@Autowired
	AttributEtenduService attributEtenduService;
		
	@Autowired
	ElementService elementService;

	@Autowired
	FamilleService familleService;
	
	@Autowired
	MetierService metierService;
	
	@Autowired
	AttributEtenduElementService attributEtenduElementService;
	
	@Override
	public GestionElementCompositionReference getGestionElementCompositionReference(Integer id, Integer idMetier) {
		
		GestionElementCompositionReference object = new GestionElementCompositionReference();
		if (id != null){
			Element element = elementService.findById(id);
			object.setElement(element);
			List<AttributEtenduMetierERValueModel> attributEtenduElements = elementService.findAttributEtenduElementValueByIdAndMetier(id, idMetier);
			object.setAttributEtendus(attributEtenduElements);
		}
		else {
			List<AttributEtenduMetierERValueModel> attributEtenduElements = new ArrayList<AttributEtenduMetierERValueModel>();
			List<AttributEtendu> attList = attributEtenduService.findAttributElementByMetier(idMetier);
			for (int i = 0; i < attList.size(); i++){
				AttributEtenduMetierERValueModel attributEtenduMetierERValueModel = new AttributEtenduMetierERValueModel();
				AttributEtendu attributEtendu = attList.get(i);
				attributEtenduMetierERValueModel.setAttributEtenduLibelle(attributEtendu.getLLibelle());
				attributEtenduMetierERValueModel.setIdAttributEtendu(attributEtendu.getIdAttributEtendu());
				attributEtenduMetierERValueModel.setValeur(attributEtendu.getLValeur());
				attributEtenduElements.add(attributEtenduMetierERValueModel);
			}
			object.setAttributEtendus(attributEtenduElements);
		}
		List<TypeElement> typeElementList = typeElementService.findAll();
		object.setTypeElements(typeElementList);
		List<Famille> familleByMetierList = familleService.findByMetier(idMetier);
		object.setFamilles(familleByMetierList);
		return object;
	}

	@Override
	public Metier getMetier(Integer idMetier) {
		return metierService.findById(idMetier);
	}
	
	
	

}
