package com.structis.server.service.domain;

import com.structis.shared.model.PzMetier;

public interface PzMetierService {
	
	public Integer insert(PzMetier metier);
	
	public Integer update(PzMetier metier);

}
