package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.structis.shared.model.Famille;

public interface ClientFamilleServiceAsync {
	public static class Util {

		private static ClientFamilleServiceAsync instance = GWT
				.create(ClientFamilleService.class);
	
		public static ClientFamilleServiceAsync getInstance() {
			return instance;
		}
		
	}
	public void findAll (AsyncCallback<List<Famille>> callback);
}


