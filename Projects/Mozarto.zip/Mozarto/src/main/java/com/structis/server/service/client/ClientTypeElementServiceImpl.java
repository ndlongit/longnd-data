package com.structis.server.service.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.client.service.ClientTypeElementService;
import com.structis.server.service.domain.TypeElementService;
import com.structis.shared.model.TypeElement;

@Service("clientTypeElementService")
public class ClientTypeElementServiceImpl implements ClientTypeElementService {

	@Autowired
	TypeElementService typeElementService;
	
	@Override
	public List<TypeElement> findAll() {
		return typeElementService.findAll();
	}

}
