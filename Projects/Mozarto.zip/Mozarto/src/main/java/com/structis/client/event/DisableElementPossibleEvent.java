package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class DisableElementPossibleEvent extends GwtEvent<DisableElementPossibleHandler> {

	private static Type<DisableElementPossibleHandler> TYPE = new Type<DisableElementPossibleHandler>();
	private String tabLabel;
	private Integer idElement;

	public static Type<DisableElementPossibleHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<DisableElementPossibleHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(DisableElementPossibleHandler handler) {
		handler.onLoad(this);
	}	

	public DisableElementPossibleEvent(String tabLabel) {
		this.tabLabel = tabLabel;
	}

	public DisableElementPossibleEvent(Integer idElement) {
		this.idElement = idElement;
	}

	public String getTabLabel() {
		return tabLabel;
	}

	public void setTabLabel(String newLabel) {
		this.tabLabel = newLabel;
	}

	public void setIdElement(Integer idElement) {
		this.idElement = idElement;
	}

	public Integer getIdElement() {
		return idElement;
	}

}
