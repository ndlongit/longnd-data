package com.structis.client.panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.structis.client.constant.ConstantClient.ScreenSize;
import com.structis.client.ecran.EcranLoadable;
import com.structis.client.event.GestionDuMetierAddTabEvent;
import com.structis.client.event.GestionDuMetierAddTabHandler;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.widget.CustomizeBorderlayoutContainer;

/**
 * administrator screen Gestion Des Element De Composition
 * 
 * @author vinh.tong
 */
public class GestionDuMetierContainer extends SimpleContainer implements EcranLoadable {

	private TabPanel centerPanel;

	private SimpleEventBus bus = new SimpleEventBus();

	private final Messages messages = GWT.create(Messages.class);

	private GestionDuMetierLeftPanel west;
	
//	private NavigationService navigation = NavigationFactory.getNavigation();
	
	public GestionDuMetierContainer() {

	}

	/**
	 * 
	 */
	@Override
	protected void onAfterFirstAttach() {
		super.onAfterFirstAttach();
		CustomizeBorderlayoutContainer container = new CustomizeBorderlayoutContainer();
		west = new GestionDuMetierLeftPanel(bus);

		BorderLayoutData westData = new BorderLayoutData(ScreenSize.MINLEFT);
		westData.setCollapsible(true);
		westData.setSplit(true);
		westData.setCollapseMini(true);
		westData.setMargins(new Margins(0, 5, 0, 0));
		westData.setMinSize(ScreenSize.MINLEFT);
		
		ContentPanel leftPanel = new ContentPanel();
		leftPanel.setHeaderVisible(false);
		leftPanel.setBorders(false);
		leftPanel.setBodyBorder(false);
		leftPanel.add(west);
		container.setWestWidget(leftPanel, westData);
		centerPanel = new TabPanel();
		
		MarginData centerData = new MarginData();

		container.setCenterWidget(centerPanel, centerData);
		container.setLeftTitle(messages.commonPanneauAction());

		add(container);
		
		bus.addHandler(GestionDuMetierAddTabEvent.getType(), new GestionDuMetierAddTabHandler() {
			
			@Override
			public void onLoad(GestionDuMetierAddTabEvent metiersAddTabEvent) {
				GestionDuMetierForm form = new GestionDuMetierForm(bus);
				centerPanel.add(form, metiersAddTabEvent.getMetier().getLLibelle());
				form.getLibelle().setText(metiersAddTabEvent.getMetier().getLLibelle());
				form.setIdMetier(metiersAddTabEvent.getMetier().getIdMetier());
				form.setMetier(metiersAddTabEvent.getMetier());
				form.fillGrids();
			}
		});

	}

	@Override
	public void onLoadApplication(NavigationEvent event) {
	}
}
