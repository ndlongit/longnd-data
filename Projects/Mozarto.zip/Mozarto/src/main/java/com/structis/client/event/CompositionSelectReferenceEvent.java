package com.structis.client.event;

import java.util.List;

import com.google.gwt.event.shared.GwtEvent;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.structis.shared.model.reference.CompositionReferenceGridModel;

public class CompositionSelectReferenceEvent extends GwtEvent<CompositionSelectReferenceHandler> {

	private static Type<CompositionSelectReferenceHandler> TYPE = new Type<CompositionSelectReferenceHandler>();

	private List<CompositionReferenceGridModel> references;
	private Integer idModelVersion;
	private Grid<CompositionReferenceGridModel> sourceGrid;
	public static Type<CompositionSelectReferenceHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<CompositionSelectReferenceHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(CompositionSelectReferenceHandler handler) {
		handler.onLoad(this);
	}

	
	public List<CompositionReferenceGridModel> getReferences() {
		return references;
	}

	public void setIdReferences(List<CompositionReferenceGridModel> references) {
		this.references = references;
	}

	public Integer getIdModelVersion() {
		return idModelVersion;
	}

	public void setIdModelVersion(Integer idModelVersion) {
		this.idModelVersion = idModelVersion;
	}

	public Grid<CompositionReferenceGridModel> getSourceGrid() {
		return sourceGrid;
	}

	public void setSourceGrid(Grid<CompositionReferenceGridModel> sourceGrid) {
		this.sourceGrid = sourceGrid;
	}
		
	
	

}
