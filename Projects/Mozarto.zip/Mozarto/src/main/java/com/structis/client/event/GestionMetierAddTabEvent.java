package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.MetierMzPzModel;

public class GestionMetierAddTabEvent extends GwtEvent<GestionMetierAddTabHandler> {

	private static Type<GestionMetierAddTabHandler> TYPE = new Type<GestionMetierAddTabHandler>();
	
	private MetierMzPzModel metier;

	public static Type<GestionMetierAddTabHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionMetierAddTabHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionMetierAddTabHandler handler) {
		handler.onLoad(this);
	}

	public GestionMetierAddTabEvent(MetierMzPzModel metier) {
		this.metier = metier;
	}

	public void setMetier(MetierMzPzModel metier) {
		this.metier = metier;
	}

	public MetierMzPzModel getMetier() {
		return metier;
	}

}
