package com.structis.shared.constant;

public enum ApplicationOrigineConstant {
	MOZARTO("M","Mozarto"), PEGAZ("P","PEGAZ");
	private ApplicationOrigineConstant(String code,String libelle) {
		this.code = code;
		this.libelle = libelle;
	}

	private final String code;
	
	private final String libelle;
	
	public String getCode() {
		return code;
	}
	
	public String getLibelle() {
		return libelle;
	}
}
