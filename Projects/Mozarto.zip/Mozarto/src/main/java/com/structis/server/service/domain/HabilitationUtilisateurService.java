package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.HabilitationUtilisateur;
import com.structis.shared.model.reference.UtilisateurMetierRoleModel;

public interface HabilitationUtilisateurService {
	HabilitationUtilisateur findByIdUtilisateurAndIdMetier(Integer idUtilisateur, Integer idMetier);
	
	int update(Integer idUtilisateur, Integer idMetier, String cRole);

	List<UtilisateurMetierRoleModel> getAllMetier(Integer idUtilisateur);
	
	int insertList(List<HabilitationUtilisateur> list);
	
	int deleteByIdUtilisateur(Integer idUtilisateur);
}
