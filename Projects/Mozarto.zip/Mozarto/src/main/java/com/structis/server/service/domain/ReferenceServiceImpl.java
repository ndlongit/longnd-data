package com.structis.server.service.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.client.navigation.NavigationFactory;
import com.structis.client.util.ImportUtil;
import com.structis.server.core.ConstantError;
import com.structis.server.persistence.MdlReferenceMapper;
import com.structis.server.util.StringUtils;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.exception.FunctionalException;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.Element;
import com.structis.shared.model.Import;
import com.structis.shared.model.ImportElement;
import com.structis.shared.model.ImportElementError;
import com.structis.shared.model.MdlAttributEtenduReference;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlCarateristiqueReference;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.MdlReferenceElement;
import com.structis.shared.model.MdlReferenceSousModele;
import com.structis.shared.model.SousReferenceReference;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.SousReferenceModel;
import com.structis.shared.model.reference.TreeNodeModel;
import com.structis.shared.model.reference.ValuePlaceHolder;

@Service
public class ReferenceServiceImpl implements ReferenceService {

	private static final String TYPE_ELEMENT_IMPORT = "c_type_element_import";
	
	private static final List<String> FIXED_HEADER_COLUMNS = Arrays.asList(
			"REFERENCE", "VALEUR", "ATTRIBUT", "CARACTERISTIQUE", "PEGAZ_ELEMENT", "FOURNISSEUR_ELEMENT", "QUANTITE");
	
	private static final List<String> FIXED_HEADER_COLUMNS_2 = Arrays.asList(
			"SOUSMODELE", "VALEUR", "ATTRIBUT", "CARACTERISTIQUE", "PEGAZ_ELEMENT", "FOURNISSEUR_ELEMENT", "QUANTITE");

	@Autowired
	MdlReferenceMapper mdlReferenceMapper;

	@Autowired
	AttributEtenduReferenceService attributEtenduReferenceService;

	@Autowired
	CarateristiqueReferenceService carateristiqueReferenceService;

	@Autowired
	ReferenceElementService referenceElementService;

	@Autowired
	AttributEtenduService attributEtenduService;

	@Autowired
	ImportElementService importElementService;

	@Autowired
	ImportElementErrorService importElementErrorService;

	@Autowired
	ModeleService modelService;

	@Autowired
	CaracteristiqueService caracteristiqueService;

	@Autowired
	private ElementService elementService;

	@Autowired
	private ReferenceSousModeleService referenceSousModeleService;
	
	@Autowired
	private SousReferenceReferenceService sousReferenceReferenceService;
	
	@Autowired
	private ModeleService modeleService;

	private static Locale locale;

	private static final Map<String, String> elementTypeMap;

	static {
		elementTypeMap = new HashMap<String, String>();
		elementTypeMap.put("reference", "REF");
		elementTypeMap.put("sousmodele", "SMO");
		elementTypeMap.put("attribut", "NAT");
		elementTypeMap.put("valeur", "VAT");
		elementTypeMap.put("caracteristique", "CAR");
		elementTypeMap.put("pegaz_element", "CEL");
		elementTypeMap.put("quantite", "QTE");
		elementTypeMap.put("fournisseur_element", "NFO");

		locale = new Locale(NavigationFactory.getNavigation().getContext().getLanguageCode());
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<MdlReference> findReferenceByModeleVersionAndCaracteristique(Integer idModeleVersion,
			Integer idCaracteristique) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idCaracteristique", idCaracteristique);
		return mdlReferenceMapper.findByModeleVersionAndCaracteristique(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<Integer> findReferenceIdListByModeleVersionAndCaracteristiqueList(Integer idModeleVersion,
			List<Integer> idCaracteristiques) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("caracteristiqueList", idCaracteristiques);
		return mdlReferenceMapper.findListIdByModeleVersionAndCaracteristiqueList(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<ValuePlaceHolder> findElementNumberOfReferenceByModeleVersionAndCaracteristique(Integer idModeleVersion,
			Integer idCaracteristique) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idCaracteristique", idCaracteristique);
		return mdlReferenceMapper.findElementNumberByModeleVersionAndCaracteristique(mapParameter);
	}

	@Override
	public MdlReference findById(Integer idReference) {
		return mdlReferenceMapper.findById(idReference);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<AttributEtenduMetierERValueModel> findAttributEtenduMetierERValueByIdAndMetier(Integer idModeleVersion,
			Integer idReference, Integer idMetier) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);
		mapParameter.put("idMetier", idMetier);

		return mdlReferenceMapper.findAttributeReferenceValue(mapParameter);
	}

	@Override
	@Transactional
	public void insert(MdlReference reference) throws FunctionalException {
		//check if exists reference with the same name in the same modele version
		List<MdlReference> references = findByModeleVersionAndLibelle(
				reference.getIdModeleVersion(), reference.getIdReference(), reference.getLLibelleLong());
		if( references != null && references.size() > 0 ) {
			throw new FunctionalException(ConstantError.ERR_DUPLICATED);
		}
		mdlReferenceMapper.insert(reference);
	}

	@Override
	public void update(MdlReference reference) throws FunctionalException {
		//check if exists reference with the same name in the same modele version
		List<MdlReference> references = findByModeleVersionAndLibelle(
				reference.getIdModeleVersion(), reference.getIdReference(), reference.getLLibelleLong());
		if( references != null && references.size() > 0 ) {
			throw new FunctionalException(ConstantError.ERR_DUPLICATED);
		}
		mdlReferenceMapper.updateSelective(reference);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<MdlReference> findByModeleVersionAndLibelle(Integer idModeleVersion, Integer idReference, String libelle) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);
		mapParameter.put("lLibelleLong", libelle);
		return mdlReferenceMapper.findByDynamicParameters(mapParameter);
	}

	@Override
	@Transactional
	public void updateAttributeAttendu(Integer idModeleVersion, Integer idReference,
			List<AttributEtenduMetierERValueModel> attributs, boolean isSous) {
		if( attributs != null && attributs.size() > 0 ) {
			//clean the current attribute value
			attributEtenduReferenceService.deleteByModelVersionAndReference(idReference, idModeleVersion);
			//add the new attribute value
			for( AttributEtenduMetierERValueModel attr : attributs ) {
				if( attr.getValeur() != null && !attr.getValeur().equals("") ) {
					MdlAttributEtenduReference attributEtenduReference = new MdlAttributEtenduReference();
					attributEtenduReference.setIdAttributEtendu(attr.getIdAttributEtendu());
					attributEtenduReference.setIdModeleVersion(idModeleVersion);
					attributEtenduReference.setIdReference(idReference);
					attributEtenduReference.setLValeur(attr.getValeur());
					attributEtenduReferenceService.insert(attributEtenduReference);					
					//attributEtenduReferenceList.add(attributEtenduReference);
				}
			}
			if (isSous) {
				updateAttributeAttenduForSousReference(idModeleVersion, idReference,
						attributs);
			}
			//			if(attributEtenduReferenceList.size()>0){
			//				attributEtenduReferenceService.insertList(attributEtenduReferenceList);
			//			}
		}
	}

	
	private void updateAttributeAttenduForSousReference(
			Integer idModeleVersion, Integer idReference,
			List<AttributEtenduMetierERValueModel> attributs) {
		List<Integer> sousReferences = findSousReferenceIdsFromReference(idModeleVersion, idReference);
		for (Integer sousId:  sousReferences) {
			MdlAttributEtenduReference criteria = new MdlAttributEtenduReference();
			criteria.setIdReference(sousId);
			criteria.setIdModeleVersion(idModeleVersion);
			List<MdlAttributEtenduReference> sousAttrs = attributEtenduReferenceService.findByBaseCriteria(criteria);
			if (sousAttrs != null && sousAttrs.size() > 0) {
				for (MdlAttributEtenduReference sa: sousAttrs) {
					AttributEtenduMetierERValueModel at = getValueFromListAttributes(sa.getIdAttributEtendu(), attributs);
					if (at == null || at.getValeur() == null || at.getValeur().isEmpty()) {
						attributEtenduReferenceService.deleteById(sa.getId());
					} else {
						sa.setLValeur(at.getValeur());
						attributEtenduReferenceService.update(sa);
					}					
				}
			}
		}
		
	}

	private AttributEtenduMetierERValueModel getValueFromListAttributes(Integer sa,
			List<AttributEtenduMetierERValueModel> attributs) {
		for (AttributEtenduMetierERValueModel att: attributs) {
			if (att.getIdAttributEtendu().equals(sa)) {
				return att;
			}			
		}
		return null;
	}

	private List<Integer> findSousReferenceIdsFromReference(
			Integer idModeleVersion, Integer idReference) {
		Map<String, Integer> mapParameter = new HashMap<String, Integer>();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);		
		return mdlReferenceMapper.findSousReferenceIdsByReference(mapParameter);
	}

	@Override
	public void updateCarateristiqueReference(Integer idModeleVersion, Integer idReference,
			List<MdlCarateristiqueReference> carateristiqueReferences, boolean isSous) {
		//clean the current carateristique
		carateristiqueReferenceService.deleteByModeleVersionAndReference(idModeleVersion, idReference);
		if( carateristiqueReferences != null && carateristiqueReferences.size() > 0 ) {
			for( MdlCarateristiqueReference item : carateristiqueReferences ) {
				if( item.getIdCaracteristique() != null && item.getIdCaracteristique() > 0 ) {
					item.setIdReference(idReference);
					item.setIdModeleVersion(idModeleVersion);
					carateristiqueReferenceService.insert(item);
				}
			}
			//			carateristiqueReferenceService.insertList(carateristiqueReferences);
		}
		if (isSous) {
			updateCarateristiqueReferenceForSousReference(idModeleVersion, idReference,
					carateristiqueReferences);
		}
	}

	private void updateCarateristiqueReferenceForSousReference(
			Integer idModeleVersion, Integer idReference,
			List<MdlCarateristiqueReference> carateristiqueReferences) {
		List<Integer> sousReferences = findSousReferenceIdsFromReference(idModeleVersion, idReference);
		for (Integer sousId:  sousReferences) {			
			List<MdlCarateristiqueReference> sousCaracteristiques = carateristiqueReferenceService.findByModeleVersionAndReference(idModeleVersion, sousId);
			if (sousCaracteristiques != null && sousCaracteristiques.size() > 0) {
				for (MdlCarateristiqueReference sa: sousCaracteristiques) {
					MdlCarateristiqueReference at = getValueFromListCarateristiques(sa.getIdCaracteristique(), carateristiqueReferences);
					if (at == null) {
						carateristiqueReferenceService.delete(sa);					
//					} else {
//						sa.setNQuantite(at.getNQuantite());						
					}					//					
				}
			}
		}		
	}

	private MdlCarateristiqueReference getValueFromListCarateristiques(
			Integer idCaracteristique,
			List<MdlCarateristiqueReference> carateristiqueReferences) {
		for (MdlCarateristiqueReference att: carateristiqueReferences) {
			if (att.getIdCaracteristique().equals(idCaracteristique)) {
				return att;
			}			
		}
		return null;
	}

	@Override
	public void updateReferenceElement(Integer idModelVersion, Integer idReference, List<MdlReferenceElement> referenceElements, boolean isSous) {
		if( referenceElements != null && referenceElements.size() > 0 ) {
			for( MdlReferenceElement referenceElement : referenceElements ) {
				referenceElementService.update(referenceElement);
			}
		}
		if (isSous) {
			updateReferenceElementForSousReference(idModelVersion, idReference,
					referenceElements);
		}
	}

	private void updateReferenceElementForSousReference(Integer idModeleVersion,
			Integer idReference, List<MdlReferenceElement> referenceElements) {
		List<Integer> sousReferences = findSousReferenceIdsFromReference(idModeleVersion, idReference);
		for (Integer sousId:  sousReferences) {			
			List<MdlReferenceElement> sousElements = referenceElementService.findByModeleVersionAndReference(idModeleVersion, sousId);
			if (sousElements != null && sousElements.size() > 0) {
				for (MdlReferenceElement sa: sousElements) {
					MdlReferenceElement at = getValueFromListElements(sa.getIdElement(), referenceElements);
					if (at == null || at.getNQuantite() == null) {
						sa.setNQuantite(null);
						
					} else {
						sa.setNQuantite(at.getNQuantite());						
					}					
					referenceElementService.update(sa);
				}
			}
		}		
	}

	private MdlReferenceElement getValueFromListElements(Integer idElement,
			List<MdlReferenceElement> referenceElements) {
			for (MdlReferenceElement att: referenceElements) {
				if (att.getIdElement().equals(idElement)) {
					return att;
				}			
			}
			return null;
	}

	@Override
	public List<MdlReference> findAllReferenceByIdModeleVersion(Integer idModeleVersion) {
		return mdlReferenceMapper.findAllReferenceByIdModeleVersion(idModeleVersion);
	}

	@Override
	public List<SousReferenceModel> findAllSousReferenceByIdModeleVersion(Integer idModeleVersion) {
		return mdlReferenceMapper.findAllSousReferenceByIdModeleVersion(idModeleVersion);
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public MdlReference findByIdLienCommun(Integer idModeleVersion, Integer idLienCommun) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommun", idLienCommun);
		return mdlReferenceMapper.findByIdLienCommun(mapParameter);
	}

	@Override
	@Transactional
	public void insert(Integer idCaracteristiqueParent, MdlReference record) {
		int recordsCount = countRefernceByModeleVersionAndLibelle(
				record.getIdModeleVersion(), record.getLLibelleLong(), record.getIdReference());
		if( recordsCount > 0 ) {
			throw new FunctionalException(ConstantError.ERR_DUPLICATED);
		}
		Integer maxRange = mdlReferenceMapper.findMaxRangeOfModel(record.getIdModeleVersion());
		if( maxRange == null ) {
			maxRange = 0;
		}
		record.setNRang(maxRange + 1);
		mdlReferenceMapper.insert(record);
		MdlCarateristiqueReference relationship = new MdlCarateristiqueReference();
		relationship.setIdCaracteristique(idCaracteristiqueParent);
		relationship.setIdReference(record.getIdReference());
		relationship.setIdModeleVersion(record.getIdModeleVersion());
		carateristiqueReferenceService.insert(relationship);
		// add default attributes to reference
		//		List<AttributEtendu> attributs = attributEtenduService.findByMetierAndType("R", 1); // HARD_CODE for temporary -- tdo comment , after db fix, will change 
		List<AttributEtendu> attributs = attributEtenduService.findByModelVersionAndType("R", record.getIdModeleVersion());
		List<MdlAttributEtenduReference> attributEtenduReferences = new ArrayList<MdlAttributEtenduReference>();
		for( AttributEtendu attr : attributs ) {
			MdlAttributEtenduReference attributEtenduReference = new MdlAttributEtenduReference();
			attributEtenduReference.setIdAttributEtendu(attr.getIdAttributEtendu());
			attributEtenduReference.setIdModeleVersion(record.getIdModeleVersion());
			attributEtenduReference.setIdReference(record.getIdReference());
			attributEtenduReference.setLValeur(attr.getLValeur());
			attributEtenduReferences.add(attributEtenduReference);
		}
		if( attributEtenduReferences.size() > 0 ) {
			attributEtenduReferenceService.insertList(attributEtenduReferences);
		}

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public int countRefernceByModeleVersionAndLibelle(Integer idModeleVersion, String lLibelle, Integer idReference) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("lLibelle", lLibelle);
		mapParameter.put("idReference", idReference);
		return mdlReferenceMapper.countReferenceByModeleVersionAndLibelle(mapParameter);
	}

	@Override
	@Transactional
	public void update(MdlReference reference, List<AttributEtenduMetierERValueModel> listAttributEtendu,
			List<MdlCarateristiqueReference> listElementEntree, List<MdlReferenceElement> listElementSortie) {
		// move to transaction
		update(reference);

		//update attribute of the reference		
		updateAttributeAttendu(reference.getIdModeleVersion(), reference.getIdReference(), listAttributEtendu, false);
		//update carateristique of reference0
		updateCarateristiqueReference(reference.getIdModeleVersion(), reference.getIdReference(), listElementEntree, false);
		//update the element quantite of reference 
		updateReferenceElement(reference.getIdModeleVersion(), reference.getIdReference(), listElementSortie, false);
	}

	@Override
	public void delete(Integer idCaracteristiqueParent, MdlReference record) {
		MdlCarateristiqueReference relation = new MdlCarateristiqueReference();
		relation.setIdCaracteristique(idCaracteristiqueParent);
		relation.setIdReference(record.getIdReference());
		relation.setIdModeleVersion(record.getIdModeleVersion());

		carateristiqueReferenceService.delete(relation);
		mdlReferenceMapper.delete(record);
	}

	@Override
	public List<String[]> importReferencesToSas(Import importData, Integer metierId, List<String[]> csvData,
			int modelVersion, int attributeValueStartIndex, int attributeValueEndIndex, int characteristicStartIndex,
			int characteristicEndIndex, int elementQuantityStartIndex, int elementQuantityEndIndex, ResourceBundleMessageSource messageSource) throws Exception {

		String[] headerColums = csvData.get(0);

		String allRowsError = validateHeaderColumnNames(FIXED_HEADER_COLUMNS, headerColums, messageSource);

		String[] row = null;
		ImportElement data = null;
		String cellValue = null;
		String csvError = null;
		String dbError = null;
		Integer idImport = importData.getIdImport();
		List<String> referenceList = new ArrayList<String>();
		
		for( int i = 1 ; i < csvData.size() ; i++ ) {
			row = csvData.get(i);
			if( ImportUtil.isNullOrEmpty(row) ) {
				continue;
			}

			ImportElement reference = null;
			String referenceStr = null;
			ImportElementError elementError = null;
			csvError = "";
			dbError = "";
			List<String> characteristicList = new ArrayList<String>();

			// Handle Reference
			cellValue = row[1];
			if( cellValue != null ) {
				cellValue = cellValue.trim();
			}
			referenceStr = cellValue;
			data = new ImportElement();
			String elementType = getElementType(headerColums[1]);
			data.setCTypeElementImport(elementType);
			data.setIdImport(idImport);
			data.setLValeur(cellValue);
			data.setNColonne(0); // Do not count first column (Error column)
			data.setNLigne(i);

			elementError = checkMaxLength(1, data, headerColums, messageSource); // Check max-length and truncate if needed

			importElementService.insert(data);
			if( elementError != null ) { // Violate max-length rule
				csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
				elementError.setIdElementImport(data.getIdElementImport());
				importElementErrorService.insert(elementError);
			}

			//Store this ImportElement (reference) for later use (Update value of the Reference)
			reference = data;

			if( !StringUtils.isNullOrEmtpy(referenceStr) ) {
				if( referenceList.contains(cellValue) ) {
					dbError = messageSource.getMessage("import.reference.error.referenceNotUniqueInFile", null, locale);
					csvError = ImportUtil.appendError(csvError, dbError);
					elementError = new ImportElementError();
					elementError.setIdElementImport(data.getIdElementImport());
					elementError.setLLibelleLong(dbError);
					importElementErrorService.insert(elementError);
				}
				else {
					referenceList.add(cellValue);
				}
			}

			// Handle Attribute/Value pair(s)
			csvError = importElementService.saveAttributeValuePairs(
					attributeValueStartIndex, attributeValueEndIndex, headerColums, row, i, metierId, idImport,
					ImportUtil.ATTRIBUTE_VALUE_TYPES[0], ImportUtil.ATTRIBUTE_VALUE_TYPES[1], "R", csvError, null, null, messageSource);

			// Handle Characteristic(s)
			
			boolean characteristicDuplicated = false;
			
			for( int j = characteristicStartIndex ; j <= characteristicEndIndex ; j++ ) {
				cellValue = row[j];
				if( !ImportUtil.isNullOrEmpty(cellValue) ) {
					cellValue = cellValue.trim();
				}
				data = new ImportElement();
				data.setCTypeElementImport(getElementType(headerColums[j]));
				data.setIdImport(idImport);
				data.setLValeur(cellValue);
				data.setNColonne(j - 1); // Do not count first column (Error column)
				data.setNLigne(i);

				elementError = checkMaxLengthCharacteristic(j, data, headerColums, messageSource); // Check max-length and truncate if needed

				importElementService.insert(data);
				if( elementError != null ) { // Violate max-length rule
					csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
					elementError.setIdElementImport(data.getIdElementImport());
					importElementErrorService.insert(elementError);
				}

				if( !ImportUtil.isNullOrEmpty(cellValue) ) {
					
					// Check unique on a row of Characteristic(s)
					if( characteristicList.contains(cellValue.toUpperCase()) ) {
						if( !characteristicDuplicated ) { // print only one error per line for this kind of error.
							characteristicDuplicated = true;
							Object[] params = { cellValue };
							dbError = messageSource.getMessage(
									"import.reference.error.manyCharacteristicsPerLine", params, locale);
							csvError = ImportUtil.appendError(csvError, dbError);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
						}
					}
					else {
						characteristicList.add(cellValue.toUpperCase());
					}
				}

				if( j == characteristicEndIndex ) {
					List<String> characteristics = new ArrayList<String>();
					String currentValue = null;
					for( int j2 = characteristicEndIndex ; j2 >= characteristicStartIndex ; j2-- ) {
						currentValue = row[j2];
						if( !StringUtils.isNullOrEmtpy(currentValue) ) {
							characteristics.add(0, currentValue);
						}
					}

					if( StringUtils.isNullOrEmtpy(referenceStr) ) {
						if( ImportUtil.isNullOrEmpty(characteristics) ) {
							dbError = messageSource.getMessage("import.reference.error.atLeastOneCharacteristicForReference", null, locale);
							csvError = ImportUtil.appendError(csvError, dbError);
							elementError = new ImportElementError();
							elementError.setIdElementImport(reference.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
						}
						else { // Update value of the empty reference
							String referenceLabel = generateReferenceLabel(modelVersion, characteristics);
							reference.setLValeur(referenceLabel);
							importElementService.update(reference);
						}
					}
					else {
						MdlReference criteria11 = new MdlReference();
						criteria11.setIdModeleVersion(modelVersion);
						criteria11.setLLibelleLong(referenceStr);
						List<MdlReference> references = findByBaseCriteria(criteria11);

						if( ImportUtil.isNullOrEmpty(references) ) {
							if( ImportUtil.isNullOrEmpty(characteristics) ) {
								dbError = messageSource.getMessage(
										"import.error.reference.atleastOneCharacteristic", null, locale);
								csvError = ImportUtil.appendError(csvError, dbError);
								elementError = new ImportElementError();
								elementError.setIdElementImport(reference.getIdElementImport());
								elementError.setLLibelleLong(dbError);
								importElementErrorService.insert(elementError);
							}
						}
					}

					if( !ImportUtil.isNullOrEmpty(characteristics) ) {
						for( String characteristicStr : characteristics ) {
							MdlCaracteristique criteria = new MdlCaracteristique();
							criteria.setIdModeleVersion(modelVersion);
							criteria.setLLibelleLong(characteristicStr);
							List<MdlCaracteristique> characList = caracteristiqueService.findByBaseCriteria(criteria);
							if( ImportUtil.isNullOrEmpty(characList) ) {
								Object[] params = {characteristicStr};
								dbError = messageSource.getMessage("import.subReference.error.characteristic.notExist", params, locale);
								csvError = ImportUtil.appendError(csvError, dbError);
							}
						}
					}
				}
			}

			csvError = saveElementQuantityPairs(
					row, headerColums, i, idImport, metierId, csvError, elementQuantityStartIndex, elementQuantityEndIndex,
					null, null, null, messageSource);

			//Append errors to first column
			if( !ImportUtil.isNullOrEmpty(allRowsError) ) {
				csvError = allRowsError + ", " + csvError;
			}
			csvData.get(i)[0] = csvError;
		}

		return csvData;
	}

	private static ImportElementError checkMaxLength(int columnIndex, ImportElement data, String[] headerColums, ResourceBundleMessageSource messageSource) {

		ImportElementError elementError = null;
		String value = data.getLValeur();
		int length = -1;
		String errorStr = null;

		switch( columnIndex ) {
			case 1 :
				length = 500;
				break;
			default :
				break;
		}

		if( length > 0 ) {
			if( !ImportUtil.checkMaxLength(value, length) ) {
				value = StringUtils.truncate(value, length);
				errorStr = buildMaxLengthErrorMessage(headerColums[columnIndex], length, messageSource);
				elementError = new ImportElementError();
				elementError.setLLibelleLong(errorStr);
			}
		}

		data.setLValeur(value);

		return elementError;
	}

	private ImportElementError checkMaxLengthCharacteristic(int columnIndex, ImportElement data, String[] headerColums, ResourceBundleMessageSource messageSource) {

		ImportElementError elementError = null;
		String value = data.getLValeur();
		int length = 50;
		String errorStr = null;

		if( !ImportUtil.checkMaxLength(value, length) ) {
			value = StringUtils.truncate(value, length);
			errorStr = buildMaxLengthErrorMessage(headerColums[columnIndex], length, messageSource);
			elementError = new ImportElementError();
			elementError.setLLibelleLong(errorStr);
		}

		data.setLValeur(value);

		return elementError;
	}

	private String generateReferenceLabel(String rootNodeLabel, List<String> characteristics, Integer modelVersion) {
		String result = "";
		
		List<String> orderedCharacteristics = caracteristiqueService.getCharacteristicNamesOrderByLevelAndRang(modelVersion, characteristics);
		
		for( String characteristic : orderedCharacteristics ) {
			if( result == "" ) {
				result = characteristic;
			}
			else {
				result += " " + characteristic;
			}
		}
		result = rootNodeLabel + " " + result;
		if( result.length() > 500 ) {

			// Get first 500 bytes of String
			result = StringUtils.truncate(result, 500);
		}

		return result;
	}

	private String generateReferenceLabel(Integer modelVersion, List<String> characteristics) {
		String rootNodeLabel = "";
		MdlCaracteristique rootNode = caracteristiqueService.getRootNode(modelVersion);
		if( rootNode != null ) {
			rootNodeLabel = rootNode.getLLibelleLong();
		}
		
		return generateReferenceLabel(rootNodeLabel, characteristics, modelVersion);
	}

	@Override
	@Transactional
	public Integer insertOrUpdate(Integer utilisateurId, MdlReference reference,
			List<AttributEtenduMetierERValueModel> listAttributEtendu, List<MdlCarateristiqueReference> listElementEntree,
			List<MdlReferenceElement> listElementSortie) {
		// move to transaction
		boolean isSousReference  = false;
		modelService.updateModifiedBy(utilisateurId, reference.getIdModeleVersion());
		if( reference.getIdReference() != null ) {
			/*if (reference.getInSousReference() != null && reference.getInSousReference() == true) {
				reference.setInSsrefMajReference(true);
				isSousReference = true;
			}*/
			update(reference);
		}
		else {
			Integer maxRange = mdlReferenceMapper.findMaxRangeOfModel(reference.getIdModeleVersion());
			if( maxRange == null ) {
				maxRange = 0;
			}
			reference.setNRang(maxRange + 1);
			insert(reference);
		}

		//update attribute of the reference		
		updateAttributeAttendu(reference.getIdModeleVersion(), reference.getIdReference(), listAttributEtendu, isSousReference);
		//update carateristique of reference0
		updateCarateristiqueReference(reference.getIdModeleVersion(), reference.getIdReference(), listElementEntree, isSousReference);
		//update the element quantite of reference
		
		updateReferenceElement(reference.getIdModeleVersion(), reference.getIdReference() ,listElementSortie, isSousReference);
		return reference.getIdReference();
	}

	@Override
	public List<MdlReference> findByBaseCriteria(MdlReference criteria) {
		return mdlReferenceMapper.findByBaseCriteria(criteria);
	}

	@Override
	@SuppressWarnings({ "rawtypes" })
	@Transactional
	public void importReferencesToMozarto(Integer importId, Integer metierId, int i, Integer idModeleVersion,
			List<String[]> csvData, int attributeValueStartIndex, int attributeValueEndIndex, int characteristicStartIndex,
			int characteristicEndIndex, int elementQuantityStartIndex, int elementQuantityEndIndex, Integer userId,
			Integer nodeId, ModelisateurRegleMessageService modelisateurRegleMessageService,
			ResourceBundleMessageSource messageSource) throws Exception {
		List<Integer> lines = importElementService.getAllLinesByImportId(importId);

		ImportElementError elementError = null;

		List<Map> allRecords = null;
		for( Integer lineNumber : lines ) {
			String dbError = "";
			allRecords = importElementService.findByImportIdAndLineNumber(importId, lineNumber);

			String referenceName = findValueByType(allRecords, getElementType("reference"));
			Integer referenceIdElementImport = findIdElementImportByType(allRecords, getElementType("reference"));

			List<String> caracteristics = findValueListByType(allRecords, getElementType("caracteristique"));

			MdlReference criteria11 = new MdlReference();
			criteria11.setIdModeleVersion(idModeleVersion);
			criteria11.setLLibelleLong(referenceName);

			List<MdlReference> references = findByBaseCriteria(criteria11);

			MdlReference reference = null;
			int mode = -1;

			if( ImportUtil.isNullOrEmpty(references) ) {
				if( ImportUtil.isNullOrEmpty(caracteristics) ) {
					dbError = messageSource.getMessage("import.error.reference.atleastOneCharacteristic", null, locale);
					ImportUtil.addErrorToRow(csvData, lineNumber, dbError);
					elementError = new ImportElementError();
					elementError.setIdElementImport(referenceIdElementImport);
					elementError.setLLibelleLong(dbError);
					importElementErrorService.insert(elementError);
					throw new RuntimeException();
				}
				else {

					// Insert new Reference
					mode = 0;
					reference = criteria11;
					//reference.setInSousReference(false);
				}
			}
			else {

				// Update Reference
				mode = 1;
				reference = references.get(0);
			}

			List<String> importedAttributeList = new ArrayList<String>();
			List<String> deletedAttributeList = new ArrayList<String>();

			List<String[]> attribyteValueList = findAttributeValueList(
					allRecords, attributeValueStartIndex, attributeValueEndIndex, importedAttributeList,
					deletedAttributeList);

			List<String[]> elementCodeQuantityList = findElementQuantityList(
					allRecords, elementQuantityStartIndex, elementQuantityEndIndex, "CEL");

			List<String[]> supplierCodeQuantityList = findElementQuantityList(
					allRecords, elementQuantityStartIndex, elementQuantityEndIndex, "NFO");

			List<AttributEtenduMetierERValueModel> attributEtenduList = buildAttributEtenduListForInsert(
					attribyteValueList, importedAttributeList, idModeleVersion, metierId);
			List<MdlCarateristiqueReference> carateristiqueReferences = buildCarateristiqueReferences(
					idModeleVersion, caracteristics);

			List<MdlReferenceElement> referenceElements = new ArrayList<MdlReferenceElement>();
			List<MdlReferenceElement> l1 = buildReferenceElementListByElementCode(
					metierId, idModeleVersion, elementCodeQuantityList);
			if( !ImportUtil.isNullOrEmpty(l1) ) {
				referenceElements.addAll(l1);
			}

			List<MdlReferenceElement> l2 = buildReferenceElementListBySipplierCode(
					metierId, idModeleVersion, supplierCodeQuantityList);
			if( !ImportUtil.isNullOrEmpty(l2) ) {
				referenceElements.addAll(l2);
			}

			if( mode == 0 ) {

				// Insert new Reference
				insertAndLink(
						userId, reference, attributEtenduList, carateristiqueReferences, referenceElements,
						modelisateurRegleMessageService, csvData, lineNumber, messageSource);
			}
			else if( mode == 1 ) {

				// Update Reference
				Integer referenceId = reference.getIdReference();

				List<AttributEtenduMetierERValueModel> finalAttributEtenduList = buildAttributeListForUpdate(
						metierId, referenceId, idModeleVersion, attributEtenduList, deletedAttributeList);
				
				List<MdlCarateristiqueReference> finalCarateristiqueReferences = buildCarateristiqueReferenceListForUpdate(carateristiqueReferences, idModeleVersion, referenceId);

				List<MdlReferenceElement> finalReferenceElements = buildReferenceElementListForUpdate(
						referenceId, referenceElements, idModeleVersion);

				// Update Reference with Links
				updateAndLink(
						userId, reference, finalAttributEtenduList, finalCarateristiqueReferences, finalReferenceElements,
						modelisateurRegleMessageService, csvData, lineNumber, messageSource);
			}
		}
		
		//Update modified date, modified by info
		modeleService.updateModifiedBy(userId, idModeleVersion);
	}

	private List<MdlCarateristiqueReference> buildCarateristiqueReferenceListForUpdate(
			List<MdlCarateristiqueReference> carateristiqueReferences, Integer idModeleVersion, Integer referenceId) {

		List<MdlCarateristiqueReference> results = new ArrayList<MdlCarateristiqueReference>();
		results.addAll(carateristiqueReferences);

		// Set this referenceId in order to be able to update mz_mdl_carateristique_reference
		for( MdlCarateristiqueReference mdlCarateristiqueReference : carateristiqueReferences ) {
			mdlCarateristiqueReference.setIdReference(referenceId);
		}

		MdlCarateristiqueReference criteria = new MdlCarateristiqueReference();
		criteria.setIdModeleVersion(idModeleVersion);
		criteria.setIdReference(referenceId);
		List<MdlCarateristiqueReference> currentCarateristiqueReferences = carateristiqueReferenceService.findByBaseCriteria(criteria);
		for( MdlCarateristiqueReference mdlCarateristiqueReference : currentCarateristiqueReferences ) {
			if( !containCarateristiqueReference(carateristiqueReferences, mdlCarateristiqueReference) ) {
				results.add(mdlCarateristiqueReference);
			}
		}
		return results;
	}

	private List<MdlReferenceElement> buildReferenceElementListForUpdate(Integer referenceId,
			List<MdlReferenceElement> referenceElements, Integer idModeleVersion) {

		List<MdlReferenceElement> results = new ArrayList<MdlReferenceElement>();

		//Update referenceIds before merging
		for( MdlReferenceElement mdlReferenceElement : referenceElements ) {
			mdlReferenceElement.setIdReference(referenceId);
		}
		results.addAll(referenceElements);

		List<MdlReferenceElement> currentReferenceElements = referenceElementService.findByModeleVersionAndReference(
				idModeleVersion, referenceId);
		for( MdlReferenceElement mdlReferenceElement : currentReferenceElements ) {
			if( !containReferenceElement(referenceElements, mdlReferenceElement) ) {
				results.add(mdlReferenceElement);
			}
		}

		return results;
	}

	private List<AttributEtenduMetierERValueModel> buildAttributeListForUpdate(Integer metierId, Integer referenceId,
			Integer idModeleVersion, List<AttributEtenduMetierERValueModel> attributEtenduList,
			List<String> deletedAttributeList) {

		List<AttributEtenduMetierERValueModel> results = new ArrayList<AttributEtenduMetierERValueModel>();

		MdlAttributEtenduReference criteria2 = new MdlAttributEtenduReference();
		criteria2.setIdModeleVersion(idModeleVersion);
		criteria2.setIdReference(referenceId);
		List<MdlAttributEtenduReference> attributEtenduReferenceList = attributEtenduReferenceService.findByBaseCriteria(criteria2);

		List<AttributEtendu> deletedAttributEtenduList = null;
		if( !ImportUtil.isNullOrEmpty(deletedAttributeList) ) {
			deletedAttributEtenduList = attributEtenduService.findByMetierAndTypeAndLabelList(
					"R", metierId, deletedAttributeList);
		}
		if( !ImportUtil.isNullOrEmpty(deletedAttributEtenduList) ) {
			removeDeletedAttributes(attributEtenduReferenceList, deletedAttributEtenduList);
		}

		List<AttributEtenduMetierERValueModel> currentAttributEtenduList = buildAttributEtenduMetierERValueModelList(
				attributEtenduReferenceList, referenceId, idModeleVersion);

		for( AttributEtenduMetierERValueModel attributEtenduMetierERValueModel : attributEtenduList ) {

			//Set Reference Id
			attributEtenduMetierERValueModel.setIdER(referenceId);
		}

		results.addAll(attributEtenduList);

		for( AttributEtenduMetierERValueModel attributEtenduMetierERValueModel : currentAttributEtenduList ) {
			if( !containAttributEtendu(attributEtenduList, attributEtenduMetierERValueModel) ) {
				results.add(attributEtenduMetierERValueModel);
			}
		}

		return results;
	}

	private List<MdlReferenceElement> buildReferenceElementListByElementCode(Integer metierId, Integer idModeleVersion,
			List<String[]> elementCodeQuantityList) {

		List<MdlReferenceElement> results = new ArrayList<MdlReferenceElement>();

		List<String> elementCodeList = new ArrayList<String>();
		if( !ImportUtil.isNullOrEmpty(elementCodeQuantityList) ) {
			for( String[] pair : elementCodeQuantityList ) {
				elementCodeList.add(pair[0]);
			}
		}

		List<Element> codeList = null;
		if( !ImportUtil.isNullOrEmpty(elementCodeList) ) {
			Element criteria = new Element();
			criteria.setIdMetier(metierId);
			codeList = elementService.findByBaseCriteriaAndElementCodeList(criteria, elementCodeList);

			if( !ImportUtil.isNullOrEmpty(codeList) ) {
				List<MdlReferenceElement> referenceElement1 = buildElementReferenceList(codeList, idModeleVersion);
				Map<Integer, Integer> quantityMap = new HashMap<Integer, Integer>();
				updateQuantityByElementCode(elementCodeQuantityList, codeList, quantityMap);
				updateQuantityValue(referenceElement1, quantityMap);
				results.addAll(referenceElement1);
			}
		}

		return results;
	}

	private List<MdlReferenceElement> buildReferenceElementListBySipplierCode(Integer metierId, Integer idModeleVersion,
			List<String[]> supplierCodeQuantityList) {

		List<MdlReferenceElement> referenceElements = new ArrayList<MdlReferenceElement>();

		List<String> supplierCodeList = new ArrayList<String>();
		if( !ImportUtil.isNullOrEmpty(supplierCodeQuantityList) ) {
			for( String[] pair : supplierCodeQuantityList ) {
				supplierCodeList.add(pair[0]);
			}
		}

		List<Element> supplierList = null;
		if( !ImportUtil.isNullOrEmpty(supplierCodeList) ) {
			Element criteria = new Element();
			criteria.setIdMetier(metierId);
			supplierList = elementService.findByBaseCriteriaAndSupplierCodeList(criteria, supplierCodeList);

			if( !ImportUtil.isNullOrEmpty(supplierList) ) {
				List<MdlReferenceElement> referenceElement2 = buildElementReferenceList(supplierList, idModeleVersion);
				Map<Integer, Integer> quantityMap = new HashMap<Integer, Integer>();
				updateQuantityBySupplierCode(supplierCodeQuantityList, supplierList, quantityMap);
				updateQuantityValue(referenceElement2, quantityMap);
				referenceElements.addAll(referenceElement2);
			}
		}

		return referenceElements;
	}

	private List<AttributEtenduMetierERValueModel> buildAttributEtenduListForInsert(List<String[]> attribyteValueList,
			List<String> importedAttributeList, Integer idModeleVersion, Integer metierId) {

		List<AttributEtenduMetierERValueModel> attributEtenduList = new ArrayList<AttributEtenduMetierERValueModel>();

		List<AttributEtendu> newAttributEtenduList = null;
		if( !ImportUtil.isNullOrEmpty(importedAttributeList) ) {
			newAttributEtenduList = attributEtenduService.findByMetierAndTypeAndLabelList(
					"R", metierId, importedAttributeList);
		}

		if( !ImportUtil.isNullOrEmpty(newAttributEtenduList) ) {
			updateValuesForAttributEtenduList(attribyteValueList, newAttributEtenduList);
			attributEtenduList = buildListAttributEtendu(newAttributEtenduList, idModeleVersion);
		}
		return attributEtenduList;
	}

	private static boolean containAttributEtendu(List<AttributEtenduMetierERValueModel> list,
			AttributEtenduMetierERValueModel item) {

		if( item == null ) {
			return false;
		}

		Integer referenceId1 = item.getIdER();
		Integer modelVersionId1 = item.getIdModeleVersion();
		Integer attributEtendu1 = item.getIdAttributEtendu();

		for( AttributEtenduMetierERValueModel item2 : list ) {
			Integer referenceId2 = item2.getIdER();
			Integer modelVersionId2 = item2.getIdModeleVersion();
			Integer attributEtendu2 = item2.getIdAttributEtendu();

			boolean equals = modelVersionId1 != null && modelVersionId1.equals(modelVersionId2) && referenceId1 != null && referenceId1.equals(referenceId2) && attributEtendu1 != null && attributEtendu1.equals(attributEtendu2);

			if( equals ) {
				return true;
			}
		}
		return false;
	}

	private static boolean containAttributEtenduReference(List<MdlAttributEtenduReference> list,
			MdlAttributEtenduReference item) {

		if( item == null ) {
			return false;
		}

		Integer referenceId1 = item.getIdReference();
		Integer modelVersionId1 = item.getIdModeleVersion();
		Integer attributEtendu1 = item.getIdAttributEtendu();

		for( MdlAttributEtenduReference item2 : list ) {
			Integer referenceId2 = item2.getIdReference();
			Integer modelVersionId2 = item2.getIdModeleVersion();
			Integer attributEtendu2 = item2.getIdAttributEtendu();

			boolean equals = modelVersionId1 != null && modelVersionId1.equals(modelVersionId2) && referenceId1 != null && referenceId1.equals(referenceId2) && attributEtendu1 != null && attributEtendu1.equals(attributEtendu2);

			if( equals ) {
				return true;
			}
		}
		return false;
	}

	private static boolean containCarateristiqueReference(List<MdlCarateristiqueReference> list,
			MdlCarateristiqueReference item) {

		if( item == null ) {
			return false;
		}

		Integer modelVersionId1 = item.getIdModeleVersion();
		Integer characteristicId1 = item.getIdCaracteristique();

		for( MdlCarateristiqueReference item2 : list ) {
			Integer modelVersionId2 = item2.getIdModeleVersion();
			Integer characteristicId2 = item2.getIdCaracteristique();

			boolean equals = modelVersionId1 != null && modelVersionId1.equals(modelVersionId2) && characteristicId1 != null && characteristicId1.equals(characteristicId2);

			if( equals ) {
				return true;
			}
		}
		return false;
	}

	private static boolean containReferenceElement(List<MdlReferenceElement> list, MdlReferenceElement item) {
		if( item == null ) {
			return false;
		}

		Integer modelVersionId1 = item.getIdModeleVersion();
		Integer elementId1 = item.getIdElement();

		for( MdlReferenceElement item2 : list ) {
			Integer modelVersionId2 = item2.getIdModeleVersion();
			Integer elementId2 = item2.getIdElement();
			boolean equals = modelVersionId1 != null && modelVersionId1.equals(modelVersionId2) && elementId1 != null && elementId1.equals(elementId2);

			if( equals ) {
				return true;
			}
		}

		return false;
	}

	@SuppressWarnings("rawtypes")
	private static String findValueByType(List<Map> allRecords, String type) {
		Map record = null;
		for( int i = 0 ; i < allRecords.size() ; i++ ) {
			record = allRecords.get(i);
			String importElementType = record.get(TYPE_ELEMENT_IMPORT).toString();
			if( type.equalsIgnoreCase(importElementType) ) {
				return record.get("l_valeur").toString();
			}
		}
		return null;
	}

	@SuppressWarnings("rawtypes")
	private static List<String> findValueListByType(List<Map> allRecords, String type) {
		List<String> results = new ArrayList<String>();
		Map record = null;
		for( int i = 0 ; i < allRecords.size() ; i++ ) {
			record = allRecords.get(i);
			String importElementType = record.get(TYPE_ELEMENT_IMPORT).toString();
			if( type.equalsIgnoreCase(importElementType) ) {
				results.add(record.get("l_valeur").toString());
			}
		}
		return results;
	}

	private static String getElementType(String key) {
		String elementType = elementTypeMap.get(key.trim().toLowerCase());
		if(elementType == null) {
			elementType = "CIN";
		}
		
		return elementType;
	}

	@SuppressWarnings("rawtypes")
	private static void removeDeletedAttributes(List<MdlAttributEtenduReference> attributEtenduReferenceList,
			List<AttributEtendu> deletedAttributEtenduList) {

		for( AttributEtendu attributEtendu : deletedAttributEtenduList ) {
			Integer attributeId = attributEtendu.getIdAttributEtendu();

			for( Iterator iterator = attributEtenduReferenceList.iterator() ; iterator.hasNext() ; ) {
				MdlAttributEtenduReference mdlAttributEtenduReference = (MdlAttributEtenduReference) iterator.next();
				if( mdlAttributEtenduReference.getIdAttributEtendu() == attributeId ) {
					iterator.remove();
				}
			}
		}
	}

	private static List<AttributEtenduMetierERValueModel> buildAttributEtenduMetierERValueModelList(
			List<MdlAttributEtenduReference> attributEtenduReferenceList, int referenceId, int modeleVersionId) {

		List<AttributEtenduMetierERValueModel> results = new ArrayList<AttributEtenduMetierERValueModel>();
		for( MdlAttributEtenduReference mdlAttributEtenduReference : attributEtenduReferenceList ) {
			AttributEtenduMetierERValueModel item = new AttributEtenduMetierERValueModel();
			item.setIdAttributEtendu(mdlAttributEtenduReference.getIdAttributEtendu());
			item.setIdER(referenceId);
			item.setIdModeleVersion(modeleVersionId);
			item.setValeur(mdlAttributEtenduReference.getLValeur());
			results.add(item);
		}
		return results;
	}

	private static void updateQuantityValue(List<MdlReferenceElement> referenceElement1, Map<Integer, Integer> quantityMap) {
		for( MdlReferenceElement mdlReferenceElement : referenceElement1 ) {
			short quantity = quantityMap.get(mdlReferenceElement.getIdElement()).shortValue();
			mdlReferenceElement.setNQuantite(quantity);
		}
	}

	private static void updateQuantityBySupplierCode(List<String[]> supplierCodeQuantityList, List<Element> supplierList,
			Map<Integer, Integer> quantityMap) {
		for( Element element : supplierList ) {
			for( String[] elementCodeQuantity : supplierCodeQuantityList ) {
				String supplierCode = elementCodeQuantity[0];
				Integer quantity = Integer.parseInt((elementCodeQuantity[1]));
				if( supplierCode != null && supplierCode.equalsIgnoreCase(element.getLNomenclatureFournisseur()) ) {
					quantityMap.put(element.getIdElement(), quantity);
					continue;
				}
			}
		}
	}

	private static List<MdlReferenceElement> buildElementReferenceList(List<Element> supplierList, int idModeleVersion) {
		List<MdlReferenceElement> results = new ArrayList<MdlReferenceElement>();

		for( Element element : supplierList ) {
			MdlReferenceElement e = new MdlReferenceElement();
			e.setIdModeleVersion(idModeleVersion);
			e.setIdElement(element.getIdElement());
			results.add(e);
		}

		return results;
	}

	private static void updateQuantityByElementCode(List<String[]> elementCodeQuantityList, List<Element> codeList,
			Map<Integer, Integer> quantityMap) {
		for( Element element : codeList ) {
			for( String[] elementCodeQuantity : elementCodeQuantityList ) {
				String elementCode = elementCodeQuantity[0];
				String quantityStr = elementCodeQuantity[1];
				Integer quantity = Integer.parseInt((quantityStr));
				if( elementCode != null && elementCode.equalsIgnoreCase(element.getCElement()) ) {
					quantityMap.put(element.getIdElement(), quantity);
					continue;
				}
			}
		}
	}

	private static void updateValuesForAttributEtenduList(List<String[]> attribyteValueList,
			List<AttributEtendu> newAttributEtenduList) {
		for( AttributEtendu attributEtendu : newAttributEtenduList ) {
			for( String[] attributValuePair : attribyteValueList ) {
				String attribute = attributValuePair[0];
				String value = attributValuePair[1];
				if( attribute != null && attribute.equalsIgnoreCase(attributEtendu.getLLibelle()) ) {
					attributEtendu.setLValeur(value);
					continue;
				}
			}
		}
	}

	private List<MdlCarateristiqueReference> buildCarateristiqueReferences(int idModeleVersion, List<String> caracteristics) {

		List<MdlCaracteristique> caracteristiqueList = caracteristiqueService.findByModelVersionAndLabelList(
				idModeleVersion, caracteristics);

		List<MdlCarateristiqueReference> result = new ArrayList<MdlCarateristiqueReference>();

		for( MdlCaracteristique mdlCaracteristique : caracteristiqueList ) {
			MdlCarateristiqueReference e = new MdlCarateristiqueReference();
			e.setIdCaracteristique(mdlCaracteristique.getIdCaracteristique());
			e.setIdModeleVersion(idModeleVersion);
			result.add(e);
		}
		return result;
	}

	private static List<AttributEtenduMetierERValueModel> buildListAttributEtendu(
			List<AttributEtendu> newAttributEtenduList, int idModeleVersion) {
		List<AttributEtenduMetierERValueModel> results = new ArrayList<AttributEtenduMetierERValueModel>();
		AttributEtenduMetierERValueModel e = null;

		for( AttributEtendu attributEtendu : newAttributEtenduList ) {
			e = new AttributEtenduMetierERValueModel();
			e.setIdAttributEtendu(attributEtendu.getIdAttributEtendu());
			e.setIdModeleVersion(idModeleVersion);
			e.setValeur(attributEtendu.getLValeur());
			e.setAttributEtenduLibelle(attributEtendu.getLLibelle());
			results.add(e);
		}
		return results;
	}

	@SuppressWarnings("rawtypes")
	private static Integer findIdElementImportByType(List<Map> allRecords, String type) {
		Map record = null;
		for( int i = 0 ; i < allRecords.size() ; i++ ) {
			record = allRecords.get(i);
			String importElementType = record.get(TYPE_ELEMENT_IMPORT).toString();
			if( type.equalsIgnoreCase(importElementType) ) {
				return Integer.parseInt(record.get("id_element_import").toString());
			}
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes" })
	private static List<String[]> findAttributeValueList(List<Map> allRecords, int startIndex, int endIndex,
			List<String> importedList, List<String> deletedList) {

		List<String[]> results = new ArrayList<String[]>();
		String[] attributeValuePair = null;
		for( int i = startIndex ; i < endIndex ; i += 2 ) {
			String attribute = getValue(allRecords, i);

			if( !StringUtils.isNullOrEmtpy(attribute) ) {
				String value = getValue(allRecords, i + 1);
				attributeValuePair = new String[2];
				attributeValuePair[0] = attribute;
				attributeValuePair[1] = value;
				results.add(attributeValuePair);

				if( StringUtils.isNullOrEmtpy(value) ) {
					deletedList.add(attribute);
				}
				else {
					importedList.add(attribute);
				}
			}
		}
		return results;
	}

	@SuppressWarnings({ "rawtypes" })
	private static List<String[]> findElementQuantityList(List<Map> allRecords, int startIndex, int endIndex, String type) {

		List<String[]> results = new ArrayList<String[]>();
		String[] attributeValuePair = null;
		for( int i = startIndex ; i < endIndex ; i += 2 ) {
			String attribute = findValueByTypeAndColumnIndex(allRecords, i, type);
			if( !StringUtils.isNullOrEmtpy(attribute) ) {
				String value = getValue(allRecords, i + 1);
				attributeValuePair = new String[2];
				attributeValuePair[0] = attribute;
				attributeValuePair[1] = value;
				results.add(attributeValuePair);
			}
		}
		return results;
	}

	@SuppressWarnings("rawtypes")
	private static String findValueByTypeAndColumnIndex(List<Map> allRecords, Integer columnIndex, String type) {
		Map record = null;
		for( int j = 0 ; j < allRecords.size() ; j++ ) {
			record = allRecords.get(j);
			int column = Integer.parseInt(record.get("n_colonne").toString());
			if( column == columnIndex ) {
				String importElementType = record.get(TYPE_ELEMENT_IMPORT).toString();
				if( type.equalsIgnoreCase(importElementType) ) {
					return record.get("l_valeur").toString();
				}
			}
		}
		return "";
	}

	@SuppressWarnings("rawtypes")
	private static String getValue(List<Map> allRecords, int columnIndex) {
		Map record = null;
		for( int j = 0 ; j < allRecords.size() ; j++ ) {
			record = allRecords.get(j);
			int column = Integer.parseInt(record.get("n_colonne").toString());
			if( column == columnIndex ) {
				return record.get("l_valeur").toString();
			}
		}
		return "";
	}

	@Override
	@Transactional
	public Integer insertAndLink(Integer utilisateurId, MdlReference reference,
			List<AttributEtenduMetierERValueModel> listAttributEtendu, List<MdlCarateristiqueReference> listElementEntree,
			List<MdlReferenceElement> listElementSortie, ModelisateurRegleMessageService modelisateurRegleMessageService,
			List<String[]> csvData, Integer lineNumber, ResourceBundleMessageSource messageSource) {

		modelService.updateModifiedBy(utilisateurId, reference.getIdModeleVersion());
		Integer maxRange = mdlReferenceMapper.findMaxRangeOfModel(reference.getIdModeleVersion());
		if( maxRange == null ) {
			maxRange = 0;
		}
		reference.setNRang(maxRange + 1);
		insert(reference);

		Integer idReference = reference.getIdReference();

		//update attribute of the reference
		updateAttributeAttendu(reference.getIdModeleVersion(), idReference, listAttributEtendu, false);
		//update carateristique of reference0
		updateCarateristiqueReference(reference.getIdModeleVersion(), idReference, listElementEntree, false);
		//update the element quantite of reference 
		insertReferenceElement(listElementSortie, idReference, reference.getIdModeleVersion());

		boolean satisfy = checkRules(
				modelisateurRegleMessageService, reference, listElementEntree, listElementSortie, csvData, lineNumber, messageSource);
		if( !satisfy ) {
			throw new RuntimeException();
		}

		return idReference;
	}

	private boolean checkRules(ModelisateurRegleMessageService modelisateurRegleMessageService, MdlReference reference,
			List<MdlCarateristiqueReference> listElementEntree, List<MdlReferenceElement> listElementSortie,List<String[]> csvData, Integer lineNumber, ResourceBundleMessageSource messageSource) {

		String dbError = "";

		TreeNodeModel parentNode = new TreeNodeModel();
		parentNode.setIdModeleVersion(reference.getIdModeleVersion());
		parentNode.setId(reference.getIdReference());
		parentNode.setModelType(ModelNodeType.REFERENCE);

		for( MdlReferenceElement mdlReferenceElement : listElementSortie ) {
			boolean satisfy = modelisateurRegleMessageService.checkSatisfyRules(
					parentNode, mdlReferenceElement.getIdElement());
			if( !satisfy ) {
				Element element = elementService.findById(mdlReferenceElement.getIdElement());
				Object[] params = {reference.getLLibelleLong(), element.getCElement(), element.getCElement()};
				dbError = messageSource.getMessage("import.reference.error.cannotLinkReferenceAndElement", params, locale);
				if( lineNumber == null ) {					
					ImportElement criteria = new ImportElement();
					criteria.setLValeur(reference.getLLibelleLong());
					criteria.setCTypeElementImport("CEL");
					List<ImportElement> list = importElementService.findByBaseCriteria(criteria );
					if(!ImportUtil.isNullOrEmpty(list)) {
						ImportElement importElement = list.get(0);
						lineNumber = importElement.getNLigne();
					}
				}
				if( lineNumber != null && lineNumber > 0 ) {
					ImportUtil.addErrorToRow(csvData, lineNumber, dbError);
				}
				return false;
			}
		}

		for( MdlCarateristiqueReference mdlCarateristiqueReference : listElementEntree ) {
			parentNode = new TreeNodeModel();
			parentNode.setIdModeleVersion(reference.getIdModeleVersion());
			parentNode.setId(mdlCarateristiqueReference.getIdCaracteristique());
			parentNode.setModelType(ModelNodeType.CARACTERISTIQUE);

			boolean satisfy = modelisateurRegleMessageService.checkSatisfyRules(parentNode, reference.getIdReference());
			if( !satisfy ) {
				MdlCaracteristique chara = caracteristiqueService.findById(mdlCarateristiqueReference.getIdCaracteristique());
				Object[] params = {reference.getLLibelleLong(), chara.getLLibelleLong(), "elementDeCompsition_Code"};
				dbError = messageSource.getMessage("import.reference.error.cannotLinkReferenceAndCharacteristic", params, locale);
				if( lineNumber == null ) {					
					ImportElement criteria = new ImportElement();
					criteria.setLValeur(chara.getLLibelleLong());
					criteria.setCTypeElementImport("CAR");
					List<ImportElement> list = importElementService.findByBaseCriteria(criteria );
					if(!ImportUtil.isNullOrEmpty(list)) {
						ImportElement importElement = list.get(0);
						lineNumber = importElement.getNLigne();
					}
				}
				if( lineNumber != null && lineNumber > 0 ) {
					ImportUtil.addErrorToRow(csvData, lineNumber, dbError);
				}
				return false;
			}
		}

		return true;
	}

	@Transactional
	private void insertReferenceElement(List<MdlReferenceElement> listElementSortie, Integer idReference, int modeleVersion) {

		referenceElementService.deleteByReferenceIdAndModelVersionId(idReference, modeleVersion);

		if( listElementSortie != null ) {
			for( MdlReferenceElement mdlReferenceElement : listElementSortie ) {
				mdlReferenceElement.setIdReference(idReference);
				referenceElementService.insert(mdlReferenceElement);
			}
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<ValuePlaceHolder> findParentNumberByidReferencesNotInIdCarateristiques(Integer idModelVersion,
			List<Integer> idReferences) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModelVersion);
		mapParameter.put("idReferences", idReferences);
		return mdlReferenceMapper.findParentNumberByIdReferencesNotInIdCarateristiques(mapParameter);
	}

	@Override
	@Transactional
	public Integer updateAndLink(Integer utilisateurId, MdlReference reference,
			List<AttributEtenduMetierERValueModel> listAttributEtendu, List<MdlCarateristiqueReference> listElementEntree,
			List<MdlReferenceElement> listElementSortie, ModelisateurRegleMessageService modelisateurRegleMessageService,
			List<String[]> csvData, Integer lineNumber, ResourceBundleMessageSource messageSource) {
		// move to transaction
		modelService.updateModifiedBy(utilisateurId, reference.getIdModeleVersion());
		Integer idReference = reference.getIdReference();
		if( idReference != null ) {
			update(reference);
		}
		else {
			Integer maxRange = mdlReferenceMapper.findMaxRangeOfModel(reference.getIdModeleVersion());
			if( maxRange == null ) {
				maxRange = 0;
			}
			reference.setNRang(maxRange + 1);
			insert(reference);
		}

		//update attribute of the reference		
		updateAttributeAttendu(reference.getIdModeleVersion(), idReference, listAttributEtendu, false);
		//update carateristique of reference0
		updateCarateristiqueReference(reference.getIdModeleVersion(), idReference, listElementEntree, false);
		//update the element quantite of reference 
		for( MdlReferenceElement mdlReferenceElement : listElementSortie ) {
			mdlReferenceElement.setIdReference(idReference);
		}
		//		updateReferenceElement(listElementSortie);
		insertReferenceElement(listElementSortie, idReference, reference.getIdModeleVersion());

		boolean satisfy = checkRules(
				modelisateurRegleMessageService, reference, listElementEntree, listElementSortie, csvData, lineNumber, messageSource);
		if( !satisfy ) {
			throw new RuntimeException();
		}

		return idReference;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteSousModele(Integer idModeleVersion, List<Integer> idReferences) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReferences", idReferences);
		mdlReferenceMapper.updateUnlinkSousModeleByIdReference(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void deleteById(List<Integer> idReferences) {
		Map mapParameter = new HashMap();
		mapParameter.put("idReferences", idReferences);
		mdlReferenceMapper.deleteByIds(mapParameter);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Integer coundSousModeleByIdReference(Integer idModelVersion, Integer idReference) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModelVersion);
		mapParameter.put("idReference", idReference);
		return mdlReferenceMapper.coundSousModeleByIdReference(mapParameter);
	}

	@Override
	public List<AttributEtenduMetierERValueModel> getListAttributEtenduByModelVersion(Integer idModeleVersion) {
		return mdlReferenceMapper.getListAttributEtenduByModelVersion(idModeleVersion);
	}

	@Override
	@Transactional
	public List<String[]> importSubReferencesToSas(Import importData, Integer metierId, List<String[]> csvData,
			int modelVersion, int attributeValueStartIndex, int attributeValueEndIndex, int characteristicStartIndex,
			int characteristicEndIndex, int elementQuantityStartIndex, int elementQuantityEndIndex,
			ResourceBundleMessageSource messageSource) throws Exception {

		String[] headerColums = csvData.get(0);
		
		String allRowsError = validateHeaderColumnNames(FIXED_HEADER_COLUMNS_2, headerColums, messageSource);

		String[] row = null;
		ImportElement data = null;
		String cellValue = null;
		String csvError = null;
		String dbError = null;
		Integer idImport = importData.getIdImport();
		
		Map<String, List<String>> subModelAttributeMap = new HashMap<String, List<String>>();
		Map<String, List<String>> subModelElementCodeMap = new HashMap<String, List<String>>();
		Map<String, List<String>> subModelSupplierCodeMap = new HashMap<String, List<String>>();

		for( int i = 1 ; i < csvData.size() ; i++ ) {
			String subModel = null;
			row = csvData.get(i);
			if( ImportUtil.isNullOrEmpty(row) ) {
				continue;
			}

			ImportElementError elementError = null;
			csvError = "";
			dbError = "";
			List<String> characteristicList = new ArrayList<String>();

			// Sub Model
			cellValue = row[1];
			if( cellValue != null ) {
				cellValue = cellValue.trim();
			}
			
			subModel = cellValue;
			if(!subModelAttributeMap.containsKey(subModel.toUpperCase())) {
				subModelAttributeMap.put(subModel.toUpperCase(), new ArrayList<String>());
			}
			if(!subModelElementCodeMap.containsKey(subModel.toUpperCase())) {
				subModelElementCodeMap.put(subModel.toUpperCase(), new ArrayList<String>());
			}
			if(!subModelSupplierCodeMap.containsKey(subModel.toUpperCase())) {
				subModelSupplierCodeMap.put(subModel.toUpperCase(), new ArrayList<String>());
			}

			data = new ImportElement();
			data.setCTypeElementImport(getElementType(headerColums[1]));
			data.setIdImport(idImport);
			data.setLValeur(cellValue);
			data.setNColonne(0); // Do not count first column (Error column)
			data.setNLigne(i);

			elementError = checkMaxLength(1, data, headerColums, messageSource); // Check max-length and truncate if needed

			importElementService.insert(data);
			if( elementError != null ) { // Violate max-length rule
				csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
				elementError.setIdElementImport(data.getIdElementImport());
				importElementErrorService.insert(elementError);
			}

			//Check required column(s)
			if( StringUtils.isNullOrEmtpy(cellValue) ) {
				dbError = buildRequiredErrorMessage(headerColums[1], messageSource);
				csvError = ImportUtil.appendError(csvError, dbError);

				elementError = new ImportElementError();
				elementError.setIdElementImport(data.getIdElementImport());
				elementError.setLLibelleLong(dbError);
				importElementErrorService.insert(elementError);
			}

			// Handle Attribute/Value pair(s)
			csvError = importElementService.saveAttributeValuePairs(
					attributeValueStartIndex, attributeValueEndIndex, headerColums, row, i, metierId, idImport,
					ImportUtil.ATTRIBUTE_VALUE_TYPES[0], ImportUtil.ATTRIBUTE_VALUE_TYPES[1], "R", csvError, subModel, subModelAttributeMap, messageSource);

			// Handle Characteristic(s)			
			boolean characteristicDuplicated = false;
			
			for( int j = characteristicStartIndex ; j <= characteristicEndIndex ; j++ ) {
				cellValue = row[j];
				if( !ImportUtil.isNullOrEmpty(cellValue) ) {
					cellValue = cellValue.trim();
				}
				data = new ImportElement();
				data.setCTypeElementImport(getElementType(headerColums[j]));
				data.setIdImport(idImport);
				data.setLValeur(cellValue);
				data.setNColonne(j - 1); // Do not count first column (Error column)
				data.setNLigne(i);

				elementError = checkMaxLengthCharacteristic(j, data, headerColums, messageSource); // Check max-length and truncate if needed

				importElementService.insert(data);
				if( elementError != null ) { // Violate max-length rule
					csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
					elementError.setIdElementImport(data.getIdElementImport());
					importElementErrorService.insert(elementError);
				}

				if( !ImportUtil.isNullOrEmpty(cellValue) ) {

					// Check unique on a row of Characteristic(s)
					if( characteristicList.contains(cellValue.toUpperCase()) ) {
						if( !characteristicDuplicated ) { // print only one error per line for this kind of error.
							characteristicDuplicated = true;
							dbError = messageSource.getMessage(
									"import.reference.error.manyCharacteristicsPerLine", null, locale);
							csvError = ImportUtil.appendError(csvError, dbError);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
						}
					}
					else {
						characteristicList.add(cellValue.toUpperCase());
					}
				}

				if( j == characteristicEndIndex ) {
					List<String> characteristics = new ArrayList<String>();
					String currentValue = null;
					for( int j2 = characteristicEndIndex ; j2 >= characteristicStartIndex ; j2-- ) {
						currentValue = row[j2];
						if( !StringUtils.isNullOrEmtpy(currentValue) ) {
							characteristics.add(0, currentValue);
						}
					}

					if( ImportUtil.isNullOrEmpty(characteristics) ) {
						dbError = messageSource.getMessage("import.error.reference.atleastOneCharacteristic", null, locale);
						csvError = ImportUtil.appendError(csvError, dbError);
						elementError = new ImportElementError();
						elementError.setIdElementImport(data.getIdElementImport());
						elementError.setLLibelleLong(dbError);
						importElementErrorService.insert(elementError);
					}
					else {
						for( String characteristicStr : characteristics ) {
							MdlCaracteristique criteria = new MdlCaracteristique();
							criteria.setLLibelleLong(characteristicStr);
							criteria.setIdModeleVersion(modelVersion);
							List<MdlCaracteristique> characList = caracteristiqueService.findByBaseCriteria(criteria);
							if( ImportUtil.isNullOrEmpty(characList) ) {
								Object[] params = {characteristicStr};
								dbError = messageSource.getMessage("import.subReference.error.characteristic.notExist", params, locale);
								csvError = ImportUtil.appendError(csvError, dbError);
							}
						}
					}
				}
			}

			csvError = saveElementQuantityPairs(
					row, headerColums, i, idImport, metierId, csvError, elementQuantityStartIndex, elementQuantityEndIndex,
					subModel, subModelElementCodeMap, subModelSupplierCodeMap, messageSource);

			//Append errors to first column
			if( !ImportUtil.isNullOrEmpty(allRowsError) ) {
				csvError = allRowsError + ", " + csvError;
			}
			csvData.get(i)[0] = csvError;
		}

		return csvData;
	}

	private String saveElementQuantityPairs(String[] row, String[] headerColums, int lineNumber, int idImport, int metierId,
			String csvError, int elementQuantityStartIndex, int elementQuantityEndIndex, String currentSubModel,
			Map<String, List<String>> subModelElementCodeMap, Map<String, List<String>> subModelSupplierCodeMap, ResourceBundleMessageSource messageSource) {

		if( elementQuantityStartIndex <= 0 || elementQuantityEndIndex <= 0 || elementQuantityEndIndex <= elementQuantityStartIndex ) {
			return csvError;
		}
		
		// Element(Supplier)/Quantity pair(s)
		List<String> elementCodeList = new ArrayList<String>();
		List<String> supplierCodeList = new ArrayList<String>();
		
		boolean elementDuplicated = false;

		for( int j = elementQuantityStartIndex ; j < elementQuantityEndIndex ; j = j + 2 ) {

			String code = row[j]; // Element/Supplier code
			String quantityStr = row[j + 1]; //Quantity

			ImportElement data = null;
			String dbError = "";
			ImportElementError elementError = null;

			if( ImportUtil.isNullOrEmpty(code) ) {
				if( ImportUtil.isNullOrEmpty(quantityStr) ) {
					continue;
				}
				else {

					//Save Element/Supplier code
					data = new ImportElement();
					data.setCTypeElementImport(getElementType(headerColums[j]));
					data.setIdImport(idImport);
					data.setLValeur(code);
					data.setNColonne(j - 1); // Do not count first column (Error column)
					data.setNLigne(lineNumber);
					importElementService.insert(data);

					// Insert error for Element/Supplier code
					dbError = messageSource.getMessage("import.reference.error.elementCodeIsRequiredForQuantity", null, locale);
					csvError = ImportUtil.appendError(csvError, dbError);
					elementError = new ImportElementError();
					elementError.setIdElementImport(data.getIdElementImport());
					elementError.setLLibelleLong(dbError);
					importElementErrorService.insert(elementError);

					// Save Quantity
					data = new ImportElement();
					data.setCTypeElementImport(getElementType(headerColums[j + 1]));
					data.setIdImport(idImport);
					data.setLValeur(StringUtils.truncate(quantityStr, 30));
					data.setNColonne(j); // Do not count first column (Error column)
					data.setNLigne(lineNumber);
					importElementService.insert(data);

					// Check if Quantity is a number, > 0
					String quantityError = null;
					try {
						int quantity = Integer.parseInt(quantityStr);
						if( quantity <= 0 ) {
							Object[] params = {code};
							quantityError = messageSource.getMessage("import.reference.error.quantityMustGreaterThan0", params, locale);
						}

					}
					catch( NumberFormatException e ) {
						Object[] params = {code};
						quantityError = messageSource.getMessage("import.reference.error.quantityMustGreaterThan0", params, locale);
					}
					finally {
						if( !ImportUtil.isNullOrEmpty(quantityError) ) {
							csvError = ImportUtil.appendError(csvError, quantityError);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(quantityError);
							importElementErrorService.insert(elementError);
						}
					}
				}
			}
			else {

				//Save Code
				data = new ImportElement();
				data.setCTypeElementImport(getElementType(headerColums[j]));
				data.setIdImport(idImport);
				data.setLValeur(code);
				data.setNColonne(j - 1); // Do not count first column (Error column)
				data.setNLigne(lineNumber);

				// Check max-length of Element/Supplier code
				elementError = checkMaxLengthCharacteristic(j, data, headerColums, messageSource); // Check max-length and truncate if needed

				importElementService.insert(data);
				if( elementError != null ) { // Violate max-length rule
					csvError = ImportUtil.appendError(csvError, elementError.getLLibelleLong());
					elementError.setIdElementImport(data.getIdElementImport());
					importElementErrorService.insert(elementError);
				}

				String header = headerColums[j];
				if( "pegaz_element".equalsIgnoreCase(header) ) {

					// Check unique on a row of ElementCode/SupplierCode
					if( elementCodeList.contains(code) ) {
						if( !elementDuplicated ) { // print only one error per line for this kind of error.
							elementDuplicated = true;
							Object[] params = { code };
							dbError = messageSource.getMessage("import.reference.error.manyElementsInLine", params, locale);
							csvError = ImportUtil.appendError(csvError, dbError);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
						}
					}
					else {
						elementCodeList.add(code);
					}

					//Check (by elementCode) if this Element existed in DB
					Element criteria = new Element();
					criteria.setIdMetier(metierId);
					criteria.setCElement(code);
					List<Element> elements = elementService.findByBaseCriteria(criteria);
					if( ImportUtil.isNullOrEmpty(elements) ) {
						dbError = "L’élément de composition " + code + " n’existe pas dans le modèle";
						csvError = ImportUtil.appendError(csvError, dbError);
						elementError = new ImportElementError();
						elementError.setIdElementImport(data.getIdElementImport());
						elementError.setLLibelleLong(dbError);
						importElementErrorService.insert(elementError);
					}

					if(currentSubModel != null && subModelElementCodeMap != null) { // Only check this rule in case of importing reference by sub-reference
						if(isInAnotherSubModel(code, currentSubModel, subModelElementCodeMap)) {
							Object[] params = {code};
							dbError = messageSource.getMessage("import.reference.error.elementExistsInDifferentModels", params, locale);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
							csvError = ImportUtil.appendError(csvError, dbError);
						}
					}
				}
				else if( "fournisseur_element".equalsIgnoreCase(header) ) {
					if( supplierCodeList.contains(code) ) {
						if( !elementDuplicated ) { // print only one error per line for this kind of error.
							elementDuplicated = true;
							Object[] params = { code };
							dbError = messageSource.getMessage("import.reference.error.manyElementsInLine", params, locale);
							csvError = ImportUtil.appendError(csvError, dbError);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
						}
					}
					else {
						supplierCodeList.add(code);
					}

					// Check (by supplierCode) if this Element existed in DB
					Element criteria = new Element();
					criteria.setIdMetier(metierId);
					criteria.setLNomenclatureFournisseur(code);
					List<Element> elements = elementService.findByBaseCriteria(criteria);
					if( ImportUtil.isNullOrEmpty(elements) ) {
						Object[] params = {code};
						dbError = messageSource.getMessage("import.reference.error.elementNotExistsInModel", params, locale);
						csvError = ImportUtil.appendError(csvError, dbError);
						elementError = new ImportElementError();
						elementError.setIdElementImport(data.getIdElementImport());
						elementError.setLLibelleLong(dbError);
						importElementErrorService.insert(elementError);
					}

					if(currentSubModel != null && subModelSupplierCodeMap != null) { // Only check this rule in case of importing reference by sub-reference
						if( isInAnotherSubModel(code, currentSubModel, subModelSupplierCodeMap) ) {
							Object[] params = {code};
							dbError = messageSource.getMessage("import.reference.error.elementExistsInDifferentModels", params, locale);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(dbError);
							importElementErrorService.insert(elementError);
							csvError = ImportUtil.appendError(csvError, dbError);
						}
					}
				}

				//Save Quantity
				data = new ImportElement();
				data.setCTypeElementImport(getElementType(headerColums[j + 1]));
				data.setIdImport(idImport);
				data.setLValeur(StringUtils.truncate(quantityStr, 30));
				data.setNColonne(j); // Do not count first column (Error column)
				data.setNLigne(lineNumber);
				importElementService.insert(data);

				if( ImportUtil.isNullOrEmpty(quantityStr) ) {

					// Insert error for Quantity
					dbError = messageSource.getMessage("import.reference.error.amountIsRequired", null, locale);
					csvError = ImportUtil.appendError(csvError, dbError);
					elementError = new ImportElementError();
					elementError.setIdElementImport(data.getIdElementImport());
					elementError.setLLibelleLong(dbError);
					importElementErrorService.insert(elementError);
				}
				else {
					// Check if Quantity is a number, > 0
					String quantityError = null;
					try {
						int quantity = Integer.parseInt(quantityStr);
						if( quantity <= 0 ) {
							Object[] params = {code};
							quantityError = messageSource.getMessage("import.reference.error.quantityMustGreaterThan0", params, locale);
						}

					}
					catch( NumberFormatException e ) {
						Object[] params = {code};
						quantityError = messageSource.getMessage("import.reference.error.quantityMustGreaterThan0", params, locale);
					}
					finally {
						if( !ImportUtil.isNullOrEmpty(quantityError) ) {
							csvError = ImportUtil.appendError(csvError, quantityError);
							elementError = new ImportElementError();
							elementError.setIdElementImport(data.getIdElementImport());
							elementError.setLLibelleLong(quantityError);
							importElementErrorService.insert(elementError);
						}
					}
				}
			}
		}

		return csvError;
	}

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public void importSubReferencesToMozarto(Integer importId, Integer metierId, int i, Integer idModeleVersion,
			List<String[]> csvData, int attributeValueStartIndex, int attributeValueEndIndex, int characteristicStartIndex,
			int characteristicEndIndex, int elementQuantityStartIndex, int elementQuantityEndIndex, Integer userId,
			Integer nodeId, ModelisateurRegleMessageService modelisateurRegleMessageService, ResourceBundleMessageSource messageSource) throws Exception {
		List<Integer> lines = importElementService.getAllLinesByImportId(importId);

		Map<String, List<List>> subModelMap = new HashMap<String, List<List>>();

		List<Map> allRecords = null;
		for( Integer lineNumber : lines ) {
			allRecords = importElementService.findByImportIdAndLineNumber(importId, lineNumber);

			String subModel = findValueByType(allRecords, getElementType("sousmodele"));
			Integer subModelIdElementImport = findIdElementImportByType(allRecords, getElementType("sousmodele"));

			List<String> importedAttributeList = new ArrayList<String>();
			List<String> deletedAttributeList = new ArrayList<String>();

			List<String[]> attribyteValueList = findAttributeValueList(
					allRecords, attributeValueStartIndex, attributeValueEndIndex, importedAttributeList,
					deletedAttributeList);

			List<String> caracteristics = findValueListByType(allRecords, getElementType("caracteristique"));

			List<String[]> elementCodeQuantityList = findElementQuantityList(
					allRecords, elementQuantityStartIndex, elementQuantityEndIndex, "CEL");
			List<String> elementCodeList = new ArrayList<String>();
			if( !ImportUtil.isNullOrEmpty(elementCodeQuantityList) ) {
				for( String[] pair : elementCodeQuantityList ) {
					elementCodeList.add(pair[0]);
				}
			}

			List<String[]> supplierCodeQuantityList = findElementQuantityList(
					allRecords, elementQuantityStartIndex, elementQuantityEndIndex, "NFO");
			List<String> supplierCodeList = new ArrayList<String>();
			if( !ImportUtil.isNullOrEmpty(supplierCodeQuantityList) ) {
				for( String[] pair : supplierCodeQuantityList ) {
					supplierCodeList.add(pair[0]);
				}
			}

			List values = null;
			if( subModelMap.get(subModel) == null ) {
				values = new ArrayList();
				subModelMap.put(subModel, values);
			}

			values = subModelMap.get(subModel);

			List l = new ArrayList();
			
			l.add(lineNumber);					// 	0
			l.add(subModelIdElementImport);		// 	1
			l.add(attribyteValueList);			//	2
			l.add(importedAttributeList);		//	3
			l.add(deletedAttributeList);		//	4
			l.add(caracteristics);				//	5
			l.add(elementCodeQuantityList);		//	6
			l.add(supplierCodeQuantityList);	//	7
			
			values.add(l);						
		}

		saveSubModelsAndSubRefrences(subModelMap, idModeleVersion, metierId, userId, csvData, modelisateurRegleMessageService, messageSource);
		createReferenceFromSubReferences(idModeleVersion, userId, csvData, modelisateurRegleMessageService, messageSource);
		
		//Update modified date, modified by info
		modeleService.updateModifiedBy(userId, idModeleVersion);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void createReferenceFromSubReferences(Integer idModeleVersion, Integer userId, List<String[]> csvData,
			ModelisateurRegleMessageService modelisateurRegleMessageService, ResourceBundleMessageSource messageSource) {

		// Auto-generated ReferenceIds (not modified on web)
		List<Integer> referenceIds = findAutoGeneratedReferenceIds(idModeleVersion, null);
		deleteAutoGeneratedReferences(modelisateurRegleMessageService, referenceIds, idModeleVersion);

		List<SousReferenceModel> subReferenceList2 = findAllSousReferenceByIdModeleVersion(idModeleVersion);

		Map<Integer, List<List>> subModelMap2 = new HashMap<Integer, List<List>>();
		if( !ImportUtil.isNullOrEmpty(subReferenceList2) ) {
			for( SousReferenceModel sousReferenceModel : subReferenceList2 ) {
				Integer key = sousReferenceModel.getIdSousModele();
				List<List> listValue = null;
				if( !subModelMap2.containsKey(key) ) {
					listValue = new ArrayList<List>();
					subModelMap2.put(key, listValue);
				}

				Integer idReference = sousReferenceModel.getIdReference();
				MdlAttributEtenduReference criteria = new MdlAttributEtenduReference();
				criteria.setIdReference(idReference);
				criteria.setIdModeleVersion(sousReferenceModel.getIdModeleVersion());

				List<MdlAttributEtenduReference> l1 = attributEtenduReferenceService.findByBaseCriteria(criteria);
				List<MdlCarateristiqueReference> l2 = carateristiqueReferenceService.findByModeleVersionAndReference(
						idModeleVersion, idReference);
				List<MdlReferenceElement> l3 = referenceElementService.findByModeleVersionAndReference(
						idModeleVersion, idReference);

				listValue = subModelMap2.get(key);
				List l = new ArrayList();
				l.add(l1);
				l.add(l2);
				l.add(l3);
				l.add(idReference);
				listValue.add(l);
			}
		}

		List<List<List>> subReferenceList = new ArrayList<List<List>>();
		Set<Integer> keys = subModelMap2.keySet();
		for( Iterator iterator = keys.iterator() ; iterator.hasNext() ; ) {
			Integer key = (Integer) iterator.next();
			List subReferenceInfo = subModelMap2.get(key);
			subReferenceList.add(subReferenceInfo);
		}

		Queue<List<List>> references = combineSubReferenceIntoReference(subReferenceList);

		List<List> dataList = new ArrayList<List>();

		for( Iterator iterator = references.iterator() ; iterator.hasNext() ; ) {
			List<List> list = (List<List>) iterator.next();
			List<MdlAttributEtenduReference> attributEtenduReferenceList = new ArrayList<MdlAttributEtenduReference>();
			List<MdlCarateristiqueReference> carateristiqueReferenceList = new ArrayList<MdlCarateristiqueReference>();
			List<MdlReferenceElement> referenceElementList = new ArrayList<MdlReferenceElement>();
			List<Integer> subReferenceIdList = new ArrayList<Integer>();

			for( Iterator iterator2 = list.iterator() ; iterator2.hasNext() ; ) {
				List subReference = (List) iterator2.next();
				List<MdlAttributEtenduReference> subList1 = (List<MdlAttributEtenduReference>) subReference.get(0);
				for( MdlAttributEtenduReference mdlAttributEtenduReference : subList1 ) {
					if( !containAttributEtenduReference(attributEtenduReferenceList, mdlAttributEtenduReference) ) {
						attributEtenduReferenceList.add(mdlAttributEtenduReference);
					}
				}

				List<MdlCarateristiqueReference> subList2 = (List<MdlCarateristiqueReference>) subReference.get(1);
				for( MdlCarateristiqueReference mdlCarateristiqueReference : subList2 ) {
					if( !containCarateristiqueReference(carateristiqueReferenceList, mdlCarateristiqueReference) ) {
						carateristiqueReferenceList.add(mdlCarateristiqueReference);
					}
				}

				List<MdlReferenceElement> subList3 = (List<MdlReferenceElement>) subReference.get(2);
				for( MdlReferenceElement mdlReferenceElement : subList3 ) {
					if( !containReferenceElement(referenceElementList, mdlReferenceElement) ) {
						referenceElementList.add(mdlReferenceElement);
					}
				}

				Integer subReferenceId = (Integer) subReference.get(3);
				if( !subReferenceIdList.contains(subReferenceId) ) {
					subReferenceIdList.add(subReferenceId);
				}
			}

			// Delete Common Elements Links first, and generate later
			deleteCommonItemsRelationsOfModifiedReferences(
					idModeleVersion, attributEtenduReferenceList, carateristiqueReferenceList, referenceElementList);

			List l2 = new ArrayList();

			l2.add(attributEtenduReferenceList);
			l2.add(carateristiqueReferenceList);
			l2.add(referenceElementList);
			l2.add(subReferenceIdList);

			dataList.add(l2);
		}

		saveOrUpdateReferences(userId, idModeleVersion, modelisateurRegleMessageService, csvData, dataList, messageSource);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void saveOrUpdateReferences(Integer userId, Integer idModeleVersion,
			ModelisateurRegleMessageService modelisateurRegleMessageService, List<String[]> csvData, List<List> dataList, ResourceBundleMessageSource messageSource) {

		for( List list : dataList ) {
			List<MdlAttributEtenduReference> attributEtenduReferenceList = (List<MdlAttributEtenduReference>) list.get(0);
			List<MdlCarateristiqueReference> carateristiqueReferences = (List<MdlCarateristiqueReference>) list.get(1);
			List<MdlReferenceElement> referenceElements = (List<MdlReferenceElement>) list.get(2);
			List<Integer> subReferenceIdList = (List<Integer>) list.get(3);

			MdlReference reference = null;
			List<String> characteristics = extractCharacteristicNames(carateristiqueReferences);
			String referenceName = generateReferenceLabel(idModeleVersion, characteristics);
			MdlReference criteria11 = new MdlReference();
			criteria11.setIdModeleVersion(idModeleVersion);
			criteria11.setLLibelleLong(referenceName);
			List<MdlReference> rList = findByBaseCriteria(criteria11);

			List<AttributEtenduMetierERValueModel> attributEtenduList = new ArrayList<AttributEtenduMetierERValueModel>();
			for( MdlAttributEtenduReference mdlAttributEtenduReference : attributEtenduReferenceList ) {
				AttributEtenduMetierERValueModel item = new AttributEtenduMetierERValueModel();
				item.setIdAttributEtendu(mdlAttributEtenduReference.getIdAttributEtendu());
				item.setIdModeleVersion(idModeleVersion);
				item.setValeur(mdlAttributEtenduReference.getLValeur());
				attributEtenduList.add(item);
			}

			Integer referenceId = null;

			if( ImportUtil.isNullOrEmpty(rList) ) {
				reference = criteria11;
				//reference.setInSousReference(true);
				insertAndLink(
						userId, reference, attributEtenduList, carateristiqueReferences, referenceElements,
						modelisateurRegleMessageService, csvData, null, messageSource);
				referenceId = reference.getIdReference();
			}
			else {
				reference = rList.get(0);
				referenceId = reference.getIdReference();
				updateAndLink(
						userId, reference, attributEtenduList, carateristiqueReferences, referenceElements,
						modelisateurRegleMessageService, csvData, null, messageSource);
			}

			saveSubReferenceReferenceRelations(referenceId, idModeleVersion, subReferenceIdList);
		}
	}
	
	private List<String> extractCharacteristicNames(List<MdlCarateristiqueReference> carateristiqueReferences) {
		List<String> results = new ArrayList<String>();
		
		for( MdlCarateristiqueReference mdlCarateristiqueReference : carateristiqueReferences ) {
			results.add(mdlCarateristiqueReference.getCaracteristiqueLibelle());
		}
		return results;
	}

	private static List<Integer> extractElementIds(List<MdlReferenceElement> list) {
		List<Integer> results = new ArrayList<Integer>();
		if( !ImportUtil.isNullOrEmpty(list) ) {
			for( MdlReferenceElement item : list ) {
				results.add(item.getIdElement());
			}
		}

		return results;
	}

	private static List<Integer> extractAttributeIds(List<MdlAttributEtenduReference> attributEtenduReferenceList) {
		List<Integer> results = new ArrayList<Integer>();
		if( !ImportUtil.isNullOrEmpty(attributEtenduReferenceList) ) {
			for( MdlAttributEtenduReference item : attributEtenduReferenceList ) {
				results.add(item.getIdAttributEtendu());
			}
		}

		return results;
	}

	private static List<Integer> extractCharacteristicIds(List<MdlCarateristiqueReference> carateristiqueReferenceList) {
		List<Integer> results = new ArrayList<Integer>();
		if( !ImportUtil.isNullOrEmpty(carateristiqueReferenceList) ) {
			for( MdlCarateristiqueReference item : carateristiqueReferenceList ) {
				results.add(item.getIdCaracteristique());
			}
		}

		return results;
	}

	private void deleteCommonItemsRelationsOfModifiedReferences(Integer idModeleVersion,
			List<MdlAttributEtenduReference> attributEtenduReferenceList,
			List<MdlCarateristiqueReference> carateristiqueReferenceList, List<MdlReferenceElement> referenceElementList) {

		List<Integer> modifiedReferenceIds = findAutoGeneratedReferenceIds(idModeleVersion, true);

		List<Integer> attributeIdList = extractAttributeIds(attributEtenduReferenceList);
		if( !ImportUtil.isNullOrEmpty(attributeIdList) && !ImportUtil.isNullOrEmpty(modifiedReferenceIds) ) {
			attributEtenduReferenceService.deleteByReferenceIdsAndAttributeIds(
					idModeleVersion, modifiedReferenceIds, attributeIdList);
		}

		List<Integer> characteristicIdList = extractCharacteristicIds(carateristiqueReferenceList);
		if( !ImportUtil.isNullOrEmpty(characteristicIdList) && !ImportUtil.isNullOrEmpty(modifiedReferenceIds) ) {
			carateristiqueReferenceService.deleteByReferenceIdsAndCharacteristicIds(
					idModeleVersion, modifiedReferenceIds, characteristicIdList);
		}

		List<Integer> referenceElementIdList = extractElementIds(referenceElementList);
		if( !ImportUtil.isNullOrEmpty(referenceElementIdList) && !ImportUtil.isNullOrEmpty(modifiedReferenceIds) ) {
			referenceElementService.deleteByReferenceIdsAndElementIds(
					idModeleVersion, modifiedReferenceIds, referenceElementIdList);
		}
	}

	private static void deleteAutoGeneratedReferences(ModelisateurRegleMessageService modelisateurRegleMessageService,
			List<Integer> referenceIds, Integer idModeleVersion) {
		
		for( Integer referenceId : referenceIds ) {
			TreeNodeModel sourceNode = new TreeNodeModel();
			sourceNode.setId(referenceId);
			sourceNode.setIdModeleVersion(idModeleVersion);
			sourceNode.setModelType(ModelNodeType.REFERENCE);
			modelisateurRegleMessageService.deleteModelisateurNode(sourceNode , true, true, true);			
		}
	}

	private void saveSubReferenceReferenceRelations(Integer referenceId, Integer idModeleVersion,
			List<Integer> subReferenceIdList) {
		
		sousReferenceReferenceService.deleteByReferenceIds(Arrays.asList(referenceId));
		
		for( Integer idSousreference : subReferenceIdList ) {
			SousReferenceReference record = new SousReferenceReference();
			record.setIdModeleVersion(idModeleVersion);
			record.setIdReference(referenceId);
			record.setIdSousreference(idSousreference);
			sousReferenceReferenceService.insert(record);
		}
	}

	@SuppressWarnings("rawtypes")
	Queue<List<List>> combineSubReferenceIntoReference(List<List<List>> source) {

		Queue<List<List>> queue = new LinkedList<List<List>>();

		if( source == null || source.size() == 0 ) {
			return queue;
		}

		//Initialize the queue with the first list of elements
		List<List> firstLine = source.get(0);
		for( int i = 0 ; i < firstLine.size() ; i++ ) {
			queue.add(new ArrayList<List>(Arrays.asList(firstLine.get(i))));
		}

		for( int i = 1 ; i < source.size() ; i++ ) {
			List<List> nextList = source.get(i);
			int currentQueueSize = queue.size();
			int k = 0;

			while( k < currentQueueSize ) {
				List<List> com = queue.poll();

				for( int j = 0 ; j < nextList.size() ; j++ ) {
					List<List> newCom = new ArrayList<List>(com);
					newCom.add(nextList.get(j));
					queue.add(newCom);
				}
				k++;
			}
		}
		return queue;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void saveSubModelsAndSubRefrences(Map<String, List<List>> subModelMap, Integer idModeleVersion,
			Integer metierId, Integer userId, List<String[]> csvData,
			ModelisateurRegleMessageService modelisateurRegleMessageService, ResourceBundleMessageSource messageSource) {
		Set<String> keys = subModelMap.keySet();
		for( Iterator iterator = keys.iterator() ; iterator.hasNext() ; ) {
			String subModelLabel = (String) iterator.next();

			MdlReferenceSousModele subModel = null;
			MdlReferenceSousModele criteria = new MdlReferenceSousModele();
			criteria.setIdModeleVersion(idModeleVersion);
			criteria.setLLibelleLong(subModelLabel);
			List<MdlReferenceSousModele> list1 = referenceSousModeleService.findByBaseCriteria(criteria);
			if( ImportUtil.isNullOrEmpty(list1) ) {
				subModel = criteria;
				referenceSousModeleService.insert(subModel);
			}
			else {
				subModel = list1.get(0);
			}
			
			Integer subModelId = subModel.getIdSousModele();

			List<List> subReferences = subModelMap.get(subModelLabel);
			for( List list : subReferences ) {
				MdlReference subReference = null;
				int lineNumber = Integer.parseInt(list.get(0).toString());
				List<String[]> attribyteValueList = (List<String[]>) list.get(2);
				List<String> importedAttributeList = (List<String>) list.get(3);
				List caracteristics = (List<String>) list.get(5);
				List<String[]> elementCodeQuantityList = (List<String[]>) list.get(6);
				List<String[]> supplierCodeQuantityList = (List<String[]>) list.get(7);

				String subReferenceLabel = generateReferenceLabel(subModelLabel, caracteristics, idModeleVersion);

				List<MdlCarateristiqueReference> carateristiqueReferences = buildCarateristiqueReferences(
						idModeleVersion, caracteristics);

				List<AttributEtenduMetierERValueModel> attributEtenduList = buildAttributEtenduListForInsert(
						attribyteValueList, importedAttributeList, idModeleVersion, metierId);

				List<MdlReferenceElement> referenceElements = new ArrayList<MdlReferenceElement>();

				List<MdlReferenceElement> l1 = buildReferenceElementListByElementCode(
						metierId, idModeleVersion, elementCodeQuantityList);
				if( !ImportUtil.isNullOrEmpty(l1) ) {
					referenceElements.addAll(l1);
				}

				List<MdlReferenceElement> l2 = buildReferenceElementListBySipplierCode(
						metierId, idModeleVersion, supplierCodeQuantityList);
				if( !ImportUtil.isNullOrEmpty(l2) ) {
					referenceElements.addAll(l2);
				}

				List<MdlReference> list2 = findByModeleVersionAndLibelle(idModeleVersion, null, subReferenceLabel);

				if( ImportUtil.isNullOrEmpty(list2) ) { // Insert new Sub-Reference
					
					String dbError = checkAttributeExistsInOtherSubModel(attributEtenduList, idModeleVersion, subModelId, messageSource);
					if(!ImportUtil.isNullOrEmpty(dbError)) {
						ImportUtil.addErrorToRow(csvData, lineNumber, dbError);
						throw new RuntimeException();
					}
					
					subReference = new MdlReference();
					subReference.setIdModeleVersion(idModeleVersion);
					subReference.setIdSousModele(subModel.getIdSousModele());
					//subReference.setInSousReference(false);
					subReference.setLLibelleLong(subReferenceLabel);

					insertAndLink(
							userId, subReference, attributEtenduList, carateristiqueReferences, referenceElements,
							modelisateurRegleMessageService, csvData, lineNumber, messageSource);
				}
				else { // Update Sub-Reference					
					subReference = list2.get(0);
					Integer referenceId = subReference.getIdReference();
					List<String> deletedAttributeList = (List<String>) list.get(4);

					List<AttributEtenduMetierERValueModel> finalAttributEtenduList = buildAttributeListForUpdate(
							metierId, referenceId, idModeleVersion, attributEtenduList, deletedAttributeList);
					
					String dbError = checkAttributeExistsInOtherSubModel(finalAttributEtenduList, idModeleVersion, subModelId, messageSource);
					if(!ImportUtil.isNullOrEmpty(dbError)) {
						ImportUtil.addErrorToRow(csvData, lineNumber, dbError);
						return;
					}

					List<MdlCarateristiqueReference> finalCarateristiqueReferences = buildCarateristiqueReferenceListForUpdate(
							carateristiqueReferences, idModeleVersion, referenceId);

					List<MdlReferenceElement> finalReferenceElements = buildReferenceElementListForUpdate(
							referenceId, referenceElements, idModeleVersion);

					updateAndLink(
							userId, subReference, finalAttributEtenduList, finalCarateristiqueReferences,
							finalReferenceElements, modelisateurRegleMessageService, csvData, lineNumber, messageSource);
				}

				// Add Sub-ReferenceId to end of the list for later use
				list.add(subReference.getIdReference());
			}
		}
	}

	private String checkAttributeExistsInOtherSubModel(List<AttributEtenduMetierERValueModel> attributEtenduList,
			Integer idModeleVersion, Integer subModelId, ResourceBundleMessageSource messageSource) {
		List<String> attributeLabels = extractAttributeLabels(attributEtenduList);
		for( String label : attributeLabels ) {
			List<AttributEtenduMetierERValueModel> l = getListAttributeOfOtherSubModel(
					idModeleVersion, subModelId, Arrays.asList(label));
			if( !ImportUtil.isNullOrEmpty(l) ) {
				AttributEtenduMetierERValueModel item = l.get(0);
				Object[] params = {item.getAttributEtenduLibelle(), item.getAttributEtenduLibelle()};
				String dbError = messageSource.getMessage("import.subReference.error.attributeIsUsedInOtherSubModel", params, locale);
				return dbError;
			}
		}
		return null;
	}

	private static List<String> extractAttributeLabels(List<AttributEtenduMetierERValueModel> attributEtenduList) {
		
		List<String> results = new ArrayList<String>();
		
		for( AttributEtenduMetierERValueModel attributEtenduMetierERValueModel : attributEtenduList ) {
			results.add(attributEtenduMetierERValueModel.getAttributEtenduLibelle());
		}
		
		return results;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<MdlReference> findByIdLienCommuns(Integer idModeleVersion, List<Integer> idLienCommuns) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommuns", idLienCommuns);
		return mdlReferenceMapper.findByIdLienCommuns(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<MdlReference> findReferencesByModeleVersionAndCaracteristiqueList(Integer idModeleVersion,
			List<Integer> idCaracteristiques) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("caracteristiqueList", idCaracteristiques);
		return mdlReferenceMapper.findByModeleVersionAndCaracteristiqueList(mapParameter);
	}

	public static String buildRequiredErrorMessage(String fieldName, ResourceBundleMessageSource messageSource) {
		Object[] params = { fieldName };
		return messageSource.getMessage("import.error.common.required", params, locale);
	}

	public static String buildMaxLengthErrorMessage(String fieldName, int length, ResourceBundleMessageSource messageSource) {
		Object[] params = { fieldName, length };
		return messageSource.getMessage("import.error.common.maxLength", params, locale);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<MdlReference> findAllReferenceByIdModeleVersionLimit(Integer limitNumber, Integer idModeleVersion) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("number", limitNumber);
		return mdlReferenceMapper.findAllReferenceByIdModeleVersionWithLimit(mapParameter);
	}

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<MdlReference> findByIds(Integer idModeleVersion, List<Integer> idReferences) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReferences", idReferences);
		return mdlReferenceMapper.findByIds(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Integer> findAutoGeneratedReferenceIds(Integer idModeleVersion, Boolean modifiedOnWeb) {
		Map params = new HashMap();
		params.put("idModeleVersion", idModeleVersion);
		params.put("modifiedOnWeb", modifiedOnWeb);
		return mdlReferenceMapper.findAutoGeneratedReferenceIds(params);
	}

	@Override
	public Integer countReferenceByIdModeleVersion(Integer idModeleVersion) {
		return mdlReferenceMapper.countReferenceByIdModeleVersion(idModeleVersion);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<AttributEtenduMetierERValueModel> getListAttributeOfOtherSubModel(Integer idModeleVersion,
			Integer idSousModele, List<String> labelList) {
		Map params = new HashMap();
		params.put("idModeleVersion", idModeleVersion);
		params.put("idSousModele", idSousModele);
		params.put("labelList", labelList);
		return mdlReferenceMapper.getListAttributeOfOtherSubModel(params);
	}

	@SuppressWarnings({ "rawtypes" })
	private static boolean isInAnotherSubModel(String code, String currentSubModel, Map<String, List<String>> subModelMap) {

		List<String> values = subModelMap.get(currentSubModel.toUpperCase());

		if( !values.contains(code.toUpperCase()) ) {
			values.add(code.toUpperCase());
		}

		Set keySet = subModelMap.keySet();
		for( Object key : keySet ) {
			values = subModelMap.get(key);
			if( values.contains(code.toUpperCase()) ) {
				if( !currentSubModel.equalsIgnoreCase(key.toString().toUpperCase()) ) {
					return true;
				}
			}
		}

		return false;
	}
	
	@Override
	public List<MdlReference> getSelectedReferencesByCompositionId(Integer compositionId) {
		return mdlReferenceMapper.getSelectedReferencesByCompositionId(compositionId);
	}

	private static String validateHeaderColumnNames(List<String> fixedHeaderColumns, String[] csvHeaderColums,
			ResourceBundleMessageSource messageSource) {
		String error = "";
		for( int i = 1 ; i < csvHeaderColums.length ; i++ ) {
			String headerColumn = csvHeaderColums[i];
			if( !fixedHeaderColumns.contains(headerColumn.toUpperCase()) ) {
				Object[] params = { headerColumn };
				if( error == "" ) {
					error = "\"" + messageSource.getMessage("import.error.headerColumn.invalid", params, locale) + "\"";
				}
				else {
					error += ", \"" + messageSource.getMessage("import.error.headerColumn.invalid", params, locale) + "\"";
				}
			}
		}

		return error;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> findLibelleInList(List<String> list, Integer idModeleVersion) {
		Map map = new HashMap();
		map.put("list", list);
		map.put("idModeleVersion", idModeleVersion);
		return mdlReferenceMapper.findLibelleInList(map);
	}
}
