package com.structis.client.panel.admin;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.structis.client.constant.ConstantClient.ScreenSize;
import com.structis.client.ecran.EcranLoadable;
import com.structis.client.event.GestionElementCompositionCloseTabEvent;
import com.structis.client.event.GestionElementCompositionCloseTabHandler;
import com.structis.client.event.GestionElementCompositionEvent;
import com.structis.client.event.GestionElementCompositionHandler;
import com.structis.client.event.ModifyEvent;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.service.ClientElementServiceAsync;
import com.structis.client.widget.CustomizeBorderlayoutContainer;
import com.structis.client.widget.DynamicTabPanel;
import com.structis.shared.model.Element;

/**
 * administrator screen Gestion Des Element De Composition
 * 
 * @author vinh.tong
 */
public class GestionDesElementDeCompositionContainer extends SimpleContainer implements EcranLoadable {

	private DynamicTabPanel centerPanel;

	private SimpleEventBus bus = new SimpleEventBus();

	private final Messages messages = GWT.create(Messages.class);

	private GestionDesElementDeCompositionLeftPanel west;

	private static int tabNum = -1;

	private NavigationService navigation = NavigationFactory.getNavigation();
	
	public GestionDesElementDeCompositionContainer() {

	}

	/**
	 * 
	 */
	@Override
	protected void onAfterFirstAttach() {
		super.onAfterFirstAttach();
		CustomizeBorderlayoutContainer container = new CustomizeBorderlayoutContainer();
		west = new GestionDesElementDeCompositionLeftPanel(bus);

		BorderLayoutData westData = new BorderLayoutData(ScreenSize.MINLEFT);
		westData.setCollapsible(true);
		westData.setSplit(true);
		westData.setCollapseMini(true);
		westData.setMargins(new Margins(0, 5, 0, 0));
		westData.setMinSize(ScreenSize.MINLEFT);
		
		ContentPanel leftPanel = new ContentPanel();
		leftPanel.setHeaderVisible(false);
		leftPanel.setBorders(false);
		leftPanel.setBodyBorder(false);
		leftPanel.add(west);
		container.setWestWidget(leftPanel, westData);
		centerPanel = new DynamicTabPanel(bus);

		MarginData centerData = new MarginData();

		container.setCenterWidget(centerPanel, centerData);
		container.setLeftTitle(messages.commonPanneauAction());

		add(container);
		bus.addHandler(GestionElementCompositionEvent.getType(), new GestionElementCompositionHandler() {

			@Override
			public void onLoad(GestionElementCompositionEvent gestionElementCompositionEvent) {
				final Integer idElement = gestionElementCompositionEvent.getIdElement();
				if( idElement != null ) {
					ClientElementServiceAsync.Util.getInstance().findById(
							gestionElementCompositionEvent.getIdElement(), new AsyncCallback<Element>() {

								@Override
								public void onSuccess(Element arg0) {
									GestionDesElementDeCompositionForm form = (GestionDesElementDeCompositionForm) centerPanel.getTabPanel().findItem(
											getTabId(arg0), false);
									if( form != null ) {
										centerPanel.getTabPanel().setActiveWidget(form);
									}
									else {
										form = new GestionDesElementDeCompositionForm(idElement, bus, arg0.getCElement());
										form.onLoad();
										form.setId(getTabId(arg0));
										centerPanel.addItem(form, arg0.getCElement());
									}

								}

								@Override
								public void onFailure(Throwable arg0) {

								}
							});
				}
				else {
					GestionDesElementDeCompositionForm form = new GestionDesElementDeCompositionForm(null, bus, "");
					form.onLoad();
					form.setId(getTabId(null));
					centerPanel.addItem(form, messages.gestionelemcompoRightNouvelElem());
					navigation.getBus().fireEvent(new ModifyEvent(false));
				}
			}
		});
		bus.addHandler(GestionElementCompositionCloseTabEvent.getType(), new GestionElementCompositionCloseTabHandler() {
			
			@Override
			public void onLoad(GestionElementCompositionCloseTabEvent gestionElementCompositionCloseTabEvent) {
				TabPanel tabPanel = centerPanel.getTabPanel();
				tabPanel.remove(tabPanel.getActiveWidget());
				
			}
		});

	}

	@Override
	public void onLoadApplication(NavigationEvent event) {
//		if (centerPanel.getNumberTabs() == 0)
//			west.getEdcGrid().setReLoad(true);
	}

	public DynamicTabPanel getTabPanel() {
		return centerPanel;
	}

	private String getTabId(Element item) {
		if( item != null )
			return "tab-" + item.getCElement() + "-" + item.getIdElement();
		else {
			tabNum++;
			return "tab-" + tabNum;
		}
	}
}
