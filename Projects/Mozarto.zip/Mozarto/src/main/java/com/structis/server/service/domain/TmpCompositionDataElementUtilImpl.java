package com.structis.server.service.domain;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.structis.shared.model.Element;
import com.structis.shared.model.reference.CompositionElementGridModel;

@Service
public class TmpCompositionDataElementUtilImpl implements TmpCompositionDataElementUtil {

	private static String CDRELEMENT = "CompositionDeReference";

	private static String ESELEMENT = "ElementSupplementaire";

	/*public static class Utitl {
		private static HttpSession session;

		public static HttpSession getSession() {
			if( session == null ) {
				ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
				session = attr.getRequest().getSession();
			}
			return session;
		}
	}*/

	private TmpCompositionDataElementUtilImpl() {
		
	}
	
	private HttpSession getSession(){
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		return session;
	}
	public void addUpdateCdrElements(List<CompositionElementGridModel> elements) {
		if( elements != null && elements.size() > 0 ) {
			List<CompositionElementGridModel> currentElements = getCdrElementData();
			if( currentElements == null ) {
				currentElements = new ArrayList<CompositionElementGridModel>();
			}
			for( CompositionElementGridModel element : elements ) {
				Integer currentItem = getIfExists(element,currentElements);
				if(currentItem == null){
					currentElements.add(element);
				}else{
					currentElements.get(currentItem).setStatus(element.getStatus());
					currentElements.get(currentItem).setQuantite(element.getQuantite());
				}
			}
			getSession().setAttribute(CDRELEMENT, currentElements);
		}
	}
	
	private Integer getIfExists(CompositionElementGridModel element,List<CompositionElementGridModel> currentElements){
		int i = 0;
		for(CompositionElementGridModel item:currentElements){
			if( element.getIdReference().intValue() == item.getIdReference().intValue() && element.getIdElement().intValue() == item.getIdElement().intValue() ) {
				return i;
			}
			i++;
		}
		return null;
	}
	
	public void changeReferenceQuantie(Integer idReference, Integer quantite, boolean isOverwrite) {
		List<CompositionElementGridModel> currentElements = getCdrElementData();
		if( currentElements != null ) {
			for( CompositionElementGridModel item : currentElements ) {
				if( item.getIdReference().intValue() == idReference.intValue() ) {
					if( isOverwrite ) {
						item.setQuantite(item.getDefaultQuantite() * quantite);
					}
					else {
						if( !((item.getStatus() > 0) && (item.getQuantite() != item.getDefaultQuantite() && item.getIsChanged() != null && item.getIsChanged())) ) {
							item.setQuantite(item.getDefaultQuantite() * quantite);
						}
					}
				}
			}
		}
		getSession().setAttribute(CDRELEMENT, currentElements);
	}

	public void unSelectRerence(List<Integer> idReferences) {
		List<CompositionElementGridModel> currentElements = getCdrElementData();

		if( currentElements != null ) {
			List<CompositionElementGridModel> listToRemove = new ArrayList<CompositionElementGridModel>();
			for( CompositionElementGridModel item : currentElements ) {
				if( idReferences.contains(item.getIdReference()) ) {
					listToRemove.add(item);
				}
			}
			if( listToRemove.size() > 0 ) {
				//for( Integer key : listToRemove ) {
					currentElements.removeAll(listToRemove);
				//}
			}
			getSession().setAttribute(CDRELEMENT, currentElements);
		}
	}

	@SuppressWarnings("unchecked")
	public List<CompositionElementGridModel> getCdrElementData() {
		List<CompositionElementGridModel> currentElements = (List<CompositionElementGridModel>) getSession().getAttribute(
				CDRELEMENT);
		return currentElements;
	}

	public void addUpdateEsElements(List<Element> elements) {
		if( elements != null && elements.size() > 0 ) {
			LinkedHashMap<Integer, Element> currentElements = getEsElementData();
			if( currentElements == null ) {
				currentElements = new LinkedHashMap<Integer, Element>();
			}
			for( Element element : elements ) {
				currentElements.put(element.getIdElement(), element);
			}
			getSession().setAttribute(ESELEMENT, currentElements);
		}
	}
	
	public void removeEsElment(List<Element> elements){
		if( elements != null && elements.size() > 0 ) {
			LinkedHashMap<Integer, Element> currentElements = getEsElementData();
			if( currentElements != null ) {
				for( Element element : elements ) {
					currentElements.remove(element.getIdElement());
				}
			}
			
			getSession().setAttribute(ESELEMENT, currentElements);
		}
	}
	
	@SuppressWarnings("unchecked")
	public LinkedHashMap<Integer, Element> getEsElementData() {
		LinkedHashMap<Integer, Element> currentElements = (LinkedHashMap<Integer, Element>) getSession().getAttribute(
				ESELEMENT);
		return currentElements;
	}
	
	public void resetData() {
		try{
			if( getSession().getAttribute(CDRELEMENT) != null ) {
				getSession().removeAttribute(CDRELEMENT);
			}
			if( getSession().getAttribute(ESELEMENT) != null ) {
				getSession().removeAttribute(ESELEMENT);
			}
		}catch(Exception e){
			
		}
	}

}
