package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class MaskEvent extends GwtEvent<MaskHandler> {

	private static Type<MaskHandler> TYPE = new Type<MaskHandler>();
	private boolean isMask;
	private String tabId;
	

	public static Type<MaskHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<MaskHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(MaskHandler handler) {
		handler.onLoad(this);
	}
		

	public MaskEvent(boolean isSetMask, String tabId) {
		super();		
		this.isMask = isSetMask;
		this.tabId = tabId;
	}

	public boolean isMask() {
		return isMask;
	}

	public void setMask(boolean isMask) {
		this.isMask = isMask;
	}

	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}	

	

}
