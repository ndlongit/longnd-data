package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.UtilisateurMetierRoleModel;

public interface UtilisateurMetierRoleModelProperties extends PropertyAccess<UtilisateurMetierRoleModel> {
	
	ModelKeyProvider<UtilisateurMetierRoleModel> idMetier();

	ValueProvider<UtilisateurMetierRoleModel, String> libelleMetier();

	ValueProvider<UtilisateurMetierRoleModel, String> libelleRole();

	ValueProvider<UtilisateurMetierRoleModel, String> cRole();

	ValueProvider<UtilisateurMetierRoleModel, Boolean> inDefaut();
}
