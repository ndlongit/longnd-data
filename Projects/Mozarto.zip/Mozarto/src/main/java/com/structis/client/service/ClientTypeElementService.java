package com.structis.client.service;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.structis.shared.model.TypeElement;

@RemoteServiceRelativePath("springGwtServices/clientTypeElementService")
public interface ClientTypeElementService extends RemoteService {
	public List<TypeElement> findAll ();
}
