package com.structis.client.panel.admin;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutData;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer.HBoxLayoutAlign;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.structis.client.event.DisableElementPossibleEvent;
import com.structis.client.event.DisableElementPossibleHandler;
import com.structis.client.event.ElementCompositionGridEvent;
import com.structis.client.event.ElementCompositionGridHandler;
import com.structis.client.event.GestionElementCompositionDisableElementEvent;
import com.structis.client.event.GestionElementCompositionEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.service.ClientElementServiceAsync;
import com.structis.client.util.NameValuePair;
import com.structis.client.util.ReportUtil;
import com.structis.client.widget.ElementCompositionGrid;
import com.structis.client.widget.FileImportDialog;
import com.structis.client.widget.HtmlButton;
import com.structis.server.constant.ConstantServer;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.Element;
import com.structis.shared.model.Metier;

public class GestionDesElementDeCompositionLeftPanel extends VerticalLayoutContainer {
	private SimpleEventBus bus;

	private Images images = GWT.create(Images.class);

	private final Messages messages = GWT.create(Messages.class);

	private NavigationService navigation = NavigationFactory.getNavigation();

	private HTML metierLabel;

	private HtmlButton addBtn;

	private HtmlButton modifBtn;

	private HtmlButton delBtn;

	private ElementCompositionGrid edcGrid;

	private Integer idMetier = navigation.getContext().getMetier().getIdMetier();

	private HTML importLink;

	private HTML exportLink;
	
	private String libelleMetier;

	private Metier metier;

	private FieldSet fieldSet;

	private VerticalLayoutContainer container;

	public GestionDesElementDeCompositionLeftPanel(SimpleEventBus pbus) {
		metier = navigation.getContext().getMetier();
		this.setIdMetier(metier.getIdMetier());
		this.bus = pbus;
		setStyleName("whiteBackGround");
		
		metierLabel = new HTML();
		libelleMetier = metier.getLLibelle();
		metierLabel.setHTML(messages.commonMetier() + ": " + libelleMetier);

		fieldSet = new FieldSet();
		fieldSet.setHeadingText(messages.gestionelemcompoLeftElemcompo());
		fieldSet.getElement().getStyle().setPadding(2, Unit.PX);
		container = new VerticalLayoutContainer();
		fieldSet.add(container);
		HBoxLayoutContainer buttonPanel = new HBoxLayoutContainer();
		buttonPanel.setPadding(new Padding(1));
		buttonPanel.setHBoxLayoutAlign(HBoxLayoutAlign.TOP);
		addBtn = new HtmlButton(messages.gestionelemcompoLeftNouveaubouton(), images.add());
		modifBtn = new HtmlButton(messages.gestionelemcompoLeftModifierbouton(), images.edit());
		delBtn = new HtmlButton(messages.gestionelemcompoLeftDesactiverbouton(), images.remove());
		buttonPanel.add(addBtn, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		buttonPanel.add(modifBtn, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		buttonPanel.add(delBtn, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		buttonPanel.setBorders(true);
		container.add(buttonPanel);
		fieldSet.setResize(true);

		add(metierLabel);
		add(fieldSet, new VerticalLayoutData(1, -1));

		importLink = new HTML();		
		importLink.setHTML(messages.gestionelemcompoLeftImport());
		importLink.setStyleName("htmlLink");
		importLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				FileImportDialog dialog = new FileImportDialog(bus,messages.commonImportPopupElement());
				setBasicParams(dialog);
				
				dialog.setFormAction("importElements");
				dialog.show();
			}
		});

		exportLink = new HTML();
		exportLink.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				if( edcGrid.getEdcGrid().getStore() != null ) {
					String exportUrl = GWT.getHostPageBaseURL() + "Mozarto_Elements.csv";

					List<NameValuePair> values = new ArrayList<NameValuePair>();
					values.add(new NameValuePair(Constant.ELEMENT_SEARCH_STR, edcGrid.getSearchString()));
					values.add(new NameValuePair(Constant.LIBELLE_METIER, libelleMetier));
					values.add(new NameValuePair(Constant.ID_METIER, idMetier.toString()));
					values.add(new NameValuePair(Constant.ELEMENT_SORTBY, edcGrid.getSortBy()));
					values.add(new NameValuePair(Constant.ELEMENT_SORTDIR, edcGrid.getSortDir()));
					Date date = new Date();
					values.add(new NameValuePair(
							Constant.CLIENT_DATE_STR, DateTimeFormat.getFormat("dd/MM/yyyy").format(date)));
					@SuppressWarnings("deprecation")
					int timezoneoffset = date.getTimezoneOffset()*(-1);
					values.add(new NameValuePair(
							Constant.CLIENT_TIMEZONEOFFSET, String.valueOf(timezoneoffset)));
					ReportUtil.showReport(exportUrl, values.toArray(new NameValuePair[values.size()]));
				}

			}
		});
		exportLink.setHTML(messages.gestionelemcompoLeftExport());
		exportLink.setStyleName("htmlLink");

		initEdcGrid();
		container.add(edcGrid);
		container.add(importLink);
		container.add(exportLink);
		container.setHeight("auto");
		addHandler();

/*		ClientGestionElementCompositionServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

			@Override
			public void onSuccess(Metier result) {
				metierLabel.setHTML(messages.commonMetier() + ": " + result.getLLibelle());
				libelleMetier = result.getLLibelle();
				add(importLink);
				add(exportLink);
			}
		});*/
	}

	public void addHandler() {
		container.addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent arg0) {
				edcGrid.setWidth(arg0.getWidth() - 2);
			}
		});
		
		bus.addHandler(ElementCompositionGridEvent.getType(), new ElementCompositionGridHandler() {
			
			@Override
			public void onLoad(ElementCompositionGridEvent elementCompositionGridEvent) {
				edcGrid.getGridLoader().load();		

			}
		});

		addBtn.getHtml().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				bus.fireEvent(new GestionElementCompositionEvent(null));

			}
		});
		modifBtn.getHtml().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				if( edcGrid != null && edcGrid.getSelectedElementId() != null ) {
					bus.fireEvent(new GestionElementCompositionEvent(edcGrid.getSelectedElementId()));
				}

			}
		});
		delBtn.getHtml().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				if( edcGrid.getSelectedElementId() != null ) {
					bus.fireEvent(new GestionElementCompositionEvent(edcGrid.getSelectedElementId()));
					bus.fireEvent(new GestionElementCompositionDisableElementEvent(edcGrid.getSelectedElementId()));					
				}

			}
		});
		addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent event) {
				int actionFieldSetHeight = getElement().getClientHeight();
				int edcFieldSetHeight = actionFieldSetHeight-120;
				//edcFieldSet.setHeight(edcFieldSetHeight);
				//edcFieldSet.getElement().repaint();
				edcGrid.setHeight(edcFieldSetHeight-30);
				edcGrid.setWidth(getElement().getClientWidth());
			}
		});
		
		bus.addHandler(DisableElementPossibleEvent.getType(), new DisableElementPossibleHandler() {
			
			@Override
			public void onLoad(DisableElementPossibleEvent event) {
				final ConfirmMessageBox box = new ConfirmMessageBox(
						messages.commonConfirmDesactiver(), messages.gestionelemcompoLeftDesactivermesage());
				box.setWidth(400);
				box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
				box.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {

					@Override
					public void onSelect(SelectEvent event) {
						box.hide();
						final Integer idElement = edcGrid.getSelectedElementId();
						ClientElementServiceAsync.Util.getInstance().deleteById(idElement, new AsyncCallbackWithErrorResolution<Element>() {

							@Override
							public void onSuccess(Element element) {
								edcGrid.getGridLoader().load();
								bus.fireEvent(new GestionElementCompositionDisableElementEvent(element.getCElement()));
							}

							@Override
							public void onFailure(Throwable caught) {
							}

						});
					}
				});
				box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
				box.getButtonById(PredefinedButton.NO.name()).addSelectHandler(new SelectHandler() {

					@Override
					public void onSelect(SelectEvent event) {
						box.hide();
					}
				});

				box.show();

			}
		});
	}

	private void initEdcGrid() {
		edcGrid = new ElementCompositionGrid(bus);
	}
	
	public void setIdMetier(Integer idMetier) {
		this.idMetier = idMetier;
	}

	public Integer getIdMetier() {
		return idMetier;
	}

	public ElementCompositionGrid getEdcGrid() {
		return edcGrid;
	}

	public void setEdcGrid(ElementCompositionGrid edcGrid) {
		this.edcGrid = edcGrid;
	}

	private void setBasicParams(FileImportDialog dialog) {
		dialog.addParamElement(Constant.ID_METIER, idMetier.toString());
		
		//FIXME 
		dialog.addParamElement(Constant.LIBELLE_METIER, libelleMetier);

		//FIXME Get log-in User Id
		dialog.addParamElement(ConstantServer.PARAM_USER_ID, "1");
	}

}
