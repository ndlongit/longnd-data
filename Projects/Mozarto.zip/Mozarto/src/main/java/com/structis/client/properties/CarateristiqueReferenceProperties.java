package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.MdlCarateristiqueReference;

public interface CarateristiqueReferenceProperties extends PropertyAccess<MdlCarateristiqueReference>{
	 
	// ModelKeyProvider<MdlCarateristiqueReference> getIndex();
	 ValueProvider<MdlCarateristiqueReference, Integer> getIdCaracteristique();
	 ValueProvider<MdlCarateristiqueReference, String> caracteristiqueLibelle();


}
