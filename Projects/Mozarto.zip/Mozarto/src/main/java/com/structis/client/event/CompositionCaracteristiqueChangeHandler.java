package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface CompositionCaracteristiqueChangeHandler extends EventHandler {
	void onLoad(CompositionCaracteristiqueChangeEvent event);
}
