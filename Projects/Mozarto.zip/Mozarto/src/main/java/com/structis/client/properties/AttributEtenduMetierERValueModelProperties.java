package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;

public interface AttributEtenduMetierERValueModelProperties extends PropertyAccess<AttributEtenduMetierERValueModel> {
	
	ModelKeyProvider<AttributEtenduMetierERValueModel> getIdER();

	ValueProvider<AttributEtenduMetierERValueModel, Integer> idModeleVersion();

	ValueProvider<AttributEtenduMetierERValueModel, Integer> idAttributEtendu();
	
	ValueProvider<AttributEtenduMetierERValueModel, String> attributEtenduLibelle();
	
	ValueProvider<AttributEtenduMetierERValueModel, String> valeur();
}
