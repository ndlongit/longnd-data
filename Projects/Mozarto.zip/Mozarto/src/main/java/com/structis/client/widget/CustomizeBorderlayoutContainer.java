package com.structis.client.widget;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.Style.LayoutRegion;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.CollapsePanel;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.structis.client.image.Images;

public class CustomizeBorderlayoutContainer extends BorderLayoutContainer {
	
	private String leftTitle = "";

	private String rightTitle = "";

	private String bottomTitle = "";
	
	class CustomizeCollapsePanel extends CollapsePanel {

		public CustomizeCollapsePanel(ContentPanel panel, BorderLayoutData data, LayoutRegion region) {
			super(panel, data, region);
			getElement().getChild(0).removeFromParent();
		}
		@Override
		protected void onBarClick(Event event) {
			//Window.alert("test");
		}
		 @Override
		  protected void doAttachChildren() {
		    super.doAttachChildren();
		    //ComponentHelper.doAttach(expandBtn);
		 }

	}
	@Override
	protected CollapsePanel createCollapsePanel(final ContentPanel panel, BorderLayoutData data, final LayoutRegion region) {
		final CustomizeCollapsePanel cp = new CustomizeCollapsePanel(panel, data, region) {
		      protected void onExpandButton() {
		        super.onExpandButton();
		        onExpandClick(this);
		      }
		    };

		    BorderLayoutData collapseData = new BorderLayoutData();
		    collapseData.setSize(data.isCollapseHidden() ? 0 : 24);

		    Margins m = data.getMargins();
		    if (m == null) {
		      m = new Margins();
		      data.setMargins(m);
		    }
		    collapseData.setMargins(new Margins(m.getTop(), m.getRight(), m.getBottom(), m.getLeft()));

		    if (data.isCollapseHidden()) {
		      cp.collapseHidden();
		      collapseData.setSize(0);
		      switch (region) {
		        case WEST:
		          collapseData.getMargins().setLeft(0);
		          break;
		        case EAST:
		          collapseData.getMargins().setRight(0);
		          break;
		        case NORTH:
		          collapseData.getMargins().setTop(0);
		          break;
		        case SOUTH:
		          collapseData.getMargins().setBottom(0);
		          break;
		      }
		    }

		    cp.setLayoutData(collapseData);
		    cp.setData("panel", panel);
		    Image image = new Image();
		    Label label = new Label();
		    if(region == LayoutRegion.WEST){
		    	label.setText(leftTitle);
			    label.getElement().addClassName("cssVerticalText");
		    	image.setResource(Images.RESOURCES.collapseRight());
		    }else if(region == LayoutRegion.EAST){
		    	label.setText(rightTitle );
			    label.getElement().addClassName("cssVerticalText");
		    	image.setResource(Images.RESOURCES.collapseLeft());
		    }else if(region == LayoutRegion.SOUTH){
		    	label.setText(bottomTitle);
		    	label.getElement().addClassName("htmlLinkRight");
		    	image.setResource(Images.RESOURCES.collapseTop());
		    }
		    else{
		    	image.setResource(Images.RESOURCES.collapseBottom());
		    }
			cp.getElement().appendChild(label.getElement());
		    image.getElement().addClassName("bottomPosittion");
		    cp.getElement().appendChild(image.getElement());
		    //cp.getElement().disable();
		    cp.addHandler(new ClickHandler() {
				@Override
				public void onClick(ClickEvent event) {
					expand(region);
				}
			}, ClickEvent.getType());
		    
		    panel.setData("collapse", cp);
		    return cp;
	}
	public void setLeftTitle(String leftTitle) {
		this.leftTitle = leftTitle;
	}
	public String getLeftTitle() {
		return leftTitle;
	}
	public String getRightTitle() {
		return rightTitle;
	}
	public void setRightTitle(String rightTitle) {
		this.rightTitle = rightTitle;
	}
	public void setBottomTitle(String bottomTitle) {
		this.bottomTitle = bottomTitle;
	}
	public String getBottomTitle() {
		return bottomTitle;
	}
	
	
}
