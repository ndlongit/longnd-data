package com.structis.client.panel.composition;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gwt.cell.client.DateCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.SortDir;
import com.sencha.gxt.data.shared.Store.StoreSortInfo;
import com.sencha.gxt.data.shared.event.StoreAddEvent;
import com.sencha.gxt.data.shared.event.StoreAddEvent.StoreAddHandler;
import com.sencha.gxt.data.shared.loader.LoadEvent;
import com.sencha.gxt.data.shared.loader.LoadHandler;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.grid.GroupingView;
import com.sencha.gxt.widget.core.client.toolbar.PagingToolBar;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.CompositionLoadComposModeleEvent;
import com.structis.client.event.CompositionLoadComposModeleHandler;
import com.structis.client.event.CompositionModifyCompoEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.CompositionAccueilModelProperties;
import com.structis.client.service.ClientCompositionServiceAsync;
import com.structis.client.widget.ImagesCompoActionCell;
import com.structis.shared.model.reference.CompositionAccueilModel;
import com.structis.shared.model.reference.ModeleModel;

public class CompositionAccueilCompoGrid extends VerticalLayoutContainer {

	private static final int NUMBER_ITEMS_BY_PAGE = 30;

	SimpleEventBus bus;

	private NavigationService navigation = NavigationFactory.getNavigation();
	
	Images images = GWT.create(Images.class);

	Integer idMetier = navigation.getContext().getMetier().getIdMetier();

	private final Messages messages = GWT.create(Messages.class);

	int recordNumber = NUMBER_ITEMS_BY_PAGE;

	private Grid<CompositionAccueilModel> grid;

	private ListStore<CompositionAccueilModel> store;
	
	private ModeleModel modele;

	@SuppressWarnings("unused")
	private List<ModeleModel> allModeles;

	PagingLoader<PagingLoadConfig, PagingLoadResult<CompositionAccueilModel>> loader;

	@SuppressWarnings("unused")
	private Integer modeleSelected = -1;

	private Label title;

	//private HBoxLayoutContainer titleContainer;

	public CompositionAccueilCompoGrid(SimpleEventBus bus1) {
		this.bus = bus1;
		setStyleName("whiteBackGround");
		title = new Label();

		/*titleContainer = new HBoxLayoutContainer();
		titleContainer.setPadding(new Padding(5));
		titleContainer.setHBoxLayoutAlign(HBoxLayoutAlign.TOP);

		BoxLayoutData flex = new BoxLayoutData(new Margins(0, 5, 0, 0));
		flex.setFlex(1);
		titleContainer.add(title, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		titleContainer.add(new Label(), flex);*/
		/*final CustomizePagingToolbar pagingToolbar = new CustomizePagingToolbar(){
			
			@Override
			protected void onButtonClick() {
				recordNumber = pagingNumberSpinner.getValue();
				loader.load();
			}
			
			@Override
			protected void onSpinnerClick(int record) {
				recordNumber = record;
				loader.load();
			}
		};*/
		PagingToolBar pagingToolbar = new PagingToolBar(ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
		//c.add(pagingToolbar,flex);
		title.getElement().getStyle().setProperty("color", "black");
		title.getElement().getStyle().setProperty("paddingRight", "10px");
		title.getElement().getStyle().setProperty("fontSize", "13px");
		pagingToolbar.insert(title, 0);
		//titleContainer.add(pagingToolbar, new BoxLayoutData(new Margins(0, 5, 0, 0)));

		//add(titleContainer, new VerticalLayoutData(1, -1));
		add(pagingToolbar, new VerticalLayoutData(1, -1));

		RpcProxy<PagingLoadConfig, PagingLoadResult<CompositionAccueilModel>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<CompositionAccueilModel>>() {

			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<CompositionAccueilModel>> callback) {
				/*int value = Integer.parseInt(pagingToolbar.getPagingNumberSpinner().getText());
				loadConfig.setOffset((value - 1) * NUMBER_ITEMS_BY_PAGE);
				loadConfig.setLimit(NUMBER_ITEMS_BY_PAGE);*/
				if(modele != null)
					ClientCompositionServiceAsync.Util.getInstance().loadCompoByModele(modele, loadConfig, callback);
			}
		};

		CompositionAccueilModelProperties props = GWT.create(CompositionAccueilModelProperties.class);
		store = new ListStore<CompositionAccueilModel>(new ModelKeyProvider<CompositionAccueilModel>() {
			@Override
			public String getKey(CompositionAccueilModel item) {
				return "" + item.getIdComposition();
				}
		});

		List<ColumnConfig<CompositionAccueilModel, ?>> cfgs = new ArrayList<ColumnConfig<CompositionAccueilModel, ?>>();

		final ColumnConfig<CompositionAccueilModel, String> libelleColumn = new ColumnConfig<CompositionAccueilModel, String>(props.lLibelleLong());
		libelleColumn.setHeader(messages.compositionAccueilRightNom());
		//		libelleColumn.setCell(new TextCell());
		libelleColumn.setMenuDisabled(true);
		libelleColumn.setSortable(true);
		cfgs.add(libelleColumn);

		ColumnConfig<CompositionAccueilModel, Date> dateColumn = new ColumnConfig<CompositionAccueilModel, Date>(props.dDateheureDmaj());
		dateColumn.setHeader(messages.compositionAccueilRightModif());
		dateColumn.setCell(new DateCell(DateTimeFormat.getFormat("dd/MM/yyyy")));
		dateColumn.setMenuDisabled(true);
		cfgs.add(dateColumn);

		ColumnConfig<CompositionAccueilModel, String> utilisateurColumn = new ColumnConfig<CompositionAccueilModel, String>(props.cUtilisateurCrea());
		utilisateurColumn.setHeader(messages.compositionAccueilRightUtilisateur());
		cfgs.add(utilisateurColumn);
		utilisateurColumn.setMenuDisabled(true);

		ColumnConfig<CompositionAccueilModel, Integer> publicationColumn = new ColumnConfig<CompositionAccueilModel, Integer>(props.pubVersion());
		publicationColumn.setHeader(messages.compositionAccueilRightPub());
		cfgs.add(publicationColumn);
		publicationColumn.setMenuDisabled(true);

		ColumnConfig<CompositionAccueilModel, String> origineColumn = new ColumnConfig<CompositionAccueilModel, String>(props.libelleApplicationOrigine());
		origineColumn.setHeader(messages.compositionAccueilRightOrigine());
		cfgs.add(origineColumn);
		origineColumn.setMenuDisabled(true);

		ColumnConfig<CompositionAccueilModel, CompositionAccueilModel> actionsColumn = new ColumnConfig<CompositionAccueilModel, CompositionAccueilModel>(
				new IdentityValueProvider<CompositionAccueilModel>());
		actionsColumn.setHeader(messages.compositionAccueilRightActions());
		actionsColumn.setMenuDisabled(true);
		actionsColumn.setWidth(150);
		actionsColumn.setFixed(true);
		ImagesCompoActionCell imagesCell = new ImagesCompoActionCell() {

			@Override
			public void onCompoDuplicate(CompositionAccueilModel compo) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onCompoModify(CompositionAccueilModel compo) {
				bus.fireEvent(new CompositionModifyCompoEvent(compo.getIdComposition()));
			}

			@Override
			public void onCompoDelete(final CompositionAccueilModel compo) {
				final ConfirmMessageBox box = new ConfirmMessageBox(messages.commonConfirmDelete(), messages.compositionAccueilRightSupprimerConfirm());
				box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
				box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
				box.addHideHandler(new HideHandler() {
					
					@Override
					public void onHide(HideEvent event) {
						if (box.getHideButton() == box.getButtonById(PredefinedButton.YES.name())){
							ClientCompositionServiceAsync.Util.getInstance().deleteById(compo.getIdComposition(), new AsyncCallbackWithErrorResolution<Integer> (){

								@Override
								public void onSuccess(Integer arg0) {
									grid.getLoader().load();
								}
							});
						}
					}
				});
				box.show();
			}

		};
		actionsColumn.setCell(imagesCell);
		cfgs.add(actionsColumn);

		ColumnModel<CompositionAccueilModel> cm = new ColumnModel<CompositionAccueilModel>(cfgs);
		GroupingView<CompositionAccueilModel> view = new GroupingView<CompositionAccueilModel>();
		view.setShowGroupedColumn(true);
		view.setForceFit(true);
		view.setAutoFill(true);

		loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<CompositionAccueilModel>>(proxy);
		loader.setRemoteSort(true);
		grid = new Grid<CompositionAccueilModel>(store, cm);
		grid.setView(view);
		grid.getView().setForceFit(true);
		//	    grid.setLoadMask(true);
		grid.setLoader(loader);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, CompositionAccueilModel, PagingLoadResult<CompositionAccueilModel>>(
				grid.getStore()));

		add(grid, new VerticalLayoutData(1, 1));

		grid.getView().refresh(false);
		loader.addLoadHandler(new LoadHandler<PagingLoadConfig, PagingLoadResult<CompositionAccueilModel>>() {

			@Override
			public void onLoad(LoadEvent<PagingLoadConfig, PagingLoadResult<CompositionAccueilModel>> event) {
				/*int numpages = loader.getTotalCount() / NUMBER_ITEMS_BY_PAGE + 1;
				pagingToolbar.getPagingNumberSpinner().setMaxValue(numpages);
				pagingToolbar.setTotalRecord(numpages);
				pagingToolbar.getTotalRecordLabel().setText("/" + String.valueOf(numpages));
				int value = Integer.parseInt(pagingToolbar.getPagingNumberSpinner().getText());
				if( value == 1 ) {
					Image prevIcon = new Image();
					prevIcon.setResource(images.leftArrowButtonDisable());
					pagingToolbar.getPrev().setHTML(prevIcon + "");
				}
				else {
					Image prevIcon = new Image();
					prevIcon.setResource(images.prevIcon());
					pagingToolbar.getPrev().setHTML(prevIcon + "");
				}
				if( value == numpages ) {
					Image nextIcon = new Image();
					nextIcon.setResource(images.rightArrowButtonDisable());
					pagingToolbar.getNext().setHTML(nextIcon + "");
				}
				else {
					Image nextIcon = new Image();
					nextIcon.setResource(images.nextIcon());
					pagingToolbar.getNext().setHTML(nextIcon + "");
				}*/
			}
		});
		grid.getStore().addStoreAddHandler(new StoreAddHandler<CompositionAccueilModel>() {
			@Override
			public void onAdd(StoreAddEvent<CompositionAccueilModel> event) {
				for( CompositionAccueilModel item : grid.getStore().getAll() )
					grid.getStore().update(item);
				grid.getView().refresh(false);
			}
		});
	    store.addSortInfo(new StoreSortInfo<CompositionAccueilModel>(props.dDateheureDmaj(), SortDir.DESC));
		addHandlers();

	}

	
	public void addHandlers (){
		bus.addHandler(CompositionLoadComposModeleEvent.getType(), new CompositionLoadComposModeleHandler() {
			@Override
			public void onLoad(CompositionLoadComposModeleEvent event) {
				modele = event.getModele();
				title.setText(messages.compositionAccueilRightListe(modele.getLLibelle()));
				grid.getLoader().load();
//				int index = titleContainer.getWidgetIndex(title);
//				titleContainer.remove(title);
//				titleContainer.insert(title, index);
			}
		});
	}

	public Grid<CompositionAccueilModel> getGrid() {
		return grid;
	}

	public void setGrid(Grid<CompositionAccueilModel> grid) {
		this.grid = grid;
	}

}
