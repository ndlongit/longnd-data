package com.structis.client.widget;

import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Image;
import com.sencha.gxt.widget.core.client.ContentPanel;
/**
 *Html button with image icon or just a link
 * @author vinh.tong
 *
 */
public class HtmlButton extends ContentPanel {
	private HTML html;
	public HtmlButton(String label, ImageResource images){
		setHeaderVisible(false);
		setBorders(false);
		setBodyBorder(false);
		html = new HTML();
		Image icon = new Image();
		icon.setResource(images);
		html.setHTML("<div class='htmlButtonIcon' >"+icon+"</div >"+"<div class='htmlButtonLabel'>"+label+"</div>");
		add(html);
	}
	public HtmlButton(String label){
		setHeaderVisible(false);
		setBorders(false);
		setBodyBorder(false);
		html = new HTML(label);
		html.setStyleName("htmlLink");
		add(html);
	}
	public HTML getHtml(){
		return html;
	}
	public void setEnable(boolean enable){
		if(enable){
			html.setStyleName("htmlLink");
		}else{
			html.setStyleName("htmlLinkDisable");
		}
	}
	public void addClickHandler(ClickHandler handler) {
		html.addClickHandler(handler);		
	}
	public boolean isEnnabled(){
		if(html.getStyleName().equals("htmlLink")){
			return true;
		}
		return false;
	}
}
