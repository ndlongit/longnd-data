package com.structis.client.navigation;

import static com.structis.client.constant.ConstantClient.CONTENT;
import static com.structis.client.navigation.Action.ACTION_ACCEUIL;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.RootPanel;
import com.structis.client.constant.ConstantClient;
import com.structis.client.ecran.EcranLoadable;
import com.structis.shared.config.ApplicationContext;
import com.structis.shared.security.Role;

/**
 * The abstract class that contains the mechanism: the direction of widget 
 * on the application and creation of breadcrumb. 
 * 
 * It uses a map to store the correspondence between an action and its guts 
 * It provided the method m initNavigation that initialized this map.
 * 
 * 
 */
public abstract class NavigationAbstract implements NavigationService {
	
	//private HorizontalPanel hPanel = new HorizontalPanel();
	private boolean init = false;
	private Action actuelle = null;
	protected List<Role> roles = new ArrayList<Role>();
	protected ApplicationContext context = new ApplicationContext();
	private SimpleEventBus bus = new SimpleEventBus();
	
	protected Map<Action, Ecran> mapNavigation = new HashMap<Action, Ecran>();
	
	/**
	 * Initialize the mapping between action and navigation
	 */
	protected abstract void initNavigation();
	
	/**
	 * Navigate to the action
	 * @param action
	 */
	public void goToEcran(Action action){
		goToEcran(action, new NavigationEvent());
	}
	
	public Action getActionActuelle(){
		return actuelle;
	}
	
	
	/**
	 * see {@link NavigationService#goToEcran(Action)}
	 */
	public void goToEcran(Action action, NavigationEvent event) {
		if (!init) {
			initNavigation();
			init = true;
		}
		
		// Test role
		Ecran ecran = null;
		if (roles.contains(action.getRole())){
			ecran =  mapNavigation.get(action);
		}
		
		if (null == ecran) {		
			ecran = mapNavigation.get(ACTION_ACCEUIL);
		}
		
		// get screen
		EcranLoadable comEcran = ecran.getEcran();
		
		// clear the content
		//RootPanel.get(FIL_ARIANE).clear();
		RootPanel.get(CONTENT).clear();
		
		try {
			RootPanel.get(CONTENT).add(comEcran);
		}
		catch(ConcurrentModificationException e) {
			GWT.log("Attention error ConcurrentModificationException" + e);
			RootPanel.get(CONTENT).add(comEcran);
		}
		//current action
		actuelle = action;
		
		// call load application
		comEcran.onLoadApplication(event);
		
		// add to history
		if (event.getParameters() != null &&
				event.getParameters().get(ConstantClient.CANCEL_HISTORY) == null){
			HistoryHelper.newItem(action.getLabel(), event.getParameters());
		}
		HistoryHelper.pushItem(action, event.getParameters());
	}
	
	public void goToTabEcran(Action action, NavigationEvent event) {
		if (event.getParameters() != null &&
				event.getParameters().get(ConstantClient.CANCEL_HISTORY) == null){
			HistoryHelper.newItem(action.getLabel(), event.getParameters());
		}
		HistoryHelper.pushItem(action, event.getParameters());
	}
	
	public void setApplicationContext(ApplicationContext context) {
		/*this.context.setDate(context.getDate());
		this.context.setRoles(context.getRoles());
		this.roles = context.getRoles();*/
		this.context = context;
	}
	
	public ApplicationContext getContext(){
		return context;
	}
	public Map<Action, Ecran> getMapNavigation(){
		return mapNavigation;
	}
	public SimpleEventBus getBus() {
		return bus;
	}

}
