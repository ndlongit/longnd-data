package com.structis.client.ecran;

import com.google.gwt.user.client.ui.IsWidget;
import com.structis.client.navigation.NavigationEvent;

/**
 * The interface for all screen of application ,and provide method   {@link EcranLoadable#onLoadApplication()} 
 * Which called whenever The screen is displayed
 * @author vinh.tong
 *
 */
public interface EcranLoadable extends IsWidget {

	/**
	 * On load screen
	 * @param event
	 */
	public abstract void onLoadApplication(NavigationEvent event);
}
