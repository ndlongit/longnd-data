package com.structis.client.widget;

import com.sencha.gxt.data.shared.loader.PagingLoadResultBean;

@SuppressWarnings({ "serial", "rawtypes" })
public class CustimizePagingLoadResultBean extends PagingLoadResultBean {
	private int realTotalLength;

	public int getRealTotalLength() {
		return realTotalLength;
	}

	public void setRealTotalLength(int totalLength) {
		this.realTotalLength = totalLength;
	}
}
