package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.MdlCarateristiqueReference;

public interface CarateristiqueReferenceService {
	List<MdlCarateristiqueReference> findByModeleVersionAndReference(Integer idModeleVersion, Integer idReference);

	void deleteByModeleVersionAndReference(Integer idModeleVersion, Integer idReference);

	void insertList(List<MdlCarateristiqueReference> listCarateristiqueReference);

	void insert(MdlCarateristiqueReference relationship);

	void delete(MdlCarateristiqueReference relation);

	List<MdlCarateristiqueReference> findByBaseCriteria(MdlCarateristiqueReference criteria);
	
	void deleteByModeleVersionIdCarateristiquesAndIdReferences(Integer idModeleVersion,List<Integer> idCarateristique, List<Integer> idReferences);

	void deleteByReferenceIdsAndCharacteristicIds(Integer idModeleVersion, List<Integer> idReferences, List<Integer> ids);
}
