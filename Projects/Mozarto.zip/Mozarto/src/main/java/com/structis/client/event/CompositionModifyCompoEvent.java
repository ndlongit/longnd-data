package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class CompositionModifyCompoEvent  extends GwtEvent<CompositionModifyCompoHandler>{
	
	private static Type<CompositionModifyCompoHandler> TYPE = new Type<CompositionModifyCompoHandler>();
	
	private Integer idComposition;
	
	public static Type<CompositionModifyCompoHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<CompositionModifyCompoHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(CompositionModifyCompoHandler handler) {
		handler.onLoad(this);
	}
	
	public CompositionModifyCompoEvent(Integer idComposition) {
		this.idComposition = idComposition;
	}

	public void setIdComposition(Integer idComposition) {
		this.idComposition = idComposition;
	}

	public Integer getIdComposition() {
		return idComposition;
	}
}
