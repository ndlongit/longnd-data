package com.structis.server.service.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.persistence.MetierMapper;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.MetierMzPzModel;

@Service("metierService")
public class MetierServiceImpl implements  MetierService {
	@Autowired
	private MetierMapper metierPO;
	
	public Metier findById(Integer id) {
		return metierPO.findById(id);	
	}
	
	@Transactional
	public Integer insert(Metier metier) {
		 return metierPO.insert(metier);	
	}
	
	@Transactional
	public Integer update(Metier metier) {
		 return metierPO.update(metier);	
	}
		
	@Transactional
	public Integer delete(Metier metier) {
		return metierPO.delete(metier);	
	}
	
	@Transactional
	public Integer deleteById(Integer id) {
		return metierPO.deleteById(id);	
	}
	public List<Metier> findAll() {
		return metierPO.findAll();		
	}

	@Override
	public List<MetierMzPzModel> findAllPegaz() {
		return metierPO.findAllPegaz();
	}

	@Override
	public List<Metier> findByLibelle(String lLibelle) {
		return metierPO.findByLibelle(lLibelle);
	}
}
