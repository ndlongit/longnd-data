package com.structis.client.panel;

import static com.structis.client.constant.ConstantClient.FLECH;

import java.util.Stack;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.XTemplates;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.AbstractHtmlLayoutContainer.HtmlData;
import com.sencha.gxt.widget.core.client.container.CardLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HtmlLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.event.MaskEvent;
import com.structis.client.event.MaskHandler;
import com.structis.client.event.ModelisateurTreeDoubleClickEvent;
import com.structis.client.event.RenameTreeNodeEvent;
import com.structis.client.event.RenameTreeNodeHandler;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.reference.TreeNodeModel;

public class NavigationModelisateurForm extends VerticalLayoutContainer {
	protected SimpleEventBus bus;

	protected final Messages messages = GWT.create(Messages.class);

	protected HorizontalPanel navigationPanel;

	private AbstractModelisateurEditForm detailForm;

	private ModelisateurRegleMessageList regleForm;

	private CardLayoutContainer container;

	protected TextButton detailButton;

	protected TextButton regleButton;

	private HTML currentNodeLabel;

	private HtmlLayoutContainer navigationContainer;
	//private HBoxLayoutContainer formNavigation;

	@SuppressWarnings("unused")
	private NavigationService navigation = NavigationFactory.getNavigation();
	
	private TreeNodeModel currentItem;
	public interface HtmlLayoutContainerTemplate extends XTemplates {
		@XTemplate("<table width=\"100%\" height=\"100%\"><tbody><tr><td height=\"100%\" width=\"100%\" class=\"cellleft\" /><td class=\"cellmiddle\" >&nbsp;</td><td style=\"text-align:right\" class=\"cellright\" />&nbsp;<td width=\"auto\" class=\"cellbuttondetail\" /><td width=\"auto\" class=\"cellbuttonregle\" /></tr></tbody></table>")
		SafeHtml getNavigationTemplate();
	}

	public NavigationModelisateurForm(SimpleEventBus bus, TreeNodeModel item, Stack<TreeNodeModel> itemsPath,
			AbstractModelisateurEditForm detailFormSoure, ModelisateurRegleMessageList regleFormSource) {
		this.bus = bus;
		this.detailForm = detailFormSoure;
		this.regleForm = regleFormSource;
		currentItem = item;
		addStyleName("containerPadding");
		/*formNavigation = new HBoxLayoutContainer();*/

		navigationPanel = new HorizontalPanel();
		/*formNavigation.add(navigationPanel);
		BoxLayoutData flex = new BoxLayoutData(new Margins(0, 5, 0, 0));
		flex.setFlex(1);
		formNavigation.add(new Label(), flex);*/
		detailButton = new TextButton(messages.modelisateurFormDetail());
		regleButton = new TextButton(messages.modelisateurFormRegles());

		/*formNavigation.add(detailButton, new BoxLayoutData(new Margins(0, 5, 0, 0)));
		formNavigation.add(regleButton, new BoxLayoutData(new Margins(0, 5, 0, 0)));*/

		HtmlLayoutContainerTemplate templates = GWT.create(HtmlLayoutContainerTemplate.class);

		navigationContainer = new HtmlLayoutContainer(templates.getNavigationTemplate());

		navigationContainer.add(navigationPanel, new HtmlData(".cellleft"));
		navigationContainer.add(detailButton, new HtmlData(".cellbuttondetail"));
		navigationContainer.add(regleButton, new HtmlData(".cellbuttonregle"));

		add(navigationContainer, new VerticalLayoutData(1, -1));
		
		container = new CardLayoutContainer();
		container.add(detailForm);
		container.add(regleForm);
		add(container, new VerticalLayoutData(1, 1));
		loadNavigation(itemsPath);
		detailButton.addSelectHandler(new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				if (regleForm.isChanged()){
					final ConfirmMessageBox box = new ConfirmMessageBox(
							messages.commonConfirmation(), messages.modelisateurSwitchConfirm(currentItem.getLibelle()));
					box.setWidth(400);
					box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
					box.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {
	
						@Override
						public void onSelect(SelectEvent event) {
							box.hide();
							container.setActiveWidget(detailForm);
							regleForm.resetForm();
							toggleDetailButton(false);
						}
					});
					box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
					box.getButtonById(PredefinedButton.NO.name()).addSelectHandler(new SelectHandler() {
	
						@Override
						public void onSelect(SelectEvent event) {
							box.hide();
						}
					});
	
					box.show();
				}
				else {
					container.setActiveWidget(detailForm);
					toggleDetailButton(false);
				}
			}
		});
		regleButton.addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				if (detailForm.isChanged()){
					final ConfirmMessageBox box = new ConfirmMessageBox(
							messages.commonConfirmation(), messages.modelisateurSwitchConfirm(currentItem.getLibelle()));
					box.setWidth(400);
					box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
					box.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {
	
						@Override
						public void onSelect(SelectEvent event) {
							box.hide();
							container.setActiveWidget(regleForm);
							detailForm.resetForm();
							detailForm.toggleSaveCancel(false);
							if( !currentItem.getModelType().equals(ModelNodeType.ELEMENT) )
								regleForm.enableButtons(true);
	
							//regleForm.loadListRelgeAndMessage();
							toggleDetailButton(true);
						}
					});
					box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
					box.getButtonById(PredefinedButton.NO.name()).addSelectHandler(new SelectHandler() {
	
						@Override
						public void onSelect(SelectEvent event) {
							box.hide();
						}
					});
	
					box.show();
				}
				else {
					container.setActiveWidget(regleForm);
					if( !currentItem.getModelType().equals(ModelNodeType.ELEMENT) )
						regleForm.enableButtons(true);

					toggleDetailButton(true);
				}
			}
		});
		toggleDetailButton(false);
		if(item.getId() == null){
			regleButton.setEnabled(false);
		}
		addHandlers();
	}

	private void addHandlers() {
		bus.addHandler(RenameTreeNodeEvent.getType(), new RenameTreeNodeHandler() {
			@Override
			public void onLoad(RenameTreeNodeEvent event) {
				if( ((AbstractModelisateurEditForm) detailForm).getTabId().equals(event.getTabId()) ) {
					if( currentNodeLabel != null ) {
						currentNodeLabel.setText(event.getNewLabel());
					}
				}
			}
		});
		final VerticalLayoutContainer panel = this;
		bus.addHandler(MaskEvent.getType(), new MaskHandler() {
			@Override
			public void onLoad(MaskEvent event) {
				if( event.isMask() ) {
					if( !((AbstractModelisateurEditForm) detailForm).getTabId().equals(event.getTabId()) ) {
						panel.mask();
					}
					else {
						navigationContainer.mask();
					}
				}
				else {
					navigationContainer.unmask();
					panel.unmask();
				}
			}

		});
	}

	public void loadNavigation(Stack<TreeNodeModel> itemsPath) {
		navigationPanel.clear();
		int maxDisplayedLabels = 4;
		if( itemsPath != null ) {
			int itemsCount = itemsPath.size();
			int i = 0;
			if( maxDisplayedLabels > itemsCount ) {
				maxDisplayedLabels = itemsCount;
			}
			do {
				final TreeNodeModel item = itemsPath.pop();
				if(item != null){
					final HTML label = new HTML(item.getLibelle());
					Label flech = new Label(FLECH);
	
					if( i == 0 ) {
						label.setStylePrimaryName("htmlLink");
						label.addClickHandler(new ClickHandler() {
							@Override
							public void onClick(ClickEvent arg0) {
								bus.fireEvent(new ModelisateurTreeDoubleClickEvent(item));
							}
						});
						navigationPanel.add(label);
						if( maxDisplayedLabels > 2 && (itemsCount > maxDisplayedLabels) ) {
							navigationPanel.add(flech);
							navigationPanel.add(new Label("..."));
						}
					}
					else if( i > itemsCount - maxDisplayedLabels ) {
						navigationPanel.add(flech);
						label.setStylePrimaryName("htmlLink");
						label.addClickHandler(new ClickHandler() {
							@Override
							public void onClick(ClickEvent arg0) {
								bus.fireEvent(new ModelisateurTreeDoubleClickEvent(item));
							}
						});
						navigationPanel.add(label);
					}
					if( i == itemsCount ) {
						currentNodeLabel = label;
					}
				}
				i++;
				
			}
			while( !itemsPath.isEmpty() );
		}
	}

	public void toggleDetailButton(boolean active) {
		detailButton.setEnabled(active);
		regleButton.setEnabled(!active);
	}

	public AbstractModelisateurEditForm getDetailForm() {
		return detailForm;
	}

	public void setDetailForm(AbstractModelisateurEditForm detailForm) {
		this.detailForm = detailForm;
	}

	public ModelisateurRegleMessageList getRegleForm() {
		return regleForm;
	}

	public void setRegleForm(ModelisateurRegleMessageList regleForm) {
		this.regleForm = regleForm;
	}

	public CardLayoutContainer getContainer() {
		return container;
	}

	public void setContainer(CardLayoutContainer container) {
		this.container = container;
	}

	public boolean isChanged() {
		return detailForm.isChanged();
	}

	public TreeNodeModel getCurrentItem() {
		return currentItem;
	}

	public void setCurrentItem(TreeNodeModel currentItem) {
		this.currentItem = currentItem;
	}

	public HorizontalPanel getNavigationPanel() {
		return navigationPanel;
	}

	public void setNavigationPanel(HorizontalPanel navigationPanel) {
		this.navigationPanel = navigationPanel;
	}
}
