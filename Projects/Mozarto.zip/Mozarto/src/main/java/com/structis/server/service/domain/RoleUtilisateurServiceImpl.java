package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.RoleUtilisateurMapper;
import com.structis.shared.model.RoleUtilisateur;

@Service
public class RoleUtilisateurServiceImpl implements RoleUtilisateurService {

	@Autowired
	RoleUtilisateurMapper mapper;
	
	@Override
	public List<RoleUtilisateur> findAll() {
		return mapper.findAll();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public RoleUtilisateur findByUtilisateurAndMetier(Integer idUtilisateur, Integer idMetier) {
		Map map = new HashMap();
		map.put("idUtilisateur", idUtilisateur);
		map.put("idMetier", idMetier);
		return mapper.findByUtilisateurAndMetier(map);
	}

//	@Override
//	public List<RoleUtilisateur> findAllNonAdmin() {
//		return mapper.findAllNonAdmin();
//	}
	
}
