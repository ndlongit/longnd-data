package com.structis.client.exception;

import com.google.gwt.core.client.GWT;
import com.google.gwt.regexp.shared.RegExp;
import com.google.gwt.user.client.rpc.StatusCodeException;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.structis.client.message.ErrorMessages;
import com.structis.client.message.Messages;

public class ExceptionMessageMapper {
	
	private final Messages messages = GWT.create(Messages.class);
	private final ErrorMessages errorMessages = GWT.create(ErrorMessages.class);
	
	private RegExp regex = RegExp.compile("500 [t|f][0-9][0-9][0-9]");

	public void map(Throwable caught){
		String header = messages.commonErreurInconnu();
		String content = caught.getMessage();
		if (caught instanceof StatusCodeException) {
			StatusCodeException scex = (StatusCodeException) caught;
			if ( null !=  scex.getMessage()
					&& regex.test(scex.getMessage())) {
			
				String code = scex.getMessage().substring(4);
				
				if (code.startsWith("t")) {
					header = messages.commonTechErreurHeader();
					content = errorMessages.getString(code);
				}
				else if (code.startsWith("f")){
					header = messages.commonFonctErreurHeader();
					content = errorMessages.getString(code);
				}
			}
		}
		//MessageBox.alert(header, content, null);
		MessageBox messageBox = new MessageBox(header, content);
		messageBox.show();
	}
}
