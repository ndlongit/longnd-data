package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.sencha.gxt.cell.core.client.AbstractEventCell;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.HasSelectHandlers;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.image.Images;
import com.structis.shared.model.reference.ModeleModel;

public abstract class ImagesModeleActionCell extends AbstractEventCell<ModeleModel> implements HasSelectHandlers {
	interface Templates extends SafeHtmlTemplates {
		@SafeHtmlTemplates.Template("<div name=\"{0}\" style=\"{1}\">{2}</div>")
		SafeHtml cell(String name, SafeStyles styles, SafeHtml value);
	}

	public ImagesModeleActionCell() {
		super("click", "keydown");
	}

	/**
	 * Create a singleton instance of the templates used to render the cell.
	 */
	private static Templates templates = GWT.create(Templates.class);

	private static final SafeHtml ICON_MODELE_DELETE = makeImage(Images.RESOURCES.delete());

	private static final SafeHtml ICON_MODELE_PREVIOUS_VERSIONS = makeImage(Images.RESOURCES.gotoNode());

	private static final SafeHtml ICON_MODELE_PUBLIC = makeImage(Images.RESOURCES.publicate());

	private static final SafeHtml ICON_MODELE_EXECUTE = makeImage(Images.RESOURCES.execute());

	private static final SafeHtml ICON_MODELE_MODIFY = makeImage(Images.RESOURCES.edit());

	private static final SafeHtml ICON_MODELE_DELETE_DISABLE = makeImage(Images.RESOURCES.deleteDisable());

	private static final SafeHtml ICON_MODELE_PREVIOUS_VERSIONS_DISABLE = makeImage(Images.RESOURCES.gotoNodeDisable());

	private static final SafeHtml ICON_MODELE_PUBLIC_DISABLE = makeImage(Images.RESOURCES.publicateDisable());

	private static final SafeHtml ICON_MODELE_EXECUTE_DISABLE = makeImage(Images.RESOURCES.executeDisable());

	private static final SafeHtml ICON_MODELE_MODIFY_DISABLE = makeImage(Images.RESOURCES.editDisable());

	private static final SafeHtml ICON_MODELE_UNDELETE = makeImage(Images.RESOURCES.undelete());

	@Override
	public void onBrowserEvent(com.google.gwt.cell.client.Cell.Context context, Element parent, ModeleModel value,
			NativeEvent event, com.google.gwt.cell.client.ValueUpdater<ModeleModel> valueUpdater) {
		// Let AbstractCell handle the keydown event.
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
		// Handle the click event.
		if( "click".equals(event.getType()) ) {
			// Ignore clicks that occur outside of the outermost element.
			EventTarget eventTarget = event.getEventTarget();
			if( parent.isOrHasChild(Element.as(eventTarget)) ) {
				// if (parent.getFirstChildElement().isOrHasChild(
				// Element.as(eventTarget))) {
				// use this to get the selected element!!
				Element el = Element.as(eventTarget);
				// check if we really click on the image
				if( el.getNodeName().equalsIgnoreCase("IMG") ) {
					//Window.alert(el.getParentElement().getAttribute("name"));
					if( el.getParentElement().getAttribute("name").equals("ICON_MODELE_DELETE") ) {
						onModeleDelete(value);
					}
					if( el.getParentElement().getAttribute("name").equals("ICON_MODELE_PREVIOUS_VERSIONS") ) {
						onModelePreviousVersion(value);
					}
					if( el.getParentElement().getAttribute("name").equals("ICON_MODELE_PUBLIC") ) {
						onModelePublic(value);
					}
					if( el.getParentElement().getAttribute("name").equals("ICON_MODELE_EXECUTE") ) {
						onModeleExecute(value);
					}
					if( el.getParentElement().getAttribute("name").equals("ICON_MODELE_MODIFY") ) {
						onModeleModify(value);
					}
					if( el.getParentElement().getAttribute("name").equals("ICON_MODELE_UNDELETE") ) {
						onModeleUndelete(value);
					}
				}
			}
		}
	};

	@Override
	public void render(Context context, ModeleModel value, SafeHtmlBuilder sb) {
		if( value == null ) {
			return;
		}
		SafeStyles imgStyle = SafeStylesUtils.fromTrustedString("float:left;cursor:hand;cursor:pointer;");
		SafeHtml rendered;

		if (value.isEnabled() && value.getInActif() && value.getNVersion().equals(0)){
			rendered = templates.cell("ICON_MODELE_PUBLIC", imgStyle, ICON_MODELE_PUBLIC);
			sb.append(rendered);
			if (value.getPubVersion() < 1){
				rendered = templates.cell("ICON_MODELE_PREVIOUS_VERSIONS_DISABLE", imgStyle, ICON_MODELE_PREVIOUS_VERSIONS_DISABLE);
			}
			else {
				rendered = templates.cell("ICON_MODELE_PREVIOUS_VERSIONS", imgStyle, ICON_MODELE_PREVIOUS_VERSIONS);
			}
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_EXECUTE", imgStyle, ICON_MODELE_EXECUTE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_MODIFY", imgStyle, ICON_MODELE_MODIFY);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_DELETE", imgStyle, ICON_MODELE_DELETE);
			sb.append(rendered);
		}
		else if (!value.isEnabled() && value.getInActif()){
			rendered = templates.cell("ICON_MODELE_PUBLIC_DISABLE", imgStyle, ICON_MODELE_PUBLIC_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_PREVIOUS_VERSIONS_DISABLE", imgStyle, ICON_MODELE_PREVIOUS_VERSIONS_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_EXECUTE_DISABLE", imgStyle, ICON_MODELE_EXECUTE_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_MODIFY_DISABLE", imgStyle, ICON_MODELE_MODIFY_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_DELETE_DISABLE", imgStyle, ICON_MODELE_DELETE_DISABLE);
			sb.append(rendered);
		}
		else if (value.getNVersion() > 0){
			rendered = templates.cell("ICON_MODELE_PUBLIC_DISABLE", imgStyle, ICON_MODELE_PUBLIC_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_PREVIOUS_VERSIONS", imgStyle, ICON_MODELE_PREVIOUS_VERSIONS);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_EXECUTE_DISABLE", imgStyle, ICON_MODELE_EXECUTE_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_MODIFY_DISABLE", imgStyle, ICON_MODELE_MODIFY_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_DELETE_DISABLE", imgStyle, ICON_MODELE_DELETE_DISABLE);
			sb.append(rendered);
		}
		else {
			rendered = templates.cell("ICON_MODELE_PUBLIC_DISABLE", imgStyle, ICON_MODELE_PUBLIC_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_PREVIOUS_VERSIONS_DISABLE", imgStyle, ICON_MODELE_PREVIOUS_VERSIONS_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_EXECUTE_DISABLE", imgStyle, ICON_MODELE_EXECUTE_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_MODIFY_DISABLE", imgStyle, ICON_MODELE_MODIFY_DISABLE);
			sb.append(rendered);
			rendered = templates.cell("ICON_MODELE_UNDELETE", imgStyle, ICON_MODELE_UNDELETE);
			sb.append(rendered);
			
		}
	}

	private static SafeHtml makeImage(ImageResource resource) {
		AbstractImagePrototype proto = AbstractImagePrototype.create(resource);
		return proto.getSafeHtml();
	}

	@Override
	public HandlerRegistration addSelectHandler(SelectHandler handler) {
		return addHandler(handler, SelectEvent.getType());
	}

	public abstract void onModelePublic(ModeleModel modele);

	public abstract void onModelePreviousVersion(ModeleModel modele);

	public abstract void onModeleExecute(ModeleModel modele);

	public abstract void onModeleModify(ModeleModel modele);

	public abstract void onModeleDelete(ModeleModel modele);
//
//	public abstract void onModelePublicDisable(ModeleModel modele);
//
//	public abstract void onModelePreviousVersionDisable(ModeleModel modele);
//
//	public abstract void onModeleExecuteDisable(ModeleModel modele);
//
//	public abstract void onModeleModifyDisable(ModeleModel modele);
//
//	public abstract void onModeleDeleteDisable(ModeleModel modele);

	public abstract void onModeleUndelete(ModeleModel modele);

}
