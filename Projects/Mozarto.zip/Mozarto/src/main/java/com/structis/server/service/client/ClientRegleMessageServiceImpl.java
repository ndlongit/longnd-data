package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoadResultBean;
import com.structis.client.service.ClientRegleMessageService;
import com.structis.server.service.domain.MessageService;
import com.structis.server.service.domain.ModelisateurRegleMessageService;
import com.structis.server.service.domain.RegleService;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;
import com.structis.shared.model.reference.RuleConflictInfo;
import com.structis.shared.model.reference.TreeNodeModel;

@Service
public class ClientRegleMessageServiceImpl implements ClientRegleMessageService {

	@Autowired
	RegleService regleService;
	
	@Autowired
	MessageService messageService;
	
	@Autowired
	ModelisateurRegleMessageService modelisateurRegleMessageService;
	
	@Override
	public ModelisateurRegleMessageListModel insertRegle(Integer idUser,TreeNodeModel source, TreeNodeModel target, Integer priorite, Integer quantite) {
		return modelisateurRegleMessageService.insertRegle(idUser,source, target, priorite, quantite);
	}

	@Override
	public List<ModelisateurRegleMessageListModel> findMessageRegleList(TreeNodeModel item) {
		return modelisateurRegleMessageService.findRegleMessageList(item,true,true);
	}

	@Override
	public RuleConflictInfo checkConflict(TreeNodeModel sourceNode, TreeNodeModel targetNode, int priorite, int quantite, boolean isUpdate) {
		return regleService.checkConflict(sourceNode, targetNode, priorite, quantite, isUpdate);
	}

	@Override
	public ModelisateurRegleMessageListModel updateRegle(Integer idUser,int idRegle, TreeNodeModel target,
			Integer priorite, Integer quantite) {
		return modelisateurRegleMessageService.updateRegle(idUser,idRegle, target, priorite, quantite);
	}

	@Override
	public void cancelInheritageRegle(Integer idUser,TreeNodeModel sourceNode, int idRegle) {
		regleService.cancelInheritage(idUser,sourceNode, idRegle);
	}

	@Override
	public void cancelInheritageMessage(Integer idUser,TreeNodeModel sourceNode, int idMessage) {
		messageService.cancelInheritage(idUser,sourceNode, idMessage);
	}

	@Override
	public void deleteRegle(Integer idUser,TreeNodeModel sourceNode, int idRegle) {
		regleService.delete(idUser,sourceNode, idRegle);
	}

	@Override
	public ModelisateurRegleMessageListModel insertMessage(Integer idUser, TreeNodeModel source, String libelle, Integer priorite) {
  		return modelisateurRegleMessageService.insertMessage(idUser, source, priorite, libelle);
	}

	@Override
	public ModelisateurRegleMessageListModel updateMessage(Integer idUser, Integer idMessage, String libelle,
			Integer priorite) {
		return modelisateurRegleMessageService.updateMessage(idUser, idMessage, libelle, priorite);
	}

	@Override
	public void deleteMessage(Integer idUser, TreeNodeModel sourceNode, int idMessage) {
		messageService.delete(idUser, sourceNode, idMessage);
	}

	@Override
	public List<ModelisateurRegleMessageListModel> findReglePointToElement(TreeNodeModel item) {
		return modelisateurRegleMessageService.findReglePointToElement(item);
	}

	@Override
	public PagingLoadResult<ModelisateurRegleMessageListModel> findMessageRegleListPaging(TreeNodeModel item,
			PagingLoadConfig loadConfig) {
		List<ModelisateurRegleMessageListModel> allRegleMessageList =  modelisateurRegleMessageService.findRegleMessageList(item,true,true);
		
		List<ModelisateurRegleMessageListModel> resullist = new ArrayList<ModelisateurRegleMessageListModel>();
	    int start = loadConfig.getOffset();
	    int limit = allRegleMessageList.size();
	    if (loadConfig.getLimit() > 0) {
	      limit = Math.min(start + loadConfig.getLimit(), limit);
	    }
	    
	    for(int i=loadConfig.getOffset(); i< limit ; i++){
	    	resullist.add(allRegleMessageList.get(i));
	    }
	    
		return new PagingLoadResultBean<ModelisateurRegleMessageListModel>(resullist, allRegleMessageList.size(), loadConfig.getOffset());
	}

	@Override
	public PagingLoadResult<ModelisateurRegleMessageListModel> findReglePointToElementPaging(TreeNodeModel item,
			PagingLoadConfig loadConfig) {
		List<ModelisateurRegleMessageListModel> allItems = modelisateurRegleMessageService.findReglePointToElement(item);
		
		List<ModelisateurRegleMessageListModel> resullist = new ArrayList<ModelisateurRegleMessageListModel>();
	    int start = loadConfig.getOffset();
	    int limit = allItems.size();
	    if (loadConfig.getLimit() > 0) {
	      limit = Math.min(start + loadConfig.getLimit(), limit);
	    }
	    
	    for(int i=loadConfig.getOffset(); i< limit ; i++){
	    	resullist.add(allItems.get(i));
	    }
	    
		return new PagingLoadResultBean<ModelisateurRegleMessageListModel>(resullist, allItems.size(), loadConfig.getOffset());
	}
	
}
