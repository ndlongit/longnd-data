package com.structis.client.navigation;

import static com.structis.shared.security.Role.ANONYMOUS;

import com.structis.shared.security.Role;

/**
 * Enum for each Action, to add an action start here
 * It's defined to make sure that the call is made on an existing action
 * Naming rule:
 * <ul> 
 * 	<li>To Enum : ACTION_ + <Name of action></li>
 * 	<li>To Label : action+ <Name of label></li>
 * </ul>
 * 
 * 
 *
 */
public enum Action {

	ACTION_ACCEUIL("acceuil", ANONYMOUS), 
	ACTION_LOGIN("actionLogin", ANONYMOUS),
	ACTION_MODELISATEUR_ACCEUI("actionModelisateurAccueil", ANONYMOUS),
	ACTION_MODELISATEUR("actionModelisateurModelisateur", ANONYMOUS),
	ACTION_COMPOSITEUR_ACCEUI("actionCompositeurAccueil", ANONYMOUS),
	ACTION_COMPOSITEUR("actionCompositeur", ANONYMOUS),
	ACTION_GESTION_DES_METIERS("actionGestionDesMetiers", ANONYMOUS),
	ACTION_GESTION_DU_METIER("actionGestionDuMetier", ANONYMOUS),
	ACTION_GESTION_DES_UTILISATEURS_ADMINGENERAL("actionGestionDesUtilisateursAdminGeneral", ANONYMOUS),
	ACTION_GESTION_DES_UTILISATEURS("actionGestionDesUtilisateurs", ANONYMOUS),
	ACTION_GESTION_DES_ELEMENTS_DE_COMPOSITION("actionGestionDesElementsDeComposition", ANONYMOUS);
	private Action(String label, Role role){
		this.label = label;
		this.role = role;
	}
	
	/**
	 * Label Label of the action is associated with resource bundle
	 */
	private final String label;
	
	/**
	 * Role to access the action
	 */
	private final Role role;

	public String getLabel() {
		return label;
	}

	public Role getRole() {
		return role;
	}
	
}

