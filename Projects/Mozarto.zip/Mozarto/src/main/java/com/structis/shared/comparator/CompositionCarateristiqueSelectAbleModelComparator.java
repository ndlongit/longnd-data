package com.structis.shared.comparator;

import java.util.Comparator;

import com.structis.shared.model.reference.CompositionCarateristiqueSelectAbleModel;

public class CompositionCarateristiqueSelectAbleModelComparator implements Comparator<CompositionCarateristiqueSelectAbleModel>{
	public int column=0;
	@Override
	public int compare(CompositionCarateristiqueSelectAbleModel o1, CompositionCarateristiqueSelectAbleModel o2) {
		int result = 0;
		if(o1.getLevel() > o2.getLevel()){
			result = 1;
		}else if(o1.getLevel() < o2.getLevel()){
			result = -1;
		}else{
			if(o1.getNRang() > o2.getNRang()){
				result = 1;
			}else if(o1.getNRang() < o2.getNRang()){
				result = -1;
			}
		}
		return result;
	}

}
