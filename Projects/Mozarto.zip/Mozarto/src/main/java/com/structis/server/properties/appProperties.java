package com.structis.server.properties;

public class appProperties {

	/* Repository rest */
	public static String sessionTimeout;

	private String uploadFolder;

	@SuppressWarnings("static-access")
	public void setSessionTimeout(String sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}

	public String getSessionTimeout() {
		return sessionTimeout;
	}

	public String getUploadFolder() {
		return uploadFolder;
	}

	public void setUploadFolder(String uploadFolder) {
		this.uploadFolder = uploadFolder;
	}
}
