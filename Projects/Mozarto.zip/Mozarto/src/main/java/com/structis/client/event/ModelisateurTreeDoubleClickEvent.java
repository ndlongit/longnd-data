package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurTreeDoubleClickEvent extends GwtEvent<ModelisateurTreeDoubleClickHandler> {

	private static Type<ModelisateurTreeDoubleClickHandler> TYPE = new Type<ModelisateurTreeDoubleClickHandler>();

	public static Type<ModelisateurTreeDoubleClickHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<ModelisateurTreeDoubleClickHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(ModelisateurTreeDoubleClickHandler handler) {
		handler.onLoad(this);
	}

	private TreeNodeModel treeNode;

	public ModelisateurTreeDoubleClickEvent(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}

	public TreeNodeModel getTreeNode() {
		return treeNode;
	}

	public void setTreeNode(TreeNodeModel treeNode) {
		this.treeNode = treeNode;
	}

}
