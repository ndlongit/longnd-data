package com.structis.client.panel.validator;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.editor.client.Editor;
import com.google.gwt.editor.client.EditorError;
import com.sencha.gxt.widget.core.client.form.Validator;
import com.sencha.gxt.widget.core.client.form.error.DefaultEditorError;
import com.structis.client.message.ErrorMessages;


@SuppressWarnings("rawtypes")
public class DupplicateValidator implements Validator {
		private final ErrorMessages errorMessages = GWT.create(ErrorMessages.class);		
		@Override
		public List validate(Editor editor, Object value) {
			final String errorMessage = errorMessages.f009();
			List<EditorError> list = new ArrayList<EditorError>();			
			list.add( new DefaultEditorError(editor,errorMessage, value));											   
			 return list;
		} 
}
