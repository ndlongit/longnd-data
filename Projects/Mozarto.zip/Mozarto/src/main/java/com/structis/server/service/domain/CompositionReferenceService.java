package com.structis.server.service.domain;

import java.util.List;

import com.structis.shared.model.CmpReference;

public interface CompositionReferenceService {
	void insertList(List<CmpReference> cmpReferences);
	
	List<CmpReference> findByIdComposition(Integer idComposition);
	 
	void deleteByIdComposition(Integer idComposition); 
}
