package com.structis.client.widget;

import com.google.gwt.cell.client.ImageCell;

public class IconCell<C> extends ImageCell {

}
