package com.structis.server.service.domain.report;

import com.structis.shared.model.report.ReportConfig;
import com.structis.shared.model.report.ReportData;

public interface ReportService {

	public static final String SERVICE_NAME = "reportService";

	ReportConfig getReportConfig();

	ReportData getHeaderInfo();

	ReportData getModelInfo();

	ReportData getReportData();
}
