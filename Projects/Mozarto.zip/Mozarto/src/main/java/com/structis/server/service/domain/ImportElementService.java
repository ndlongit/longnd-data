package com.structis.server.service.domain;

import java.util.List;
import java.util.Map;

import org.springframework.context.support.ResourceBundleMessageSource;

import com.structis.shared.model.ImportElement;

public interface ImportElementService {

	public static final String SERVIECE_NAME = "importElementService";

	public ImportElement findById(Integer id);

	public Integer insert(ImportElement record);

	public Integer update(ImportElement record);

	public Integer delete(ImportElement record);

	public Integer deleteById(Integer id);

	public List<ImportElement> findAll();

	public List<Integer> getAllLinesByImportId(Integer importId);

	@SuppressWarnings("rawtypes")
	public List<Map> findByImportIdAndLineNumber(Integer importId, Integer lineNumber);

	String saveAttributeValuePairs(int startAttributeValueIndex, int endAttributeValueIndex, String[] headerColums,
			String[] row, int line, int metierId, int idImport, String attributeType, String valueType,
			String attributEtenduType, String csvError, String currentSubModel,
			Map<String, List<String>> subModelAttributeMap, ResourceBundleMessageSource messageSource);

	void importElementToMozarto(Integer importId, int metierId, List<String[]> csvData, ResourceBundleMessageSource messageSource) throws Exception;

	public List<ImportElement> findByBaseCriteria(ImportElement criteria);
}
