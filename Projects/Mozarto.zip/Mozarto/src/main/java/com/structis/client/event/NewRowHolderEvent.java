package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class NewRowHolderEvent extends GwtEvent<NewRowHolderHandler> {

	private static Type<NewRowHolderHandler> TYPE = new Type<NewRowHolderHandler>();

	public static Type<NewRowHolderHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<NewRowHolderHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(NewRowHolderHandler handler) {
		handler.onLoad(this);
	}

		

}
