package com.structis.client.panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.text.shared.AbstractSafeHtmlRenderer;
import com.sencha.gxt.cell.core.client.form.ComboBoxCell.TriggerAction;
import com.sencha.gxt.core.client.XTemplates;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutPack;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.ComboBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.structis.client.event.ModifyEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.RoleUtilisateurProperties;
import com.structis.client.service.ClientGestionUtilisateursServiceAsync;
import com.structis.client.widget.HtmlButton;
import com.structis.shared.model.RoleUtilisateur;
import com.structis.shared.model.Utilisateur;

public class GestionDesUtilisateursForm extends ContentPanel {

	private SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private String tabLabel = "";

	private Utilisateur utilisateur;

	private FieldSet statutFieldSet;

	private ComboBox<RoleUtilisateur> role;

	private FieldSet infoFieldSet;

	private TextButton validerButton;

	private HtmlButton annulerButton;

	private ListStore<RoleUtilisateur> roleStore;

	private boolean isReadOnly = false;

	private VerticalLayoutContainer infoContainer;

	private VerticalLayoutContainer statutContainer;

	private VerticalLayoutContainer container;

	private TextField nom;

	private TextField prenom;

	private TextField mail;

	private boolean isChanged = false;

	private Integer idMetier;
	
	private Integer idUtilisateurLogin;
	
	private NavigationService navigation = NavigationFactory.getNavigation();

	interface ComboBoxTemplates extends XTemplates {

		@XTemplate("<div  style = \"height:11px;\" >&nbsp;{lLibelle}</div>")
		SafeHtml state(String lLibelle);

	}

	public GestionDesUtilisateursForm(SimpleEventBus bus) {
		idUtilisateurLogin = navigation.getContext().getUtilisateur().getIdUtilisateur();
		this.bus = bus;
		buildForm();
		addHandler();
	}

	private void buildForm() {
		setHeaderVisible(false);
		container = new VerticalLayoutContainer();
		statutFieldSet = new FieldSet();
		statutFieldSet.setHeadingText(messages.utilisateursStatut());

		RoleUtilisateurProperties properties = GWT.create(RoleUtilisateurProperties.class);
		roleStore = new ListStore<RoleUtilisateur>(properties.cRole());
		role = new ComboBox<RoleUtilisateur>(
				roleStore, properties.lLibelle(), new AbstractSafeHtmlRenderer<RoleUtilisateur>() {

					@Override
					public SafeHtml render(RoleUtilisateur item) {
						final ComboBoxTemplates comboBoxTemplates = GWT.create(ComboBoxTemplates.class);
						return comboBoxTemplates.state(item.getLLibelle());
					}
				});
		role.setTriggerAction(TriggerAction.ALL);
		statutContainer = new VerticalLayoutContainer();
		statutContainer.getElement().setPadding(new Padding(10, 20, 10, 20));
		statutFieldSet.add(statutContainer);
		statutContainer.add(role, new VerticalLayoutData(1, 1));

		container.add(statutFieldSet);
		infoFieldSet = new FieldSet();
		infoFieldSet.setHeadingText(messages.utilisateursInfo());
		container.add(infoFieldSet);
		infoContainer = new VerticalLayoutContainer();
		infoFieldSet.add(infoContainer);

		nom = new TextField();
		nom.setReadOnly(true);
		infoContainer.add(new FieldLabel(nom, messages.utilisateursNom()), new VerticalLayoutData(1, -1));
		prenom = new TextField();
		prenom.setReadOnly(true);
		infoContainer.add(new FieldLabel(prenom, messages.utilisateursPrenom()), new VerticalLayoutData(1, -1));
		mail = new TextField();
		mail.setReadOnly(true);
		infoContainer.add(new FieldLabel(mail, messages.utilisateursMail()), new VerticalLayoutData(1, -1));
		infoContainer.getElement().setPadding(new Padding(10, 20, 10, 20));

		add(container);
		annulerButton = new HtmlButton(messages.commonAnnulerButton());
		annulerButton.setStyleName("htmlLink");
		addButton(annulerButton);

		validerButton = new TextButton(messages.commonValiderButton());
		addButton(validerButton);
		setButtonAlign(BoxLayoutPack.CENTER);
		getButtonBar().setSpacing(30);
		getBody().setBorders(false);
		enableButtons(false);

	}

	protected void addHandler() {
		addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent arg0) {
				container.setWidth(arg0.getWidth());
				container.setHeight(arg0.getHeight());
			}
		});
		container.addResizeHandler(new ResizeHandler() {

			@Override
			public void onResize(ResizeEvent arg0) {
				statutFieldSet.setWidth(arg0.getWidth());
				infoFieldSet.setWidth(arg0.getWidth());
			}
		});
		validerButton.addSelectHandler(new SelectHandler() {
			
			@Override
			public void onSelect(SelectEvent event) {
				validerForm();
			}
		});
		annulerButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				annulerForm();
			}
		});
		role.addSelectionHandler(new SelectionHandler<RoleUtilisateur>() {

			@Override
			public void onSelection(SelectionEvent<RoleUtilisateur> arg0) {
				toggleChange(true);
			}
		});
	}

	public void validerForm() {
		if(idUtilisateurLogin != null && idUtilisateurLogin.equals(utilisateur.getIdUtilisateur())){
			MessageBox box = new MessageBox(messages.commonInfoHeader(), messages.utilisateursModifnonautorisee());
			box.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
			box.show();
			box.addHideHandler(new HideHandler() {
				
				@Override
				public void onHide(HideEvent event) {
					fillInfo(utilisateur);
					enableButtons(false);
				}
			});
			return;
		}
		String cRole;
		if (role.getValue() != null)
			cRole = role.getValue().getCRole();
		else 
			cRole = null;
		ClientGestionUtilisateursServiceAsync.Util.getInstance().updateRoleUtilisateur(
				utilisateur.getIdUtilisateur(), idMetier, cRole,
				new AsyncCallbackWithErrorResolution<Integer>() {

					@Override
					public void onSuccess(Integer arg0) {
						toggleChange(false);
					}
				});
	}

	public void annulerForm() {
		ConfirmMessageBox messageBox = new ConfirmMessageBox(
				messages.commonConfirmation(), messages.utilisateursAnnulermessage());
		messageBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonOui());
		messageBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonNon());
		messageBox.getButtonById(PredefinedButton.YES.name()).addSelectHandler(new SelectHandler() {

			@Override
			public void onSelect(SelectEvent event) {
				fillInfo(utilisateur);
				toggleChange(false);
			}
		});
		messageBox.show();
	}

	public void setTabLabel(String tabLabel) {
		this.tabLabel = tabLabel;
	}

	public String getTabLabel() {
		return tabLabel;
	}

	public void fillInfo(Utilisateur utilisateur) {
		nom.setText(utilisateur.getLNom());
		prenom.setText(utilisateur.getLPrenom());
		mail.setText(utilisateur.getLMail());
		Integer idUtilisateur = utilisateur.getIdUtilisateur();
		ClientGestionUtilisateursServiceAsync.Util.getInstance().findRoleByUtilisateurAndMetier(
				idUtilisateur, idMetier, new AsyncCallbackWithErrorResolution<RoleUtilisateur>() {

					@Override
					public void onSuccess(RoleUtilisateur arg0) {
						role.setValue(arg0);
					}
				});
	}

	public void enableButtons(boolean enable) {
		annulerButton.setEnable(enable);
		validerButton.setEnabled(enable);
	}

	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	public Utilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setRoleStore(ListStore<RoleUtilisateur> roleStore) {
		this.roleStore = roleStore;
	}

	public ListStore<RoleUtilisateur> getRoleStore() {
		return roleStore;
	}

	public void setReadOnly(boolean isReadOnly) {
		this.isReadOnly = isReadOnly;
		role.setReadOnly(!isReadOnly);
	}

	public boolean isReadOnly() {
		return isReadOnly;
	}

	public void setChanged(boolean isChanged) {
		this.isChanged = isChanged;
	}

	public boolean isChanged() {
		return isChanged;
	}

	public Integer getIdMetier() {
		return idMetier;
	}

	public void setIdMetier(Integer idMetier) {
		this.idMetier = idMetier;
	}

	protected void toggleChange(boolean changed) {
		enableButtons(changed);
		if(isChanged != changed){
			bus.fireEvent(new ModifyEvent(!changed));
		}
		isChanged = changed;
	}
}
