package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.structis.shared.model.reference.MetierMzPzModel;

public class GestionDuMetierAddTabEvent extends GwtEvent<GestionDuMetierAddTabHandler> {

	private static Type<GestionDuMetierAddTabHandler> TYPE = new Type<GestionDuMetierAddTabHandler>();
	
	private MetierMzPzModel metier;

	public static Type<GestionDuMetierAddTabHandler> getType() {
		return TYPE;
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GestionDuMetierAddTabHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GestionDuMetierAddTabHandler handler) {
		handler.onLoad(this);
	}

	public GestionDuMetierAddTabEvent(MetierMzPzModel metier) {
		this.metier = metier;
	}

	public void setMetier(MetierMzPzModel metier) {
		this.metier = metier;
	}

	public MetierMzPzModel getMetier() {
		return metier;
	}

}
