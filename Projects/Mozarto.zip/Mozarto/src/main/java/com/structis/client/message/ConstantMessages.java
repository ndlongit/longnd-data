package com.structis.client.message;

import com.google.gwt.i18n.client.ConstantsWithLookup;

/**
 * This interface is to store messages containing {}
 * 
 *
 */
public interface ConstantMessages extends ConstantsWithLookup {
	
	/* ### Les actions */
	@Key("relation1")
	String relation1();
	@Key("relation2")
	String relation2();
	@Key("relation3")
	String relation3();
	@Key("relation4")
	String relation4();
	@Key("relation5")
	String relation5();
	@Key("relation6")
	String relation6();
}
