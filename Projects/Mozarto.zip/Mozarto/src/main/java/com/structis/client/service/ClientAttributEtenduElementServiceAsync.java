package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.structis.shared.model.AttributEtenduElement;

public interface ClientAttributEtenduElementServiceAsync {
	public static class Util {

		private static ClientAttributEtenduElementServiceAsync instance = GWT
				.create(ClientAttributEtenduElementService.class);
	
		public static ClientAttributEtenduElementServiceAsync getInstance() {
			return instance;
		}
		
	}
	public void insert (List<AttributEtenduElement> attributEtenduElement, AsyncCallback<List<AttributEtenduElement>> callback);
}
