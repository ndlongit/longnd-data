package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.MetierMzPzModel;

public interface ClientGestionMetierServiceAsync {
	public static class Util {

		private static ClientGestionMetierServiceAsync instance = GWT
				.create(ClientGestionMetierService.class);
	
		public static ClientGestionMetierServiceAsync getInstance() {
			return instance;
		}
		
	}
	
	public void findAll(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<MetierMzPzModel>> callback);
	
	public void insertOrUpdate(MetierMzPzModel metier, List<AttributEtendu> attributEtendus, AsyncCallback<Metier> callback);
}
