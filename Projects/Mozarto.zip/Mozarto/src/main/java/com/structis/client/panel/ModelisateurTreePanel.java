package com.structis.client.panel;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Stack;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.Node;
import com.google.gwt.dom.client.Style.Cursor;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.core.client.Style.SelectionMode;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.TreeStore;
import com.sencha.gxt.data.shared.loader.ChildTreeStoreBinding;
import com.sencha.gxt.data.shared.loader.TreeLoader;
import com.sencha.gxt.dnd.core.client.DndDropEvent;
import com.sencha.gxt.dnd.core.client.TreeGridDragSource;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer.BoxLayoutData;
import com.sencha.gxt.widget.core.client.container.HBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.CellClickEvent;
import com.sencha.gxt.widget.core.client.event.CellClickEvent.CellClickHandler;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.event.ExpandItemEvent;
import com.sencha.gxt.widget.core.client.event.ExpandItemEvent.ExpandItemHandler;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.GridViewConfig;
import com.sencha.gxt.widget.core.client.menu.Item;
import com.sencha.gxt.widget.core.client.menu.Menu;
import com.sencha.gxt.widget.core.client.menu.MenuItem;
import com.sencha.gxt.widget.core.client.menu.SeparatorMenuItem;
import com.sencha.gxt.widget.core.client.treegrid.TreeGridView;
import com.structis.client.event.MaskEvent;
import com.structis.client.event.MaskHandler;
import com.structis.client.event.ModelisateurAddTabEvent;
import com.structis.client.event.ModelisateurCloseTabEvent;
import com.structis.client.event.ModelisateurTreeCopyEvent;
import com.structis.client.event.ModelisateurTreeCopyHandler;
import com.structis.client.event.ModelisateurTreeDoubleClickEvent;
import com.structis.client.event.ModelisateurTreeDoubleClickHandler;
import com.structis.client.event.ModifyEvent;
import com.structis.client.event.RemoveNodeEvent;
import com.structis.client.event.RemoveNodeHandler;
import com.structis.client.event.RenameTreeNodeEvent;
import com.structis.client.event.RenameTreeNodeHandler;
import com.structis.client.event.TargetElementSelectEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.service.ClientCaracteristiqueServiceAsync;
import com.structis.client.service.ClientModelisateurServiceAsync;
import com.structis.client.util.AppUtil;
import com.structis.client.util.NameValuePair;
import com.structis.client.util.ReportUtil;
import com.structis.client.widget.CopierSubMenu;
import com.structis.client.widget.CustomizeConfirmMessageBox;
import com.structis.client.widget.CustomizeTreeGrid;
import com.structis.client.widget.CustomizeTreeGridDropTarget;
import com.structis.client.widget.FileImportDialog;
import com.structis.client.widget.SupprimerMenu;
import com.structis.client.widget.TreeMenuIcon;
import com.structis.server.constant.ConstantServer;
import com.structis.shared.constant.Constant;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.constant.Niveau;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.TreeNodeModel;
import com.structis.shared.model.reference.TreeNodeRegleModel;

public class ModelisateurTreePanel extends VerticalLayoutContainer {
	private SimpleEventBus bus;
	
	private Menu contextMenu1;
	private Menu contextMenu2;

	private Messages messages = GWT.create(Messages.class);

	private TreeGridDragSource<TreeNodeModel> treeDragSource;

	private HTML parameterButton;

	private CheckBox parameterCheckBox;

	private int cx = 0;

	private int cy = 0;

	private NavigationService navigation = NavigationFactory.getNavigation();

	private VerticalLayoutContainer parametreContainer;

	private Image parameterButtonIcon;

	private Image isMulIcon;
	
	public static boolean expanded = false;
	
	private Label parametreLabel;
	
	TreeMenuIcon menuIcon = new TreeMenuIcon();
	
	private TreeNodeModel nodeToBeCopied;
	
	private boolean copierRegles = true;
	
	private boolean copierMessages = true;
	
	private boolean copierDescendances = true;
	
	//TextButton buttonMenu = new TextButton("ButtonMenu");
	
	
	
	class KeyProvider implements ModelKeyProvider<TreeNodeModel> {
		@Override
		public String getKey(TreeNodeModel item) {	
			if (item != null)
				return AppUtil.getTabId(item);
			return "";
			//return KeyNodeGenerator.gernerateKey(item);
		}
	}

	private TreeStore<TreeNodeModel> treeStore;

	private CustomizeTreeGrid<TreeNodeModel> tree;

	private TreeNodeModel modelisaterModel;
	
	private int idModeleVersion;
	
	private Integer idMetier;
	
	private Integer idUtilisateur;

	private MenuItem supprimerItem2;

	private SeparatorMenuItem separator;

	private HBoxLayoutContainer hPanel;

	private MenuItem collerItem;

//	private Menu contextMenu3;
	
	public ModelisateurTreePanel(final SimpleEventBus bus) {
		this.idMetier = navigation.getContext().getMetier().getIdMetier();
		this.idUtilisateur = navigation.getContext().getUtilisateur().getIdUtilisateur();
		this.bus = bus;
		buildPanel();
		addHandler();
	}

	

	private void buildPanel() {
		/*buttonMenu.setIcon(Images.RESOURCES.treeMenuIconClose());
		buttonMenu.setShadow(false);*/
		addStyleName("whiteBackGround");
		//setScrollMode(ScrollMode.AUTO);
		Images bundle = GWT.create(Images.class);

		RpcProxy<TreeNodeModel, List<TreeNodeModel>> proxy = new RpcProxy<TreeNodeModel, List<TreeNodeModel>>() {

			@Override
			public void load(TreeNodeModel loadConfig, AsyncCallback<List<TreeNodeModel>> callback) {
				ClientModelisateurServiceAsync.Util.getInstance().getFolderChildren(
						loadConfig, parameterCheckBox.getValue(), callback);
			}
		};

		final TreeLoader<TreeNodeModel> loader = new TreeLoader<TreeNodeModel>(proxy) {
			@Override
			public boolean hasChildren(TreeNodeModel parent) {
				return parent.isHasChildren();
			}
		};

		//TreeNodeModelProperties nodeProperties = GWT.create(TreeNodeModelProperties.class);

		treeStore = new TreeStore<TreeNodeModel>(new KeyProvider());
		loader.addLoadHandler(new ChildTreeStoreBinding<TreeNodeModel>(treeStore));

		final ColumnConfig<TreeNodeModel, TreeNodeModel> ccLibelle = new ColumnConfig<TreeNodeModel, TreeNodeModel>(
				new IdentityValueProvider<TreeNodeModel>(), 200);
		ccLibelle.setMenuDisabled(true);
		ccLibelle.setSortable(false);
		ccLibelle.setCell(new AbstractCell<TreeNodeModel>() {
			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, TreeNodeModel value, SafeHtmlBuilder sb) {
				String label = value.getLibelle();
				if( value instanceof TreeNodeRegleModel ) {
					TreeNodeRegleModel node = (TreeNodeRegleModel) value;
					if( Niveau.CONSEILLEE.getIndex() == node.getRelation() ) {
						sb.appendHtmlConstant("<span class='treeRegleNode' title=\""+label+"\" >" + label + "</span>");
					}
					else if( Niveau.INDISPENSABLE.getIndex() == node.getRelation() ) {
						sb.appendHtmlConstant("<span class='treeRegleNodeGrey' title=\""+label+"\" >" + label + "</span>");
					}
					else if( Niveau.INTERDITE.getIndex() == node.getRelation() ) {
						sb.appendHtmlConstant("<span class='treeRegleNodeStrikeGrey' title=\""+label+"\" >" + label + "</span>");
					}
				}
				else {
					sb.appendHtmlConstant("<span class='treeNode' title=\""+label+"\"  >" +label + "</span>");
				}
			}
		});
		
		ColumnConfig<TreeNodeModel, TreeNodeModel> ccMenu = new ColumnConfig<TreeNodeModel, TreeNodeModel>(
				new IdentityValueProvider<TreeNodeModel>(), 26);
		ccMenu.setCell(new AbstractCell<TreeNodeModel>() {
			@Override
			public void render(com.google.gwt.cell.client.Cell.Context context, TreeNodeModel value, SafeHtmlBuilder sb) {
				if( !(value instanceof TreeNodeRegleModel) ){
					sb.appendHtmlConstant("<span id='"+value.hashCode()+"' style='visibility:hidden;'  ></span>");
				}
			}
		});
		
		
		List<ColumnConfig<TreeNodeModel, ?>> listColumm = new ArrayList<ColumnConfig<TreeNodeModel, ?>>();
		listColumm.add(ccLibelle);
		listColumm.add(ccMenu);
		
		ColumnModel<TreeNodeModel> cm = new ColumnModel<TreeNodeModel>(listColumm);
		tree = new CustomizeTreeGrid<TreeNodeModel>(treeStore, cm, ccLibelle);
		TreeGridView<TreeNodeModel> treeGridView = new TreeGridView<TreeNodeModel>();
		treeGridView.setViewConfig(new GridViewConfig<TreeNodeModel>() {
			
			@Override
			public String getRowStyle(TreeNodeModel model, int rowIndex) {
				return "treeNode";
			}
			@Override
			public String getColStyle(TreeNodeModel model, ValueProvider<? super TreeNodeModel, ?> valueProvider, int rowIndex,
					int colIndex) {
				return null;
			}
		});
		tree.setView(treeGridView);
		//treeGridView.setForceFit(true);
		tree.setBorders(true);
		tree.setTreeLoader(loader);
		tree.getView().setTrackMouseOver(false);
		tree.getView().setAutoExpandColumn(ccLibelle);
		tree.getView().setEnableRowBody(false);
		//tree.getView().setAutoFill(true);
		tree.getView().setColumnLines(false);
		tree.getView().setAdjustForHScroll(true);
		//tree.getView().setForceFit(true);
		tree.getStyle().setJointCloseIcon(bundle.plus());
		tree.getStyle().setJointOpenIcon(bundle.minus());
		tree.getStyle().setLeafIcon(bundle.java());
		tree.setAutoLoad(false);
		tree.setLoadMask(true);
		tree.setHideHeaders(true);
		tree.setLazyRowRender(10);
		//tree.setAutoExpand(true);
		tree.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		tree.setBorders(false);
		tree.setCaching(true);
		
		//tree.setView(treeGridView);
		CustomizeTreeGridDropTarget<TreeNodeModel> customizedTreeDragTarget = new CustomizeTreeGridDropTarget<TreeNodeModel>(
				tree, bus);
		customizedTreeDragTarget.setAllowDropOnLeaf(true);
		customizedTreeDragTarget.setAddChildren(true);

		treeStore.clear();
		
		buildContextMenu();
		
		//tree.setContextMenu(contextMenu2);
		//loader.load();
		//		FieldSet treeFielSet = new FieldSet();
		//		treeFielSet.setHeadingHtml(messages.modelisateurLabel());
		//		treeFielSet.setStyleName("fieldsetPadding");

		hPanel = new HBoxLayoutContainer();
		parametreLabel = new Label(messages.modelisateurParametresLabel());
		parametreLabel.setStyleName("htmlLink");
		hPanel.add(parametreLabel);
		BoxLayoutData flex = new BoxLayoutData(new Margins(0, 5, 0, 0));
		flex.setFlex(1);
		hPanel.add(new Label(), flex);
		parameterButtonIcon = new Image();
		parameterButtonIcon.setResource(Images.RESOURCES.arrowDown());
		parameterButtonIcon.getElement().getStyle().setCursor(Cursor.POINTER);
		hPanel.add(parameterButtonIcon);
		hPanel.getElement().getStyle().setProperty("minWidth", "200px");
		
		parameterCheckBox = new CheckBox();
		parameterCheckBox.setBoxLabel(messages.modelisateurParametresCheckboxLabel());
		parameterCheckBox.setVisible(false);
		VerticalLayoutContainer parametreContainer = new VerticalLayoutContainer();
		parametreContainer.setBorders(true);
		parametreContainer.addStyleName("fieldsetPadding");
		parametreContainer.add(hPanel, new VerticalLayoutData(1, -1));
		parametreContainer.add(parameterCheckBox, new VerticalLayoutData(1, -1));
		
		HBoxLayoutContainer hPanelCompositionMultiParameter = new HBoxLayoutContainer();
		BoxLayoutData flex1 = new BoxLayoutData(new Margins(0, 5, 0, 0));
		flex1.setFlex(1);
		hPanelCompositionMultiParameter.add(new Label(), flex);
		isMulIcon = new Image();
		isMulIcon.setResource(Images.RESOURCES.uncheckIcon());
		hPanelCompositionMultiParameter.add(isMulIcon);
		//add(hPanelCompositionMultiParameter, new VerticalLayoutData(1, -1));
		add(new HTML(messages.modelisateurLabel()), new VerticalLayoutData(1, -1));
		add(parametreContainer, new VerticalLayoutData(1, -1));
		add(tree, new VerticalLayoutData(1, 1));
		tree.getView().setAutoFill(true);
	}

	private void toogleParameter() {
		if( parameterCheckBox.isVisible() ) {
			parameterCheckBox.setVisible(false);
			parameterButtonIcon.setResource(Images.RESOURCES.arrowDown());
		}
		else {
			parameterCheckBox.setVisible(true);
			parameterButtonIcon.setResource(Images.RESOURCES.arrowUp());
		}

	}

	private void addHandler() {
		hPanel.addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent arg0) {
				if(arg0.getWidth() > 25)
				parametreLabel.setWidth(arg0.getWidth() - 25 + "");
			}
		});
		parameterButtonIcon.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				toogleParameter();

			}
		});
		parametreLabel.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				toogleParameter();
			}
		});
		/*
		 * parameterCheckBox.addChangeHandler(new ChangeHandler() {
		 * @Override public void onChange(ChangeEvent event) { loadTree(); } });
		 */
		parameterCheckBox.addValueChangeHandler(new ValueChangeHandler<Boolean>() {

			@Override
			public void onValueChange(ValueChangeEvent<Boolean> event) {
				loadTree(idModeleVersion);
			}
		});
		
		
		tree.addExpandHandler(new ExpandItemHandler<TreeNodeModel>() {

			@Override
			public void onExpand(ExpandItemEvent<TreeNodeModel> event) {
				ModelisateurTreePanel.expanded = true;
			}
		});
		tree.getSelectionModel().addSelectionHandler(new SelectionHandler<TreeNodeModel>() {

			@Override
			public void onSelection(SelectionEvent<TreeNodeModel> event) {
				if( !(event.getSelectedItem() instanceof TreeNodeRegleModel) ) {
					menuIcon.removeFromParent();
					if(event.getSelectedItem().getId() != null && event.getSelectedItem().getId() != 0){
						Node menu = tree.getTreeView().getRow(event.getSelectedItem()).getChild(1).getChild(0).getChild(0);				
						menuIcon.resetMenu();
						((Element)menu).getStyle().setProperty("visibility", "inherit");
						//buttonMenu.setMenu(contextMenu2);
						((Element)menu).appendChild(menuIcon.getElement());
					}
				}
			}
		});
		
		tree.addCellClickHandler(new CellClickHandler() {

			@Override
			public void onCellClick(CellClickEvent event) {
				TreeNodeModel nodeModel = tree.getStore().get(event.getRowIndex());
				if( !(nodeModel instanceof TreeNodeRegleModel) ) {
					bus.fireEvent(new TargetElementSelectEvent(nodeModel));
				}
				if(event.getCellIndex() == 1){
					menuIcon.toogleDisplayMenu();
					
					if(menuIcon.getStatus() == 1){
						if( nodeModel.getModelType().equals(ModelNodeType.ELEMENT) &&  !(nodeModel instanceof TreeNodeRegleModel) ) {
							contextMenu1.showAt(menuIcon.getAbsoluteLeft(), menuIcon.getAbsoluteTop()+16);
						}
						else if(!(nodeModel instanceof TreeNodeRegleModel)){
							if(nodeModel.getId() != null && nodeModel.getId() != 0){
								if(nodeModel.getParentId() == null){
									separator.setVisible(false);
									supprimerItem2.setVisible(false);
								}
								else{
									separator.setVisible(true);
									supprimerItem2.setVisible(true);
								}
								if(nodeModel.getModelType() == ModelNodeType.REFERENCE){
									collerItem.setVisible(false);
								}
								else{
									collerItem.setVisible(true);
								}
								if(nodeToBeCopied == null){
									collerItem.setEnabled(false);
								}
								else{
									collerItem.setEnabled(true);
								}
								
								contextMenu2.showAt(menuIcon.getAbsoluteLeft(), menuIcon.getAbsoluteTop()+16);
							}
						}
					}
				}
				//buttonMenu.showMenu();
			}
		});
		tree.addCellDoubleClickHandler(new CellDoubleClickHandler() {
			@Override
			public void onCellClick(CellDoubleClickEvent event) {
				TreeNodeModel nodeModel = tree.getSelectionModel().getSelectedItem();
				if( !(nodeModel instanceof TreeNodeRegleModel) ) {
					bus.fireEvent(new ModelisateurTreeDoubleClickEvent(nodeModel));
				}
			}
		});
		
		
		
		bus.addHandler(ModelisateurTreeDoubleClickEvent.getType(), new ModelisateurTreeDoubleClickHandler() {
			@Override
			public void onLoad(ModelisateurTreeDoubleClickEvent modelisateurTreeDoubleClickEvent) {
				TreeNodeModel nodeModel = modelisateurTreeDoubleClickEvent.getTreeNode();
				bus.fireEvent(new ModelisateurAddTabEvent(nodeModel, getHierarchy(nodeModel), false, false, false));
			}
		});
		bus.addHandler(RenameTreeNodeEvent.getType(), new RenameTreeNodeHandler() {
			@Override
			public void onLoad(RenameTreeNodeEvent event) {
				TreeNodeModel nodeModel = tree.getTreeStore().findModelWithKey(event.getTabId());
				if( nodeModel != null ) {
					if(idModeleVersion == 0){
						idModeleVersion = event.getNewVersionId();
						navigation.getBus().fireEvent(new ModifyEvent(true));
					}
					nodeModel.setLibelle(event.getNewLabel());
					nodeModel.setTempId(event.getNewId());
					nodeModel.setId(event.getNewId());
					nodeModel.setIdModeleVersion(event.getNewVersionId());
					tree.getTreeStore().update(nodeModel);
					tree.getView().refresh(true);
					tree.getSelectionModel().getSelection().clear();
//					tree.getSelectionModel().select(nodeModel, true);
				}
			}
		});
		bus.addHandler(MaskEvent.getType(), new MaskHandler() {
			@Override
			public void onLoad(MaskEvent event) {
				if( event.isMask() ) {
					if( treeDragSource == null ) {
						treeDragSource = new TreeGridDragSource<TreeNodeModel>(tree) {
							@Override
							protected void onDragDrop(DndDropEvent event) {
							}
						};
					}
					else {
						treeDragSource.enable();
					}
				}
				else {
					treeDragSource.disable();
				}
			}

		});
		bus.addHandler(RemoveNodeEvent.getType(), new RemoveNodeHandler() {
			@Override
			public void onLoad(RemoveNodeEvent event) {
				TreeNodeModel nodeModel = event.getTreeNode();
				tree.getTreeStore().remove(nodeModel);		
				tree.getTreeStore().commitChanges();
			}
		});
		/*addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent event) {
				Window.alert(event.getWidth()+"");
				
			}
		});*/
		bus.addHandler(ModelisateurTreeCopyEvent.getType(), new ModelisateurTreeCopyHandler() {
			
			@Override
			public void onLoad(ModelisateurTreeCopyEvent event) {
				contextMenu2.hide();
				if(event.isConfirmCopy()){
					nodeToBeCopied = tree.getSelectionModel().getSelectedItem();
					copierRegles = event.isCopyRegles();
					copierMessages = event.isCopyMessages();
					copierDescendances = event.isCopyChildren();
					collerItem.setEnabled(true);
				}
			}
		});

	}

	private Stack<TreeNodeModel> getHierarchy(TreeNodeModel node) {
		Stack<TreeNodeModel> items = new Stack<TreeNodeModel>();
		items.push(node);

		TreeNodeModel p = node;
		//have parent
		while( (p = treeStore.getParent(p)) != null ) {
			items.push(p);
		}
		return items;
	}

	private void buildContextMenu() {
		contextMenu1 = new Menu();
		contextMenu2 = new Menu();
		contextMenu1.addHideHandler(new HideHandler() {
			
			@Override
			public void onHide(HideEvent event) {
				menuIcon.toogleDisplayMenu();
			}
		});
		contextMenu2.addHideHandler(new HideHandler() {
			
			@Override
			public void onHide(HideEvent event) {
				menuIcon.toogleDisplayMenu();
			}
		});
		
		MenuItem afficher = new MenuItem();
		afficher.setText(messages.modelisateurMenuAfficher());
		afficher.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {

				TreeNodeModel node = tree.getSelectionModel().getSelectedItem();
				if (node.getModelType() == ModelNodeType.ELEMENT) {
					if( !(node instanceof TreeNodeRegleModel) ) {
						bus.fireEvent(new ModelisateurTreeDoubleClickEvent(node));
					}
				}
			}
		});

		MenuItem modifier = new MenuItem();
		modifier.setText(messages.modelisateurMenuModifier());
		modifier.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {

				TreeNodeModel node = tree.getSelectionModel().getSelectedItem();
				if (node.getModelType() == ModelNodeType.CARACTERISTIQUE || node.getModelType() == ModelNodeType.REFERENCE) {
					if( !(node instanceof TreeNodeRegleModel) ) {
						bus.fireEvent(new ModelisateurTreeDoubleClickEvent(node));
					}
				}
			}
		});

		MenuItem imCaractItem = new MenuItem();
		imCaractItem.setText(messages.modelisateurMenuImporterCaracteristique());
		imCaractItem.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {
				FileImportDialog dialog = new FileImportDialog(bus,messages.commonImportPopupCaracteristique());

				TreeNodeModel node = tree.getSelectionModel().getSelectedItem();
				Integer nodeId = node.getId();
				Integer modelVersionId = node.getIdModeleVersion();

				setBasicParams(dialog);

				dialog.setFormAction("importCharacteristics");
				dialog.addParamElement(ConstantServer.PARAM_NODE_ID, nodeId + "");
				dialog.addParamElement(ConstantServer.PARAM_MODEL_EVERSION_ID, modelVersionId + "");

				dialog.show();		
			}
		});

		MenuItem exCaractItem = new MenuItem();
		exCaractItem.setText(messages.modelisateurMenuExporterCaracteristique());
		exCaractItem.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {
				
				ClientModelisateurServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

					@Override
					public void onSuccess(Metier result) {
						TreeNodeModel node = tree.getSelectionModel().getSelectedItem();
						String exportUrl = GWT.getHostPageBaseURL() + "Mozarto_Caracteristiques.csv";
						List<NameValuePair> values = new ArrayList<NameValuePair>();
						values.add(new NameValuePair(Constant.CARACTERISTIQUE_IDMODELEVERSION_STR, node.getIdModeleVersion().toString()));
						values.add(new NameValuePair(Constant.LIBELLE_METIER, result.getLLibelle()));
						Date date = new Date();
						values.add(new NameValuePair(Constant.CLIENT_DATE_STR, DateTimeFormat.getFormat("dd/MM/yyyy").format(date)));
						@SuppressWarnings("deprecation")
						int timezoneoffset = date.getTimezoneOffset() * (-1);
						values.add(new NameValuePair(Constant.CLIENT_TIMEZONEOFFSET, String.valueOf(timezoneoffset)));
						ReportUtil.showReport(exportUrl, values.toArray(new NameValuePair[values.size()]));
					}
				});
			}
		});

		MenuItem imRefItem = new MenuItem();
		imRefItem.setText(messages.modelisateurMenuImporterReference());
		imRefItem.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {

				TreeNodeModel node = tree.getSelectionModel().getSelectedItem();
				Integer nodeId = node.getId();
				Integer modelVersionId = node.getIdModeleVersion();

				FileImportDialog dialog = new FileImportDialog(bus,messages.modelisateurMenuImporterReference());
				setBasicParams(dialog);

				dialog.setFormAction("importReferences");
				dialog.addParamElement(ConstantServer.PARAM_NODE_ID, nodeId + "");
				dialog.addParamElement(ConstantServer.PARAM_MODEL_EVERSION_ID, modelVersionId + "");

				dialog.show();
			}
		});

		MenuItem exRefItem = new MenuItem();
		exRefItem.setText(messages.modelisateurMenuExporterReference());
		exRefItem.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {
				ClientModelisateurServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

					@Override
					public void onSuccess(Metier result) {
						TreeNodeModel node = tree.getSelectionModel().getSelectedItem();

						String exportUrl = GWT.getHostPageBaseURL() + "Mozarto_References.csv";

						List<NameValuePair> values = new ArrayList<NameValuePair>();
						values.add(new NameValuePair(Constant.ID_METIER, String.valueOf(idMetier)));
						values.add(new NameValuePair(Constant.LIBELLE_METIER, result.getLLibelle()));
						values.add(new NameValuePair(Constant.CARACTERISTIQUE_IDMODELEVERSION_STR, node.getIdModeleVersion().toString()));
						Date date = new Date();
						values.add(new NameValuePair(Constant.CLIENT_DATE_STR, DateTimeFormat.getFormat("dd/MM/yyyy").format(date)));
						@SuppressWarnings("deprecation")
						int timezoneoffset = date.getTimezoneOffset() * (-1);
						values.add(new NameValuePair(Constant.CLIENT_TIMEZONEOFFSET, String.valueOf(timezoneoffset)));
						ReportUtil.showReport(exportUrl, values.toArray(new NameValuePair[values.size()]));
						
					}
				});
			}
		});

		MenuItem imSsRefItem = new MenuItem();
		imSsRefItem.setText(messages.modelisateurMenuImporterSousReference());
		imSsRefItem.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {
				FileImportDialog dialog = new FileImportDialog(bus,messages.modelisateurMenuImporterSousReference());

				TreeNodeModel node = tree.getSelectionModel().getSelectedItem();
				Integer nodeId = node.getId();
				Integer modelVersionId = node.getIdModeleVersion();

				setBasicParams(dialog);

				dialog.setFormAction("importSubReferences");
				dialog.addParamElement(ConstantServer.PARAM_NODE_ID, nodeId + "");
				dialog.addParamElement(ConstantServer.PARAM_MODEL_EVERSION_ID, modelVersionId + "");

				dialog.show();		
			}
		});

		MenuItem exSsRefItem = new MenuItem();
		exSsRefItem.setText(messages.modelisateurMenuExporterSousReference());
		exSsRefItem.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {
				ClientModelisateurServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

					@Override
					public void onSuccess(Metier result) {
						TreeNodeModel node = tree.getSelectionModel().getSelectedItem();

						String exportUrl = GWT.getHostPageBaseURL() + "Mozarto_SousReferences.csv";

						List<NameValuePair> values = new ArrayList<NameValuePair>();
						values.add(new NameValuePair(Constant.ID_METIER, String.valueOf(idMetier)));
						values.add(new NameValuePair(Constant.LIBELLE_METIER, result.getLLibelle()));
						values.add(new NameValuePair(Constant.CARACTERISTIQUE_IDMODELEVERSION_STR, node.getIdModeleVersion().toString()));
						Date date = new Date();
						values.add(new NameValuePair(Constant.CLIENT_DATE_STR, DateTimeFormat.getFormat("dd/MM/yyyy").format(date)));
						@SuppressWarnings("deprecation")
						int timezoneoffset = date.getTimezoneOffset() * (-1);
						values.add(new NameValuePair(Constant.CLIENT_TIMEZONEOFFSET, String.valueOf(timezoneoffset)));
						ReportUtil.showReport(exportUrl, values.toArray(new NameValuePair[values.size()]));
					}
				});
			}
		});

		MenuItem copierItem = new MenuItem();
		copierItem.setText(messages.modelisateurMenuCopier());

		CopierSubMenu copierSubMenu = new CopierSubMenu(messages.modelisateurMenuCopierSubmenuTitle(), bus);
		copierSubMenu.getRegles().setBoxLabel(messages.modelisateurMenuCopierSubmenuRegles());
		copierSubMenu.getMessages().setBoxLabel(messages.modelisateurMenuCopierSubmenuMessages());
		copierSubMenu.getDescendance().setBoxLabel(messages.modelisateurMenuCopierSubmenuDescendance());
		copierSubMenu.getConfirmButton().setText(messages.modelisateurMenuCopier());
		final MenuItem copierWindowItem = new MenuItem();
		copierWindowItem.setWidth(290);
	    copierWindowItem.setHeight(120);
	    copierSubMenu.setEnableScrolling(false);
		copierSubMenu.add(copierWindowItem);
		copierItem.setSubMenu(copierSubMenu);

		copierItem.setHideOnClick(false);
		
		collerItem = new MenuItem();
		collerItem.setText(messages.modelisateurMenuColler());
		collerItem.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {
				tree.mask();
				duplicateNode (tree.getSelectionModel().getSelectedItem());
//				insertNode(nodeToBeCopied, tree.getSelectionModel().getSelectedItem());
			}
		});
		collerItem.setEnabled(false);

		supprimerItem2 = new MenuItem();
		supprimerItem2.setText(messages.modelisateurMenuSupprimer());

		SupprimerMenu supprimerSubMenu = new SupprimerMenu(tree,messages.modelisateurMenuSupprimerSubmenuTitle(),bus,contextMenu2);
		supprimerSubMenu.getRegles().setBoxLabel(messages.modelisateurMenuSupprimerSubmenuRegles());
		supprimerSubMenu.getMessages().setBoxLabel(messages.modelisateurMenuSupprimerSubmenuMessages());
		//supprimerSubMenu.getDescendance().setReadOnly(true);
		//supprimerSubMenu.getDescendance().disable();
		supprimerSubMenu.getDescendance().setBoxLabel(messages.modelisateurMenuSupprimerSubmenuDescendance());
		supprimerSubMenu.getConfirmButton().setText(messages.modelisateurMenuSupprimer());
		MenuItem supprimerWindowItem = new MenuItem();
		supprimerWindowItem.setWidth(290);
		supprimerWindowItem.setHeight(120);
		supprimerSubMenu.setEnableScrolling(false);
		supprimerSubMenu.add(supprimerWindowItem);
		supprimerItem2.setSubMenu(supprimerSubMenu);
		
		supprimerItem2.setHideOnClick(false);

		MenuItem supprimerItem1 = new MenuItem();
		supprimerItem1.setText(messages.modelisateurMenuSupprimer());
		supprimerItem1.addSelectionHandler(new SelectionHandler<Item>() {

			@Override
			public void onSelection(SelectionEvent<Item> event) {
				final TreeNodeModel node = tree.getSelectionModel().getSelectedItem();
				TreeNodeModel parentNode = treeStore.getParent(node);
				node.setParentId(parentNode.getId());
				String content = "<table><tr><td style='line-height:100%' >"+messages.modelisateurMessageDeleteElement(node.getLibelle(), parentNode.getLibelle(), node.getQuantite())+"</td></tr></table>";
				final CustomizeConfirmMessageBox confirmBox = new CustomizeConfirmMessageBox(messages.commonConfirmDelete(),content );
				confirmBox.addHideHandler(new HideHandler() {
					public void onHide(HideEvent event) {
						if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
							
							/*if (node.getModelType().equals(ModelNodeType.REFERENCE)) {
								if (node.isSousRef()) {
									AppUtil.showConfirmMessageBox(messages.modelisateurReferenceSousReferenceChange(node.getLibelle()), new SelectHandler() {							
										@Override
										public void onSelect(SelectEvent event) {								
											deleteNode(node);
											bus.fireEvent(new ModelisateurCloseTabEvent(node));
										}															
									}, null);
								} else {
									deleteNode(node);
									bus.fireEvent(new ModelisateurCloseTabEvent(node));
								}
							} else {*/
								deleteNode(node);
								bus.fireEvent(new ModelisateurCloseTabEvent(node));
							//}
							
						}
						else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {
							
						}
					}
				});
				confirmBox.show();
			}
		});

		
		contextMenu1.add(afficher);
		contextMenu1.add(supprimerItem1);
		contextMenu2.add(modifier);
		contextMenu2.add(new SeparatorMenuItem());
		contextMenu2.add(imCaractItem);
		contextMenu2.add(exCaractItem);
		contextMenu2.add(imRefItem);
		contextMenu2.add(exRefItem);
		contextMenu2.add(imSsRefItem);
		contextMenu2.add(exSsRefItem);
		contextMenu2.add(new SeparatorMenuItem());
		contextMenu2.add(copierItem);
		contextMenu2.add(collerItem);
		separator = new SeparatorMenuItem();
		contextMenu2.add(separator);
		contextMenu2.add(supprimerItem2);

//		contextMenu3.add(modifier);
//		contextMenu3.add(new SeparatorMenuItem());
//		contextMenu3.add(imCaractItem);
//		contextMenu3.add(exCaractItem);
//		contextMenu3.add(imRefItem);
//		contextMenu3.add(exRefItem);
//		contextMenu3.add(imSsRefItem);
//		contextMenu3.add(exSsRefItem);
//		contextMenu3.add(new SeparatorMenuItem());
//		contextMenu3.add(copierItem);
//		contextMenu3.add(collerItem);
	}

	protected void duplicateNode(final TreeNodeModel target) {
		ClientModelisateurServiceAsync.Util.getInstance().duplicateNode(nodeToBeCopied, target, copierRegles, copierMessages, copierDescendances, idUtilisateur, idMetier, new AsyncCallbackWithErrorResolution<TreeNodeModel>() {

			@Override
			public void onSuccess(TreeNodeModel arg0) {
				treeStore.add(target, arg0);
				tree.unmask();
				if(arg0.isSousRef()){
					MessageBox box = new MessageBox(messages.commonInfoHeader(), messages.modelisateurCopySousref(nodeToBeCopied.getLibelle()));
					box.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
					box.show();
				}
					
			}
			
			@Override
			public void onFailure(Throwable caught){
				tree.unmask();
				String errorMessage = caught.getMessage();
				String libellesExited = "";
				if(errorMessage.startsWith("500 f013 "))
					libellesExited = errorMessage.substring(9);
				MessageBox box = new MessageBox(messages.commonInfoHeader(), messages.modelisateurCopyExiste(libellesExited));
				box.setWidth(500);
				box.getButtonById(PredefinedButton.OK.name()).setText(messages.commonFermerButton());
				box.show();
			}
		});
	}



	private void deleteNode(
			final TreeNodeModel node) {
		ClientModelisateurServiceAsync.Util.getInstance().deleteModelisateurNode(node, true, true, true, new AsyncCallbackWithErrorResolution<Void>() {
		@Override
			public void onSuccess(Void result) {
				treeStore.remove(node);
				//ModifierModeleEvent
				//bus.fireEvent(new ModifierModeleEvent(0));
			}
		});
		
	}		
	public static native void faireRedirection(String url) /*-{
		$wnd.location = url;
	}-*/;

	private void setBasicParams(final FileImportDialog dialog) {
		ClientModelisateurServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

			@Override
			public void onSuccess(Metier result) {
				dialog.addParamElement(Constant.ID_METIER, String.valueOf(idMetier));
				dialog.addParamElement(Constant.LIBELLE_METIER, result.getLLibelle());
	
				//FIXME Get log-in User Id
				dialog.addParamElement(ConstantServer.PARAM_USER_ID, "1");
			}
		});
		
	}

	public void createTree() {
		treeStore.clear();
		idModeleVersion = 0;
		TreeNodeModel modelisaterModel = new TreeNodeModel();
		modelisaterModel.setLibelle(messages.commontreenewnode());
		modelisaterModel.setModelType(ModelNodeType.CARACTERISTIQUE);
		modelisaterModel.setHasChildren(false);
		treeStore.add(modelisaterModel);
		ModelisateurAddTabEvent event = new ModelisateurAddTabEvent(modelisaterModel, null, true, true, false);
		event.setParentNode(null);
		bus.fireEvent(event);
		//tree.getSelectionModel().select(0, true);
	}
	/**
	 * for testing
	 */
	public void loadTree(final int idModele) {
		nodeToBeCopied = null;
		if(idModele != 0){
			this.idModeleVersion = idModele;
		}
		if(this.idModeleVersion !=0 ){	
			treeStore.clear();
			//final int idCaracteristque = navigation.getContext().getModelisation();
			final TreeNodeModel modelisaterModel = new TreeNodeModel();
			ClientCaracteristiqueServiceAsync.Util.getInstance().findByIdModele(
					this.idModeleVersion, new AsyncCallbackWithErrorResolution<MdlCaracteristique>() {
						@Override
						public void onSuccess(MdlCaracteristique result) {
							if( result != null && result.getIdCaracteristiqueParent() == null ) {
								modelisaterModel.setId(result.getIdCaracteristique());
								modelisaterModel.setIdModeleVersion(idModeleVersion);
								modelisaterModel.setLibelle(result.getLLibelleLong());
								modelisaterModel.setModelType(ModelNodeType.CARACTERISTIQUE);
								modelisaterModel.setHasChildren(true);
								treeStore.add(modelisaterModel);
								ClientModelisateurServiceAsync.Util.getInstance().getFolderChildren(
										modelisaterModel, parameterCheckBox.getValue(),
										new AsyncCallbackWithErrorResolution<List<TreeNodeModel>>() {
											@Override
											public void onSuccess(final List<TreeNodeModel> result) {
	
												if( result != null && result.size() > 0 ) {
	
													Timer timer = new Timer() {
														@Override
														public void run() {
															
															treeStore.add(modelisaterModel, result);
															//treeStore.update(modelisaterModel);
															tree.setExpanded(treeStore.getChild(0), true);
															//tree.getView().refresh(true);
														}
													};
													timer.schedule(1);
												}
											}
										});
							}
						}
					});
		}

	}
	
	private void insertNode(TreeNodeModel item, TreeNodeModel parent) {
		tree.setExpanded(parent, true);
		
		TreeNodeModel model = new TreeNodeModel();

		model.setLibelle(item.getLibelle());
		model.setModelType(item.getModelType());
		model.setIdModeleVersion(item.getIdModeleVersion());
		model.setParentId(parent.getId());
		tree.getTreeStore().add(parent, model);
		tree.getView().refresh(true);
		
	}
}
