package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.structis.shared.model.AttributEtendu;

public interface ClientAttributEtenduServiceAsync {
	public static class Util {

		private static ClientAttributEtenduServiceAsync instance = GWT
				.create(ClientAttributEtenduService.class);

		public static ClientAttributEtenduServiceAsync getInstance() {
			return instance;
		}
	}	

	public void findAll (AsyncCallback<List<AttributEtendu>> callback);
	
	public void findAllAttributEtendu(Integer idMetier, AsyncCallback<List<List<AttributEtendu>>> callback);
	
	public void insertAndUpdate(List<AttributEtendu> attributEtendus, Integer idMetier, AsyncCallback<Integer> callback);
	
	public void delete(AttributEtendu attributEtendu, AsyncCallback<Integer> callback);
}
