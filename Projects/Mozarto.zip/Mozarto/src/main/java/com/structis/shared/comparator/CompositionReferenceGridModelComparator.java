package com.structis.shared.comparator;

import java.util.Comparator;

import com.structis.shared.model.reference.CompositionReferenceGridModel;

public class CompositionReferenceGridModelComparator   implements Comparator<CompositionReferenceGridModel>{
	public int column=0; 
	//private boolean isSort;
	
	@Override
	public int compare(CompositionReferenceGridModel node1, CompositionReferenceGridModel node2) {
		
		int result = 0;
		if(node1.getStatus() > node2.getStatus()){
			result = -1;
		}else if(node1.getStatus() < node2.getStatus()){
			result = 1;
		}else {
			if(node1.getRelation() > node2.getRelation()){
				result = -1;
			}else if(node1.getRelation() < node2.getRelation()){
				result = 1;
			}else{
				 result = (node1.getLLibelleLong().compareToIgnoreCase(node2.getLLibelleLong()));
			}
		}
		
		
	
		return result;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	};
	
}
