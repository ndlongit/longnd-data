package com.structis.server.service.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.structis.server.persistence.TypeElementMapper;
import com.structis.shared.model.TypeElement;

/**
 * 
 * @author vu.dang
 *
 */
@Service("typeElementService")
public class TypeElementServiceImpl implements TypeElementService {
	@Autowired
	private TypeElementMapper mapper;
	
	public TypeElement findById(String id) {
		return mapper.findById(id);	
	}
	
	@Transactional
	public Integer insert(TypeElement record) {
		 return mapper.insert(record);	
	}
	
	@Transactional
	public Integer update(TypeElement record) {
		return mapper.update(record);	
	}
		
	@Transactional
	public Integer delete(TypeElement record) {
		return mapper.delete(record);	
	}
	
	@Transactional
	public Integer deleteById(String id) {
		return mapper.deleteById(id);	
	}
	public List<TypeElement> findAll() {
		return mapper.findAll();		
	}
}
