package com.structis.client.panel.admin;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.structis.client.constant.ConstantClient.ScreenSize;
import com.structis.client.ecran.EcranLoadable;
import com.structis.client.event.GestionUtilisateursAddTabEvent;
import com.structis.client.event.GestionUtilisateursAddTabHandler;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationEvent;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.widget.CustomizeBorderlayoutContainer;
import com.structis.client.widget.DynamicTabPanel;
import com.structis.shared.model.Utilisateur;

/**
 * administrator screen Gestion Des Element De Composition
 * 
 * @author vinh.tong
 */
public class GestionDesUtilisateursAdminContainer extends SimpleContainer implements EcranLoadable {

	private DynamicTabPanel centerPanel;

	private SimpleEventBus bus = new SimpleEventBus();

	private final Messages messages = GWT.create(Messages.class);

	private GestionDesUtilisateursAdminLeftPanel west;

	private int tabNum;
	
	private Utilisateur utilisateur;
	
	@SuppressWarnings("unused")
	private Integer idUtilisateur;
	
	private Integer idMetier;
	
	private NavigationService navigation = NavigationFactory.getNavigation();
	
	public GestionDesUtilisateursAdminContainer() {
		
	}

	/**
	 * 
	 */
	@Override
	protected void onAfterFirstAttach() {
		super.onAfterFirstAttach();
		idUtilisateur = navigation.getContext().getUtilisateur().getIdUtilisateur();
		idMetier = navigation.getContext().getMetier().getIdMetier();
		CustomizeBorderlayoutContainer container = new CustomizeBorderlayoutContainer();
		west = new GestionDesUtilisateursAdminLeftPanel(bus);

		BorderLayoutData westData = new BorderLayoutData(ScreenSize.MINLEFT);
		westData.setCollapsible(true);
		westData.setSplit(true);
		westData.setCollapseMini(true);
		westData.setMargins(new Margins(0, 5, 0, 0));
		westData.setMinSize(ScreenSize.MINLEFT);
		
		ContentPanel leftPanel = new ContentPanel();
		leftPanel.setHeaderVisible(false);
		leftPanel.setBorders(false);
		leftPanel.setBodyBorder(false);
		leftPanel.add(west);
		container.setWestWidget(leftPanel, westData);
		centerPanel = new DynamicTabPanel(bus);
		
		MarginData centerData = new MarginData();

		container.setCenterWidget(centerPanel, centerData);
		container.setLeftTitle(messages.commonPanneauAction());

		add(container);
		
		bus.addHandler(GestionUtilisateursAddTabEvent.getType(), new GestionUtilisateursAddTabHandler() {
			
			@Override
			public void onLoad(GestionUtilisateursAddTabEvent event) {
				utilisateur = event.getUtilisateur();
				if(utilisateur != null){
					GestionDesUtilisateursAdminForm form = (GestionDesUtilisateursAdminForm) centerPanel.getTabPanel().findItem(
						getTabId(utilisateur), false);
					if( form != null ) {
						centerPanel.getTabPanel().setActiveWidget(form);
					}
					else {
						form = new GestionDesUtilisateursAdminForm(bus);
						form.setId(getTabId(utilisateur));
						form.setTabLabel(utilisateur.getNomComplet());
						centerPanel.addItem(form, utilisateur.getNomComplet());
						form.setIdMetier(idMetier);
						form.fillInfo(utilisateur);
						form.setUtilisateur(utilisateur);
						form.loadGridData();
						
					}
				}
				else {
					GestionDesUtilisateursAdminForm form = new GestionDesUtilisateursAdminForm(bus);
					form.setId(getTabId(utilisateur));
					form.setTabLabel(messages.utilisateursNouvel());
					centerPanel.addItem(form, messages.utilisateursNouvel());
					form.setIdMetier(idMetier);
					form.loadGridData();					
				}
			}
		});

	}

	@Override
	public void onLoadApplication(NavigationEvent event) {
	}
	
	private String getTabId(Utilisateur utilisateur) {
		if( utilisateur != null )
			return "tab-" + utilisateur.getNomComplet() + "-" + utilisateur.getIdUtilisateur();
		else {
			tabNum++;
			return "tab-" + tabNum;
		}
	}
}
