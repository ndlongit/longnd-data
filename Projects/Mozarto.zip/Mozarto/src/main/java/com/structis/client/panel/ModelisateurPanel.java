package com.structis.client.panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.SimpleContainer;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.structis.client.constant.ConstantClient.ScreenSize;
import com.structis.client.event.ModelisateurAddTabEvent;
import com.structis.client.event.ModelisateurAddTabHandler;
import com.structis.client.event.ModelisateurCloseTabEvent;
import com.structis.client.event.ModelisateurCloseTabHandler;
import com.structis.client.event.ModelisateurTreeReloadAddElementEvent;
import com.structis.client.event.ModelisateurTreeReloadAfterAddElementHandler;
import com.structis.client.event.TargetElementSelectEvent;
import com.structis.client.event.TargetElementSelectHandler;
import com.structis.client.message.Messages;
import com.structis.client.util.AppUtil;
import com.structis.client.widget.CustomizeBorderlayoutContainer;
import com.structis.client.widget.DynamicTabPanel;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.reference.TreeNodeModel;

public class ModelisateurPanel extends SimpleContainer {

	private SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private ModelisateurLeftPanel modelisateurLeftPanel;

	private DynamicTabPanel detailFormTabPanel;

	ModelisateurTreePanel modelisateurTreePanel;

	public ModelisateurPanel(SimpleEventBus bus) {
		this.bus = bus;
		setBorders(true);
		buildPanel();
		addHandler();
	}

	private void buildPanel() {
		final CustomizeBorderlayoutContainer mainContainer = new CustomizeBorderlayoutContainer();
		mainContainer.setBorders(false);

		modelisateurLeftPanel = new ModelisateurLeftPanel(bus);

		modelisateurTreePanel = new ModelisateurTreePanel(bus);
		final BorderLayoutData westData = new BorderLayoutData(.25);
		westData.setCollapsible(true);
		westData.setSplit(true);
		westData.setCollapseMini(true);
		westData.setMargins(new Margins(0, 5, 0, 0));
		westData.setMinSize(ScreenSize.MINLEFT);
		westData.setMaxSize(ScreenSize.COMPOSITEUR_MINRIGHT);
		final BorderLayoutData centerData = new BorderLayoutData(.25);
		centerData.setMinSize(ScreenSize.MINCENTER);

		detailFormTabPanel = new DynamicTabPanel(bus);

		final BorderLayoutData eastData = new BorderLayoutData(.5);
		eastData.setMargins(new Margins(0, 0, 0, 5));
		eastData.setCollapsible(true);
		eastData.setCollapseMini(true);
		eastData.setSplit(true);
		eastData.setMinSize(ScreenSize.MINHRIGHT);

		//con.setNorthWidget(north, northData);
		ContentPanel leftPanel = new ContentPanel();
		leftPanel.setHeaderVisible(false);
		leftPanel.setBorders(false);
		leftPanel.setBodyBorder(false);
		ContentPanel centerPanel = new ContentPanel();
		centerPanel.setHeaderVisible(false);
		centerPanel.setBorders(false);
		centerPanel.setBodyBorder(false);
		ContentPanel rightPanel = new ContentPanel();
		rightPanel.setHeaderVisible(false);
		rightPanel.setBorders(false);
		rightPanel.setBodyBorder(false);
		leftPanel.add(modelisateurLeftPanel);
		centerPanel.add(modelisateurTreePanel);
		rightPanel.add(detailFormTabPanel);

		mainContainer.setWestWidget(leftPanel, westData);
		mainContainer.setCenterWidget(centerPanel, centerData);
		mainContainer.setEastWidget(rightPanel, eastData);
		mainContainer.setLeftTitle(messages.commonPanneauAction());
		mainContainer.setRightTitle(messages.commonPanneauDetail());

		add(mainContainer);

	}

	private void addHandler() {

		bus.addHandler(ModelisateurAddTabEvent.getType(), new ModelisateurAddTabHandler() {
			@Override
			public void onLoad(ModelisateurAddTabEvent modelisateurAddTabEvent) {
				TreeNodeModel nodeModel = modelisateurAddTabEvent.getTreeNode();
				TreeNodeModel parentNode = modelisateurAddTabEvent.getParentNode();
				NavigationModelisateurForm tabItem = null;
				tabItem = (NavigationModelisateurForm) detailFormTabPanel.getTabPanel().findItem(
						AppUtil.getTabId(nodeModel), false);
				boolean loadedNavigation = false;
				if( tabItem == null ) {
					tabItem = detailFormTabPanel.getTabByIdNodeAndType(
							nodeModel.getId(), nodeModel.getModelType().getLabel());
					if(tabItem !=null && tabItem.getCurrentItem().getParentId()!= null && nodeModel.getId() != null && tabItem.getCurrentItem().getParentId().intValue() != nodeModel.getId().intValue()){
						tabItem.loadNavigation(modelisateurAddTabEvent.getItemsPath());
						loadedNavigation = true;
					}
				}

				if( tabItem != null ) {
					detailFormTabPanel.getTabPanel().setActiveWidget(tabItem);
					if(modelisateurAddTabEvent.getItemsPath() != null && !loadedNavigation){
						tabItem.loadNavigation(modelisateurAddTabEvent.getItemsPath());
					}
					final AbstractModelisateurEditForm form = tabItem.getDetailForm();
					if( form instanceof ModelisateurReferenceForm || form instanceof ModelisateurCaracteristiqueForm ) {
						if (form.isChanged()){
							final ConfirmMessageBox confirmMessageBox =  showConfirmReloadMessage(tabItem);
							confirmMessageBox.addHideHandler(new HideHandler() {
								
								@Override
								public void onHide(HideEvent event) {
									if(confirmMessageBox.getHideButton() == confirmMessageBox.getButtonById(PredefinedButton.YES.name())){
										form.loadForm();
										form.setChanged(false);
									}
								}
							});
						}
					}
					else if (form instanceof ModelisateurElementForm){
						((ModelisateurElementForm)form).reloadGridEds();
						
					}
				}
				else {
					String tabId = AppUtil.getTabId(nodeModel);
					AbstractModelisateurEditForm detailForm = null;
					if( nodeModel.getModelType().equals(ModelNodeType.CARACTERISTIQUE) ) {
						detailForm = new ModelisateurCaracteristiqueForm(bus, nodeModel, parentNode);

						ModelisateurRegleMessageList regleCaracteristiqueForm = new ModelisateurRegleMessageList(
								bus, nodeModel);

						tabItem = new NavigationModelisateurForm(
								bus, nodeModel, modelisateurAddTabEvent.getItemsPath(), detailForm, regleCaracteristiqueForm);
						((ModelisateurCaracteristiqueForm) detailForm).setNavigationModelisateurForm(tabItem);
						((ModelisateurCaracteristiqueForm) detailForm).setModelisateurRegleMessageList(regleCaracteristiqueForm);
					}
					else if( nodeModel.getModelType().equals(ModelNodeType.REFERENCE) ) {
						detailForm = new ModelisateurReferenceForm(bus, nodeModel, parentNode);
						//						detailForm.setParentNode(parentNode);
						ModelisateurRegleMessageList regleReferenceForm = new ModelisateurRegleMessageList(bus, nodeModel);
						tabItem = new NavigationModelisateurForm(
								bus, nodeModel, modelisateurAddTabEvent.getItemsPath(), detailForm, regleReferenceForm);
						((ModelisateurReferenceForm) detailForm).setNavigationModelisateurForm(tabItem);
						((ModelisateurReferenceForm) detailForm).setModelisateurRegleMessageList(regleReferenceForm);
					}
					else if( nodeModel.getModelType().equals(ModelNodeType.ELEMENT) ) {
						detailForm = new ModelisateurElementForm(bus, nodeModel, parentNode);
						ModelisateurRegleMessageList regleReferenceForm = new ModelisateurRegleMessageList(bus, nodeModel);
						tabItem = new NavigationModelisateurForm(
								bus, nodeModel, modelisateurAddTabEvent.getItemsPath(), detailForm, regleReferenceForm);
					}

					detailForm.setTabId(tabId);
					tabItem.setId(tabId);

					detailFormTabPanel.addItem(tabItem, nodeModel.getLibelle());
				}
				if(modelisateurAddTabEvent.isCreateModele()){
					Widget w = detailFormTabPanel.getTabPanel().getActiveWidget();
					if (w instanceof NavigationModelisateurForm) {		
						ModelisateurCaracteristiqueForm form = (ModelisateurCaracteristiqueForm)(((NavigationModelisateurForm) w).getDetailForm());
						form.setCreateModele(true);
						form.setCreate(true);
					}
				}
				if(modelisateurAddTabEvent.isCreate()){
					Widget w = detailFormTabPanel.getTabPanel().getActiveWidget();
					if (w instanceof NavigationModelisateurForm) {		
						AbstractModelisateurEditForm form = (AbstractModelisateurEditForm)(((NavigationModelisateurForm) w).getDetailForm());
						form.setCreate(true);
					}
				}
				if(modelisateurAddTabEvent.isOpenRegleView()){
					NavigationModelisateurForm w = (NavigationModelisateurForm)detailFormTabPanel.getTabPanel().getActiveWidget();
					if (w instanceof NavigationModelisateurForm) {		
						ModelisateurRegleMessageList form = (ModelisateurRegleMessageList)(w.getRegleForm());
						w.getContainer().setActiveWidget(form);
						form.enableButtons(true);
						w.toggleDetailButton(true);
					}
				}
			}
			
		});
		bus.addHandler(ModelisateurCloseTabEvent.getType(), new ModelisateurCloseTabHandler() {
			
			@Override
			public void onLoad(ModelisateurCloseTabEvent modelisateurCloseTabEvent) {
				TreeNodeModel nodeModel = modelisateurCloseTabEvent.getTreeNode();
				NavigationModelisateurForm tabItem = null;
				tabItem = (NavigationModelisateurForm) detailFormTabPanel.getTabPanel().findItem(
						AppUtil.getTabId(nodeModel), false);
				if( tabItem == null ) {
					tabItem = detailFormTabPanel.getTabByIdNodeAndType(
							nodeModel.getId(), nodeModel.getModelType().getLabel());
				}

				if( tabItem != null ) {
					detailFormTabPanel.getTabPanel().remove(tabItem);
				}
			}
		});
		SelectionHandler<Widget> tabHandler = new SelectionHandler<Widget>() {
			@Override
			public void onSelection(SelectionEvent<Widget> event) {
				Widget widget = event.getSelectedItem();
				NavigationModelisateurForm tabIem = (NavigationModelisateurForm) widget;
				tabIem.getRegleForm().loadListRelgeAndMessage();
				//Info.display("Message", "'" + tabIem.regleForm.container.getActiveWidget().getClass().getName() + "' Selected");
			}
		};

		detailFormTabPanel.getTabPanel().addSelectionHandler(tabHandler);
		bus.addHandler(TargetElementSelectEvent.getType(), new TargetElementSelectHandler() {
			@Override
			public void onLoad(TargetElementSelectEvent targetElementSelectEvent) {
				Widget widget = detailFormTabPanel.getTabPanel().getActiveWidget();
				if( widget != null ) {
					NavigationModelisateurForm tabIem = (NavigationModelisateurForm) widget;
					//check if regle edit form is display
					String activeNavigationPanel = tabIem.getContainer().getActiveWidget().getClass().getName() + "";
					if( ModelisateurRegleMessageList.class.getName().equals(activeNavigationPanel) ) {
						ModelisateurRegleMessageList modelisateurRegleMessageList = (ModelisateurRegleMessageList) tabIem.getContainer().getActiveWidget();
						String activeRegleMessageEditForm = modelisateurRegleMessageList.getEditFormContainer().getActiveWidget().getClass().getName();
						if( ModelisateurRegleForm.class.getName().equals(activeRegleMessageEditForm) ) {
							ModelisateurRegleForm regleEditForm = (ModelisateurRegleForm) modelisateurRegleMessageList.getEditFormContainer().getActiveWidget();
							TreeNodeModel node = targetElementSelectEvent.getTreeNode();
							if( node != null ) {
								regleEditForm.setTartget(node);
							}
						}
					}
				}
			}
		});
		bus.addHandler(ModelisateurTreeReloadAddElementEvent.getType(), new ModelisateurTreeReloadAfterAddElementHandler() {
			@Override
			public void onLoad(ModelisateurTreeReloadAddElementEvent modelisateurTreeAddElementEvent) {
				NavigationModelisateurForm tabItem = null;
				TreeNodeModel nodeModel = modelisateurTreeAddElementEvent.getTreeNode();
				tabItem = detailFormTabPanel.getTabByIdNodeAndType(nodeModel.getId(), nodeModel.getModelType().getLabel());
				if( tabItem != null ) {
					tabItem.getDetailForm().loadForm();
				}
			}
		});
		

	}
	
	public ConfirmMessageBox showConfirmReloadMessage(NavigationModelisateurForm tabItem){
		AbstractModelisateurEditForm detailForm = tabItem.getDetailForm();
		String itemName = "";
		if (detailForm instanceof ModelisateurCaracteristiqueForm)
			itemName = messages.modelisateurCaracteristiqueLabel();
		else if (detailForm instanceof ModelisateurReferenceForm)
			itemName = messages.modelisateurReferenceLabel();
		else if (detailForm instanceof ModelisateurElementForm)
			itemName = messages.modelisateurElementLabel();
		
		String confirmMessage = messages.modelisateurConfirmationCloseTab(itemName);
		final ConfirmMessageBox confirmBox = new ConfirmMessageBox(
				messages.commonConfirmation(), confirmMessage);
		confirmBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
		confirmBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
		
		confirmBox.show();
		return confirmBox;
	}

	public ModelisateurTreePanel getModelisateurTreePanel() {
		return modelisateurTreePanel;
	}

	public void setModelisateurTreePanel(ModelisateurTreePanel modelisateurTreePanel) {
		this.modelisateurTreePanel = modelisateurTreePanel;
	}

	public DynamicTabPanel getDetailFormTabPanel() {
		return detailFormTabPanel;
	}

	public void setDetailFormTabPanel(DynamicTabPanel detailFormTabPanel) {
		this.detailFormTabPanel = detailFormTabPanel;
	}

}
