package com.structis.client.widget;

import com.sencha.gxt.widget.core.client.toolbar.PagingToolBar;

public class PagingToolBarWithoutDisplayText extends PagingToolBar {

	public PagingToolBarWithoutDisplayText(int pageSize) {
		super(pageSize);
		afterText.setLabel("&nbsp;&nbsp;&nbsp;");
		afterText.setWidth(35);
		displayText.getElement().getStyle().setProperty("display", "none");
	}
}
