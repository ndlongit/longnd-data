package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface GestionUtilisateurRenameUtilisateurHandler extends EventHandler {
	void onLoad(GestionUtilisateurRenameUtilisateurEvent event);
}
