package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class GridLoadEvent  extends GwtEvent<GridLoadHandler>{

	private static Type<GridLoadHandler> TYPE = new Type<GridLoadHandler>();
	
	private Integer record;
	
	public static Type<GridLoadHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<GridLoadHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(GridLoadHandler handler) {
		handler.onLoad(this);
	}
	
	public GridLoadEvent(int record) {
		this.record = record;
	}

	public void setRecord(Integer record) {
		this.record = record;
	}

	public int getRecord() {
		return record;
	}

}
