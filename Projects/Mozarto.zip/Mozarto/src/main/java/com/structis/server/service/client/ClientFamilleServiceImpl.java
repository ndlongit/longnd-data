package com.structis.server.service.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.client.service.ClientFamilleService;
import com.structis.server.service.domain.FamilleService;
import com.structis.shared.model.Famille;

@Service("clientFamilleService")
public class ClientFamilleServiceImpl implements ClientFamilleService{

	@Autowired
	FamilleService familleService;
	
	@Override
	public List<Famille> findAll() {
		List<Famille> familles = familleService.findAll();
		
		return familles;
	}
	

}
