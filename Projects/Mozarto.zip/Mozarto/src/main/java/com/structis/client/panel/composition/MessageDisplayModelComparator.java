package com.structis.client.panel.composition;

import java.util.Comparator;

public class MessageDisplayModelComparator implements Comparator<MessageDisplayModel> {
	@Override
	public int compare(MessageDisplayModel o1, MessageDisplayModel o2) {
		if(o1.getIdRelation() > o2.getIdRelation()){
			return 1;
		}else if(o1.getIdRelation() < o2.getIdRelation()){
			return -1;
		}
		
		return 0;
	}
}
