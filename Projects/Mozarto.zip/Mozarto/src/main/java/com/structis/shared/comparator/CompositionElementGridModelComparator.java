package com.structis.shared.comparator;

import java.util.Comparator;

import com.structis.shared.model.reference.CompositionElementGridModel;


public class CompositionElementGridModelComparator implements Comparator<CompositionElementGridModel> { 
	public int column = 0; // 0= Code ,1 = libele, 2 = nomenclature 
	private boolean isSort;
	private boolean firstLoad = true;
	@Override
	public int compare(CompositionElementGridModel node1, CompositionElementGridModel node2) {
		String value1 = "";
		String value2 = "";
		
		
		switch(column){		
			case 0:
				value1 = node1.getCElement()!=null?node1.getCElement():"";
				value2 = node2.getCElement()!=null?node2.getCElement():"";
				break;
			case 1:
				value1 = node1.getLLibelleLong()!=null?node1.getLLibelleLong():"";
				value2 = node2.getLLibelleLong()!=null?node2.getLLibelleLong():"";	
				break;
			case 2:
				value1 = node1.getLNomenclatureFournisseur()!=null?node1.getLNomenclatureFournisseur():"";
				value2 = node2.getLNomenclatureFournisseur()!=null?node2.getLNomenclatureFournisseur():"";	
				break;
		}
		
		int result = 0;

		if(node1.getRelation() == node2.getRelation()){
			if(isSort || (firstLoad && column == 0)) {
				result = value1.compareToIgnoreCase(value2); //ascending order
			}
			else {
				result = value2.compareToIgnoreCase(value1);	//descending order
			}
		}else if(node1.getRelation() < node2.getRelation()){
			result = -1;
		}
		
		return result;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	public boolean isSort() {
		return isSort;
	}
	public void setSort(boolean isSort) {
		this.isSort = isSort;
	}
	public void setFirstLoad(boolean firstLoad) {
		this.firstLoad = firstLoad;
	}
	public boolean isFirstLoad() {
		return firstLoad;
	};
}


