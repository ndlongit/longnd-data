package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface GestionUtilisateursAddTabHandler extends EventHandler {
	void onLoad(GestionUtilisateursAddTabEvent event);
}
