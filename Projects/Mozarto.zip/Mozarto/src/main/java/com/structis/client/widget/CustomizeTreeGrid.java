package com.structis.client.widget;

import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.user.client.Event;
import com.sencha.gxt.data.shared.TreeStore;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.tree.TreeStyle;
import com.sencha.gxt.widget.core.client.treegrid.TreeGrid;

public class CustomizeTreeGrid<M> extends TreeGrid<M> {

	public CustomizeTreeGrid(TreeStore<M> store, ColumnModel<M> cm, ColumnConfig<M, ?> treeColumn) {
		super(store, cm, treeColumn);
	}

	/**
	 * To remove the folder icon
	 */
	public ImageResource calculateIconStyle(M model) {
		ImageResource style = super.calculateIconStyle(model);

		TreeStyle ts = getStyle();
		if( !isLeaf(model) ) {
			if( isExpanded(model) ) {
				style = null;
			}
			else {
				style = null;
			}
		}
		else {
			style = ts.getLeafIcon();
		}
		return style;
	}

	@Override
	protected void onDoubleClick(Event e) {
		super.onDoubleClick(e);
	}

}
