package com.structis.client.service;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.ModeleModel;

@RemoteServiceRelativePath("springGwtServices/accueilService")
public interface ClientAccueilModelisateurService extends RemoteService {

	PagingLoadResult<ModeleModel> getModele(Integer idModele, Integer idMetier, PagingLoadConfig loadConfig);
	
	Integer updateByIdModele(Integer idModele, boolean actif);

	Metier getMetier(Integer idMetier);
}
