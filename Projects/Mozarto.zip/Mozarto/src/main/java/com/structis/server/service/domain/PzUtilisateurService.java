package com.structis.server.service.domain;

import com.structis.shared.model.PzUtilisateur;

public interface PzUtilisateurService {
	
	public Integer insert(PzUtilisateur utilisateur);
	
	public Integer update(PzUtilisateur utilisateur);
	
	public PzUtilisateur findByCode(String code);
	
	public PzUtilisateur findById (Integer id);

}
