package com.structis.client.service;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.MetierMzPzModel;

@RemoteServiceRelativePath("springGwtServices/gestionMetierService")
public interface ClientGestionMetierService extends RemoteService {

	public PagingLoadResult<MetierMzPzModel> findAll(PagingLoadConfig loadConfig);
	
	public Metier insertOrUpdate(MetierMzPzModel metier, List<AttributEtendu> attributEtendus);
}
