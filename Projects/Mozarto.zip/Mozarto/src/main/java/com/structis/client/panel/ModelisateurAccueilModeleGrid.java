package com.structis.client.panel;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.Scheduler;
import com.google.gwt.core.client.Scheduler.ScheduledCommand;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.data.client.loader.RpcProxy;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.event.StoreAddEvent;
import com.sencha.gxt.data.shared.event.StoreAddEvent.StoreAddHandler;
import com.sencha.gxt.data.shared.loader.LoadEvent;
import com.sencha.gxt.data.shared.loader.LoadHandler;
import com.sencha.gxt.data.shared.loader.LoadResultListStoreBinding;
import com.sencha.gxt.data.shared.loader.PagingLoadConfig;
import com.sencha.gxt.data.shared.loader.PagingLoadResult;
import com.sencha.gxt.data.shared.loader.PagingLoader;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.event.RowClickEvent;
import com.sencha.gxt.widget.core.client.event.RowClickEvent.RowClickHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.grid.GroupingView;
import com.sencha.gxt.widget.core.client.toolbar.PagingToolBar;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.ModelisateurExecuterModeleEvent;
import com.structis.client.event.ModifierModeleEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.ModeleModelProperties;
import com.structis.client.service.ClientAccueilModelisateurServiceAsync;
import com.structis.client.widget.ImagesModeleActionCell;
import com.structis.shared.model.reference.ModeleModel;

public class ModelisateurAccueilModeleGrid extends VerticalLayoutContainer {

	SimpleEventBus bus;

	private NavigationService navigation = NavigationFactory.getNavigation();
	
	Images images = GWT.create(Images.class);

	Integer idMetier = navigation.getContext().getMetier().getIdMetier();

	private final Messages messages = GWT.create(Messages.class);

	//int recordNumber = 30;

	private Grid<ModeleModel> grid;

	private ListStore<ModeleModel> store;

	@SuppressWarnings("unused")
	private List<ModeleModel> allModeles;

	PagingLoader<PagingLoadConfig, PagingLoadResult<ModeleModel>> loader;

	@SuppressWarnings("unused")
	private Integer modeleSelected = -1;

	public ModelisateurAccueilModeleGrid(SimpleEventBus bus1) {
		this.bus = bus1;
		setStyleName("whiteBackGround");
		Label title = new Label(messages.accueilModeleGridTitle());

		
		PagingToolBar pagingToolbar = new PagingToolBar(ConstantClient.ScreenSize.SMALL_DEFAULT_RECORD_NUMBER);
		
		//c.add(pagingToolbar,flex);
		title.getElement().getStyle().setProperty("color", "black");
		title.getElement().getStyle().setProperty("paddingRight", "10px");
		title.getElement().getStyle().setProperty("fontSize", "13px");
		
		pagingToolbar.insert(title, 0);
		add(pagingToolbar, new VerticalLayoutData(1, -1));

		RpcProxy<PagingLoadConfig, PagingLoadResult<ModeleModel>> proxy = new RpcProxy<PagingLoadConfig, PagingLoadResult<ModeleModel>>() {

			@Override
			public void load(PagingLoadConfig loadConfig, AsyncCallback<PagingLoadResult<ModeleModel>> callback) {
				/*int value = Integer.parseInt(pagingToolbar.getPagingNumberSpinner().getText());
				loadConfig.setOffset((value - 1) * 30);
				loadConfig.setLimit(30);*/
				ClientAccueilModelisateurServiceAsync.Util.getInstance().getModele(null, idMetier, loadConfig, callback);
			}
		};

		ModeleModelProperties props = GWT.create(ModeleModelProperties.class);
		store = new ListStore<ModeleModel>(new ModelKeyProvider<ModeleModel>() {
			@Override
			public String getKey(ModeleModel item) {
				return "" + item.getIdModele();
			}
		});
	
		loader = new PagingLoader<PagingLoadConfig, PagingLoadResult<ModeleModel>>(proxy);
		loader.setRemoteSort(true);
		loader.addLoadHandler(new LoadResultListStoreBinding<PagingLoadConfig, ModeleModel, PagingLoadResult<ModeleModel>>(
				store));
		pagingToolbar.bind(loader);
		
		List<ColumnConfig<ModeleModel, ?>> cfgs = new ArrayList<ColumnConfig<ModeleModel, ?>>();
		/*
		 * final ColumnConfig<ModeleModel, ModeleModel> libelleColumn = new
		 * ColumnConfig<ModeleModel, ModeleModel>( new IdentityValueProvider<ModeleModel>());
		 */
		final ColumnConfig<ModeleModel, String> libelleColumn = new ColumnConfig<ModeleModel, String>(props.lLibelle());
		libelleColumn.setHeader(messages.accueilModeleGridLibelle());
		//		libelleColumn.setCell(new TextCell());
		libelleColumn.setMenuDisabled(true);
		libelleColumn.setSortable(true);
		cfgs.add(libelleColumn);

		/*
		 * ColumnConfig<ModeleModel, ModeleModel> dateColumn = new ColumnConfig<ModeleModel,
		 * ModeleModel>( new IdentityValueProvider<ModeleModel>());
		 */
		ColumnConfig<ModeleModel, Date> dateColumn = new ColumnConfig<ModeleModel, Date>(props.dDateheureCrea());
		dateColumn.setHeader(messages.accueilModeleGridDate());
		//		dateColumn.setCell(new DateCell(DateTimeFormat.getFormat("dd/MM/yyyy")));
		dateColumn.setMenuDisabled(true);
		cfgs.add(dateColumn);

		/*
		 * ColumnConfig<ModeleModel, ModeleModel> utilisateurColumn = new ColumnConfig<ModeleModel,
		 * ModeleModel>( new IdentityValueProvider<ModeleModel>());
		 */
		ColumnConfig<ModeleModel, String> utilisateurColumn = new ColumnConfig<ModeleModel, String>(props.cUtilisateur());
		utilisateurColumn.setHeader(messages.accueilModeleGridUtilisateur());
		//		utilisateurColumn.setCell(new TextCell());
		cfgs.add(utilisateurColumn);
		utilisateurColumn.setMenuDisabled(true);

		/*
		 * ColumnConfig<ModeleModel, ModeleModel> publicationColumn = new ColumnConfig<ModeleModel,
		 * ModeleModel>( new IdentityValueProvider<ModeleModel>());
		 */
		ColumnConfig<ModeleModel, Integer> publicationColumn = new ColumnConfig<ModeleModel, Integer>(props.pubVersion());
		publicationColumn.setHeader(messages.accueilModeleGridPub());
		cfgs.add(publicationColumn);
		publicationColumn.setMenuDisabled(true);

		ColumnConfig<ModeleModel, ModeleModel> actionsColumn = new ColumnConfig<ModeleModel, ModeleModel>(
				new IdentityValueProvider<ModeleModel>());
		actionsColumn.setHeader(messages.accueilModeleGridActions());
		actionsColumn.setMenuDisabled(true);
		actionsColumn.setWidth(150);
		actionsColumn.setFixed(true);
		ImagesModeleActionCell imagesCell = new ImagesModeleActionCell() {

			@Override
			public void onModelePublic(ModeleModel modele) {
				Window.alert("Publier");
				//TODO to be implemented
			}

			@Override
			public void onModelePreviousVersion(final ModeleModel modele) {
				if( modele.getNVersion().equals(0) ) {
					modeleSelected = modele.getIdModele();
					ClientAccueilModelisateurServiceAsync.Util.getInstance().getModele(
							modele.getIdModele(), idMetier, loader.getLastLoadConfig(),
							new AsyncCallbackWithErrorResolution<PagingLoadResult<ModeleModel>>() {

								@Override
								public void onSuccess(PagingLoadResult<ModeleModel> arg0) {
									grid.getStore().replaceAll(arg0.getData());
									for( ModeleModel m : grid.getStore().getAll() ) {
										if( m.getNVersion().equals(0) ) {
											m.setEnabled(false);
											grid.getStore().update(m);
										}
									}
									grid.getView().refresh(true);
									grid.addRowClickHandler(new RowClickHandler() {

										@Override
										public void onRowClick(RowClickEvent event) {
											ModeleModel tmp = grid.getStore().get(event.getRowIndex());

											if( tmp.getNVersion().equals(0) && event.getColumnIndex() != 4) {

												ClientAccueilModelisateurServiceAsync.Util.getInstance().getModele(
														null,
														idMetier,
														loader.getLastLoadConfig(),
														new AsyncCallbackWithErrorResolution<PagingLoadResult<ModeleModel>>() {

															@Override
															public void onSuccess(PagingLoadResult<ModeleModel> arg0) {
																grid.getStore().replaceAll(arg0.getData());
																setCellDisplay(libelleColumn, 0);
																grid.getView().refresh(true);

															}
														});
											}

										}
									});
								}
							});
				}
				else {
					final ConfirmMessageBox confirmBox = new ConfirmMessageBox(
							messages.commonConfirmation(), messages.accueilRepriseVersionConfirmMessage());
					confirmBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
					confirmBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
					confirmBox.addHideHandler(new HideHandler() {
						public void onHide(HideEvent event) {
							if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
								//TODO to be implemented
							}
							else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {
							}
						}
					});
					confirmBox.show();

				}
			}

			@Override
			public void onModeleModify(ModeleModel modele) {
				bus.fireEvent(new ModifierModeleEvent(modele.getIdModeleVersion()));
			}

			@Override
			public void onModeleExecute(ModeleModel modele) {
				navigation.getBus().fireEvent(new ModelisateurExecuterModeleEvent(modele.getIdModeleVersion()));
				//bus.fireEvent(new ExecuterModeleEvent(modele.getIdModeleVersion()));
			}

			@Override
			public void onModeleDelete(final ModeleModel modele) {
				final ConfirmMessageBox confirmBox = new ConfirmMessageBox(
						messages.commonConfirmation(), messages.accueilDeleteConfirmMessage());
				confirmBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
				confirmBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
				confirmBox.addHideHandler(new HideHandler() {
					public void onHide(HideEvent event) {
						if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
							ClientAccueilModelisateurServiceAsync.Util.getInstance().updateByIdModele(
									modele.getIdModele(), false, new AsyncCallbackWithErrorResolution<Integer>() {

										@Override
										public void onSuccess(Integer arg0) {
											modele.setInActif(false);
											grid.getStore().update(modele);
											grid.getLoader().load();
										}
									});
						}
						else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {
						}
					}
				});
				confirmBox.show();
			}

			@Override
			public void onModeleUndelete(final ModeleModel modele) {
				final ConfirmMessageBox confirmBox = new ConfirmMessageBox(
						messages.commonConfirmation(), messages.accueilUndeleteConfirmMessage());
				confirmBox.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
				confirmBox.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
				confirmBox.addHideHandler(new HideHandler() {
					public void onHide(HideEvent event) {
						if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.YES.name()) ) {
							ClientAccueilModelisateurServiceAsync.Util.getInstance().updateByIdModele(
									modele.getIdModele(), true, new AsyncCallbackWithErrorResolution<Integer>() {

										@Override
										public void onSuccess(Integer arg0) {
											modele.setInActif(true);
											grid.getStore().update(modele);
										}
									});
						}
						else if( confirmBox.getHideButton() == confirmBox.getButtonById(PredefinedButton.NO.name()) ) {
						}
					}
				});
				confirmBox.show();

			}
		};
		actionsColumn.setCell(imagesCell);
		cfgs.add(actionsColumn);

		ColumnModel<ModeleModel> cm = new ColumnModel<ModeleModel>(cfgs);
		GroupingView<ModeleModel> view = new GroupingView<ModeleModel>();
		view.setShowGroupedColumn(true);
		view.setForceFit(true);
		view.setAutoFill(true);

		
		grid = new Grid<ModeleModel>(store, cm) {
			@Override
			protected void onAfterFirstAttach() {
				super.onAfterFirstAttach();
				Scheduler.get().scheduleDeferred(new ScheduledCommand() {
					@Override
					public void execute() {
						loader.load();
					}
				});
			}
		};
		grid.setView(view);
		grid.getView().setForceFit(true);
		//	    grid.setLoadMask(true);
		grid.setLoader(loader);
		

		add(grid, new VerticalLayoutData(1, 1));

		setCellDisplay(libelleColumn, 0);
		setCellDisplay(dateColumn, 1);
		setCellDisplay(utilisateurColumn, 2);
		setCellDisplay(publicationColumn, 3);
		grid.getView().refresh(false);
		loader.addLoadHandler(new LoadHandler<PagingLoadConfig, PagingLoadResult<ModeleModel>>() {

			@Override
			public void onLoad(LoadEvent<PagingLoadConfig, PagingLoadResult<ModeleModel>> event) {
				/*int numpages = loader.getTotalCount() / 30 + 1;
				pagingToolbar.getPagingNumberSpinner().setMaxValue(numpages);
				pagingToolbar.setTotalRecord(numpages);
				pagingToolbar.getTotalRecordLabel().setText("/" + String.valueOf(numpages));
				int value = Integer.parseInt(pagingToolbar.getPagingNumberSpinner().getText());
				if( value == 1 ) {
					Image prevIcon = new Image();
					prevIcon.setResource(images.leftArrowButtonDisable());
					pagingToolbar.getPrev().setHTML(prevIcon + "");
				}
				else {
					Image prevIcon = new Image();
					prevIcon.setResource(images.prevIcon());
					pagingToolbar.getPrev().setHTML(prevIcon + "");
				}
				if( value == numpages ) {
					Image nextIcon = new Image();
					nextIcon.setResource(images.rightArrowButtonDisable());
					pagingToolbar.getNext().setHTML(nextIcon + "");
				}
				else {
					Image nextIcon = new Image();
					nextIcon.setResource(images.nextIcon());
					pagingToolbar.getNext().setHTML(nextIcon + "");
				}*/
			}
		});
		grid.getStore().addStoreAddHandler(new StoreAddHandler<ModeleModel>() {
			@Override
			public void onAdd(StoreAddEvent<ModeleModel> event) {
				for( ModeleModel item : grid.getStore().getAll() )
					grid.getStore().update(item);
				grid.getView().refresh(false);
			}
		});

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void setCellDisplay(ColumnConfig col, final int index) {
		switch( index ) {
			case 0 : //libelle
				col = (ColumnConfig<ModeleModel, String>) col;
				col.setCell(new AbstractCell<String>() {
					@Override
					public void render(com.google.gwt.cell.client.Cell.Context context, String value, SafeHtmlBuilder sb) {
						ModeleModel modeleValue = store.get(context.getIndex());
						@SuppressWarnings("unused")
						String label = "";
						label = modeleValue.getLLibelle();

						sb.appendHtmlConstant(generateStringStyle(value, modeleValue));
					}
				});
				break;
			case 1 : //date
				col = (ColumnConfig<ModeleModel, Date>) col;
				col.setCell(new AbstractCell<Date>() {
					@Override
					public void render(com.google.gwt.cell.client.Cell.Context context, Date value, SafeHtmlBuilder sb) {
						ModeleModel modeleValue = store.get(context.getIndex());
						String label = "";
						label = DateTimeFormat.getFormat("dd/MM/yyyy").format(modeleValue.getDDateheureCrea());
						sb.appendHtmlConstant(generateStringStyle(label, modeleValue));
					}
				});
				break;
			case 2 : //utilisateur
				col = (ColumnConfig<ModeleModel, String>) col;
				col.setCell(new AbstractCell<String>() {
					@Override
					public void render(com.google.gwt.cell.client.Cell.Context context, String value, SafeHtmlBuilder sb) {
						ModeleModel modeleValue = store.get(context.getIndex());
						String label = "";
						label = modeleValue.getCUtilisateur();
						sb.appendHtmlConstant(generateStringStyle(label, modeleValue));
					}
				});
				break;
			case 3 : //publication

				col = (ColumnConfig<ModeleModel, Integer>) col;
				col.setCell(new AbstractCell<Integer>() {
					@Override
					public void render(com.google.gwt.cell.client.Cell.Context context, Integer value, SafeHtmlBuilder sb) {
						ModeleModel modeleValue = store.get(context.getIndex());
						String label = "";
						if( modeleValue.getPubVersion() > 0 )
							label = String.valueOf(modeleValue.getPubVersion());
						else
							label = "";

						sb.appendHtmlConstant(generateStringStyle(label, modeleValue));
					}
				});
				break;
		}
		/*
		 * col.setCell(new AbstractCell<String>() {
		 * @Override public void render(com.google.gwt.cell.client.Cell.Context context, String
		 * value, SafeHtmlBuilder sb) { ModeleModel modeleValue = store.get(context.getIndex());
		 * String label = ""; switch( index ) { case 0 : //libelle label =
		 * modeleValue.getLLibelle(); break; case 1 : //date label =
		 * DateTimeFormat.getFormat("dd/MM/yyyy").format(modeleValue.getDDateheureCrea()); break;
		 * case 2 : //utilisateur label = modeleValue.getCUtilisateur(); break; case 3 :
		 * //publication if (modeleValue.getPubVersion() > 0) label =
		 * String.valueOf(modeleValue.getPubVersion()); else label = ""; break; }
		 * sb.appendHtmlConstant(generateStringStyle(label,modeleValue)); } });
		 */
	}

	private String generateStringStyle(String label, ModeleModel modeleValue) {
		String styleString = "";
		if( label == null )
			label = "";

		if( !modeleValue.getInActif() ) {
			styleString = "<span class='inactiveItem' >" + label + "</span>"; //styleItalicGray
		}
		else {
			if( !modeleValue.isEnabled() ) {
				styleString = "<span class='grayItem' >" + label + "</span>"; //styleGray
			}
			else {
				styleString = label; //styleNormal
			}
		}
		return styleString;
	}

	public Grid<ModeleModel> getGrid() {
		return grid;
	}

	public void setGrid(Grid<ModeleModel> grid) {
		this.grid = grid;
	}

}
