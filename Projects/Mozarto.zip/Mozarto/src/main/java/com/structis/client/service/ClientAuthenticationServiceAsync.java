package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.structis.shared.config.ApplicationContext;
import com.structis.shared.model.Metier;

public interface ClientAuthenticationServiceAsync {
	public static class Util {

		private static ClientAuthenticationServiceAsync instance = GWT.create(ClientAuthenticationService.class);

		public static ClientAuthenticationServiceAsync getInstance() {
			return instance;
		}

	}

	void getCurrentLogin(AsyncCallback<ApplicationContext> callback);

	void login(String userName, String passWord, Integer idMetier, AsyncCallback<ApplicationContext> callback);

	void changeMetier(Integer metierId, AsyncCallback<ApplicationContext> callback);

	void logout(AsyncCallback<Void> callback);

	void getAllMetier(AsyncCallback<List<Metier>> callback);

}
