package com.structis.server.service.report;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.structis.client.util.ImportUtil;
import com.structis.server.constant.ConstantServer;
import com.structis.server.core.SpringGetter;
import com.structis.server.service.domain.AttributEtenduService;
import com.structis.server.service.domain.CaracteristiqueService;
import com.structis.server.service.domain.CompositionReferenceService;
import com.structis.server.service.domain.CompositionService;
import com.structis.server.service.domain.ElementService;
import com.structis.server.service.domain.ModeleService;
import com.structis.server.service.domain.ReferenceService;
import com.structis.server.service.domain.UtilisateurService;
import com.structis.server.util.PropertiesUtil;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.AttributEtendu;
import com.structis.shared.model.CmpComposition;
import com.structis.shared.model.CmpReference;
import com.structis.shared.model.Element;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.MdlReference;
import com.structis.shared.model.Utilisateur;

/**
 * Servlet implementation class ShowBirtReport
 */
@SuppressWarnings("deprecation")
public class ShowBirtReport extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static final String FIRST_COLUMN_WIDTH = "20%";

	private static final String HEADER_BG_COLOUR = "#CCCCCC";

	private static final String ODD_ROW_BG_COLOUR = "#EEEEEE";

	private static final String EVEN_ROW_BG_COLOUR = "#FFFFFF";

	private static final Logger LOGGER = Logger.getLogger(ShowBirtReport.class);

	private static Integer totalQuantity;

	private PropertiesUtil reportConfig;

	private CompositionService compositionService;

	private CaracteristiqueService caracteristiqueService;

	private ReferenceService referenceService;

	private ElementService elementService;

	private AttributEtenduService attributEtenduService;
	
	private CompositionReferenceService compositionReferenceService;
	
	private UtilisateurService utilisateurService;
	
	private  ModeleService  modeleService;
	
	private static ReportDesignHandle reportDesignHandle;

	private static ElementFactory elementFactory;

	private static ReportEngine engine;

	private static IReportRunnable design;

	private DecimalFormat df = new DecimalFormat("#.###");
	
	private List<AttributEtendu> allMetierAttributes;
	
	private Integer metierId;
	
	private Integer userId;
	
	private Integer modelVersionId;
	
	private Map<String, Double> totalAttributeValueMap;
	@SuppressWarnings("rawtypes")
	private List<List> columnsElementOrder;
	
	//private Map<Integer, Short> orderElementMap;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShowBirtReport() {
		super();
	}

	@Override
	public void init() throws ServletException {
		super.init();

		compositionService = (CompositionService) SpringGetter.getBean(getServletContext(), "compositionService");
		caracteristiqueService = (CaracteristiqueService) SpringGetter.getBean(getServletContext(), "caracteristiqueService");
		referenceService = (ReferenceService) SpringGetter.getBean(getServletContext(), "referenceService");
		elementService = (ElementService) SpringGetter.getBean(getServletContext(), "elementService");
		attributEtenduService = (AttributEtenduService) SpringGetter.getBean(getServletContext(), "attributEtenduService");
		compositionReferenceService = (CompositionReferenceService)SpringGetter.getBean(getServletContext(), "compositionReferenceService");
		utilisateurService = (UtilisateurService)SpringGetter.getBean(getServletContext(), "utilisateurService");
		modeleService = (ModeleService)SpringGetter.getBean(getServletContext(), "modeleService");
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		totalQuantity = 0;
		String reportConfigFile = getServletContext().getRealPath("/")+ "birt/reports/" + "report-config.properties";
		reportConfig = new PropertiesUtil(reportConfigFile);
		//String contextPath = request.getContextPath();
		String reportName = request.getParameter(ConstantServer.PARAM_REPORT_NAME);
		modelVersionId = Integer.parseInt(request.getParameter(ConstantServer.PARAM_MODEL_EVERSION_ID));
		Integer compositionId = Integer.parseInt(request.getParameter(ConstantServer.PARAM_COMPOSITION_ID));
		metierId = Integer.parseInt(request.getParameter(Constant.ID_METIER));
		userId = Integer.parseInt(request.getParameter(Constant.ID_USER));
		
		CmpComposition composition = compositionService.findById(compositionId);
		
		File newReportFile = null;
		try {
			try {
				String reportFolder = getServletContext().getRealPath("/") + "birt/reports/";
				String reportFile = reportFolder + reportName;
				if( !new File(reportFile).exists() ) {
					throw new RuntimeException("Report file does not exist:" + reportFile);
				}

				String xmlDataFile = reportFolder + "pegaz-info.xml";
				newReportFile = cloneReportFile(reportFolder, reportFile, xmlDataFile);
				initReportDesigner(newReportFile.getAbsolutePath());
				GridHandle headerGrid = (GridHandle) reportDesignHandle.findElement("headerGrid");
				processHeaderBlock(headerGrid);

				GridHandle outerGrid = (GridHandle) reportDesignHandle.findElement("outerGrid");
				int row = 0;
				
				processPegazInfoBlock(outerGrid, ++row, xmlDataFile);

				MdlCaracteristique characteristic = caracteristiqueService.getRootNode(modelVersionId);
				
				allMetierAttributes = attributEtenduService.findByMetierAndType("E", metierId);
				
				totalAttributeValueMap = new HashMap<String, Double>();
				
				columnsElementOrder = buildColumnOrderForElement();
				
				processModelBlock(outerGrid, ++row, composition, characteristic.getLLibelleLong());

				GridHandle referenceGrid = (GridHandle) reportDesignHandle.findElement("referenceGrid");
				CellHandle referenceCell = referenceGrid.getCell(1, 1);
				++row;
				
				
				//This map is used to sort Attributes of Element (and manually added Element) blocks
				//orderElementMap = buildColumnOrderMapForAttributes(allMetierAttributes);
				
				processReferenceBlock(referenceCell, compositionId);


				processManuallyAddedElementBlock(
						outerGrid, ++row, compositionId, metierId, allMetierAttributes, columnsElementOrder,
						/*allElementAttributes,*/ totalAttributeValueMap);

				processTotalCalculationBlock(outerGrid, ++row, /*allElementAttributes,*/ totalAttributeValueMap);
				
				processSignatureBlock(outerGrid, ++row);

				reportDesignHandle.saveAs(newReportFile.getAbsolutePath());
				reportDesignHandle.close();

				//Generate PDF report	
				initReportEngine(newReportFile.getAbsolutePath());

				String downloadFileName = generateReportFileName(composition.getLLibelleLong());
				File pdfFile = generatePdfReport();

				FileInputStream fileToDownload = new FileInputStream(pdfFile);
				ServletOutputStream output = response.getOutputStream();
				response.setHeader("Content-Disposition", "attachment; filename=" + downloadFileName);
				response.setContentLength(fileToDownload.available());
				response.setCharacterEncoding("utf-8");

				int c;
				while( (c = fileToDownload.read()) != -1 ) {
					output.write(c);
				}

				output.flush();
				output.close();
				fileToDownload.close();

				LOGGER.info("Export PDF Done");
			}
			catch( SemanticException e ) {
				LOGGER.error(e.getMessage(), e);
			}
			catch( Exception e ) {
				throw e;
			}
		}
		catch( Exception e ) {
			LOGGER.error(e.getMessage(), e);
		}
		finally {
			if( newReportFile != null ) {
				newReportFile.delete();
			}
		}
	}

	private String generateReportFileName(String compositionName) {

		//File name pattern: Mozarto_titreDeComposition_dd-MM-yyyy-hhmmss.pdf
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-hhmmss");
		Date d = new Date();
		String timeStamp = sdf.format(d);
		return "Mozarto_" + compositionName + "_" + timeStamp + ".pdf";
	}

	private void processSignatureBlock(GridHandle outerGrid, int row) throws SemanticException {
		if( "true".equalsIgnoreCase(reportConfig.getValue("report.signature.endOfPage")) ) {
			outerGrid.getCell(row, 1).drop();
		}
		else {
			GridHandle footerGrid = (GridHandle) reportDesignHandle.findElement("footerGrid");
			footerGrid.getCell(1, 1).drop();
			outerGrid.getCell(row, 1).setProperty("paddingTop", "0pt");
			outerGrid.getCell(row, 1).setProperty("paddingBottom", "0pt");
		}
	}
	private String isDisplayColumnTotal(String columnName){
		for(int i=0; i < allMetierAttributes.size(); i++){
			String propertyKey = "calcul_totaux.attribut.0"+(i+1);
			String columnNameConfig = reportConfig.getValue(propertyKey);
			if(columnNameConfig != null && columnNameConfig.equalsIgnoreCase(columnName) ){
				return columnName;
			}
		}
		return null;
	}
	private void processTotalCalculationBlock(GridHandle outerGrid, int row, /*List<AttributEtendu> allElementAttributes,*/
			Map<String, Double> totalAttributeValueMap) throws SemanticException {
		if( !"true".equalsIgnoreCase(reportConfig.getValue("report.totalCalculation.show")) ) {
			return;
		}
		List<AttributEtendu> allMetierAttributesToDisplay = new ArrayList<AttributEtendu>();
		for(int i=0; i < allMetierAttributes.size(); i++){
				if(isDisplayColumnTotal(allMetierAttributes.get(i).getLLibelle()) != null 
						/*&& totalAttributeValueMap.get(allMetierAttributes.get(i).getLLibelle().toUpperCase()) != null
						&& totalAttributeValueMap.get(allMetierAttributes.get(i).getLLibelle().toUpperCase()) != null*/){
					allMetierAttributesToDisplay.add(allMetierAttributes.get(i));
				}
			//}
		}
		
		/*if( allMetierAttributesToDisplay.size() == 0 ) {
			return;
		}*/
		CellHandle mainCell = outerGrid.getCell(row, 1);
		mainCell.setProperty("paddingTop", "0pt");
		mainCell.setProperty("paddingBottom", "0pt");
		int headerRowNumber = 0;
		if(reportConfig.getValue("calcul_totaux.attribut.00") != null && !"".equals(reportConfig.getValue("calcul_totaux.attribut.00"))){
			headerRowNumber = 1;
		}
		TableHandle table = createTable(null, 2, headerRowNumber, allMetierAttributesToDisplay.size(), true);
		table.setProperty("marginBottom", (Integer.valueOf(reportConfig.getValue("report.n_distance_blocs_principaux"))-4)+"pt");
		mainCell.getContent().add(table);

		//buildRowOrderMapForTotalCalculationBlock(allElementAttributes);
		
		int i = 0;
		for( AttributEtendu attributEtendu : allMetierAttributesToDisplay ) {
			String attributeLabel = attributEtendu.getLLibelle();

			RowHandle detailRow = (RowHandle) table.getDetail().get(i);
			CellHandle cell1 = (CellHandle) detailRow.getCells().get(0);
			LabelHandle label1 = createLabel(reportDesignHandle.getMessage("totalQuantityXAttr").replace(
					"ATTR", attributEtendu.getLLibelle()));
			cell1.getContent().add(label1);
			CellHandle cell2 = (CellHandle) detailRow.getCells().get(1);
			Double value = totalAttributeValueMap.get(attributeLabel.toUpperCase());
			LabelHandle label2 = null;
			if(value == null){
				label2 = createLabel("0");
			}else if (value == -1){
				label2 = createLabel(reportDesignHandle.getMessage("errorcalculate"));
			}else{
				label2 = createLabel(df.format(value));
			}
			
			cell2.getContent().add(label2);
			i++;
		}

		// Set header labels
		
		if(reportConfig.getValue("calcul_totaux.attribut.00") != null && !"".equals(reportConfig.getValue("calcul_totaux.attribut.00"))){
			RowHandle headerRow = (RowHandle) table.getHeader().get(0);
			headerRow.setProperty("backgroundColor", HEADER_BG_COLOUR);
			CellHandle headerCell1 = (CellHandle) headerRow.getCells().get(0);
			headerCell1.setProperty("textAlign", "left");
	
			LabelHandle label1 = createLabel(reportDesignHandle.getMessage("totalQuantity"));
			headerCell1.getContent().add(label1);
			CellHandle headerCell2 = (CellHandle) headerRow.getCells().get(1);
			headerCell2.setProperty("textAlign", "left");

			LabelHandle label2 = createLabel(totalQuantity + "");
			headerCell2.getContent().add(label2);
		}
		
	}

	@SuppressWarnings("rawtypes")
	private void processManuallyAddedElementBlock(GridHandle outerGrid, int row, Integer compositionId, Integer metierId,
			List<AttributEtendu> allMetierAttributes, List<List> columnsOrder,
			/*List<AttributEtendu> allElementAttributes,*/ Map<String, Double> totalAttributeValueMap) throws SemanticException {
		if( !"true".equalsIgnoreCase(reportConfig.getValue("report.manuallyAddedElementInfo.show")) ) {
			return;
		}

		List<Element> manuallySelectedElements = elementService.findManuallySelectedCompositionElement(compositionId);
		if( ImportUtil.isNullOrEmpty(manuallySelectedElements) ) {
			return;
		}

		CellHandle cell = outerGrid.getCell(row, 1);
		cell.setProperty("paddingTop", "0pt");
		cell.setProperty("paddingBottom", "0pt");
		TableHandle table = createElementBlock(
				metierId, allMetierAttributes, columnsOrder,  manuallySelectedElements, /*allElementAttributes,*/
				totalAttributeValueMap);

		if( table != null ) {
			table.setProperty("marginBottom", reportConfig.getValue("report.n_distance_blocs_principaux")+"pt");
			cell.getContent().add(table);
		}
	}

	@SuppressWarnings("rawtypes")
	private TableHandle processElementByReferenceBlock(Integer referenceId, Integer compositionId, Integer metierId,
			List<AttributEtendu> allMetierAttributes, List<List> columnsOrder, 
			/*List<AttributEtendu> allElementAttributes,*/ Map<String, Double> totalAttributeValueMap) throws SemanticException {

		List<Element> elements = elementService.findCompositionElementByReference(compositionId, referenceId);
		
		if( ImportUtil.isNullOrEmpty(elements) ) {
			return null;
		}

		TableHandle table = createElementBlock(
				 metierId, allMetierAttributes, columnsOrder, elements,/* allElementAttributes,*/
				totalAttributeValueMap);
		removeAllPaddingTable(table);
	
		return table;
	}

	@SuppressWarnings("rawtypes")
	private TableHandle createElementBlock( Integer metierId, List<AttributEtendu> allMetierAttributes,
			List<List> columnsOrder, /*Map<Integer, Short> orderMap,*/ List<Element> elements,
			/*List<AttributEtendu> allElementAttributes,*/ Map<String, Double> totalAttributeValueMap) throws SemanticException {

		int elementColumns = 4;
		int totalColumns = elementColumns;
		Map<Integer, Short> orderMap = new HashMap<Integer, Short>();
		
		List<AttributEtendu> allMetierAttributesToDisplay = new ArrayList<AttributEtendu>();
		short rankIndex = 0;
		for(int i=0; i < allMetierAttributes.size(); i++){
			String columnName = reportConfig.getValue("element.attribut.colonne.0"+(i+1));
			for(AttributEtendu allMetierAttribute:allMetierAttributes){
				if(columnName != null && allMetierAttribute.getLLibelle().equalsIgnoreCase(columnName)){
					allMetierAttributesToDisplay.add(allMetierAttribute);
					orderMap.put(allMetierAttribute.getIdAttributEtendu(), rankIndex);
					rankIndex = (short) (rankIndex + 1);
				}
			}
		}
		
		
		if( !ImportUtil.isNullOrEmpty(allMetierAttributesToDisplay) ) {
			totalColumns += allMetierAttributesToDisplay.size();
		}

		TableHandle table = createTable(null, totalColumns, 1, elements.size(), true);
		RowHandle headerRow = (RowHandle) table.getHeader().get(0);

		//build header row.
		int i = 0;
		for( List list : columnsOrder ) {
			String columnLabel = list.get(1).toString();
			String columnWidth = list.get(2).toString() + "%";
			String align = list.get(3).toString();

			CellHandle cell = (CellHandle) headerRow.getCells().get(i);
			table.getColumns().get(i).setProperty("width", columnWidth);
			cell.setProperty("textAlign", align);
			LabelHandle label = createLabel(columnLabel);
			setBackgroundColor(cell, HEADER_BG_COLOUR);
			cell.getContent().add(label);
			i++;
		}

		int j = elementColumns;
		for( AttributEtendu attributEtendu : allMetierAttributesToDisplay ) {
			CellHandle cell = (CellHandle) headerRow.getCells().get(j);
			cell.setProperty("textAlign", "left");
			LabelHandle label = createLabel(attributEtendu.getLLibelle());
			setBackgroundColor(cell, HEADER_BG_COLOUR);
			cell.getContent().add(label);
			j++;
		}

		//build detail rows.
		RowHandle detailRow = null;
		List column1 = columnsOrder.get(0);
		List column2 = columnsOrder.get(1);
		List column3 = columnsOrder.get(2);
		List column4 = columnsOrder.get(3);
		int k = 0;
		for( Element element : elements ) {
			detailRow = (RowHandle) table.getDetail().get(k);

			CellHandle cell1 = (CellHandle) detailRow.getCells().get(0);
			processDetailCell(cell1, column1, element, k);

			CellHandle cell2 = (CellHandle) detailRow.getCells().get(1);
			processDetailCell(cell2, column2, element, k);

			CellHandle cell3 = (CellHandle) detailRow.getCells().get(2);
			processDetailCell(cell3, column3, element, k);

			CellHandle cell4 = (CellHandle) detailRow.getCells().get(3);
			processDetailCell(cell4, column4, element, k);

			List<AttributEtendu> elementAttributes = attributEtenduService.findElementAttributeByElementId(
					metierId, element.getIdElement());
			for( AttributEtendu attributEtendu : elementAttributes ) {
				if(orderMap.containsKey(attributEtendu.getIdAttributEtendu())){
					String attributeLabel = attributEtendu.getLLibelle();
					String attributeValue = attributEtendu.getLValeur();
	
					if( isNumeric(attributeValue) ) {
						try {
							Double value = totalAttributeValueMap.get(attributeLabel.toUpperCase());
							if( value == null ) {
								//allElementAttributes.add(attributEtendu);
								totalAttributeValueMap.put(
										attributeLabel.toUpperCase(), Double.parseDouble(attributeValue) * element.getQte());
							}
							else {
								if(value != -1){
									totalAttributeValueMap.put(
											attributeLabel.toUpperCase(),
											value + (Double.parseDouble(attributeValue) * element.getQte()));
								}
							}
						}
						catch( NumberFormatException e ) {
							
						}
					}else{
						totalAttributeValueMap.put(attributeLabel.toUpperCase(),(double) -1);
					}
	
					short rank = orderMap.get(attributEtendu.getIdAttributEtendu());
					CellHandle cell = (CellHandle) detailRow.getCells().get(rank + elementColumns);
					if( k % 2 == 1 ) {
						setBackgroundColor(cell, ODD_ROW_BG_COLOUR);
					}
					LabelHandle label = createLabel(attributeValue);
					cell.getContent().add(label);
				}
			}

			k++;
		}
		return table;
	}
	
	@SuppressWarnings("rawtypes")
	private static void processDetailCell(CellHandle cell, List columnInfo, Element element, int rowIndex)
			throws SemanticException {
		if( rowIndex % 2 == 1 ) {
			setBackgroundColor(cell, ODD_ROW_BG_COLOUR);
		}

		setBorders(cell);
		String align = columnInfo.get(3).toString();
		cell.setProperty("textAlign", align);
		String cellValue = "";
		if( "quantity".equalsIgnoreCase(columnInfo.get(0).toString()) ) {
			int quantity = element.getQte();
			cellValue = quantity + "";
			totalQuantity += quantity;
		}
		else if( "code".equalsIgnoreCase(columnInfo.get(0).toString()) ) {
			cellValue = element.getCElement();
		}
		else if( "label".equalsIgnoreCase(columnInfo.get(0).toString()) ) {
			cellValue = element.getLLibelleLong();
		}
		else if( "supplierName".equalsIgnoreCase(columnInfo.get(0).toString()) ) {
			cellValue = element.getLNomenclatureFournisseur();
		}
		LabelHandle label = createLabel(cellValue);
		cell.getContent().add(label);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static List<List> buildColumnOrderForElement() {
		List<List> results = new ArrayList<List>();

		//column 1
		List l1 = new ArrayList();
		l1.add("quantity"); //Column name
		l1.add("Qté"); // Column label
		l1.add("5"); // Column width (%)
		l1.add("right"); // Column text align

		//column 2
		List l2 = new ArrayList();
		l2.add("code");
		l2.add("Code");
		l2.add("10");
		l2.add("center");

		//column 3
		List l3 = new ArrayList();
		l3.add("label");
		l3.add("Libellé");
		l3.add("20");
		l3.add("left");

		//column 4
		List l4 = new ArrayList();
		l4.add("supplierName");
		l4.add("Nomenc. four");
		l4.add("15");
		l4.add("left");

		results.add(l1);
		results.add(l2);
		results.add(l3);
		results.add(l4);

		return results;
	}

	private static LabelHandle createLabel(String text) throws SemanticException {
		LabelHandle label = elementFactory.newLabel(null);
		label.setText(text);
		return label;
	}



	private GridHandle createCharacteristicOfReferenceBlock(/*CellHandle mainCell,*/ Integer referenceId) throws SemanticException {
		GridHandle grid = null;
		//if( "true".equalsIgnoreCase(reportConfig.getValue("report.characteristicInfo.show")) ) {

		List<MdlCaracteristique> characteristics = caracteristiqueService.findCaracteristiqueByModeleVersionAndReference(
				modelVersionId, referenceId);//caracteristiqueService.findByCompositionId(compositionId);
		Map<Integer, String> parentCharacteristics = new HashMap<Integer, String>();
		for( MdlCaracteristique characteristic : characteristics ) {
			if( characteristic.getIdCaracteristiqueParent() != null ) {
				MdlCaracteristique caracteristiqueParent = caracteristiqueService.findById(characteristic.getIdCaracteristiqueParent());
				parentCharacteristics.put(characteristic.getIdCaracteristique(), caracteristiqueParent.getLLibelleLong());
			}
		}

		if( ImportUtil.isNullOrEmpty(characteristics) ) {
			return null;
		}

		grid = createGrid(null, 2, 1);
		grid.getColumns().get(0).setProperty("width", FIRST_COLUMN_WIDTH);

		CellHandle cell = grid.getCell(1, 1);
		//removeAllPadding(cell);
		cell.setProperty("textAlign", "left");
		LabelHandle label = createLabel("Caractéristiques");
		cell.getContent().add(label);
		//cell.setProperty("borderBottomWidth", "1pt");

		int totalItems = characteristics.size();
		int itemPerRow = 4;
		int numOfRow = (int) Math.ceil(totalItems * 2.0 / itemPerRow);
		GridHandle characteristicGrid = createGrid(null, itemPerRow, numOfRow);
		characteristicGrid.setProperty("width", "100%");
		characteristicGrid.setProperty("paddingTop", "0pt");
		characteristicGrid.setProperty("marginTop", "0pt");

		cell = grid.getCell(1, 2);
		//setNullBorders(cell);

		cell.getContent().add(characteristicGrid);
		removeAllPaddingCell(cell);
		int currentArrayIndex = 0;
		for( int i = 1 ; i <= numOfRow ; i++ ) {
			for( int j = 1 ; j <= (itemPerRow / 2) ; j++ ) {
				MdlCaracteristique data = null;
				if( currentArrayIndex < totalItems ) {
					data = characteristics.get(currentArrayIndex);
				}
				int indexLabel;
				int indexValue;
				if( j == 1 ) {
					indexLabel = 1;
					indexValue = 2;
				}
				else {
					indexLabel = 3;
					indexValue = 4;
				}

				CellHandle cellC = (CellHandle) characteristicGrid.getCell(i, indexLabel);
				cellC.setProperty("textAlign", "left");
				if( data != null ) {
					String labelString = parentCharacteristics.get(data.getIdCaracteristique()) != null ? parentCharacteristics.get(data.getIdCaracteristique()) : "";
					label = createLabel(labelString);
					
					cellC.getContent().add(label);
				}
				setBackgroundColor(cellC, ODD_ROW_BG_COLOUR);
				setBorderIngrid(numOfRow, itemPerRow, i, indexLabel, cellC);
				cellC = (CellHandle) characteristicGrid.getCell(i, indexValue);
				cellC.setProperty("textAlign", "left");
				if( data != null ) {
					label = createLabel(data.getLLibelleLong());
					cellC.getContent().add(label);
				}
				setBackgroundColor(cellC, EVEN_ROW_BG_COLOUR);
				setBorderIngrid(numOfRow, itemPerRow, i, indexValue, cellC);

				currentArrayIndex = currentArrayIndex + 1;
			}
			
		}
		//cell.setProperty("borderBottomWidth", "1pt");
		//mainCell.getContent().add(createLabel(""));
		//mainCell.getContent().add(grid);
		grid.setProperty("marginTop", "0px");
		grid.setProperty("paddingTop", "0px");
			//grid.setProperty("marginBottom", reportConfig.getValue("report.n_distance_blocs_reference")+"pt");
		//}
		return grid;
	}
	private void setBorderIngrid(int numOfRow, int itemPerRow,int i, int j, CellHandle cellp) throws SemanticException{
		if(i == 1){
			cellp.setProperty("borderTopWidth", "0pt");
		}
		if(i == (numOfRow)){
			cellp.setProperty("borderBottomWidth", "0pt");
		}
		if(j == 1){
			cellp.setProperty("borderLeftWidth", "0pt");
		}
		if(j == itemPerRow){
			cellp.setProperty("borderRightWidth", "0pt");
		}
	}
	private static GridHandle createGrid(String name, int columnNum, int rowNum) throws SemanticException {
		GridHandle grid = reportDesignHandle.getElementFactory().newGridItem(name, columnNum, rowNum);

		for( int i = 1 ; i <= rowNum ; i++ ) {
			for( int j = 1 ; j <= columnNum ; j++ ) {
				CellHandle cell = (CellHandle) grid.getCell(i, j);
				setBorders(cell);
			}
		}

		return grid;
	}

	private static void setBackgroundColor(CellHandle cell, String backgroundColor) {
		try {
			cell.setProperty("backgroundColor", backgroundColor);
		}
		catch( SemanticException e ) {
			e.printStackTrace();
		}
	}

	private void removeAllPaddingCell(CellHandle cell) throws SemanticException {
		cell.setProperty("paddingTop", "0pt");
		cell.setProperty("paddingLeft", "0pt");
		cell.setProperty("paddingBottom", "0pt");
		cell.setProperty("paddingRight", "0pt");
		cell.setProperty("marginTop", "0pt");
		cell.setProperty("marginLeft", "0pt");
		cell.setProperty("marginBottom", "0pt");
		cell.setProperty("marginRight", "0pt");
	}
	private void removeAllPaddingTable(TableHandle table) throws SemanticException {
		table.setProperty("paddingTop", "0pt");
		table.setProperty("paddingLeft", "0pt");
		table.setProperty("paddingBottom", "0pt");
		table.setProperty("paddingRight", "0pt");
		table.setProperty("marginTop", "0pt");
		table.setProperty("marginLeft", "0pt");
		table.setProperty("marginBottom", "0pt");
		table.setProperty("marginRight", "0pt");
	}
	
	
	/*private TableHandle createReferenceCaracteristiqueElementBlock()  throws Exception{
		TableHandle grid = createTable(null, 1, 0, 4, true);
		return grid;
	}*/
	private TableHandle createReferenceTablePadding()  throws Exception{
		TableHandle grid = createTable(null, 1, 0, 1, true);
		grid.setProperty("borderLeftWidth", "0pt");
		grid.setProperty("borderRightWidth", "0pt");
		grid.setProperty("height", reportConfig.getValue("report.n_distance_blocs_reference") + "pt");
		return grid;
	}
	private TableHandle createReferenceTable(MdlReference mdlReference,String observation) throws Exception {
		List<AttributEtendu> attributes = attributEtenduService.findByReferenceId(mdlReference.getIdReference());
		int detailRow = 0;
		if(observation != null){
			detailRow = detailRow + 1;
		}
		List<AttributEtendu> allAttributesToDisplay = new ArrayList<AttributEtendu>();
		for(int i=0; i < allMetierAttributes.size(); i++){
			String columnName = reportConfig.getValue("reference.attribut.colonne.0"+(i+1));
			for(AttributEtendu attribute:attributes){
				if(columnName != null && attribute.getLLibelle().equalsIgnoreCase(columnName)){
					allAttributesToDisplay.add(attribute);
				}
			}
		}
		
		if(attributes.size() > 0 && allAttributesToDisplay.size() > 0){
			detailRow = detailRow + 1;
		}
		
		
		TableHandle grid = createTable(null, 3, 1, /*attributes.size()+1*/detailRow, true);
		removeAllPaddingTable(grid);
		grid.setWidth("100%");
		grid.getColumns().get(0).setProperty("width", FIRST_COLUMN_WIDTH);
		grid.getColumns().get(1).setProperty("width", "76%");
		grid.getColumns().get(2).setProperty("width", "4%");

		// Get the first row.
		RowHandle row = (RowHandle) grid.getHeader().get(0);
		CellHandle cell = null;
		LabelHandle label = null;

		cell = (CellHandle) row.getCells().get(0);
		cell.setProperty("textAlign", "left");
		label = createLabel("Référence");
		cell.getContent().add(label);

		cell = (CellHandle) row.getCells().get(1);
		cell.setProperty("textAlign", "left");
		label = createLabel(mdlReference.getLLibelleLong());
		cell.getContent().add(label);

		cell = (CellHandle) row.getCells().get(2);
		cell.setProperty("textAlign", "center");
		label = createLabel(mdlReference.getQuantity() + "");
		cell.getContent().add(label);
		
		int rowIndex = 0;
		
		if(observation != null){
			row = (RowHandle) grid.getDetail().get(rowIndex);
			cell = (CellHandle) row.getCells().get(0);
			cell.setProperty("textAlign", "left");
			label = createLabel(reportDesignHandle.getMessage("Observations"));
			cell.getContent().add(label);
			//Merge cells 2 and 3
			cell = (CellHandle) row.getCells().get(2);
			cell.drop();
	
			cell = (CellHandle) row.getCells().get(1);
			cell.setColumnSpan(2);
			cell.setProperty("textAlign", "left");
			String observationString = observation != null ? observation : "";
			label = createLabel(observationString); //observation value
			cell.getContent().add(label);
			rowIndex = 1;
		}
		
		
		int totalAttributeItems = allAttributesToDisplay.size();
		if( totalAttributeItems > 0){
			row = (RowHandle) grid.getDetail().get(rowIndex);
			
			cell = (CellHandle) row.getCells().get(2);
			cell.drop();
			
			cell = (CellHandle) row.getCells().get(1);
			cell.drop();
			cell = (CellHandle) row.getCells().get(0);
			cell.setProperty("textAlign", "left");
			cell.setColumnSpan(3);
			
			int itemPerRow = 4;
			int numOfRow = (int) Math.ceil(totalAttributeItems * 2.0 / itemPerRow);
			GridHandle attributesGrid = createGrid(null, itemPerRow, numOfRow);
			attributesGrid.setProperty("width", "100%");
			removeAllPaddingCell(cell);
			//setNullBorders(cell);
			cell.getContent().add(attributesGrid);
			setBackgroundColor(cell, EVEN_ROW_BG_COLOUR);
			int currentArrayIndex = 0;
			for( int i = 1 ; i <= numOfRow ; i++ ) {
				for( int j = 1 ; j <= (itemPerRow/2) ; j++ ) {
					AttributEtendu data = null;
					if(currentArrayIndex < totalAttributeItems){
						data = allAttributesToDisplay.get(currentArrayIndex);
					}
					int indexLabel;
					int indexValue;
					if(j == 1){
						indexLabel = 1;
						indexValue = 2;
					}else{
						indexLabel = 3;
						indexValue = 4;
					}
					String colorBackground = "";
					if( i % 2 == 1 ) {
						colorBackground = ODD_ROW_BG_COLOUR ;
					}else{
						colorBackground =  EVEN_ROW_BG_COLOUR;
					}
					CellHandle cellA = (CellHandle) attributesGrid.getCell(i, indexLabel);
					cellA.setProperty("textAlign", "left");
					if(data != null){
						label = createLabel(data.getLLibelle());
						cellA.getContent().add(label);
					}
					setBackgroundColor(cellA, colorBackground);
					/*if(i == 1){
						cell.setProperty("borderTopWidth", "0pt");
					}*/
					setBorderIngrid(numOfRow, itemPerRow, i, indexLabel, cellA);
					
					cellA = (CellHandle) attributesGrid.getCell(i, indexValue);
					cellA.setProperty("textAlign", "left");
					if(data != null){
						label = createLabel(data.getLValeur());
						cellA.getContent().add(label);
					}
					setBackgroundColor(cellA, colorBackground);
					/*if(i == 1){
						cell.setProperty("borderTopWidth", "0pt");
					}*/
					setBorderIngrid(numOfRow, itemPerRow, i, indexValue, cellA);
					
					currentArrayIndex = currentArrayIndex + 1;
				}
			}
			//cell.setProperty("borderBottomWidth", "1pt");
		}
		return grid;
	}

	private static void setBorders(CellHandle cell) throws SemanticException {
		cell.setProperty("borderBottomColor", "#000000");
		cell.setProperty("borderBottomStyle", "solid");
		cell.setProperty("borderBottomWidth", "thin");
		cell.setProperty("borderLeftColor", "#000000");
		cell.setProperty("borderLeftStyle", "solid");
		cell.setProperty("borderLeftWidth", "thin");
		cell.setProperty("borderRightColor", "#000000");
		cell.setProperty("borderRightStyle", "solid");
		cell.setProperty("borderRightWidth", "thin");
		cell.setProperty("borderTopColor", "#000000");
		cell.setProperty("borderTopStyle", "solid");
		cell.setProperty("borderTopWidth", "thin");
		cell.setProperty("paddingLeft", "5pt");
		//cell.setProperty("paddingBottom", "5pt");
	}
	private static void setNullBorders(CellHandle cell) throws SemanticException {
		//cell.setProperty("borderBottomColor", "#000000");
		//cell.setProperty("borderBottomStyle", "solid");
		cell.setProperty("borderBottomWidth", "0pt");
		//cell.setProperty("borderLeftColor", "#000000");
		//cell.setProperty("borderLeftStyle", "solid");
		cell.setProperty("borderLeftWidth", "0pt");
		
		//cell.setProperty("borderRightColor", "#000000");
		//cell.setProperty("borderRightStyle", "solid");
		cell.setProperty("borderRightWidth", "0pt");
		//cell.setProperty("borderTopColor", "#000000");
		//cell.setProperty("borderTopStyle", "solid");
		cell.setProperty("borderTopWidth", "0pt");
	}
	
	private static void setStyleCellReferenceBlock(CellHandle cell,boolean left,boolean top, boolean right, boolean bottom)throws SemanticException {
		cell.setProperty("borderBottomColor", "#000000");
		cell.setProperty("borderBottomStyle", "solid");
		cell.setProperty("borderBottomWidth", bottom?"thin":"0pt");
		cell.setProperty("borderLeftColor", "#000000");
		cell.setProperty("borderLeftStyle", "solid");
		cell.setProperty("borderLeftWidth", left?"thin":"0pt");
		cell.setProperty("borderRightColor", "#000000");
		cell.setProperty("borderRightStyle", "solid");
		cell.setProperty("borderRightWidth", right?"thin":"0pt");
		cell.setProperty("borderTopColor", "#000000");
		cell.setProperty("borderTopStyle", "solid");
		cell.setProperty("borderTopWidth", top?"thin":"0pt");
		cell.setProperty("backgroundColor", "#FFFFFF");
		cell.setProperty("paddingLeft", "0pt");
		cell.setProperty("paddingTop", "0pt");
		cell.setProperty("paddingRight", "0pt");
		cell.setProperty("paddingBottom", "0pt");
		cell.setProperty("marginLeft", "0pt");
		cell.setProperty("marginTop", "0pt");
		cell.setProperty("marginRight", "0pt");
		cell.setProperty("marginBottom", "0pt");
	}
	
	private void processReferenceBlock(CellHandle cell, Integer compositionId) throws Exception {
		List<CmpReference> cmpReferences = compositionReferenceService.findByIdComposition(compositionId);
		Map<Integer, String> commentCmpReferences = new HashMap<Integer, String>();
		for( CmpReference cmpReference : cmpReferences ) {
			commentCmpReferences.put(cmpReference.getIdReference(), cmpReference.getLCommentaire());
		}
		List<MdlReference> references = referenceService.getSelectedReferencesByCompositionId(compositionId);
		for( MdlReference mdlReference : references ) {
			int numberBlock = 0;
			if("true".equalsIgnoreCase(reportConfig.getValue("report.referenceInfo.show"))){
				TableHandle referenceTable = createReferenceTable(
						mdlReference, commentCmpReferences.get(mdlReference.getIdReference()));
				if( referenceTable != null ) {
					cell.getContent().add(referenceTable);
				}
				numberBlock++;
			}
			if( "true".equalsIgnoreCase(reportConfig.getValue("report.characteristicInfo.show")) ) {
				GridHandle caracteristiqueTable = createCharacteristicOfReferenceBlock(mdlReference.getIdReference());
				if( caracteristiqueTable != null ) {
					if(numberBlock > 0){
						TableHandle distanceTable = createReferenceTablePadding();
						cell.getContent().add(distanceTable);
						RowHandle rowReferenceDistance = (RowHandle) distanceTable.getDetail().get(0);
						setStyleCellReferenceBlock((CellHandle) rowReferenceDistance.getCells().get(0), true, false, true, false);
						rowReferenceDistance.setProperty("height", reportConfig.getValue("report.n_distance_blocs_reference") + "pt");
					}
					
					cell.getContent().add(caracteristiqueTable);
				}
				numberBlock++;
			}
			if( "true".equalsIgnoreCase(reportConfig.getValue("report.elementInfo.show")) ) {

				TableHandle elementTable = processElementByReferenceBlock(
						mdlReference.getIdReference(), compositionId, metierId, allMetierAttributes, columnsElementOrder,
						 totalAttributeValueMap);
				if( elementTable != null ) {
					if(numberBlock > 0){
						TableHandle distanceTable = createReferenceTablePadding();
						cell.getContent().add(distanceTable);
						RowHandle rowReferenceDistance = (RowHandle) distanceTable.getDetail().get(0);
						setStyleCellReferenceBlock((CellHandle) rowReferenceDistance.getCells().get(0), true, false, true, false);
						rowReferenceDistance.setProperty("height", reportConfig.getValue("report.n_distance_blocs_reference") + "pt");
					}
					cell.getContent().add(elementTable);
				}
			}
			if(numberBlock > 0){
				TableHandle distanceTable = createReferenceTablePadding();
				cell.getContent().add(distanceTable);
				RowHandle rowReferenceDistance = (RowHandle) distanceTable.getDetail().get(0);
				setStyleCellReferenceBlock((CellHandle) rowReferenceDistance.getCells().get(0), false, false, false, false);
				rowReferenceDistance.setProperty("height", reportConfig.getValue("report.n_distance_blocs_principaux") + "pt");
			}
		}
		
		
	}
	private void processPegazInfoBlock(GridHandle outerGrid, int row, String xmlDataFile) {
		try {
			File pegazInfoFile = new File(xmlDataFile);
			if( !pegazInfoFile.exists() ) {
				outerGrid.getCell(row, 1).drop();
			}else{
				outerGrid.getCell(row, 1).setProperty("paddingBottom", reportConfig.getValue("report.n_distance_blocs_principaux")+"pt");
			}
		}
		catch( Exception e ) {
		}
	}

	private void processHeaderBlock(GridHandle headerGrid) throws ContentException, NameException {
		try {
			if( !"true".equalsIgnoreCase(reportConfig.getValue("report.docummentTitle.show")) ) {
				headerGrid.getCell(1, 1).drop();
			}else{
				headerGrid.setProperty("marginBottom", (Integer.valueOf(reportConfig.getValue("report.n_distance_blocs_principaux"))-20)+"pt");
			}
		}
		catch( Exception e ) {
		}
	}

	private void processModelBlock(GridHandle outerGrid, int row, CmpComposition composition, String modelName)
			throws SemanticException, IOException {
		if( "true".equalsIgnoreCase(reportConfig.getValue("report.modelInfo.show")) ) {
			GridHandle grid = (GridHandle) reportDesignHandle.findElement("modelInfoBlock");
			CellHandle cell = null;
			LabelHandle label = null;
			//Model name
			cell = grid.getCell(1, 2);
			label = elementFactory.newLabel(null);
			label.setText(modelName);
			cell.getContent().add(label);

			//Model version
			cell = grid.getCell(1, 3);
			label = elementFactory.newLabel(null);
			int Nversion = modeleService.findNVersionByIdModele(composition.getIdModeleVersion());
			label.setText(Nversion + "");
			cell.getContent().add(label);

			//Composition name
			cell = grid.getCell(2, 2);
			
			label = elementFactory.newLabel(null);
			/*String propertyColumnWidth = grid.getColumns().get(cell.getColumn()).getStringProperty("width");
			DimensionValue propertyColumnWidthPT = DimensionUtil.convertTo(propertyColumnWidth, DimensionType.UNITS_IN, DimensionType.UNITS_CM);*/
			label.setText(composition.getLLibelleLong());
			cell.getContent().add(label);
			cell = grid.getCell(3, 2);
			if(composition.getLCommentaire() != null){
				label = elementFactory.newLabel(null);
				String comment = composition.getLCommentaire() != null? composition.getLCommentaire():"";
				label.setText(comment/*wrap(comment, cell.getWidth().getMeasure())*/);
				cell.getContent().add(label);
			}else{
				grid.getRows().get(2).drop();
			}
			outerGrid.getCell(row, 1).setProperty("paddingBottom", reportConfig.getValue("report.n_distance_blocs_principaux")+"pt");
		}
		else {
			outerGrid.getCell(row, 1).drop();
		}
	}

	private static void initReportEngine(String reportFile) {
		EngineConfig conf = new EngineConfig();

		// Create new Report engine based off of the configuration
		engine = new ReportEngine(conf);

		// With our new engine, lets try to open the report design
		try {
			design = engine.openReportDesign(reportFile);
		}
		catch( Exception e ) {
			throw new RuntimeException("An error occured during the opening of the report file!");
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static File generatePdfReport() throws IOException {
		File f = null;
		IRunAndRenderTask task = null;
		PDFRenderContext renderContext = new PDFRenderContext();
		HashMap contextMap = null;
		PDFRenderOption options = null;

		// With the file open, create the Run and Render task to run the report
		task = engine.createRunAndRenderTask(design);

		contextMap = new HashMap();
		// contextMap.put(EngineConstants.APPCONTEXT_HTML_RENDER_CONTEXT, renderContext);
		contextMap.put(EngineConstants.APPCONTEXT_PDF_RENDER_CONTEXT, renderContext);
		task.setAppContext(contextMap);

		// This will set the output file location, the format to render to, and apply to the task
		options = new PDFRenderOption();
		options.setOutputFormat("pdf");
		options.setOption(IPDFRenderOption.PDF_HYPHENATION, true);
		options.setOption(IPDFRenderOption.PDF_TEXT_WRAPPING, true);
		f = createTempFile();

		options.setOutputFileName(f.getAbsolutePath());
		task.setRenderOption(options);

		try {
			task.run();
		}
		catch( Exception e ) {
			throw new RuntimeException("An error occured while running the report!");
		}

		// Destroy the engine and let the garbage collector
		engine.destroy();

		return f;
	}

	private static void initReportDesigner(String reportFile) throws BirtException {
		DesignConfig config = new DesignConfig();

		//		config.setProperty("BIRT_HOME", engineHome);
		Platform.startup(config);
		IDesignEngineFactory factory = (IDesignEngineFactory) Platform.createFactoryObject(IDesignEngineFactory.EXTENSION_DESIGN_ENGINE_FACTORY);
		IDesignEngine engine = factory.createDesignEngine(config);
		SessionHandle session = engine.newSessionHandle(ULocale.ENGLISH);

		reportDesignHandle = session.openDesign(reportFile);
		elementFactory = reportDesignHandle.getElementFactory();
	}

	private  File cloneReportFile(String reportFolder, String reportFile, String xmlDataFile) {
		File tempReportFile = null;
		try {
			File f = new File(reportFile);

			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF8"));

			StringBuilder sb = new StringBuilder();
			String line = null;

			while( (line = in.readLine()) != null ) {
				sb.append(line);
				sb.append("\n");
			}
			String fileContent = sb.toString();
			xmlDataFile = xmlDataFile.replaceAll("\\\\", "/");
			xmlDataFile = xmlDataFile.replaceAll("'", "<![CDATA[']]>");
			xmlDataFile = xmlDataFile.replaceAll("&", "<![CDATA[&]]>");

			//Fill in some data
			//TODO Get User Name from DB
			Utilisateur user = utilisateurService.findUtilisateurById(userId);
			fileContent = fileContent.replaceAll("__Login User__", user.getLNom() + " " +user.getLPrenom());
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			String createdDate = sdf.format(new Date());
			fileContent = fileContent.replaceAll("__Created Date__", createdDate);
			fileContent = fileContent.replaceAll("__logo__", reportConfig.getValue("report.docummentTitle.chemin_logo"));

			// Update XML data source file
			File pegazInfoFile = new File(xmlDataFile);
			if( pegazInfoFile.exists() ) {
				String xmlDataSet = "<property name=\"FILELIST\">" + xmlDataFile + "</property>";
				fileContent = fileContent.replaceAll("<property name=\"FILELIST\">pegaz-info.xml</property>", xmlDataSet);
			}

			in.close();

			String tempFileName = "Temp" + Long.toString(System.nanoTime()) + ".rptdesign";
			tempReportFile = new File(reportFolder + tempFileName);
			Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempReportFile), "UTF-8"));
			out.write(fileContent);
			out.close();
		}
		catch( UnsupportedEncodingException e ) {
			LOGGER.error(e.getMessage(), e);
		}
		catch( IOException e ) {
			LOGGER.error(e.getMessage(), e);
		}
		catch( Exception e ) {
			LOGGER.error(e.getMessage(), e);
		}

		return tempReportFile;
	}

	private static TableHandle createTable(String name, int columnNum, int headerRow, int detailRow, boolean border)
			throws SemanticException {
		TableHandle table = reportDesignHandle.getElementFactory().newTableItem(name, columnNum, headerRow, detailRow, 0);
		if( headerRow > 0){
			RowHandle header = (RowHandle) table.getHeader().get(0);
			
			for( int i = 0 ; i < header.getCells().getCount() ; i++ ) {
				CellHandle cell = (CellHandle) header.getCells().get(i);
				if( border ) {
					setBorders(cell);
				}
			}
		}

		for( int i = 0 ; i < table.getDetail().getCount() ; i++ ) {
			RowHandle detail = (RowHandle) table.getDetail().get(i);
			for( int j = 0 ; j < detail.getCells().getCount() ; j++ ) {
				CellHandle cell = (CellHandle) detail.getCells().get(j);
				if( border ) {
					setBorders(cell);
				}
				if( i % 2 == 1 ) {
					cell.setProperty("backgroundColor", ODD_ROW_BG_COLOUR);
				}
			}
		}

		table.setProperty("repeatHeader", "true");
		return table;
	}

	private static boolean isNumeric(String str) {
		try {
			Double.parseDouble(str);
		}
		catch( NumberFormatException nfe ) {
			return false;
		}
		return true;
	}

	private static File createTempFile() throws IOException {
		String tempFileName = "Temp" + Long.toString(System.nanoTime());
		File f = File.createTempFile(tempFileName, ".pdf");
		return f;
	}
	
}
