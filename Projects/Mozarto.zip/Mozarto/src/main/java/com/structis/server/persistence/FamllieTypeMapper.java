package com.structis.server.persistence;

import java.util.List;

import com.structis.shared.model.FamilleType;

public interface FamllieTypeMapper {
    int deleteById(String cTypeFamille);

  
    int delete(FamilleType record);

  
    int insert(FamilleType record);

 
   
    int insertSelective(FamilleType record);

   
    FamilleType findById(String cTypeFamille);

    List<FamilleType> findAll();

   
    int updateSelective(FamilleType record);

   
    int update(FamilleType record);
}
