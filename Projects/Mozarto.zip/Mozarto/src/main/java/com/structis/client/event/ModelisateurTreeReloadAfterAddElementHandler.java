package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ModelisateurTreeReloadAfterAddElementHandler extends EventHandler {
	void onLoad(ModelisateurTreeReloadAddElementEvent modelisateurTreeAddElementEvent);
}
