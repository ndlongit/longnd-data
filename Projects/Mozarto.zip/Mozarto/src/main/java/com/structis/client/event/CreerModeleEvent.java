package com.structis.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class CreerModeleEvent  extends GwtEvent<CreerModeleHandler>{

	private static Type<CreerModeleHandler> TYPE = new Type<CreerModeleHandler>();
	public static Type<CreerModeleHandler> getType() {
		return TYPE;
	}
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<CreerModeleHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(CreerModeleHandler handler) {
		handler.onLoad(this);
	}
	
	public CreerModeleEvent() {
	}

}
