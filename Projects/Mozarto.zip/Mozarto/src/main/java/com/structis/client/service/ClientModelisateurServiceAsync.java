package com.structis.client.service;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.structis.shared.model.MdlCaracteristique;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.TreeNodeModel;

public interface ClientModelisateurServiceAsync {
	public static class Util {

		private static ClientModelisateurServiceAsync instance = GWT.create(ClientModelisateurService.class);

		public static ClientModelisateurServiceAsync getInstance() {
			return instance;
		}

	}

	/**
	 * Return the children of given parent when expand node in the tree
	 * 
	 * @param node folder
	 * @return the children
	 */
	void getFolderChildren(TreeNodeModel node, boolean includeRegle, AsyncCallback<List<TreeNodeModel>> callback);

	/**
	 * @param node
	 * @param callback
	 */
	void getParent(TreeNodeModel node, AsyncCallback<List<TreeNodeModel>> callback);

	void findAll(AsyncCallback<List<MdlCaracteristique>> callback);

	void deleteModelisateurNode(TreeNodeModel sourceNode, boolean isDeleteRegle, boolean isDeleteMessage,
			boolean isDeleteAll, AsyncCallback<Void> callback);

	void validateToDelete(TreeNodeModel sourceNode, boolean isDeleteRegle, boolean isDeleteMessage, boolean isDeleteAll,
			AsyncCallback<String> callback);
	
	void getMetier(Integer idMetier, AsyncCallback<Metier> callback);
	
	void duplicateNode(TreeNodeModel nodeToBeCopied, TreeNodeModel target, boolean isCopyRegle, boolean isCopyMessage, boolean isCopyChildren, Integer idUtilisateur, Integer idMetier, AsyncCallback<TreeNodeModel> callback);
}
