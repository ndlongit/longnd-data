package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.AttributElementModel;

public interface AttributElementModelProperties extends PropertyAccess<AttributElementModel> {
	 ModelKeyProvider<AttributElementModel> getIdElement();
//	ValueProvider<AttributElementModel, Integer> idElement();

	ValueProvider<AttributElementModel, Integer> idAttributEtendu();
	
	ValueProvider<AttributElementModel, String> attributEtenduLibelle();
	
	ValueProvider<AttributElementModel, String> valeur();
}
