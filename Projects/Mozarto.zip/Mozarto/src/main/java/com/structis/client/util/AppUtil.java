package com.structis.client.util;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.HasWidgets;
import com.google.gwt.user.client.ui.IsWidget;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FormPanel.LabelAlign;
import com.sencha.gxt.widget.core.client.form.FormPanelHelper;
import com.structis.client.message.Messages;
import com.structis.shared.model.reference.TreeNodeModel;

public class AppUtil {
	public static final Messages messages = GWT.create(Messages.class);
	
	public static void showConfirmMessageBox(String message, SelectHandler callbackYes, SelectHandler callbackNon) {
		final ConfirmMessageBox box = new ConfirmMessageBox(
				messages.commonConfirmation(), message);
		showBox(box, callbackYes, callbackNon);
	}
	public static void showConfirmInfoBox(String message,String header, SelectHandler callbackYes, SelectHandler callbackNon) {
		final ConfirmMessageBox box = new ConfirmMessageBox(
				header, message);
		showBox(box, callbackYes, callbackNon);
	}
	
	public static void showBox( ConfirmMessageBox box, SelectHandler callbackYes, SelectHandler callbackNon){
		box.setWidth(300);
		box.getButtonById(PredefinedButton.YES.name()).setText(messages.commonDialogOuiButton());
		if (callbackYes != null) {
			box.getButtonById(PredefinedButton.YES.name()).addSelectHandler(callbackYes);
		}
		box.getButtonById(PredefinedButton.NO.name()).setText(messages.commonDialogNonButton());
		if (callbackNon != null) {
			box.getButtonById(PredefinedButton.NO.name()).addSelectHandler(callbackNon);
		}
		box.show();		
	}
	public static void showMessageBox(String message) {
		final MessageBox box = new MessageBox(messages.commonDialogHeader());
		box.setMessage(message);
		box.setWidth(400);			
		box.show();		
	}
	public static String getTabId(TreeNodeModel item) {
		/*if (item.getId() != null) {
			return ""+item.getModelType().getLabel()+item.getId();
		} else {*/
		return "" + item.hashCode();
		//}
	}
	public static String getTabId(String type, Integer id) {		
		return ""+type+id;		
	}
	
	public static void alignLabels(LabelAlign labelAlign, HasWidgets panel) {
		List<FieldLabel> labels = FormPanelHelper.getFieldLabels(panel);
		for( FieldLabel label : labels ) {
			label.setLabelAlign(labelAlign);
		}
	}

	public static String capitalize(String value) {
		int length = value.length();
		StringBuilder s = new StringBuilder(length);
		for( int i = 0 ; i < length ; i++ ) {
			char c = value.charAt(i);
			if( i == 0 ) {
				c = Character.toUpperCase(c);
			}
			else {
				c = Character.toLowerCase(c);
			}
			s.append(c);
		}
		return s.toString();
	}

	public static SafeHtml makeImage(ImageResource resource) {
		AbstractImagePrototype proto = AbstractImagePrototype.create(resource);
		return proto.getSafeHtml();
	}
	
	public static void goToLoginPage() {
	    String url = GWT.getHostPageBaseURL();

	    if(!GWT.isProdMode()) {
	        url = "http://127.0.0.1:8888/mozarto.html?gwt.codesvr=127.0.0.1:9997";
	    }
	    Window.Location.replace(url);
	}
	
	/*public static HBoxLayoutContainer createAlignRightPanel(IsWidget widget){
		HBoxLayoutContainer c = new HBoxLayoutContainer();
		BoxLayoutData flex = new BoxLayoutData(new Margins(0, 5, 0, 0));
		flex.setFlex(1);
		c.add(new Label(), flex);
		c.add(widget);
		return c;
	}*/
	
	public static VerticalLayoutContainer createGridWidthPagingContainer(IsWidget widgetGrid, IsWidget widgetToolbar){
		VerticalLayoutContainer con = new VerticalLayoutContainer();
	    con.setBorders(true);
	    con.add(widgetGrid, new VerticalLayoutData(1, 1));
	    con.add(widgetToolbar, new VerticalLayoutData(1, 30));
	    return con;
	}
	
}
