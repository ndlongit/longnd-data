package com.structis.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface CompositionSelectReferenceHandler extends EventHandler {
	void onLoad(CompositionSelectReferenceEvent event);
}
