package com.structis.client.message;


/**
 * Interface to represent the messages contained in resource bundle: D:/JAVAROOT/
 * gwtsandbox/src/main/resources/com/structis/client/Messages.properties'.
 */
public interface Messages extends com.google.gwt.i18n.client.Messages {

	/**
	 * Translated "Enter your name".
	 * 
	 * @return translated "Enter your name"
	 */
	@DefaultMessage("Enter your name")
	@Key("nameField")
	String nameField();

	/**
	 * Translated "Send".
	 * 
	 * @return translated "Send"
	 */
	@DefaultMessage("Send")
	@Key("sendButton")
	String sendButton();

	/* #### COMMON ECRAN #### */
	@Key("common.nouveaumetier")
	String commonNouveaumetier();
	
	@Key("common.panneauaction")
	String commonPanneauAction();
	
	@Key("common.panneaudetail")
	String commonPanneauDetail();
	
	@Key("common.maxlength")
	String commonMaxlength(int max);
	
	@Key("common.retourpegaz")
	String commonRetourPegaz();
	
	@Key("common.addbutton")
	String commonAddButton();

	@Key("common.annulerbutton")
	String commonAnnulerButton();

	@Key("common.validerbutton")
	String commonValiderButton();

	@Key("common.dialogouibutton")
	String commonDialogOuiButton();

	@Key("common.dialognonbutton")
	String commonDialogNonButton();

	@Key("common.dialogheader")
	String commonDialogHeader();

	@Key("common.dialogfooter")
	String commonDialogFooter();

	@Key("common.parcourir")
	String commonParcourir();

	@Key("common.erreurheader")
	String commonErreurHeader();

	@Key("common.infoheader")
	String commonInfoHeader();
	
	@Key("common.confirmheader")
	String commonConfirmheader();

	@Key("common.majsucces")
	String commonMajSucces();

	@Key("common.fermerbutton")
	String commonFermerButton();

	@Key("common.uploadbutton")
	String commonUploadButton();

	@Key("common.uploadheader")
	String commonUploadHeader();

	@Key("common.modifierbutton")
	String commonModifierButton();

	@Key("common.validationuploaderrormessage")
	String commonValidationUploadErrorMessage();

	@Key("common.modelinvalide")
	String commonModelInvalide();

	@Key("common.modelincomplet")
	String commonModelIncomplet();

	@Key("common.imageautoriser")
	String commonImageAutoriser();

	@Key("common.upbutton")
	String commUpButton();

	@Key("common.downbutton")
	String commDownButton();

	@Key("common.numerique")
	String commonNumerique();

	@Key("common.supprimer")
	String commonSupprimer();

	@Key("common.enregistrer")
	String commonEnregistrer();

	@Key("common.creationbutton")
	String commonCreationButton();

	@Key("common.addall")
	String commonAddAll();

	@Key("common.addselected")
	String commonAddSelected();

	@Key("common.removeall")
	String commonRemoveAll();

	@Key("common.removeselected")
	String commonRemoveSelected();

	@Key("common.champobligatoire")
	String commonChampObligatoire();

	@Key("common.exportpdf")
	String commonExportPdf();

	@Key("common.idincorect")
	String commonIdIncorrect();

	@Key("common.techerreurheader")
	String commonTechErreurHeader();

	@Key("common.foncterreurheader")
	String commonFonctErreurHeader();

	@Key("common.erreurinconnu")
	String commonErreurInconnu();

	@Key("common.uniteseul")
	String commonUniteSeul();

	@Key("common.siteproductiondoublon")
	String commonSiteProductionDoublon();

	@Key("common.labeldoublon")
	String commonLabelDoublon();

	@Key("common.dialogclassement")
	String commonDialogClassement();

	@Key("common.produitnonvalid")
	String commonProduitNonValid();

	@Key("common.fieldsetinvalid")
	String commonFieldSetInvalid();

	@Key("common.maxnombre")
	String commonMaxNombre();

	@Key("common.caracteristiquedoublon")
	String commonCarcteristiqueDoublon();

	@Key("common.longeurmaxerror")
	String commonLongeurMaxError(Integer max);

	@Key("common.modelincompletpopup")
	String commonModelIncompletPopup();

	@Key("common.recherchebutton")
	String commonRechercheButton();

	@Key("common.confirmation")
	String commonConfirmation();

	@Key("common.confirm.delete")
	String commonConfirmDelete();

	@Key("common.confirm.desactiver")
	String commonConfirmDesactiver();

	@Key("common.confirmation.closetab")
	String commonConfirmationClosetab();

	@Key("common.oui")
	String commonOui();

	@Key("common.non")
	String commonNon();

	@Key("common.toutes")
	String commonToutes();

	@Key("common.encours")
	String commonEncours();

	@Key("common.download")
	String commonDownload();

	@Key("common.metier")
	String commonMetier();

	@Key("common.metiers")
	String commonMetiers();
	
	@Key("common.utilisateurs")
	String commonUtilisateurs();

	@Key("common.obligatoire")
	String commonObligatoire();

	@Key("common.affichage")
	String commonAffichage();

	@Key("common.contact")
	String commonContact();

	@Key("common.Aide")
	String commonAide();

	@Key("common.English")
	String commonEnglish();

	@Key("common.Deutsch")
	String commonDeutsch();
	
	@Key("common.Francais")
	String commonFrancais();

	@Key("common.disconnection")
	String commonDisconnection();

	@Key("common.selectmetier")
	String commonselectmetier();
	
	@Key("common.confirm.change")
	String commonConfirmChange();
	
	@Key("common.confirm.change.metier")
	String commonConfirmChangeMetier();
	
	@Key("common.saisir.code")
	String commonSaisirCode();
	
	@Key("common.duplicate.libelle")
	String commonDuplicateLibelle(String libelle);
	
	@Key("common.duplicatemodele.libelle")
	String commonDuplicateModeleLibelle(String libelle);

	/* Grid elements de composition */
	@Key("common.elemcompogrid.dragdrop.selectioneditems")
	String commonElemcompogridDragdropSelectioneditems(int items);
	
	@Key("common.elemcompogrid.dragdrop.selectioneditem")
	String commonElemcompogridDragdropSelectioneditem();
	
	@Key("common.elemcompogrid.code")
	String commonElemcompogridCode();

	@Key("common.elemcompogrid.libelle")
	String commonElemcompogridLibelle();

	@Key("common.elemcompogrid.nomenclaturefournisseur")
	String commonElemcompogridNomenclatureFournisseur();

	@Key("common.import.popup.message")
	String commonImportPopupMessage();

	@Key("common.import.popup.browsebutton")
	String commonImportPopupBrowsebutton();

	@Key("common.import.popup.importbutton")
	String commonImportPopupImportbutton();

	@Key("common.import.popup.element")
	String commonImportPopupElement();

	@Key("common.import.popup.caracteristique")
	String commonImportPopupCaracteristique();

	@Key("common.import.popup.reference")
	String commonImportPopupReference();

	@Key("common.import.popup.sousreference")
	String commonImportPopupSousreference();
	
	@Key("common.message.waiting")
	String waitingMessage();
	
	@Key("common.configm.disconnection")
	String commonConfigmDisconnection();
	
	@Key("common.limit")
	String commonLimit(String champ, int nombre);

	/* Ecran Accueil */
	@Key("modelisateur.menu.afficher")
	String modelisateurMenuAfficher();
	
	@Key("modelisateur.menu.modifier")
	String modelisateurMenuModifier();

	@Key("modelisateur.menu.excaract")
	String modelisateurMenuExporterCaracteristique();

	@Key("modelisateur.menu.imcaract")
	String modelisateurMenuImporterCaracteristique();

	@Key("modelisateur.menu.exref")
	String modelisateurMenuExporterReference();

	@Key("modelisateur.menu.imref")
	String modelisateurMenuImporterReference();

	@Key("modelisateur.menu.imssref")
	String modelisateurMenuImporterSousReference();

	@Key("modelisateur.menu.exssref")
	String modelisateurMenuExporterSousReference();

	@Key("modelisateur.menu.copier")
	String modelisateurMenuCopier();

	@Key("modelisateur.menu.coller")
	String modelisateurMenuColler();

	@Key("modelisateur.menu.supprimer")
	String modelisateurMenuSupprimer();
	
	@Key("modelisateur.menu.copierSubmenu.regles")
	String modelisateurMenuCopierSubmenuRegles();
	
	@Key("modelisateur.menu.copierSubmenu.messages")
	String modelisateurMenuCopierSubmenuMessages();
	
	@Key("modelisateur.menu.copierSubmenu.descendance")
	String modelisateurMenuCopierSubmenuDescendance();
	
	@Key("modelisateur.menu.copierSubmenu.title")
	String modelisateurMenuCopierSubmenuTitle();
	
	@Key("modelisateur.menu.supprimerSubmenu.regles")
	String modelisateurMenuSupprimerSubmenuRegles();
	
	@Key("modelisateur.menu.supprimerSubmenu.messages")
	String modelisateurMenuSupprimerSubmenuMessages();
	
	@Key("modelisateur.menu.supprimerSubmenu.descendance")
	String modelisateurMenuSupprimerSubmenuDescendance();
	
	@Key("modelisateur.menu.supprimerSubmenu.title")
	String modelisateurMenuSupprimerSubmenuTitle();

	@Key("modelisateur.deletenode.confirm")
	String modelisateurDeleteNodeConfirm();
	
	@Key("modelisateur.label")
	String modelisateurLabel();

	@Key("accueil.contentheader")
	String accueilContentHeader();
	
	@Key("accueil.creerModele")
	String accueilCreerModele();
	
	@Key("accueil.deleteConfirmMessage")
	String accueilDeleteConfirmMessage();
	
	@Key("accueil.undeleteConfirmMessage")
	String accueilUndeleteConfirmMessage();
	
	@Key("accueil.repriseVersionConfirmMessage")
	String accueilRepriseVersionConfirmMessage();
	
	@Key("accueil.modeleGrid.libelle")
	String accueilModeleGridLibelle();
	
	@Key("accueil.modeleGrid.pub")
	String accueilModeleGridPub();
	
	@Key("accueil.modeleGrid.utilisateur")
	String accueilModeleGridUtilisateur();
	
	@Key("accueil.modeleGrid.date")
	String accueilModeleGridDate();
	
	@Key("accueil.modeleGrid.actions")
	String accueilModeleGridActions();
	
	@Key("accueil.modeleGrid.title")
	String accueilModeleGridTitle();

	@Key("modelisateur.action")
	String modelisateurAction();

	@Key("modelisateur.action.description")
	String modelisateurActionDescription();

	@Key("modelisateur.caracteristique")
	String modelisateurCaracteristique();

	@Key("modelisateur.reference")
	String modelisateurReference();

	@Key("modelisateur.elementdecomposition")
	String modelisateurElementDeComposition();

	@Key("modelisateur.rechercheavancee")
	String modelisateurRechercheAvancee();

	@Key("modelisateur.form.regle.creemessage")
	String modelisateurFormRegleCreemessage();

	@Key("modelisateur.form.regle.creeregle")
	String modelisateurFormRegleCreeregle();

	@Key("modelisateur.form.regle.gridtitle")
	String modelisateurFormRegleGridtitle();

	@Key("modelisateur.form.regle.gridelementcible")
	String modelisateurFormRegleGridelementcible();
	
	@Key("modelisateur.form.regle.gridelementsource")
	String modelisateurFormRegleGridElementSource();
	
	@Key("modelisateur.form.regle.gridrelation")
	String modelisateurFormRegleGridrelation();

	@Key("modelisateur.form.regle.gridquantite")
	String modelisateurFormRegleGridquantite();

	@Key("modelisateur.form.regle.gridheritage")
	String modelisateurFormRegleGridheritage();

	@Key("modelisateur.form.regle.gridaction")
	String modelisateurFormRegleGridaction();

	@Key("modelisateur.form.regle.regle.entre")
	String modelisateurFormRegleRegleEntre();

	@Key("modelisateur.form.regle.telement")
	String modelisateurFormRegleTelement();

	@Key("modelisateur.form.regle.lementselectmessage")
	String modelisateurFormRegleLementselectmessage();

	@Key("modelisateur.form.regle.niveaurelation")
	String modelisateurFormRegleNiveaurelation();

	@Key("modelisateur.form.regle.level.indispensable")
	String modelisateurFormRegleLevelIndispensable();

	@Key("modelisateur.form.regle.level.conseillee")
	String modelisateurFormRegleLevelConseillee();

	@Key("modelisateur.form.regle.level.interdite")
	String modelisateurFormRegleLevelInterdite();

	@Key("modelisateur.form.regle.confirm.delete")
	String modelisateurFormRegleConfirmDelete();

	@Key("modelisateur.form.message.confirm.delete")
	String modelisateurFormMessageConfirmDelete();

	@Key("modelisateur.form.regle.confirm.unlink")
	String modelisateurFormRegleConfirmUnlink();

	@Key("modelisateur.form.message.confirm.unlink")
	String modelisateurFormMessageConfirmUnlink();
	
	@Key("modelisateur.form.closetab.info")
	String modelisateurFormClosetabInfo();
	
	@Key("modelisateur.reference.label")
	String modelisateurReferenceLabel();
	
	@Key("modelisateur.caracteristique.label")
	String modelisateurCaracteristiqueLabel();
	
	@Key("modelisateur.element.label")
	String modelisateurElementLabel();
	
	@Key("modelisateur.confirmation.closetab")	
	String modelisateurConfirmationCloseTab(String item);
	
	@Key("modelisateur.form.message")	
	String modelisateurFormMessage();
	
	@Key("modelisateur.form.message.importance")
	String modelisateurFormMessageImportance();
	
	@Key("modelisateur.form.message.importance.information")
	String modelisateurFormMessageImportanceInformation();
	
	@Key("modelisateur.form.message.importance.avertissement")
	String modelisateurFormMessageImportanceAvertissement();
	
	@Key("modelisateur.form.message.importance.alerte")
	String modelisateurFormMessageImportanceAlerte();
	
	@Key("modelisateur.form.message.annuler.confirm")
	String modelisateurFormMessageAnnulerConfirm();
	
	@Key("modelisateur.parametresLabel")	
	String modelisateurParametresLabel();
	
	@Key("modelisateur.parametres.checkbox.label")
	String modelisateurParametresCheckboxLabel();
	
	@Key("modelisateur.delete.message.element")
	String modelisateurMessageDeleteElement(String element, String reference, int qte);
	
	@Key("modelisateur.delete.message.carateristique")
	String modelisateurDeleteMessageCarateristique(String cara);
	
	@Key("modelisateur.delete.message.reference")
	String modelisateurDeleteMessageReference(String reference);
	
	@Key("modelisateur.copy.sousref")
	String modelisateurCopySousref(String reference);
	
	@Key("modelisateur.copy.existe")
	String modelisateurCopyExiste(String libelles);
	
	
	/* Ecran Gestion des elements de composition */
	
	@Key("gestionelemcompo.right.obligatoire")
	String gestionelemcompoRightObligatoire(String field);
	
	@Key("gestionelemcompo.right.unique")
	String gestionelemcompoRightUnique(String field);
	
	@Key("gestionelemcompo.right.nouvelelem")
	String gestionelemcompoRightNouvelElem();

	@Key("gestionelemcompo.right.type")
	String gestionelemcompoRightType();

	@Key("gestionelemcompo.right.code")
	String gestionelemcompoRightCode();

	@Key("gestionelemcompo.right.actif")
	String gestionelemcompoRightActif();

	@Key("gestionelemcompo.right.nomfourn")
	String gestionelemcompoRightNomclematureFournisseur();

	@Key("gestionelemcompo.right.libelle")
	String gestionelemcompoRightLibelle();

	@Key("gestionelemcompo.right.famille")
	String gestionelemcompoRightFamille();

	@Key("gestionelemcompo.right.famille.famille")
	String gestionelemcompoRightFamilleFamille();

	@Key("gestionelemcompo.right.famille.ssfamille")
	String gestionelemcompoRightFamilleSousFamille();

	@Key("gestionelemcompo.right.famille.groupe")
	String gestionelemcompoRightFamilleGroupe();

	@Key("gestionelemcompo.right.famille.ssgroupe")
	String gestionelemcompoRightFamilleSousGroupe();

	@Key("gestionelemcompo.right.famille.typeprest")
	String gestionelemcompoRightFamilleTypePrestation();

	@Key("gestionelemcompo.right.attributs")
	String gestionelemcompoRightAttributs();

	@Key("gestionelemcompo.right.attribut")
	String gestionelemcompoRightAttribut();

	@Key("gestionelemcompo.right.attributvide")
	String gestionelemcompoRightAttributVide();

	@Key("gestionelemcompo.right.attributs.libelle")
	String gestionelemcompoRightAttributsLibelle();

	@Key("gestionelemcompo.right.attributs.valeur")
	String gestionelemcompoRightAttributsValeur();

	@Key("gestionelemcompo.right.champvide")
	String gestionelemcompoRightChampvide();

	@Key("gestionelemcompo.right.codeunique")
	String gestionelemcompoRightCodeUnique();

	@Key("gestionelemcompo.right.nomenclatureunique")
	String gestionelemcompoRightNomenclatureUnique();

	@Key("gestionelemcompo.right.annulertitre")
	String gestionelemcompoRightAnnulerTitre();

	@Key("gestionelemcompo.right.annulermessage")
	String gestionelemcompoRightAnnulerMessage();

	@Key("gestionelemcompo.left.nouveaubouton")
	String gestionelemcompoLeftNouveaubouton();

	@Key("gestionelemcompo.left.modifierbouton")
	String gestionelemcompoLeftModifierbouton();

	@Key("gestionelemcompo.left.desactiverbouton")
	String gestionelemcompoLeftDesactiverbouton();

	@Key("gestionelemcompo.left.rechavancee")
	String gestionelemcompoLeftRechavancee();

	@Key("gestionelemcompo.left.import")
	String gestionelemcompoLeftImport();

	@Key("gestionelemcompo.left.export")
	String gestionelemcompoLeftExport();

	@Key("gestionelemcompo.left.elemcompo")
	String gestionelemcompoLeftElemcompo();

	@Key("gestionelemcompo.left.moinstroiscaracteres")
	String gestionelemcompoLeftMoinstroiscaracteres();

	@Key("gestionelemcompo.left.desactivermesage")
	String gestionelemcompoLeftDesactivermesage();

	@Key("gestionelemcompo.left.desactiverinfo")
	String gestionelemcompoLeftDesactiverinfo();
	
	@Key("gestionelemcompo.left.rechavanceeencours")
	String gestionelemcompoLeftRechavanceeencours();
	
	@Key("gestionelemcompo.left.selectionnertype")
	String gestionelemcompoLeftSelectionnertype();

	/*
	 * Modelisateur ecran
	 */
	@Key("modelisateur.form.maximuntabmessage")
	String modelisateurFormMaximuntabMessage();

	@Key("modelisateur.form.libelle")
	String modelisateurFormLibelle();

	@Key("modelisateur.form.commentaires")
	String modelisateurFormCommentaires();

	@Key("modelisateur.form.relations")
	String modelisateurFormRelations();

	@Key("modelisateur.form.regles")
	String modelisateurFormRegles();

	@Key("modelisateur.form.detail")
	String modelisateurFormDetail();

	@Key("modelisateur.form.relation.elemententree")
	String modelisateurFormRelationElementEntree();

	@Key("modelisateur.form.relation.elementsortie")
	String modelisateurFormRelationElementSortie();

	@Key("modelisateur.form.relation.elementsortiecomposition")
	String modelisateurFormRelationElementSortieComposition();

	@Key("modelisateur.form.relation.act")
	String modelisateurFormRelationAct();

	@Key("modelisateur.form.relation.qte")
	String modelisateurFormRelationQte();

	@Key("modelisateur.form.attributsreference")
	String modelisateurFormAttributsReference();

	@Key("modelisateur.form.valeur")
	String modelisateurFormValeur();
	
	@Key("modelisateur.form.code")
	String modelisateurFormCode();
	
	@Key("modelisateur.form.attributselement")
	String modelisateurFormAttributsElement();

	@Key("common.tree.new.node")
	String commontreenewnode();

	@Key("modelisateur.right.delete.caracteristique.reference")
	String modelisateurRightDeleteCaracteristiqueReference(String caracteristique, String reference);	
	
	@Key("modelisateur.element.violate.rule")
	String modelisateurElementViolateRules(String reference, String elementCode);

	@Key("modelisateur.reference.violate.rule")
	String modelisateurReferenceViolateRules(String libelle, String referenceName);
	
	@Key("composition.right.reference.seuil")
	String compositionRightReferenceSeuil(int seuil);
	
	@Key("modelisateur.switch.confirm")
	String modelisateurSwitchConfirm(String nodeLabel);
	
	@Key("modelisateur.reference.sousreference.change")
	String modelisateurReferenceSousReferenceChange(String reference);

	//Ecran composition
	
	@Key("composition.accueil.left.creer")
	String compositionAccueilLeftCreer();
	
	@Key("composition.accueil.left.modele")
	String compositionAccueilLeftModele();
	
	@Key("composition.accueil.right.liste")
	String compositionAccueilRightListe(String modele);
	
	@Key("composition.accueil.right.nom")
	String compositionAccueilRightNom();
	
	@Key("composition.accueil.right.modif")
	String compositionAccueilRightModif();

	@Key("composition.accueil.right.utilisateur")
	String compositionAccueilRightUtilisateur();
	 
	@Key("composition.accueil.right.pub")
	String compositionAccueilRightPub();
	
	@Key("composition.accueil.right.origine")
	String compositionAccueilRightOrigine();
	
	@Key("composition.accueil.right.actions")
	String compositionAccueilRightActions();
	
	@Key("composition.accueil.right.dupliquer")
	String compositionAccueilRightDupliquer();
	
	@Key("composition.accueil.right.modifier")
	String compositionAccueilRightModifier();
	
	@Key("composition.accueil.right.supprimer")
	String compositionAccueilRightSupprimer();
	
	@Key("composition.accueil.right.supprimer.confirm")
	String compositionAccueilRightSupprimerConfirm();
	
	@Key("composition.filter.header")
	String compositionFilterHeader();
	
	@Key("composition.right.elementgrid.select")
	String compositionRightElementgridSelect();
	
	@Key("composition.right.elementgrid.code")
	String compositionRightElementgridCode();
	
	@Key("composition.right.elementgrid.libelle")
	String compositionRightElementgridLibelle();
	
	@Key("composition.right.elementgrid.nomenclaturefournisseur")
	String compositionRightElementgridNomenclaturefournisseur();
	
	@Key("composition.right.elementgrid.qte")
	String compositionRightElementgridQte();
	
	@Key("composition.right.elementgrid.eltsup")
	String compositionRightElementgridEltsup();
	
	@Key("composition.right.elementgrid.ajouterelt")
	String compositionRightElementgridAjouterelt();
			
	@Key("composition.change.caracter.source.rule.obligatoire")
	String compositionChangeCaracterSourceRuleObligatoire(String lLibelleLong,
			String newSource, String lLibelleLong2);

	@Key("composition.change.caracter.source.rule.conseillee")
	String compositionChangeCaracterSourceRuleConseillee(String lLibelleLong,
			String newSource, String lLibelleLong2);

	@Key("composition.change.caracter.source.rule.interdite")
	String compositionChangeCaracterSourceRuleInterdite(String lLibelleLong,
			String newSource);

	@Key("composition.right.elementgrid.addwindow.title")
	String compositionRightElementgridAddwindowTitle();
	
	@Key("composition.right.elementgrid.addwindow.description")
	String compositionRightElementgridAddwindowDescription();
	
	@Key("composition.right.elementgrid.uncheckconfirm")
	String compositionRightElementgridUncheckconfirm();

	@Key("composition.right.reference.deselect.when.element.change")
	String compositionRightReferenceDeselectWhenElementChange();
	
	@Key("composition.right.reference.quantite.change")
	String compositionRightReferenceQuantiteChange();

	@Key("compositeur.label")
	String compositeurLabel();
	
	@Key("composition.right.compositiongrid.title")
	String compositionRightCompositiongridTitle();
	
	@Key("composition.left.tree.button.state1")
	String compositionLeftTreeButtonState1();
	
	@Key("composition.left.tree.button.state2")
	String compositionLeftTreeButtonState2();
	
	@Key("composition.left.tree.button.state3")
	String compositionLeftTreeButtonState3();
	
	@Key("composition.top.compositionmultiple")
	String compositionTopCompositionmultiple();
	
	@Key("composition.top.titre")
	String compositionTopTitre();
	
	@Key("composition.right.reference.confirm.message")
	String compositionRightReferenceConfirmMessage();
	
	@Key("composition.reset.caracteristique.combo.break.rule")
	String compositionResetCaracteristiqueComboBreakRule(String source);
	
	@Key("composition.save.confirm")
	String compositionSaveConfirm();
	
	@Key("import.error.message")
	String importErrorMessage();
	
	@Key("import.error.textLink")
	String importErrorTextLink();

	
	/**
	 * Login window
	 */
	@Key("login.window.title")
	String loginWindowTitle();
	
	@Key("login.window.label.identifiant")
	String loginWindowLabelIdentifiant();
	
	@Key("login.window.label.motdepasse")
	String loginWindowLabelMotdepasse();

	
	//Ecran gestion des metiers
	@Key("metiers.form.desactivermessage")
	String metiersFormDesactivermessage();
	
	@Key("metiers.form.libelle.metier.unique")
	String metiersFormLibelleMetierUnique();
	
	@Key("metiers.form.code.limit")
	String metiersFormCodeLimit();
	
	@Key("metiers.form.libelle")
	String metiersFormLibelle();
	
	@Key("metiers.form.actif")
	String metiersFormActif();
	
	@Key("metiers.form.codepegaz")
	String metiersFormCodepegaz();
	
	@Key("metiers.form.servmat")
	String metiersFormServmat();
	
	@Key("metiers.form.commentaires")
	String metiersFormCommentaires();
	
	@Key("metiers.form.valeur")
	String metiersFormValeur();
	
	@Key("metiers.form.compo")
	String metiersFormCompo();
	
	@Key("metiers.form.action")
	String metiersFormAction();
	
	@Key("metiers.form.reference")
	String metiersFormReference();
	
	@Key("metiers.form.element")
	String metiersFormElement();
	
	@Key("metiers.form.information")
	String metiersFormInformation();
	
	@Key("metiers.form.confirmdelete")
	String metiersFormConfirmdelete(String type);
	
	@Key("metiers.form.lumessage")
	String metiersFormLumessage();
	
	@Key("metiers.form.eltconfig")
	String metiersFormEltconfig();
	
	@Key("metiers.form.refconfig")
	String metiersFormRefconfig();
	
	@Key("metiers.form.libelle.unique")
	String metiersFormLibelleUnique(String type);
	
	@Key("metiers.form.elt")
	String metierFormElt();
	
	@Key("metiers.form.ref")
	String metiersFormRef();
	
	@Key("metiers.form.obligatoire")
	String metiersFormObligatoire();
	
	@Key("metiers.form.annulermessage")
	String metiersFormAnnulermessage();
	
	@Key("utilisateurs.statut")
	String utilisateursStatut();
	
	@Key("utilisateurs.info")
	String utilisateursInfo();
	
	@Key("utilisateurs.nom")
	String utilisateursNom();
	
	@Key("utilisateurs.prenom")
	String utilisateursPrenom();
	
	@Key("utilisateurs.mail")
	String utilisateursMail();
	
	@Key("utilisateurs.idMozarto")
	String utilisateursIdMozarto();
	
	@Key("utilisateurs.idPegaz")
	String utilisateursIdPegaz();
	
	@Key("utilisateurs.motdepasse")
	String utilisateursMotdepasse();
	
	@Key("utilisateurs.actif")
	String utilisateursActif();
	
	@Key("utilisateurs.autorisations")
	String utilisateursAutorisations();
	
	@Key("utilisateurs.annulermessage")
	String utilisateursAnnulermessage();
	
	@Key("utilisateurs.desactivermessage")
	String utilisateursDesactivermessage();
	
	@Key("utilisateurs.nouvel")
	String utilisateursNouvel();
	
	@Key("utilisateurs.modifnonautorisee")
	String utilisateursModifnonautorisee();
	
	@Key("utilisateurs.metier")
	String utilisateursMetier();
	
	@Key("utilisateurs.fonction")
	String utilisateursFonction();
	
	@Key("utilisateurs.metierpardefaut")
	String utilisateursMetierpardefaut();
	
	@Key("utilisateurs.champ.obligatoire")
	String utilisateursChampObligatoire(String champ);
	
	@Key("utilisateurs.mail.incorrect")
	String utilisateursMailIncorrect();
	
	@Key("utilisateurs.limit")
	String utilisateursLimit(String champ, int limit);
	
	@Key("utilisateurs.existed")
	String utilisateursExisted(String champ);
	
	@Key("utilisateurs.confirmdelete")
	String utilisateursConfirmdelete();
}
