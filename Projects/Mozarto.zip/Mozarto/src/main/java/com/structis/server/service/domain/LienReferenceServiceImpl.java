package com.structis.server.service.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.server.persistence.MdlLienReferenceMapper;
import com.structis.shared.model.MdlLienReference;

@Service
public class LienReferenceServiceImpl implements LienReferenceService {

	@Autowired
	MdlLienReferenceMapper mdlLienReferenceMapper;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public MdlLienReference findLienReferenceByReference(int idModeleVersion, int idReference) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReference", idReference);
		return mdlLienReferenceMapper.findByReference(mapParameter);
	}

	@Override
	public int insert(MdlLienReference record) {
		return mdlLienReferenceMapper.insert(record);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<Integer> findIdCommunsByCarateristique(int idModeleVersion,List<Integer> idCarateristiques) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("caracteristiqueList", idCarateristiques);
		return mdlLienReferenceMapper.findIdCommunsByCarateristique(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Integer> findByIdReferences(int idModeleVersion, List<Integer> idReferences) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idReferences", idReferences);
		return mdlLienReferenceMapper.findByIdReferences(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteByIdLienCommuns(int idModeleVersion,List<Integer> idLienCommuns) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommuns", idLienCommuns);
		mdlLienReferenceMapper.deleteByIds(mapParameter);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<MdlLienReference> findIncludeReferenceByIdLienCommuns(int idModeleVersion, List<Integer> idLienCommuns) {
		Map mapParameter = new HashMap();
		mapParameter.put("idModeleVersion", idModeleVersion);
		mapParameter.put("idLienCommuns", idLienCommuns);
		return mdlLienReferenceMapper.findIncludeReferenceByIdLienCommuns(mapParameter);
	}

}
