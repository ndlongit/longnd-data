package com.structis.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.sencha.gxt.cell.core.client.AbstractEventCell;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.HasSelectHandlers;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.structis.client.image.Images;
import com.structis.shared.model.reference.ModelisateurRegleMessageListModel;

public abstract class RegleMessageActionCell extends AbstractEventCell<ModelisateurRegleMessageListModel> implements
		HasSelectHandlers {

	interface Templates extends SafeHtmlTemplates {
		@SafeHtmlTemplates.Template("<div name=\"{0}\" style=\"{1}\">{2}</div>")
		SafeHtml cell(String name, SafeStyles styles, SafeHtml value);
	}

	public RegleMessageActionCell() {
		super("click", "keydown");
	}

	private static Templates templates = GWT.create(Templates.class);

	private static final SafeHtml ICON_EDIT = makeImage(Images.RESOURCES.edit());

	private static final SafeHtml ICON_DELETE = makeImage(Images.RESOURCES.delete());

	private static final SafeHtml ICON_REMVOE = makeImage(Images.RESOURCES.remove());

	private static final SafeHtml ICON_GOTO = makeImage(Images.RESOURCES.gotoNode());

	@Override
	public void onBrowserEvent(com.google.gwt.cell.client.Cell.Context context, Element parent,
			ModelisateurRegleMessageListModel value, NativeEvent event,
			com.google.gwt.cell.client.ValueUpdater<ModelisateurRegleMessageListModel> valueUpdater) {
		super.onBrowserEvent(context, parent, value, event, valueUpdater);
		// Handle the click event.
		if( "click".equals(event.getType()) ) {
			EventTarget eventTarget = event.getEventTarget();
			if( parent.isOrHasChild(Element.as(eventTarget)) ) {
				Element el = Element.as(eventTarget);
				if( el.getNodeName().equalsIgnoreCase("IMG") ) {
					if( el.getParentElement().getAttribute("name").equals("ICON_EDIT") ) {
						onEdit(value);
					}
					else if( el.getParentElement().getAttribute("name").equals("ICON_DELETE") ) {
						onDelete(value);
					}
					else if( el.getParentElement().getAttribute("name").equals("ICON_GOTO") ) {
						onGoto(value);
					}
					else if( el.getParentElement().getAttribute("name").equals("ICON_REMVOE") ) {
						onUnlink(value);
					}
				}
			}
		}
	};

	@Override
	public void render(Context context, ModelisateurRegleMessageListModel value, SafeHtmlBuilder sb) {
		if( value == null ) {
			return;
		}
		SafeStyles imgStyle = SafeStylesUtils.fromTrustedString("display:inline;cursor:hand;cursor:pointer;padding-left:6px;");
		SafeHtml rendered;

		if( !value.isHeritage() ) {
			rendered = templates.cell("ICON_EDIT", imgStyle, ICON_EDIT);
			sb.append(rendered);
			rendered = templates.cell("ICON_DELETE", imgStyle, ICON_DELETE);
			sb.append(rendered);
		}
		else {
			rendered = templates.cell("ICON_GOTO", imgStyle, ICON_GOTO);
			sb.append(rendered);
			if(!"".equals(value.getCibleLibelle())){
				rendered = templates.cell("ICON_REMVOE", imgStyle, ICON_REMVOE);
				sb.append(rendered);
			}
		}

	}

	private static SafeHtml makeImage(ImageResource resource) {
		AbstractImagePrototype proto = AbstractImagePrototype.create(resource);
		return proto.getSafeHtml();
	}

	@Override
	public HandlerRegistration addSelectHandler(SelectHandler handler) {
		return addHandler(handler, SelectEvent.getType());
	}

	public abstract void onEdit(ModelisateurRegleMessageListModel node);

	public abstract void onDelete(ModelisateurRegleMessageListModel node);

	public abstract void onUnlink(ModelisateurRegleMessageListModel node);

	public abstract void onGoto(ModelisateurRegleMessageListModel node);

}
