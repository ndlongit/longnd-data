
package com.structis.client.properties;

import java.util.Date;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.reference.CompositionAccueilModel;
/**
 * 
 * @author vinh.tong
 *
 */
public interface CompositionAccueilModelProperties extends PropertyAccess<CompositionAccueilModel> {
  ModelKeyProvider<CompositionAccueilModel> idComposition();
	
  @Path("lLibelleLong")
  LabelProvider<CompositionAccueilModel> getLLibelle();

  ValueProvider<CompositionAccueilModel, Date> dDateheureDmaj();

  ValueProvider<CompositionAccueilModel, String> lLibelleLong();

  ValueProvider<CompositionAccueilModel, String> cUtilisateurCrea();

  ValueProvider<CompositionAccueilModel, Integer> pubVersion();

  ValueProvider<CompositionAccueilModel, String> libelleApplicationOrigine();
}
