
package com.structis.client.properties;

import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.structis.shared.model.Element;
/**
 * 
 * @author vinh.tong
 *
 */
public interface ElementProperties extends PropertyAccess<Element> {
  ModelKeyProvider<Element> idElement();

  ValueProvider<Element, String> cElement();

  ValueProvider<Element, String> lLibelleLong();

  ValueProvider<Element, String> lNomenclatureFournisseur();

  ValueProvider<Element, Integer> qte();
}
