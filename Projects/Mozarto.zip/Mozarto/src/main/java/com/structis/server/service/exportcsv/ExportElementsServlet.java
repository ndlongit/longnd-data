package com.structis.server.service.exportcsv;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sencha.gxt.data.shared.SortDir;
import com.structis.server.core.SpringGetter;
import com.structis.server.service.domain.ElementService;
import com.structis.server.service.domain.FamilleService;
import com.structis.shared.constant.Constant;
import com.structis.shared.model.Element;
import com.structis.shared.model.Famille;
import com.structis.shared.model.reference.AttributEtenduMetierERValueModel;
import com.structis.shared.model.reference.ElementWithFamillesAndAttributsModel;

@SuppressWarnings("serial")
public class ExportElementsServlet extends RemoteServiceServlet {
	public final static String FILE_NAME = "Mozarto";

	public final static String FILE_TYPE = ".csv";

//	public final static String EXPORT_FOLDER_PATH = "/export";
	
	@Autowired
	ElementService elementService;

	@Autowired
	FamilleService familleService;

	protected SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-HHmmss");

	protected List<Famille> allFamilles;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		elementService = (ElementService) SpringGetter.getBean(getServletContext(), "elementService");
		familleService = (FamilleService) SpringGetter.getBean(getServletContext(), "familleService");

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {
			String searchStr = request.getParameter(Constant.ELEMENT_SEARCH_STR);
			String libelleMetier = request.getParameter(Constant.LIBELLE_METIER);
			Integer idMetier = Integer.parseInt(request.getParameter(Constant.ID_METIER));
			String sortByStr = request.getParameter(Constant.ELEMENT_SORTBY);
			String sortDirStr = request.getParameter(Constant.ELEMENT_SORTDIR);
			int timezoneOffsetClient = Integer.parseInt(request.getParameter(Constant.CLIENT_TIMEZONEOFFSET));
			TimeZone timeZone = TimeZone.getTimeZone("GMT");
			timeZone.setRawOffset((int) (timezoneOffsetClient * DateUtils.MILLIS_PER_MINUTE));
			sdf.setTimeZone(timeZone);
			String filename = FILE_NAME + "_" + libelleMetier + "_ElementsCompositions_" + sdf.format(Calendar.getInstance().getTime()) + FILE_TYPE;

			Element element = new Element();
			//TODO change idMetier
			element.setIdMetier(idMetier);
			element.setInActif(true);
			element.setLLibelleLong("%" + searchStr + "%");
			element.setLNomenclatureFournisseur("%" + searchStr + "%");
			element.setCElement("%" + searchStr + "%");
			SortDir sortDir;
			if( sortDirStr.equals("DESC") )
				sortDir = SortDir.DESC;
			else
				sortDir = SortDir.ASC;

			List<Element> elements = elementService.findAllByCriteria(element, sortByStr, sortDir);
			List<ElementWithFamillesAndAttributsModel> elementWithFamillesAndAttributsModels = new ArrayList<ElementWithFamillesAndAttributsModel>();
			//TODO change idMetier
			allFamilles = familleService.findByMetier(idMetier);
			int numberAttr = 0;
			for( Element elt : elements ) {
				List<AttributEtenduMetierERValueModel> attributEtenduMetierERValueModels = elementService.findAttributEtenduElementValueByIdAndMetier(
						elt.getIdElement(), elt.getIdMetier());
				ElementWithFamillesAndAttributsModel elementWithFamillesAndAttributsModel = new ElementWithFamillesAndAttributsModel();
				elementWithFamillesAndAttributsModel.setElement(elt);
				elementWithFamillesAndAttributsModel.setAttributEtenduMetierERValueModels(attributEtenduMetierERValueModels);
				numberAttr = attributEtenduMetierERValueModels.size();
				List<Famille> familles = new ArrayList<Famille>();
				Famille tmp = findFamille(elt.getIdFamille());
				if(tmp != null){
					if( Constant.TYPE_FAMILLE_FAMILLE.equals(tmp.getCTypeFamille()) || Constant.TYPE_FAMILLE_TYPEPRESTATION.equals(
							tmp.getCTypeFamille()) ) {
						familles.add(tmp);
					}
					else  {
						if( Constant.TYPE_FAMILLE_SOUSFAMILLE.equals(tmp.getCTypeFamille()) ) {
							Famille f = findFamille(tmp.getIdFamilleParent());
							familles.add(f);
							familles.add(tmp);
	
						}
						else {
							if( Constant.TYPE_FAMILLE_GROUPE.equals(tmp.getCTypeFamille()) ) {
								Famille sf = findFamille(tmp.getIdFamilleParent());
								Famille f = findFamille(sf.getIdFamilleParent());
								familles.add(f);
								familles.add(sf);
								familles.add(tmp);
							}
							else {
								Famille g = findFamille(tmp.getIdFamilleParent());
								Famille sf = findFamille(g.getIdFamilleParent());
								Famille f = findFamille(sf.getIdFamilleParent());
								familles.add(f);
								familles.add(sf);
								familles.add(g);
								familles.add(tmp);
							}
						}
					}
				}
				elementWithFamillesAndAttributsModel.setFamilles(familles);
				elementWithFamillesAndAttributsModels.add(elementWithFamillesAndAttributsModel);
			}
			ExportElements exportElements = new ExportElements();
			exportElements.setElementList(elementWithFamillesAndAttributsModels);
			Writer export = exportElements.export(getServletContext().getRealPath(filename), numberAttr);
			PrintWriter printWriter = new PrintWriter(export);
			printWriter.flush();
			printWriter.close();
			FileInputStream fileToDownload = new FileInputStream(
					getServletContext().getRealPath(filename));
			response.setContentType("application/msexcel");
			response.setHeader("Content-Disposition",
					"attachment; filename=" + filename);
			response.setContentLength(fileToDownload.available());
			int c;
			ServletOutputStream output = response.getOutputStream();
			while ((c = fileToDownload.read()) != -1) {
				output.write(c);
			}
		}
		catch( Exception e ) {
			e.printStackTrace();
		}

	}

	public Famille findFamille(Integer idFamille) {
		Famille f = null;
		if( allFamilles != null )
			for( int i = 0 ; i < allFamilles.size() ; i++ ) {
				if( allFamilles.get(i).getIdFamille() == idFamille )
					return allFamilles.get(i);
			}
		return f;
	}
}
