package com.structis.server.service.client;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.structis.client.service.ClientAttributEtenduService;
import com.structis.server.service.domain.AttributEtenduElementService;
import com.structis.server.service.domain.AttributEtenduReferenceService;
import com.structis.server.service.domain.AttributEtenduService;
import com.structis.shared.model.AttributEtendu;

@Service("clientAttributEtenduService")
public class ClientAttributEtenduServiceImpl implements ClientAttributEtenduService{

	@Autowired
	AttributEtenduService attributEtenduService;
	
	@Autowired
	AttributEtenduElementService attributEtenduElementService;
	
	@Autowired
	AttributEtenduReferenceService attributEtenduReferenceService;
	
	@Override
	public List<AttributEtendu> findAll() {
		return attributEtenduService.findAll();
	}

	@Override
	public List<List<AttributEtendu>> findAllAttributEtendu(Integer idMetier) {
		List<List<AttributEtendu>> list = new LinkedList<List<AttributEtendu>>();
		List<AttributEtendu> all = attributEtenduService.findAllByMetier(idMetier);
		List<AttributEtendu> allRef = new ArrayList<AttributEtendu>();
		List<AttributEtendu> allElt = new ArrayList<AttributEtendu>();
		for (AttributEtendu att : all){
			if ("R".equals(att.getCTypeAttributEtendu()))
				allRef.add(att);
			else if ("E".equals(att.getCTypeAttributEtendu()))
				allElt.add(att);
		}
		list.add(0, allRef);
		list.add(1, allElt);
		return list;
	}

	@Override
	public Integer insertAndUpdate(List<AttributEtendu> attributEtendus, Integer idMetier) {
		List<AttributEtendu> attListToBeInserted = new ArrayList<AttributEtendu>();

		short findMaxRang = attributEtenduService.findMaxRang();
		int rang = findMaxRang + 1;
		for(AttributEtendu attributEtendu : attributEtendus){
			if (attributEtendu.getLLibelle() != null && !attributEtendu.getLLibelle().equals("")){
				if (attributEtendu.getIdAttributEtendu() == null){
					attributEtendu.setCLabelAttributEtendu("");
					attributEtendu.setIdMetier(idMetier);
					
					attributEtendu.setNRang((short) rang);
					attListToBeInserted.add(attributEtendu);
				}
				else {
					attributEtenduService.update(attributEtendu);
				}
			}
		}
		if (attListToBeInserted.size() > 0){
			attributEtenduService.insertList(attListToBeInserted);
		}
		return 0;
	}

	@Override
	public Integer delete(AttributEtendu attributEtendu) {
		if(attributEtendu.getIdAttributEtendu() != null){
			if ("R".equals(attributEtendu.getCTypeAttributEtendu())){
				attributEtenduReferenceService.deleteByIdAttribut(attributEtendu.getIdAttributEtendu());
			}
			else if ("E".equals(attributEtendu.getCTypeAttributEtendu())){
				attributEtenduElementService.deleteByIdAttribut(attributEtendu.getIdAttributEtendu());
			}
			attributEtenduService.delete(attributEtendu);
		}
		return 0;
	}
	

}
