package com.structis.server.service.domain.report;

import org.springframework.stereotype.Service;

import com.structis.shared.model.report.ReportConfig;
import com.structis.shared.model.report.ReportData;

@Service(ReportService.SERVICE_NAME)
public class ReportServiceImpl implements ReportService {

	@Override
	public ReportConfig getReportConfig() {
		return createTestReportConfig();
	}

	private ReportConfig createTestReportConfig() {
		ReportConfig config = new ReportConfig();
		
		config.setShowTitleBlock(true);		
		config.setShowModelBlock(true);
		
		return config;
	}

	@Override
	public ReportData getHeaderInfo() {
		return createTestHeaderInfo();
	}

	@Override
	public ReportData getModelInfo() {
		return createTestModelInfo();
	}

	@Override
	public ReportData getReportData() {
		return createTestData();
	}

	private ReportData createTestHeaderInfo() {
		ReportData reportData = new ReportData();

		reportData.setLoginUserName("Truchot Julien");

		return reportData;
	}

	private ReportData createTestModelInfo() {
		ReportData reportData = new ReportData();

		reportData.setModelName("Nom du modele");
		reportData.setModelVersion(1);
		reportData.setCompositionName("composition Name");

		return reportData;
	}

	private ReportData createTestData() {
		ReportData reportData = new ReportData();

		return reportData;
	}
}
