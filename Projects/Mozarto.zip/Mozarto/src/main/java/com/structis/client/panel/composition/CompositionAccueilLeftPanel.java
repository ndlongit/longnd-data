package com.structis.client.panel.composition;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HTML;
import com.sencha.gxt.cell.core.client.form.ComboBoxCell.TriggerAction;
import com.sencha.gxt.core.client.util.Padding;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.form.ComboBox;
import com.structis.client.event.CompositionLoadComposModeleEvent;
import com.structis.client.exception.AsyncCallbackWithErrorResolution;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.properties.ModeleModelProperties;
import com.structis.client.service.ClientCompositionServiceAsync;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.ModeleModel;

public class CompositionAccueilLeftPanel extends VerticalLayoutContainer {
	private SimpleEventBus bus;

	@SuppressWarnings("unused")
	private Images images = GWT.create(Images.class);

	private final Messages messages = GWT.create(Messages.class);

	private NavigationService navigation = NavigationFactory.getNavigation();

	private HTML metierLabel;
	
	@SuppressWarnings("unused")
	private Integer idMetier;
	
	private HTML creerCompoLink;

	private Metier metier;

	private ComboBox<ModeleModel> modeleComboBox;

	private HorizontalLayoutContainer modeleContainer;

	private HTML modeleLabel;

	public CompositionAccueilLeftPanel(SimpleEventBus bus) {
		getElement().setPadding(new Padding(5, 10, 5, 10));
		metier = navigation.getContext().getMetier();
		idMetier = metier.getIdMetier();
		this.bus = bus;
		setStyleName("whiteBackGround");
		
		VerticalLayoutContainer topContainer = new VerticalLayoutContainer();
		add(topContainer, new VerticalLayoutData(1, -1));
		metierLabel = new HTML();
		metierLabel.setHTML(messages.commonMetier() + ": " + metier.getLLibelle());

		topContainer.add(metierLabel);
		topContainer.setHeight(40);
		
		ModeleModelProperties props = GWT.create(ModeleModelProperties.class);
		ListStore<ModeleModel> store = new ListStore<ModeleModel>(props.idModele());
		modeleComboBox = new ComboBox<ModeleModel>(store, props.getLLibelle());
		modeleComboBox.setTypeAhead(true);
		modeleComboBox.setTriggerAction(TriggerAction.ALL);
		modeleContainer = new HorizontalLayoutContainer();
		modeleLabel = new HTML(messages.compositionAccueilLeftModele() + ": ");
		modeleContainer.add(modeleLabel);
		modeleContainer.add(modeleComboBox);
		topContainer.add(modeleContainer, new VerticalLayoutData(1, 1));
		
		VerticalLayoutContainer centerContainer = new VerticalLayoutContainer();
		add(centerContainer, new VerticalLayoutData(1, 1));
		creerCompoLink = new HTML();
		creerCompoLink.setHTML("> " + messages.compositionAccueilLeftCreer());
		creerCompoLink.setStyleName("htmlLink");
		
		centerContainer.add(creerCompoLink);
		centerContainer.getElement().setPadding(new Padding(10));
		addHandler();

		ClientCompositionServiceAsync.Util.getInstance().findAllLastPublicVersionByMetier(metier.getIdMetier(), new AsyncCallbackWithErrorResolution<List<ModeleModel>>() {

			@Override
			public void onSuccess(List<ModeleModel> arg0) {
				modeleComboBox.getStore().replaceAll(arg0);
			}
		});
	}

	public void addHandler() {
		creerCompoLink.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				//TODO
				Window.alert("create composition");
			}
		});
		modeleComboBox.addSelectionHandler(new SelectionHandler<ModeleModel>() {
			
			@Override
			public void onSelection(SelectionEvent<ModeleModel> arg0) {
				bus.fireEvent(new CompositionLoadComposModeleEvent(arg0.getSelectedItem()));
			}
		});
		addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent arg0) {
				modeleContainer.setWidth(arg0.getWidth());
				if(modeleContainer.getElement().getClientWidth() > 75){
					modeleLabel.setWidth("52px");
					modeleComboBox.setWidth(modeleContainer.getElement().getClientWidth() - 75);
				}
			}
		});
	}
}
