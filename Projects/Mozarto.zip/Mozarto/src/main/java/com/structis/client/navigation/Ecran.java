package com.structis.client.navigation;

import com.structis.client.ecran.EcranLoadable;

/**
 * Class wrap widget application , it contents the widget
 *
 */
public class Ecran {
	
	/**
	 * the widget
	 */
	private EcranLoadable ecran;
	
	/**
	 * 
	 * @param ecran
	 */
	public Ecran(EcranLoadable ecran) {
		this.ecran = ecran;
	}

	public EcranLoadable getEcran() {
		return ecran;
	}


}
