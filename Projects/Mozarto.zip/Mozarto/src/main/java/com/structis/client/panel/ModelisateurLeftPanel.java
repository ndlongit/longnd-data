package com.structis.client.panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Image;
import com.sencha.gxt.core.client.XTemplates;
import com.sencha.gxt.dnd.core.client.DndDragStartEvent;
import com.sencha.gxt.dnd.core.client.DndDropEvent;
import com.sencha.gxt.dnd.core.client.DragSource;
import com.sencha.gxt.dnd.core.client.GridDragSource;
import com.sencha.gxt.dnd.core.client.GridDragSource.GridDragSourceMessages;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.CellClickEvent;
import com.sencha.gxt.widget.core.client.event.CellClickEvent.CellClickHandler;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.structis.client.constant.ConstantClient;
import com.structis.client.event.MaskEvent;
import com.structis.client.event.MaskHandler;
import com.structis.client.event.TargetElementSelectEvent;
import com.structis.client.image.Images;
import com.structis.client.message.Messages;
import com.structis.client.navigation.NavigationFactory;
import com.structis.client.navigation.NavigationService;
import com.structis.client.widget.ElementCompositionGrid;
import com.structis.shared.constant.ModelNodeType;
import com.structis.shared.model.Element;
import com.structis.shared.model.Metier;
import com.structis.shared.model.reference.TreeNodeModel;
public class ModelisateurLeftPanel extends VerticalLayoutContainer {

	private SimpleEventBus bus;

	private final Messages messages = GWT.create(Messages.class);

	private HTML metierLabel;

	private FieldSet actionFieldSet;

	private FieldSet edcFieldSet;

	private HTML actionDescription;

	private TextField edcSearchTextField;

	private Images images = GWT.create(Images.class);

	private ElementCompositionGrid edcGrid;
	
	VerticalLayoutContainer actionPanel;
	
	private NavigationService navigation = NavigationFactory.getNavigation();
	
	@SuppressWarnings("unused")
	private Integer idMetier;

	private Metier metier;

	protected class CustomizeGridDragSourceMessages implements GridDragSourceMessages {
		
		public CustomizeGridDragSourceMessages(){
			super();
		}
		
		@Override
		public String itemsSelected(int items) {
			if (items < 2)
				return messages.commonElemcompogridDragdropSelectioneditem();
			else {
				return messages.commonElemcompogridDragdropSelectioneditems(items);
			}
		}
	}
	
	public ModelisateurLeftPanel(SimpleEventBus bus) {
		metier = navigation.getContext().getMetier();
		this.idMetier = metier.getIdMetier();
		this.bus = bus;
		buildPanel();
		addHandler();		
	}

	public interface HtmlLayoutContainerTemplate extends XTemplates {
		@XTemplate("<table width=\"100%\" height=\"100%\"><tbody><tr><td width=\"90%\" class=\"cell1\" /><td></td><td class=\"cell2\" /></tr></tbody></table>")
		SafeHtml getTemplate();
	}

	private void buildPanel() {
		//setHeaderVisible(false);
		addStyleName("whiteBackGround");
		metierLabel = new HTML();
		metierLabel.setHTML(messages.commonMetier() + ": " + metier.getLLibelle());

		actionDescription = new HTML();
		actionDescription.setHTML(messages.modelisateurActionDescription());

		edcSearchTextField = new TextField();
		edcSearchTextField.setEmptyText("");

		//initEdcGrid();

		edcFieldSet = new FieldSet();
		edcFieldSet.setHeadingHtml(messages.modelisateurElementDeComposition());
		edcFieldSet.setStyleName("fieldsetPadding");
		edcGrid = new ElementCompositionGrid(bus);
        edcFieldSet.add(edcGrid/*, new MarginData(4)*/);
		actionFieldSet = new FieldSet();
		actionFieldSet.setHeadingHtml(messages.modelisateurAction());
		actionFieldSet.setStyleName("fieldsetPadding");
		actionPanel = new VerticalLayoutContainer();
		actionPanel.add(actionDescription);
		actionPanel.add(new HTML("<hr/>"));
		//actionPanel.add(caracteristiqueButton);
		addButton(
				actionPanel, messages.modelisateurCaracteristique(), ConstantClient.Action.createCaracteristique,
				images.addIcon());
		addButton(actionPanel, messages.modelisateurReference(), ConstantClient.Action.createReference, images.addIcon());
		addButton(
				actionPanel, messages.modelisateurElementDeComposition(), ConstantClient.Action.createElement,
				images.addIcon());

		actionPanel.add(edcFieldSet,new VerticalLayoutData(1,.9));
		actionFieldSet.add(actionPanel,new MarginData(3));
		add(metierLabel);
		add(actionFieldSet, new VerticalLayoutData(1, 1));
		@SuppressWarnings("unused")
		GridDragSource<Element> source2 = new GridDragSource<Element>(edcGrid.getEdcGrid()) {			
			@Override
			protected void onDragDrop(DndDropEvent event) {					
				
			}
			@Override
			protected void onDragStart(DndDragStartEvent event) {
				super.onDragStart(event);
				//event.setData(ConstantClient.Action.dragElement);				
			}

			@Override
			public GridDragSourceMessages getMessages() {
				return new CustomizeGridDragSourceMessages();
			}
		};
/*		ClientModelisateurServiceAsync.Util.getInstance().getMetier(idMetier, new AsyncCallbackWithErrorResolution<Metier>() {

			@Override
			public void onSuccess(Metier result) {
				metierLabel.setHTML(messages.commonMetier() + ": " + result.getLLibelle());
			}
		});*/

	}

	private void addButton(VerticalLayoutContainer container, String label, final String action, ImageResource imageResource) {
		HTML htmlbuton = new HTML();
		htmlbuton.addStyleName("actionButton");
		Image image = new Image();
		image.setResource(imageResource);
		htmlbuton.setHTML(image + " " + label);
		container.add(htmlbuton);

		@SuppressWarnings("unused")
		DragSource source = new DragSource(htmlbuton) {
			@Override
			protected void onDragStart(DndDragStartEvent event) {
				super.onDragStart(event);
				// by default drag is allowed
				event.setData(action);
				event.getStatusProxy().update(messages.commonElemcompogridDragdropSelectioneditem());
			}
			
		};		

	}

	private void addHandler() {
		final VerticalLayoutContainer panel = this;
		bus.addHandler(MaskEvent.getType(), new MaskHandler() {
			@Override
			public void onLoad(MaskEvent event) {
				if (event.isMask()) {
					panel.mask();
				} else {
					panel.unmask();
				}				
			}
			
		});
		edcGrid.getEdcGrid().addCellClickHandler(new CellClickHandler() {
			
			@Override
			public void onCellClick(CellClickEvent event) {
				Element  element = edcGrid.getEdcGrid().getStore().get(event.getRowIndex());
				TreeNodeModel nodeModel = new TreeNodeModel();
				nodeModel.setId(element.getIdElement());
				nodeModel.setModelType(ModelNodeType.ELEMENT);
				nodeModel.setLibelle(element.getLLibelleLong());
				bus.fireEvent(new TargetElementSelectEvent(nodeModel));
			}
		});
		/*addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent event) {
				int actionFieldSetHeight = getElement().getClientHeight();
				actionPanel.setHeight(actionFieldSetHeight-50);
				int edcFieldSetHeight = actionFieldSetHeight-200;
				//edcFieldSet.setHeight(edcFieldSetHeight);
				//edcFieldSet.getElement().repaint();
				edcGrid.setHeight(edcFieldSetHeight-50);
				edcGrid.setWidth(getElement().getClientWidth());
			}
		});*/

		addResizeHandler(new ResizeHandler() {
			
			@Override
			public void onResize(ResizeEvent event) {
				int actionFieldSetHeight = getElement().getClientHeight();
				int edcFieldSetHeight = actionFieldSetHeight-120;
				//edcFieldSet.setHeight(edcFieldSetHeight);
				//edcFieldSet.getElement().repaint();
				edcGrid.setHeight(edcFieldSetHeight-30);
				edcGrid.setWidth(getElement().getClientWidth());
			}
		});
	}

	public void onLoadPanel() {
		
	}

}
