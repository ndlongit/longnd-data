/*==============================================================*/
/* Nom de SGBD :  Microsoft SQL Server 2008                     */
/* Date de cr�ation :  16/10/2012 14:58:51                      */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_attribut_etendu') and o.name = 'FK_MZ_ATTRI_ATTRIBUT__MZ_TYPE_')
alter table mz_attribut_etendu
   drop constraint FK_MZ_ATTRI_ATTRIBUT__MZ_TYPE_
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_attribut_etendu') and o.name = 'FK_MZ_ATTRI_PERSONNAL_MZ_METIE')
alter table mz_attribut_etendu
   drop constraint FK_MZ_ATTRI_PERSONNAL_MZ_METIE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_attribut_etendu_element') and o.name = 'FK_MZ_ATTRI_ATTRIBUT__MZ_ELEME')
alter table mz_attribut_etendu_element
   drop constraint FK_MZ_ATTRI_ATTRIBUT__MZ_ELEME
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_attribut_etendu_element') and o.name = 'FK_MZ_ATTRI_ATTRIBUT__MZ_ATTRI')
alter table mz_attribut_etendu_element
   drop constraint FK_MZ_ATTRI_ATTRIBUT__MZ_ATTRI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_attribut_etendu_reference') and o.name = 'FK_MZ_CMP_A_CMP_ATTRI_MZ_ATTRI')
alter table mz_cmp_attribut_etendu_reference
   drop constraint FK_MZ_CMP_A_CMP_ATTRI_MZ_ATTRI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_attribut_etendu_reference') and o.name = 'FK_MZ_CMP_A_MDL_ATTRI_MZ_CMP_R')
alter table mz_cmp_attribut_etendu_reference
   drop constraint FK_MZ_CMP_A_MDL_ATTRI_MZ_CMP_R
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_caracteristique_select') and o.name = 'FK_MZ_CMP_C_CMP_CARAC_MZ_CMP_C')
alter table mz_cmp_caracteristique_select
   drop constraint FK_MZ_CMP_C_CMP_CARAC_MZ_CMP_C
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_caracteristique_select') and o.name = 'FK_MZ_CMP_C_CMP_CARAC_MZ_MDL_C')
alter table mz_cmp_caracteristique_select
   drop constraint FK_MZ_CMP_C_CMP_CARAC_MZ_MDL_C
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_composition') and o.name = 'FK_MZ_CMP_C_CMP_MODEL_MZ_MDL_M')
alter table mz_cmp_composition
   drop constraint FK_MZ_CMP_C_CMP_MODEL_MZ_MDL_M
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_composition') and o.name = 'FK_MZ_CMP_C_MZ_CMP_UT_MZ_UTILI')
alter table mz_cmp_composition
   drop constraint FK_MZ_CMP_C_MZ_CMP_UT_MZ_UTILI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_composition') and o.name = 'FK_MZ_CMP_C_MZ_CMP_UT_MZ_UTILI2')
alter table mz_cmp_composition
   drop constraint FK_MZ_CMP_C_MZ_CMP_UT_MZ_UTILI2
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_element_select') and o.name = 'FK_MZ_CMP_E_CMP_ELEME_MZ_CMP_C')
alter table mz_cmp_element_select
   drop constraint FK_MZ_CMP_E_CMP_ELEME_MZ_CMP_C
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_element_select') and o.name = 'FK_MZ_CMP_E_CMP_ELEME_MZ_ELEME')
alter table mz_cmp_element_select
   drop constraint FK_MZ_CMP_E_CMP_ELEME_MZ_ELEME
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_reference') and o.name = 'FK_MZ_CMP_R_CMP_MODEL_MZ_MDL_R')
alter table mz_cmp_reference
   drop constraint FK_MZ_CMP_R_CMP_MODEL_MZ_MDL_R
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_reference') and o.name = 'FK_MZ_CMP_R_CMP_REFER_MZ_CMP_C')
alter table mz_cmp_reference
   drop constraint FK_MZ_CMP_R_CMP_REFER_MZ_CMP_C
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_reference_element') and o.name = 'FK_MZ_CMP_R_CMP_REFER_MZ_CMP_R')
alter table mz_cmp_reference_element
   drop constraint FK_MZ_CMP_R_CMP_REFER_MZ_CMP_R
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_cmp_reference_element') and o.name = 'FK_MZ_CMP_R_CMP_REFER_MZ_ELEME')
alter table mz_cmp_reference_element
   drop constraint FK_MZ_CMP_R_CMP_REFER_MZ_ELEME
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_element') and o.name = 'FK_MZ_ELEME_ELEMENT_R_MZ_FAMIL')
alter table mz_element
   drop constraint FK_MZ_ELEME_ELEMENT_R_MZ_FAMIL
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_element') and o.name = 'FK_MZ_ELEME_ELEMENT_R_MZ_METIE')
alter table mz_element
   drop constraint FK_MZ_ELEME_ELEMENT_R_MZ_METIE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_famille') and o.name = 'FK_MZ_FAMIL_FAMILLEPA_MZ_FAMIL')
alter table mz_famille
   drop constraint FK_MZ_FAMIL_FAMILLEPA_MZ_FAMIL
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_famille') and o.name = 'FK_MZ_FAMIL_FAMILLE_E_MZ_FAMIL')
alter table mz_famille
   drop constraint FK_MZ_FAMIL_FAMILLE_E_MZ_FAMIL
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_habilitation_utilisateur') and o.name = 'FK_MZ_HABIL_HABILITAT_MZ_UTILI')
alter table mz_habilitation_utilisateur
   drop constraint FK_MZ_HABIL_HABILITAT_MZ_UTILI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_habilitation_utilisateur') and o.name = 'FK_MZ_HABIL_HABILITAT_MZ_ROLE_')
alter table mz_habilitation_utilisateur
   drop constraint FK_MZ_HABIL_HABILITAT_MZ_ROLE_
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_habilitation_utilisateur') and o.name = 'FK_MZ_HABIL_HABILITAT_MZ_METIE')
alter table mz_habilitation_utilisateur
   drop constraint FK_MZ_HABIL_HABILITAT_MZ_METIE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_attribut_etendu_reference') and o.name = 'FK_MZ_MDL_A_MDL_ATTRI_MZ_MDL_R')
alter table mz_mdl_attribut_etendu_reference
   drop constraint FK_MZ_MDL_A_MDL_ATTRI_MZ_MDL_R
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_attribut_etendu_reference') and o.name = 'FK_MZ_MDL_A_MDL_ATTRI_MZ_ATTRI')
alter table mz_mdl_attribut_etendu_reference
   drop constraint FK_MZ_MDL_A_MDL_ATTRI_MZ_ATTRI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_caracteristique') and o.name = 'FK_MZ_MDL_C_MDL_CARAC_MZ_MDL_C')
alter table mz_mdl_caracteristique
   drop constraint FK_MZ_MDL_C_MDL_CARAC_MZ_MDL_C
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_caracteristique') and o.name = 'FK_MZ_MDL_C_MDL_MODEL_MZ_MDL_M')
alter table mz_mdl_caracteristique
   drop constraint FK_MZ_MDL_C_MDL_MODEL_MZ_MDL_M
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_carateristique_reference') and o.name = 'FK_MZ_MDL_C_MDL_CARAT_MZ_MDL_C')
alter table mz_mdl_carateristique_reference
   drop constraint FK_MZ_MDL_C_MDL_CARAT_MZ_MDL_C
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_carateristique_reference') and o.name = 'FK_MZ_MDL_C_MDL_CARAT_MZ_MDL_R')
alter table mz_mdl_carateristique_reference
   drop constraint FK_MZ_MDL_C_MDL_CARAT_MZ_MDL_R
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_message') and o.name = 'FK_MZ_MDL_M_MDL_MESSA_MZ_MDL_L')
alter table mz_mdl_message
   drop constraint FK_MZ_MDL_M_MDL_MESSA_MZ_MDL_L
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_message') and o.name = 'FK_MZ_MDL_M_MDL_SOURC_MZ_MDL_L')
alter table mz_mdl_message
   drop constraint FK_MZ_MDL_M_MDL_SOURC_MZ_MDL_L
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_modele') and o.name = 'FK_MZ_MDL_M_MODELE_LI_MZ_METIE')
alter table mz_mdl_modele
   drop constraint FK_MZ_MDL_M_MODELE_LI_MZ_METIE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_modele') and o.name = 'FK_MZ_MDL_M_MZ_MDL_UT_MZ_UTILI')
alter table mz_mdl_modele
   drop constraint FK_MZ_MDL_M_MZ_MDL_UT_MZ_UTILI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_modele_version') and o.name = 'FK_MZ_MDL_M_HORODATE_MZ_UTILI')
alter table mz_mdl_modele_version
   drop constraint FK_MZ_MDL_M_HORODATE_MZ_UTILI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_modele_version') and o.name = 'FK_MZ_MDL_M_MDL_EXEMP_MZ_MDL_M')
alter table mz_mdl_modele_version
   drop constraint FK_MZ_MDL_M_MDL_EXEMP_MZ_MDL_M
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_reference') and o.name = 'FK_MZ_MDL_R_REFERENCE_MZ_MDL_R')
alter table mz_mdl_reference
   drop constraint FK_MZ_MDL_R_REFERENCE_MZ_MDL_R
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_reference_element') and o.name = 'FK_MZ_MDL_R_MDL_REFER_MZ_ELEME')
alter table mz_mdl_reference_element
   drop constraint FK_MZ_MDL_R_MDL_REFER_MZ_ELEME
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_reference_element') and o.name = 'FK_MZ_MDL_R_MDL_REFER_MZ_MDL_R')
alter table mz_mdl_reference_element
   drop constraint FK_MZ_MDL_R_MDL_REFER_MZ_MDL_R
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_regle') and o.name = 'FK_MZ_MDL_R_MDL_TYPAG_MZ_MDL_T')
alter table mz_mdl_regle
   drop constraint FK_MZ_MDL_R_MDL_TYPAG_MZ_MDL_T
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_type_regle') and o.name = 'FK_MZ_MDL_T_MDL_TYPE__MZ_MDL_S')
alter table mz_mdl_type_regle
   drop constraint FK_MZ_MDL_T_MDL_TYPE__MZ_MDL_S
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_mdl_type_regle') and o.name = 'FK_MZ_MDL_T_MDL_SOURC_MZ_MDL_T')
alter table mz_mdl_type_regle
   drop constraint FK_MZ_MDL_T_MDL_SOURC_MZ_MDL_T
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_metier_lien_pegaz') and o.name = 'FK_MZ_METIE_METIER_LI_PZ_METIE')
alter table mz_metier_lien_pegaz
   drop constraint FK_MZ_METIE_METIER_LI_PZ_METIE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_metier_lien_pegaz') and o.name = 'FK_MZ_METIE_METIER_LI_MZ_METIE')
alter table mz_metier_lien_pegaz
   drop constraint FK_MZ_METIE_METIER_LI_MZ_METIE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_preference_graphique_utilisateur') and o.name = 'FK_MZ_PREF_GRAPHIQUE1')
alter table mz_preference_graphique_utilisateur
   drop constraint FK_MZ_PREF_GRAPHIQUE1
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_preference_graphique_utilisateur') and o.name = 'FK_MZ_PREF_UTIL1')
alter table mz_preference_graphique_utilisateur
   drop constraint FK_MZ_PREF_UTIL1
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_preference_utilisateur') and o.name = 'FK_MZ_PREFE_LANGUE_PA_MZ_LANGU')
alter table mz_preference_utilisateur
   drop constraint FK_MZ_PREFE_LANGUE_PA_MZ_LANGU
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_preference_utilisateur') and o.name = 'FK_MZ_PREFE_UTILISATE_MZ_UTILI')
alter table mz_preference_utilisateur
   drop constraint FK_MZ_PREFE_UTILISATE_MZ_UTILI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_sas_import') and o.name = 'FK_MZ_SAS_I_REFERENCE_MZ_UTILI')
alter table mz_sas_import
   drop constraint FK_MZ_SAS_I_REFERENCE_MZ_UTILI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_utilisateur_lien_pegaz') and o.name = 'FK_MZ_UTILI_UTILISATE_MZ_UTILI')
alter table mz_utilisateur_lien_pegaz
   drop constraint FK_MZ_UTILI_UTILISATE_MZ_UTILI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('mz_utilisateur_lien_pegaz') and o.name = 'FK_MZ_UTILI_UTILISATE_PZ_UTILI')
alter table mz_utilisateur_lien_pegaz
   drop constraint FK_MZ_UTILI_UTILISATE_PZ_UTILI
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_application_origine')
            and   type = 'U')
   drop table mz_application_origine
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_attribut_etendu')
            and   name  = 'ASSOCIATION_5_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_attribut_etendu.ASSOCIATION_5_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_attribut_etendu')
            and   name  = 'PERSONNALISE_ATTRIBUT_ETENDU_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_attribut_etendu.PERSONNALISE_ATTRIBUT_ETENDU_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_attribut_etendu')
            and   type = 'U')
   drop table mz_attribut_etendu
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_attribut_etendu_element')
            and   name  = 'ATTRIBUT_ETENDU_ELEMENT2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_attribut_etendu_element.ATTRIBUT_ETENDU_ELEMENT2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_attribut_etendu_element')
            and   name  = 'ATTRIBUT_ETENDU_ELEMENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_attribut_etendu_element.ATTRIBUT_ETENDU_ELEMENT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_attribut_etendu_element')
            and   type = 'U')
   drop table mz_attribut_etendu_element
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_attribut_etendu_reference')
            and   name  = 'ATTRIBUT_ETENDU_REFERENCE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_attribut_etendu_reference.ATTRIBUT_ETENDU_REFERENCE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_cmp_attribut_etendu_reference')
            and   type = 'U')
   drop table mz_cmp_attribut_etendu_reference
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_caracteristique_select')
            and   name  = 'COMPOSITION_CARACTERISTIQUE_SELECT2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_caracteristique_select.COMPOSITION_CARACTERISTIQUE_SELECT2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_caracteristique_select')
            and   name  = 'COMPOSITION_CARACTERISTIQUE_SELECT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_caracteristique_select.COMPOSITION_CARACTERISTIQUE_SELECT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_cmp_caracteristique_select')
            and   type = 'U')
   drop table mz_cmp_caracteristique_select
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_composition')
            and   name  = 'COMPO_POUR_APPLICATION_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_composition.COMPO_POUR_APPLICATION_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_composition')
            and   name  = 'COMPOSITION_RATTACHEE_A_MODELE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_composition.COMPOSITION_RATTACHEE_A_MODELE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_cmp_composition')
            and   type = 'U')
   drop table mz_cmp_composition
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_element_select')
            and   name  = 'COMPOSITION_ELEMENT2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_element_select.COMPOSITION_ELEMENT2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_element_select')
            and   name  = 'COMPOSITION_ELEMENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_element_select.COMPOSITION_ELEMENT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_cmp_element_select')
            and   type = 'U')
   drop table mz_cmp_element_select
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_reference')
            and   name  = 'ITEM_RATTACHE_A_MODELE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_reference.ITEM_RATTACHE_A_MODELE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_reference')
            and   name  = 'COMPOSITION_REFERENCE_SELECT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_reference.COMPOSITION_REFERENCE_SELECT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_cmp_reference')
            and   type = 'U')
   drop table mz_cmp_reference
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_reference_element')
            and   name  = 'COMPOSITION_ELEMENT2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_reference_element.COMPOSITION_ELEMENT2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_reference_element')
            and   name  = 'COMPOSITION_ELEMENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_reference_element.COMPOSITION_ELEMENT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_cmp_reference_element')
            and   type = 'U')
   drop table mz_cmp_reference_element
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_regle_element')
            and   name  = 'CMP_REGLE_ELEMENT3_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_regle_element.CMP_REGLE_ELEMENT3_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_regle_element')
            and   name  = 'CMP_REGLE_ELEMENT2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_regle_element.CMP_REGLE_ELEMENT2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_cmp_regle_element')
            and   name  = 'CMP_REGLE_ELEMENT1_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_cmp_regle_element.CMP_REGLE_ELEMENT1_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_cmp_regle_element')
            and   type = 'U')
   drop table mz_cmp_regle_element
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_element')
            and   name  = 'ELEMENT_RATTACHE_A_FAMILLE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_element.ELEMENT_RATTACHE_A_FAMILLE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_element')
            and   name  = 'ELEMENT_RATTACHE_A_METIER_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_element.ELEMENT_RATTACHE_A_METIER_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_element')
            and   type = 'U')
   drop table mz_element
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_famille')
            and   name  = 'FAMILLE_LIEE_A_METIER_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_famille.FAMILLE_LIEE_A_METIER_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_famille')
            and   name  = 'FAMILLE_EST_DU_TYPE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_famille.FAMILLE_EST_DU_TYPE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_famille')
            and   name  = 'FAMILLEPARENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_famille.FAMILLEPARENT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_famille')
            and   type = 'U')
   drop table mz_famille
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_famille_type')
            and   name  = 'TYPE_FAMILLE_DE_TYPE_ELEMENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_famille_type.TYPE_FAMILLE_DE_TYPE_ELEMENT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_famille_type')
            and   type = 'U')
   drop table mz_famille_type
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_habilitation_utilisateur')
            and   name  = 'HABILITATION_UTILISATEUR3_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_habilitation_utilisateur.HABILITATION_UTILISATEUR3_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_habilitation_utilisateur')
            and   name  = 'HABILITATION_UTILISATEUR2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_habilitation_utilisateur.HABILITATION_UTILISATEUR2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_habilitation_utilisateur')
            and   name  = 'HABILITATION_UTILISATEUR_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_habilitation_utilisateur.HABILITATION_UTILISATEUR_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_habilitation_utilisateur')
            and   type = 'U')
   drop table mz_habilitation_utilisateur
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_langue')
            and   type = 'U')
   drop table mz_langue
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_attribut_etendu_reference')
            and   name  = 'ATTRIBUT_ETENDU_REFERENCE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_attribut_etendu_reference.ATTRIBUT_ETENDU_REFERENCE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_attribut_etendu_reference')
            and   type = 'U')
   drop table mz_mdl_attribut_etendu_reference
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_caracteristique')
            and   name  = 'MODELE_COMPORTE_CARACTERISTIQUE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_caracteristique.MODELE_COMPORTE_CARACTERISTIQUE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_caracteristique')
            and   name  = 'CARACTERISTIQUE_PARENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_caracteristique.CARACTERISTIQUE_PARENT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_caracteristique')
            and   type = 'U')
   drop table mz_mdl_caracteristique
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_carateristique_reference')
            and   name  = 'CARATERISTIQUE_ITEM2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_carateristique_reference.CARATERISTIQUE_ITEM2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_carateristique_reference')
            and   name  = 'CARATERISTIQUE_ITEM_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_carateristique_reference.CARATERISTIQUE_ITEM_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_carateristique_reference')
            and   type = 'U')
   drop table mz_mdl_carateristique_reference
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_lien_caracteristique')
            and   name  = 'LIEN_DE_TYPE_CARACTERISTIQUE_COMPORTE_UNE_CARACTERISTIQUE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_lien_caracteristique.LIEN_DE_TYPE_CARACTERISTIQUE_COMPORTE_UNE_CARACTERISTIQUE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_lien_caracteristique')
            and   type = 'U')
   drop table mz_mdl_lien_caracteristique
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_lien_commun')
            and   name  = 'LIEN_MODELE_VERSION_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_lien_commun.LIEN_MODELE_VERSION_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_lien_commun')
            and   name  = 'ASSOCIATION_39_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_lien_commun.ASSOCIATION_39_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_lien_commun')
            and   type = 'U')
   drop table mz_mdl_lien_commun
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_lien_element')
            and   name  = 'LIEN_DE_TYPE_ELEMENT_COMPORTE_UNE_ELEMENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_lien_element.LIEN_DE_TYPE_ELEMENT_COMPORTE_UNE_ELEMENT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_lien_element')
            and   type = 'U')
   drop table mz_mdl_lien_element
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_lien_reference')
            and   name  = 'LIEN_DE_TYPE_REFERENCE_COMPORTE_UNE_REFERENCE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_lien_reference.LIEN_DE_TYPE_REFERENCE_COMPORTE_UNE_REFERENCE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_lien_reference')
            and   type = 'U')
   drop table mz_mdl_lien_reference
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_message')
            and   name  = 'MDL_TYPAGE_MESSAGE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_message.MDL_TYPAGE_MESSAGE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_message')
            and   name  = 'MDL_MODELE_COMPORTE_MESSAGE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_message.MDL_MODELE_COMPORTE_MESSAGE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_message')
            and   type = 'U')
   drop table mz_mdl_message
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_modele')
            and   type = 'U')
   drop table mz_mdl_modele
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_modele_version')
            and   name  = 'HORODATE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_modele_version.HORODATE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_modele_version')
            and   name  = 'MODELE_EST_VERSIONNE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_modele_version.MODELE_EST_VERSIONNE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_modele_version')
            and   type = 'U')
   drop table mz_mdl_modele_version
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_reference')
            and   name  = 'MDL_MODELE_COMPORTE_REFERENCE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_reference.MDL_MODELE_COMPORTE_REFERENCE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_reference')
            and   type = 'U')
   drop table mz_mdl_reference
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_reference_element')
            and   name  = 'REFERENCE_ELEMENT2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_reference_element.REFERENCE_ELEMENT2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_reference_element')
            and   name  = 'REFERENCE_ELEMENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_reference_element.REFERENCE_ELEMENT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_reference_element')
            and   type = 'U')
   drop table mz_mdl_reference_element
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_reference_sous_modele')
            and   name  = 'MDL_MODELE_COMPORTE_REFERENCE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_reference_sous_modele.MDL_MODELE_COMPORTE_REFERENCE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_reference_sous_modele')
            and   type = 'U')
   drop table mz_mdl_reference_sous_modele
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_regle')
            and   name  = 'ASSOCIATION_42_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_regle.ASSOCIATION_42_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_regle')
            and   name  = 'SOURCE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_regle.SOURCE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_regle')
            and   name  = 'MDL_MODELE_COMPORTE_REGLE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_regle.MDL_MODELE_COMPORTE_REGLE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_regle')
            and   name  = 'REGLE_EST_DU_TYPE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_regle.REGLE_EST_DU_TYPE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_regle')
            and   type = 'U')
   drop table mz_mdl_regle
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_sousreference_reference')
            and   name  = 'MDL_SOUSREFERENCE_REFERENCE2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_sousreference_reference.MDL_SOUSREFERENCE_REFERENCE2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_mdl_sousreference_reference')
            and   name  = 'MDL_SOUSREFERENCE_REFERENCE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_mdl_sousreference_reference.MDL_SOUSREFERENCE_REFERENCE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_sousreference_reference')
            and   type = 'U')
   drop table mz_mdl_sousreference_reference
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_type_lien')
            and   type = 'U')
   drop table mz_mdl_type_lien
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_type_regle')
            and   type = 'U')
   drop table mz_mdl_type_regle
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_mdl_version')
            and   type = 'U')
   drop table mz_mdl_version
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_metier')
            and   type = 'U')
   drop table mz_metier
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_metier_lien_pegaz')
            and   name  = 'METIER_LIEN_PEGAZ2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_metier_lien_pegaz.METIER_LIEN_PEGAZ2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_metier_lien_pegaz')
            and   name  = 'METIER_LIEN_PEGAZ_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_metier_lien_pegaz.METIER_LIEN_PEGAZ_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_metier_lien_pegaz')
            and   type = 'U')
   drop table mz_metier_lien_pegaz
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_preference_graphique')
            and   type = 'U')
   drop table mz_preference_graphique
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_preference_graphique_utilisateur')
            and   name  = 'PREFERENCE_GRAPHIQUE_UTILISATEUR2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_preference_graphique_utilisateur.PREFERENCE_GRAPHIQUE_UTILISATEUR2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_preference_graphique_utilisateur')
            and   name  = 'PREFERENCE_GRAPHIQUE_UTILISATEUR_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_preference_graphique_utilisateur.PREFERENCE_GRAPHIQUE_UTILISATEUR_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_preference_graphique_utilisateur')
            and   type = 'U')
   drop table mz_preference_graphique_utilisateur
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_preference_utilisateur')
            and   name  = 'LANGUE_PAR_DEFAUT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_preference_utilisateur.LANGUE_PAR_DEFAUT_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_preference_utilisateur')
            and   name  = 'UTILISATEUR_A_POUR_PREFERENCE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_preference_utilisateur.UTILISATEUR_A_POUR_PREFERENCE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_preference_utilisateur')
            and   type = 'U')
   drop table mz_preference_utilisateur
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_role_utilisateur')
            and   type = 'U')
   drop table mz_role_utilisateur
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_sas_import')
            and   name  = 'IMPORT_SUR_METIER_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_sas_import.IMPORT_SUR_METIER_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_sas_import')
            and   name  = 'ETAT_D_AVANCEMENT_DE_L_IMPORT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_sas_import.ETAT_D_AVANCEMENT_DE_L_IMPORT_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_sas_import')
            and   name  = 'IMPORT_A_POUR_TYPE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_sas_import.IMPORT_A_POUR_TYPE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_sas_import')
            and   name  = 'IMPORT_SUR_MODELE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_sas_import.IMPORT_SUR_MODELE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_sas_import')
            and   type = 'U')
   drop table mz_sas_import
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_sas_import_element')
            and   name  = 'ELEMENT_D_IMPORT_A_POUR_TYPE_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_sas_import_element.ELEMENT_D_IMPORT_A_POUR_TYPE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_sas_import_element')
            and   name  = 'ASSOCIATION_50_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_sas_import_element.ASSOCIATION_50_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_sas_import_element')
            and   type = 'U')
   drop table mz_sas_import_element
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_sas_import_element_erreur')
            and   name  = 'ERREUR_TROUVEE_SUR_ELEMENT_D_IMPORT_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_sas_import_element_erreur.ERREUR_TROUVEE_SUR_ELEMENT_D_IMPORT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_sas_import_element_erreur')
            and   type = 'U')
   drop table mz_sas_import_element_erreur
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_sas_import_element_type')
            and   type = 'U')
   drop table mz_sas_import_element_type
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_sas_import_etat')
            and   type = 'U')
   drop table mz_sas_import_etat
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_sas_import_type')
            and   type = 'U')
   drop table mz_sas_import_type
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_type_attribut_etendu')
            and   type = 'U')
   drop table mz_type_attribut_etendu
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_type_element')
            and   type = 'U')
   drop table mz_type_element
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_utilisateur')
            and   type = 'U')
   drop table mz_utilisateur
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_utilisateur_lien_pegaz')
            and   name  = 'UTILISATEUR_LIEN_PEGAZ2_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_utilisateur_lien_pegaz.UTILISATEUR_LIEN_PEGAZ2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('mz_utilisateur_lien_pegaz')
            and   name  = 'UTILISATEUR_LIEN_PEGAZ_FK'
            and   indid > 0
            and   indid < 255)
   drop index mz_utilisateur_lien_pegaz.UTILISATEUR_LIEN_PEGAZ_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('mz_utilisateur_lien_pegaz')
            and   type = 'U')
   drop table mz_utilisateur_lien_pegaz
go

if exists (select 1
            from  sysobjects
           where  id = object_id('pz_metier')
            and   type = 'U')
   drop table pz_metier
go

if exists (select 1
            from  sysobjects
           where  id = object_id('pz_utilisateur')
            and   type = 'U')
   drop table pz_utilisateur
go

if exists(select 1 from systypes where name='LIBELLE_COURT')
   drop type LIBELLE_COURT
go

if exists(select 1 from systypes where name='LIBELLE_LONG')
   drop type LIBELLE_LONG
go

if exists(select 1 from systypes where name='MAIL')
   drop type MAIL
go

if exists(select 1 from systypes where name='TEXTE')
   drop type TEXTE
go

/*==============================================================*/
/* Domaine : LIBELLE_COURT                                      */
/*==============================================================*/
create type LIBELLE_COURT
   from varchar(50)
go

/*==============================================================*/
/* Domaine : LIBELLE_LONG                                       */
/*==============================================================*/
create type LIBELLE_LONG
   from varchar(500)
go

/*==============================================================*/
/* Domaine : MAIL                                               */
/*==============================================================*/
create type MAIL
   from varchar(64)
go

/*==============================================================*/
/* Domaine : TEXTE                                              */
/*==============================================================*/
create type TEXTE
   from varchar(2000)
go

/*==============================================================*/
/* Table : mz_application_origine                               */
/*==============================================================*/
create table mz_application_origine (
   c_application_origine char(1)              not null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_APPLICATION_ORIGINE primary key nonclustered (c_application_origine)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Application pour laquelle une composition a pu �tre r�alis�e
   Valeurs pr�d�finies :
    - ''P'' : PEGAZ
    - ''M'' : Mozarto',
   'user', @CurrentUser, 'table', 'mz_application_origine'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code identifiant de l''application d''origine',
   'user', @CurrentUser, 'table', 'mz_application_origine', 'column', 'c_application_origine'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� de l''application origine',
   'user', @CurrentUser, 'table', 'mz_application_origine', 'column', 'l_libelle'
go

/*==============================================================*/
/* Table : mz_attribut_etendu                                   */
/*==============================================================*/
create table mz_attribut_etendu (
   id_attribut_etendu   int                  identity,
   c_type_attribut_etendu char(1)              not null,
   id_metier            int                  not null,
   n_rang               smallint             not null,
   c_label_attribut_etendu varchar(10)          not null,
   l_libelle            LIBELLE_COURT        not null,
   in_utilisation_compositeur bit                  not null,
   l_valeur             TEXTE                null,
   l_commentaire        TEXTE                null,
   constraint PK_MZ_ATTRIBUT_ETENDU primary key nonclustered (id_attribut_etendu)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'D�finition des attributs �tendus de r�f�rences et d''�l�ments pour le m�tier',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu', 'column', 'id_attribut_etendu'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du type d''attribut �tendu (indique s''il s''agit d''un attribut �tendu sur r�f�rence ou sur �l�ment)',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu', 'column', 'c_type_attribut_etendu'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du m�tier',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu', 'column', 'id_metier'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Rang d''ordonnancement de l''attribut �tendu',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu', 'column', 'n_rang'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code de l''attribut �tendu (utilis� pour l''import/export de donn�es)',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu', 'column', 'c_label_attribut_etendu'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� de l''attribut �tendu
   ',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu', 'column', 'l_libelle'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Indicateur bool�en permettant de savoir si cet attribut �tendu s''utilise au niveau du compositeur (vrai) ou pas (faux)',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu', 'column', 'in_utilisation_compositeur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Valeur par d�faut de l''attribut �tendu',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu', 'column', 'l_valeur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Commentaire sur l''attribut �tendu',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu', 'column', 'l_commentaire'
go

/*==============================================================*/
/* Index : PERSONNALISE_ATTRIBUT_ETENDU_FK                      */
/*==============================================================*/
create index PERSONNALISE_ATTRIBUT_ETENDU_FK on mz_attribut_etendu (
id_metier ASC
)
go

/*==============================================================*/
/* Index : ASSOCIATION_5_FK                                     */
/*==============================================================*/
create index ASSOCIATION_5_FK on mz_attribut_etendu (
c_type_attribut_etendu ASC
)
go

/*==============================================================*/
/* Table : mz_attribut_etendu_element                           */
/*==============================================================*/
create table mz_attribut_etendu_element (
   id_element           int                  not null,
   id_attribut_etendu   int                  not null,
   l_valeur             TEXTE                not null,
   constraint PK_MZ_ATTRIBUT_ETENDU_ELEMENT primary key (id_element, id_attribut_etendu)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Valorisation d''un attribut �tendu d''�l�ment de composition',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''�l�ment de composition',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu_element', 'column', 'id_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''attribut �tendu',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu_element', 'column', 'id_attribut_etendu'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Valeur de l''attribut �tendu de l''�l�ment',
   'user', @CurrentUser, 'table', 'mz_attribut_etendu_element', 'column', 'l_valeur'
go

/*==============================================================*/
/* Index : ATTRIBUT_ETENDU_ELEMENT_FK                           */
/*==============================================================*/
create index ATTRIBUT_ETENDU_ELEMENT_FK on mz_attribut_etendu_element (
id_element ASC
)
go

/*==============================================================*/
/* Index : ATTRIBUT_ETENDU_ELEMENT2_FK                          */
/*==============================================================*/
create index ATTRIBUT_ETENDU_ELEMENT2_FK on mz_attribut_etendu_element (
id_attribut_etendu ASC
)
go

/*==============================================================*/
/* Table : mz_cmp_attribut_etendu_reference                     */
/*==============================================================*/
create table mz_cmp_attribut_etendu_reference (
   id_attribut_etendu   int                  not null,
   id_modele_version    int                  not null,
   id_composition       int                  not null,
   id_reference         int                  not null,
   l_valeur             TEXTE                not null,
   constraint PK_MZ_CMP_ATTRIBUT_ETENDU_REFE primary key (id_modele_version, id_composition, id_reference, id_attribut_etendu)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Association d''un attribut �tendu � une r�f�rence (ou une sous-r�f�rence)',
   'user', @CurrentUser, 'table', 'mz_cmp_attribut_etendu_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''attribut �tendu',
   'user', @CurrentUser, 'table', 'mz_cmp_attribut_etendu_reference', 'column', 'id_attribut_etendu'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_cmp_attribut_etendu_reference', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_attribut_etendu_reference', 'column', 'id_composition'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la r�f�rence s�lectionn�e dans cette composition',
   'user', @CurrentUser, 'table', 'mz_cmp_attribut_etendu_reference', 'column', 'id_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Valeur de l''attribut �tendu de la r�f�rence',
   'user', @CurrentUser, 'table', 'mz_cmp_attribut_etendu_reference', 'column', 'l_valeur'
go

/*==============================================================*/
/* Index : ATTRIBUT_ETENDU_REFERENCE_FK                         */
/*==============================================================*/
create index ATTRIBUT_ETENDU_REFERENCE_FK on mz_cmp_attribut_etendu_reference (
id_modele_version ASC
)
go

/*==============================================================*/
/* Table : mz_cmp_caracteristique_select                        */
/*==============================================================*/
create table mz_cmp_caracteristique_select (
   id_composition       int                  not null,
   id_modele_version    int                  not null,
   id_caracteristique   int                  not null,
   constraint PK_MZ_CMP_CARACTERISTIQUE_SELE primary key (id_modele_version, id_composition, id_caracteristique),
   constraint uk_mz_cmp_caracteristique_select1 unique (id_composition, id_caracteristique)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Les caract�ristiques s�lectionn�es de la composition (au moment o� la composition est enregistr�e)',
   'user', @CurrentUser, 'table', 'mz_cmp_caracteristique_select'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_caracteristique_select', 'column', 'id_composition'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_cmp_caracteristique_select', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la caract�ristique',
   'user', @CurrentUser, 'table', 'mz_cmp_caracteristique_select', 'column', 'id_caracteristique'
go

/*==============================================================*/
/* Index : COMPOSITION_CARACTERISTIQUE_SELECT_FK                */
/*==============================================================*/
create index COMPOSITION_CARACTERISTIQUE_SELECT_FK on mz_cmp_caracteristique_select (
id_modele_version ASC,
id_composition ASC
)
go

/*==============================================================*/
/* Index : COMPOSITION_CARACTERISTIQUE_SELECT2_FK               */
/*==============================================================*/
create index COMPOSITION_CARACTERISTIQUE_SELECT2_FK on mz_cmp_caracteristique_select (
id_modele_version ASC,
id_caracteristique ASC
)
go

/*==============================================================*/
/* Table : mz_cmp_composition                                   */
/*==============================================================*/
create table mz_cmp_composition (
   id_composition       int                  identity,
   id_modele_version    int                  not null,
   c_application_origine char(1)              not null,
   id_utilisateur_crea  int                  null,
   id_utilisateur_dmaj  int                  not null,
   d_dateheure_dmaj     datetime             not null,
   l_libelle_long       LIBELLE_LONG         not null,
   l_commentaire        TEXTE                null,
   constraint PK_MZ_CMP_COMPOSITION primary key nonclustered (id_composition),
   constraint uk_mz_cmp_composition1 unique (id_modele_version, id_composition)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Composition r�alis�e pour une version du mod�le',
   'user', @CurrentUser, 'table', 'mz_cmp_composition'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_cmp_composition', 'column', 'id_composition'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_cmp_composition', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code de l''application pour laquelle a �t� r�alis�e cette composition',
   'user', @CurrentUser, 'table', 'mz_cmp_composition', 'column', 'c_application_origine'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du dernier utilisateur ayant modifi� l''objet',
   'user', @CurrentUser, 'table', 'mz_cmp_composition', 'column', 'id_utilisateur_dmaj'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Date/heure de la derni�re modification de l''objet',
   'user', @CurrentUser, 'table', 'mz_cmp_composition', 'column', 'd_dateheure_dmaj'
go

/*==============================================================*/
/* Index : COMPOSITION_RATTACHEE_A_MODELE_FK                    */
/*==============================================================*/
create index COMPOSITION_RATTACHEE_A_MODELE_FK on mz_cmp_composition (
id_modele_version ASC
)
go

/*==============================================================*/
/* Index : COMPO_POUR_APPLICATION_FK                            */
/*==============================================================*/
create index COMPO_POUR_APPLICATION_FK on mz_cmp_composition (
c_application_origine ASC
)
go

/*==============================================================*/
/* Table : mz_cmp_element_select                                */
/*==============================================================*/
create table mz_cmp_element_select (
   id_modele_version    int                  not null,
   id_composition       int                  not null,
   id_element           int                  not null,
   n_quantite           smallint             not null,
   constraint PK_MZ_CMP_ELEMENT_SELECT primary key (id_modele_version, id_composition, id_element)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Les �l�ments autonomes de la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_element_select'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_cmp_element_select', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_element_select', 'column', 'id_composition'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''�l�ment suppl�mentaire ajout� ',
   'user', @CurrentUser, 'table', 'mz_cmp_element_select', 'column', 'id_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Quantit� d�finie pour cet �l�ment suppl�mentaire',
   'user', @CurrentUser, 'table', 'mz_cmp_element_select', 'column', 'n_quantite'
go

/*==============================================================*/
/* Index : COMPOSITION_ELEMENT_FK                               */
/*==============================================================*/
create index COMPOSITION_ELEMENT_FK on mz_cmp_element_select (
id_modele_version ASC,
id_composition ASC
)
go

/*==============================================================*/
/* Index : COMPOSITION_ELEMENT2_FK                              */
/*==============================================================*/
create index COMPOSITION_ELEMENT2_FK on mz_cmp_element_select (
id_element ASC
)
go

/*==============================================================*/
/* Table : mz_cmp_reference                                     */
/*==============================================================*/
create table mz_cmp_reference (
   id_composition_reference int                  identity,
   id_modele_version    int                  not null,
   id_composition       int                  not null,
   id_reference         int                  not null,
   n_quantite           smallint             not null,
   l_commentaire        TEXTE                null,
   constraint PK_MZ_CMP_REFERENCE primary key nonclustered (id_composition_reference),
   constraint uk_mz_cmp_reference1 unique (id_modele_version, id_composition, id_reference)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Une instance de r�f�rence quantifi�e pour la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_cmp_reference', 'column', 'id_composition_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_cmp_reference', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_reference', 'column', 'id_composition'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la r�f�rence s�lectionn�e dans cette composition',
   'user', @CurrentUser, 'table', 'mz_cmp_reference', 'column', 'id_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Quantit� d�finie pour la r�f�rence s�lectionn�e dans cette composition',
   'user', @CurrentUser, 'table', 'mz_cmp_reference', 'column', 'n_quantite'
go

/*==============================================================*/
/* Index : COMPOSITION_REFERENCE_SELECT_FK                      */
/*==============================================================*/
create index COMPOSITION_REFERENCE_SELECT_FK on mz_cmp_reference (
id_modele_version ASC,
id_composition ASC
)
go

/*==============================================================*/
/* Index : ITEM_RATTACHE_A_MODELE_FK                            */
/*==============================================================*/
create index ITEM_RATTACHE_A_MODELE_FK on mz_cmp_reference (
id_modele_version ASC,
id_reference ASC
)
go

/*==============================================================*/
/* Table : mz_cmp_reference_element                             */
/*==============================================================*/
create table mz_cmp_reference_element (
   id_reference         int                  not null,
   id_composition       int                  not null,
   id_modele_version    int                  not null,
   id_element           int                  not null,
   n_quantite           smallint             not null,
   in_selection         bit                  not null,
   constraint PK_MZ_CMP_REFERENCE_ELEMENT primary key (id_modele_version, id_composition, id_reference, id_element)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'La surd�finition des relations avec les �l�ments pour cette r�f�rence dans la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_reference_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la r�f�rence li�e � cette surd�finition',
   'user', @CurrentUser, 'table', 'mz_cmp_reference_element', 'column', 'id_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_reference_element', 'column', 'id_composition'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_cmp_reference_element', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''�l�ment cible de cette surd�finition',
   'user', @CurrentUser, 'table', 'mz_cmp_reference_element', 'column', 'id_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Quantit� de cette surd�finition',
   'user', @CurrentUser, 'table', 'mz_cmp_reference_element', 'column', 'n_quantite'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Indique si l''�l�ment est s�lectionn� ou d�s�lectionn�',
   'user', @CurrentUser, 'table', 'mz_cmp_reference_element', 'column', 'in_selection'
go

/*==============================================================*/
/* Index : COMPOSITION_ELEMENT_FK                               */
/*==============================================================*/
create index COMPOSITION_ELEMENT_FK on mz_cmp_reference_element (
id_modele_version ASC,
id_composition ASC,
id_reference ASC
)
go

/*==============================================================*/
/* Index : COMPOSITION_ELEMENT2_FK                              */
/*==============================================================*/
create index COMPOSITION_ELEMENT2_FK on mz_cmp_reference_element (
id_element ASC
)
go

/*==============================================================*/
/* Table : mz_cmp_regle_element                                 */
/*==============================================================*/
create table mz_cmp_regle_element (
   id_reference         int                  not null,
   id_composition       int                  not null,
   id_modele_version    int                  not null,
   id_regle             int                  not null,
   id_element           int                  not null,
   n_quantite           smallint             not null,
   in_selection         bit                  not null,
   constraint PK_MZ_CMP_REGLE_ELEMENT primary key (id_modele_version, id_composition, id_regle, id_element, id_reference)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'La surd�finition des relations avec les �l�ments provenant des r�gles li�es � cette r�f�rence (par h�ritage ou non) dans la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_regle_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la composition',
   'user', @CurrentUser, 'table', 'mz_cmp_regle_element', 'column', 'id_composition'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_cmp_regle_element', 'column', 'id_modele_version'
go

/*==============================================================*/
/* Index : CMP_REGLE_ELEMENT1_FK                                */
/*==============================================================*/
create index CMP_REGLE_ELEMENT1_FK on mz_cmp_regle_element (
id_modele_version ASC,
id_composition ASC,
id_reference ASC
)
go

/*==============================================================*/
/* Index : CMP_REGLE_ELEMENT2_FK                                */
/*==============================================================*/
create index CMP_REGLE_ELEMENT2_FK on mz_cmp_regle_element (
id_regle ASC
)
go

/*==============================================================*/
/* Index : CMP_REGLE_ELEMENT3_FK                                */
/*==============================================================*/
create index CMP_REGLE_ELEMENT3_FK on mz_cmp_regle_element (
id_element ASC
)
go

/*==============================================================*/
/* Table : mz_element                                           */
/*==============================================================*/
create table mz_element (
   id_element           int                  identity,
   id_metier            int                  not null,
   c_type_element       char(3)              not null,
   id_famille           int                  not null,
   c_element            varchar(10)          not null,
   in_actif             bit                  not null,
   l_nomenclature_fournisseur LIBELLE_COURT        null,
   l_libelle_long       LIBELLE_LONG         not null,
   constraint PK_MZ_ELEMENT primary key nonclustered (id_element)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'El�ment de composition pour le m�tier',
   'user', @CurrentUser, 'table', 'mz_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_element', 'column', 'id_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du m�tier',
   'user', @CurrentUser, 'table', 'mz_element', 'column', 'id_metier'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code indiquant le type d''�l�ment',
   'user', @CurrentUser, 'table', 'mz_element', 'column', 'c_type_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant de la famille de l''�l�ment',
   'user', @CurrentUser, 'table', 'mz_element', 'column', 'id_famille'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code de l''�l�ment de composition (unique pour le m�tier)',
   'user', @CurrentUser, 'table', 'mz_element', 'column', 'c_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Indicateur d''activit� (1 = actif ; 0 = inactif). Utilis� pour supprimer logiquement l''objet.',
   'user', @CurrentUser, 'table', 'mz_element', 'column', 'in_actif'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� du code de l''�l�ment de composition �tabli par le fournisseur (doit �tre unique ou NULL pour le m�tier)',
   'user', @CurrentUser, 'table', 'mz_element', 'column', 'l_nomenclature_fournisseur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� de l''�l�ment de composition',
   'user', @CurrentUser, 'table', 'mz_element', 'column', 'l_libelle_long'
go

/*==============================================================*/
/* Index : ELEMENT_RATTACHE_A_METIER_FK                         */
/*==============================================================*/
create index ELEMENT_RATTACHE_A_METIER_FK on mz_element (
id_metier ASC
)
go

/*==============================================================*/
/* Index : ELEMENT_RATTACHE_A_FAMILLE_FK                        */
/*==============================================================*/
create index ELEMENT_RATTACHE_A_FAMILLE_FK on mz_element (
id_famille ASC,
id_metier ASC
)
go

/*==============================================================*/
/* Table : mz_famille                                           */
/*==============================================================*/
create table mz_famille (
   id_famille           int                  identity,
   c_type_famille       char(3)              not null,
   c_type_element       char(3)              not null,
   id_metier            int                  not null,
   id_famille_parent    int                  null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_FAMILLE primary key nonclustered (id_famille),
   constraint uk_mz_famille1 unique (id_famille, id_metier)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Famille de l''�l�ment de composition',
   'user', @CurrentUser, 'table', 'mz_famille'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_famille', 'column', 'id_famille'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du m�tier pour la famille',
   'user', @CurrentUser, 'table', 'mz_famille', 'column', 'id_metier'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant de la famille parente de cette famille',
   'user', @CurrentUser, 'table', 'mz_famille', 'column', 'id_famille_parent'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� de la famille',
   'user', @CurrentUser, 'table', 'mz_famille', 'column', 'l_libelle'
go

/*==============================================================*/
/* Index : FAMILLEPARENT_FK                                     */
/*==============================================================*/
create index FAMILLEPARENT_FK on mz_famille (
id_famille_parent ASC,
id_metier ASC
)
go

/*==============================================================*/
/* Index : FAMILLE_EST_DU_TYPE_FK                               */
/*==============================================================*/
create index FAMILLE_EST_DU_TYPE_FK on mz_famille (
c_type_famille ASC,
c_type_element ASC
)
go

/*==============================================================*/
/* Index : FAMILLE_LIEE_A_METIER_FK                             */
/*==============================================================*/
create index FAMILLE_LIEE_A_METIER_FK on mz_famille (
id_metier ASC
)
go

/*==============================================================*/
/* Table : mz_famille_type                                      */
/*==============================================================*/
create table mz_famille_type (
   c_type_famille       char(3)              not null,
   c_type_element       char(3)              not null,
   l_libelle            LIBELLE_COURT        null,
   constraint PK_MZ_FAMILLE_TYPE primary key nonclustered (c_type_famille),
   constraint AK_UK_MZ_FAMILLE_TYPE_MZ_FAMIL unique (c_type_famille, c_type_element)
)
go

/*==============================================================*/
/* Index : TYPE_FAMILLE_DE_TYPE_ELEMENT_FK                      */
/*==============================================================*/
create index TYPE_FAMILLE_DE_TYPE_ELEMENT_FK on mz_famille_type (
c_type_element ASC
)
go

/*==============================================================*/
/* Table : mz_habilitation_utilisateur                          */
/*==============================================================*/
create table mz_habilitation_utilisateur (
   id_utilisateur       int                  not null,
   id_metier            int                  not null,
   c_role               varchar(10)          null,
   in_defaut            bit                  not null,
   constraint PK_MZ_HABILITATION_UTILISATEUR primary key (id_utilisateur, id_metier)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'R�le d''un utilisateur pour un m�tier',
   'user', @CurrentUser, 'table', 'mz_habilitation_utilisateur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''utilisateur',
   'user', @CurrentUser, 'table', 'mz_habilitation_utilisateur', 'column', 'id_utilisateur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du m�tier',
   'user', @CurrentUser, 'table', 'mz_habilitation_utilisateur', 'column', 'id_metier'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du r�le associ� � l''utilisateur pour le m�tier',
   'user', @CurrentUser, 'table', 'mz_habilitation_utilisateur', 'column', 'c_role'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Donn�e indiquant qu''il s''agit du m�tier par d�faut pour l''utilisateur',
   'user', @CurrentUser, 'table', 'mz_habilitation_utilisateur', 'column', 'in_defaut'
go

/*==============================================================*/
/* Index : HABILITATION_UTILISATEUR_FK                          */
/*==============================================================*/
create index HABILITATION_UTILISATEUR_FK on mz_habilitation_utilisateur (
id_utilisateur ASC
)
go

/*==============================================================*/
/* Index : HABILITATION_UTILISATEUR2_FK                         */
/*==============================================================*/
create index HABILITATION_UTILISATEUR2_FK on mz_habilitation_utilisateur (
c_role ASC
)
go

/*==============================================================*/
/* Index : HABILITATION_UTILISATEUR3_FK                         */
/*==============================================================*/
create index HABILITATION_UTILISATEUR3_FK on mz_habilitation_utilisateur (
id_metier ASC
)
go

/*==============================================================*/
/* Table : mz_langue                                            */
/*==============================================================*/
create table mz_langue (
   c_langue             char(3)              not null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_LANGUE primary key nonclustered (c_langue)
)
go

/*==============================================================*/
/* Table : mz_mdl_attribut_etendu_reference                     */
/*==============================================================*/
create table mz_mdl_attribut_etendu_reference (
   id_reference         int                  not null,
   id_attribut_etendu   int                  not null,
   id_modele_version    int                  not null,
   l_valeur             TEXTE                not null,
   constraint PK_MZ_MDL_ATTRIBUT_ETENDU_REFE primary key (id_modele_version, id_reference, id_attribut_etendu)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Association d''un attribut �tendu � une r�f�rence (ou une sous-r�f�rence)',
   'user', @CurrentUser, 'table', 'mz_mdl_attribut_etendu_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la r�f�rence',
   'user', @CurrentUser, 'table', 'mz_mdl_attribut_etendu_reference', 'column', 'id_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''attribut �tendu',
   'user', @CurrentUser, 'table', 'mz_mdl_attribut_etendu_reference', 'column', 'id_attribut_etendu'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_attribut_etendu_reference', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Valeur de l''attribut �tendu de la r�f�rence',
   'user', @CurrentUser, 'table', 'mz_mdl_attribut_etendu_reference', 'column', 'l_valeur'
go

/*==============================================================*/
/* Index : ATTRIBUT_ETENDU_REFERENCE_FK                         */
/*==============================================================*/
create index ATTRIBUT_ETENDU_REFERENCE_FK on mz_mdl_attribut_etendu_reference (
id_modele_version ASC,
id_reference ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_caracteristique                               */
/*==============================================================*/
create table mz_mdl_caracteristique (
   id_caracteristique   int                  identity,
   id_modele_version    int                  not null,
   id_caracteristique_parent int                  null,
   n_rang               smallint             not null,
   l_libelle            LIBELLE_COURT        not null,
   l_commentaire        TEXTE                null,
   constraint PK_MZ_MDL_CARACTERISTIQUE primary key nonclustered (id_caracteristique),
   constraint uk_mz_mdl_caracteristique1 unique (id_modele_version, id_caracteristique)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Caract�ristique du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_caracteristique'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_mdl_caracteristique', 'column', 'id_caracteristique'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_caracteristique', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la caract�ristique parente de cette caract�ristique (vaut NULL si la caract�ristique est la racine du mod�le)',
   'user', @CurrentUser, 'table', 'mz_mdl_caracteristique', 'column', 'id_caracteristique_parent'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Num�ro de rang de la caract�ristique (permet d''ordonner les caract�ristiques enfantes d''un m�me noeud)',
   'user', @CurrentUser, 'table', 'mz_mdl_caracteristique', 'column', 'n_rang'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� de la caract�ristique',
   'user', @CurrentUser, 'table', 'mz_mdl_caracteristique', 'column', 'l_libelle'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Commentaire sur la caract�ristique',
   'user', @CurrentUser, 'table', 'mz_mdl_caracteristique', 'column', 'l_commentaire'
go

/*==============================================================*/
/* Index : CARACTERISTIQUE_PARENT_FK                            */
/*==============================================================*/
create index CARACTERISTIQUE_PARENT_FK on mz_mdl_caracteristique (
id_modele_version ASC,
id_caracteristique_parent ASC
)
go

/*==============================================================*/
/* Index : MODELE_COMPORTE_CARACTERISTIQUE_FK                   */
/*==============================================================*/
create index MODELE_COMPORTE_CARACTERISTIQUE_FK on mz_mdl_caracteristique (
id_modele_version ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_carateristique_reference                      */
/*==============================================================*/
create table mz_mdl_carateristique_reference (
   id_caracteristique   int                  not null,
   id_reference         int                  not null,
   id_modele_version    int                  not null,
   constraint PK_MZ_MDL_CARATERISTIQUE_REFER primary key (id_caracteristique, id_reference, id_modele_version)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Relation entre une r�f�rence et une caract�ristique',
   'user', @CurrentUser, 'table', 'mz_mdl_carateristique_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto d''une carac�ristique du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_carateristique_reference', 'column', 'id_caracteristique'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto d''une r�f�rence du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_carateristique_reference', 'column', 'id_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_carateristique_reference', 'column', 'id_modele_version'
go

/*==============================================================*/
/* Index : CARATERISTIQUE_ITEM_FK                               */
/*==============================================================*/
create index CARATERISTIQUE_ITEM_FK on mz_mdl_carateristique_reference (
id_modele_version ASC,
id_caracteristique ASC
)
go

/*==============================================================*/
/* Index : CARATERISTIQUE_ITEM2_FK                              */
/*==============================================================*/
create index CARATERISTIQUE_ITEM2_FK on mz_mdl_carateristique_reference (
id_modele_version ASC,
id_reference ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_lien_caracteristique                          */
/*==============================================================*/
create table mz_mdl_lien_caracteristique (
   id_lien_commun       int                  not null,
   id_caracteristique   int                  not null,
   id_modele_version    int                  null,
   constraint PK_MZ_MODELE_COMPOSITION_LIEN_CARAC primary key nonclustered (id_lien_commun)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Lien vers une caract�ristique (utilisation dans les r�gles et les messages)',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_caracteristique'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du lien commun',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_caracteristique', 'column', 'id_lien_commun'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la caract�ristique',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_caracteristique', 'column', 'id_caracteristique'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_caracteristique', 'column', 'id_modele_version'
go

/*======================================================================*/
/* Index : LIEN_DE_TYPE_CARACTERISTIQUE_COMPORTE_UNE_CARACTERISTIQUE_FK */
/*======================================================================*/
create index LIEN_DE_TYPE_CARACTERISTIQUE_COMPORTE_UNE_CARACTERISTIQUE_FK on mz_mdl_lien_caracteristique (
id_modele_version ASC,
id_caracteristique ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_lien_commun                                   */
/*==============================================================*/
create table mz_mdl_lien_commun (
   id_lien_commun       int                  identity,
   c_type_lien          char(1)              not null,
   id_modele_version    int                  not null,
   constraint PK_MZ_MDL_LIEN_COMMUN primary key nonclustered (id_lien_commun),
   constraint uk_mz_mdl_lien_commun1 unique (id_lien_commun, id_modele_version)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Table permettant de factoriser les noeuds caract�ristique, r�f�rence, �l�ment en "lien commun" (utilisation dans les r�gles et les messages)',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_commun'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_commun', 'column', 'id_lien_commun'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du type de lien commun',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_commun', 'column', 'c_type_lien'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_commun', 'column', 'id_modele_version'
go

/*==============================================================*/
/* Index : ASSOCIATION_39_FK                                    */
/*==============================================================*/
create index ASSOCIATION_39_FK on mz_mdl_lien_commun (
c_type_lien ASC
)
go

/*==============================================================*/
/* Index : LIEN_MODELE_VERSION_FK                               */
/*==============================================================*/
create index LIEN_MODELE_VERSION_FK on mz_mdl_lien_commun (
id_modele_version ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_lien_element                                  */
/*==============================================================*/
create table mz_mdl_lien_element (
   id_lien_commun       int                  not null,
   id_element           int                  not null,
   id_modele_version    int                  null,
   constraint PK_MZ_MODELE_COMPOSITION_LIEN_ELEM primary key nonclustered (id_lien_commun)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Lien vers un �l�ment (utilisation dans les r�gles et les messages)',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du lien commun',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_element', 'column', 'id_lien_commun'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''�l�ment de composition',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_element', 'column', 'id_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_element', 'column', 'id_modele_version'
go

/*==============================================================*/
/* Index : LIEN_DE_TYPE_ELEMENT_COMPORTE_UNE_ELEMENT_FK         */
/*==============================================================*/
create index LIEN_DE_TYPE_ELEMENT_COMPORTE_UNE_ELEMENT_FK on mz_mdl_lien_element (
id_element ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_lien_reference                                */
/*==============================================================*/
create table mz_mdl_lien_reference (
   id_lien_commun       int                  not null,
   id_reference         int                  not null,
   id_modele_version    int                  null,
   constraint PK_MZ_MODELE_COMPOSITION_LIEN_REF primary key nonclustered (id_lien_commun)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Lien vers une r�f�rence (utilisation dans les r�gles et les messages)',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du lien commun',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_reference', 'column', 'id_lien_commun'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la r�f�rence',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_reference', 'column', 'id_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_lien_reference', 'column', 'id_modele_version'
go

/*==============================================================*/
/* Index : LIEN_DE_TYPE_REFERENCE_COMPORTE_UNE_REFERENCE_FK     */
/*==============================================================*/
create index LIEN_DE_TYPE_REFERENCE_COMPORTE_UNE_REFERENCE_FK on mz_mdl_lien_reference (
id_modele_version ASC,
id_reference ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_message                                       */
/*==============================================================*/
create table mz_mdl_message (
   id_message           int                  identity,
   id_source_lien_commun int                  not null,
   id_modele_version    int                  not null,
   c_type_lien          char(1)              not null,
   l_libelle_long       LIBELLE_LONG         not null,
   n_priorite           smallint             not null,
   constraint PK_MZ_MDL_MESSAGE primary key nonclustered (id_message),
   constraint uk_mz_mdl_message1 unique (id_modele_version, id_message, c_type_lien)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'D�finition des messages pour le mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_message'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_mdl_message', 'column', 'id_message'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du lien commun source de ce message',
   'user', @CurrentUser, 'table', 'mz_mdl_message', 'column', 'id_source_lien_commun'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_message', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du type de lien commun source de ce message',
   'user', @CurrentUser, 'table', 'mz_mdl_message', 'column', 'c_type_lien'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Texte du message',
   'user', @CurrentUser, 'table', 'mz_mdl_message', 'column', 'l_libelle_long'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Priorit� de ce message
   Valeur pr�d�finie : information (=4), avertissement (=5), alerte (=6)
   Si la priorit� est n�gative, alors il s''agit d''une annulation de message d''information (=-4), d''avertissement (=-5), d''alerte (=-6)',
   'user', @CurrentUser, 'table', 'mz_mdl_message', 'column', 'n_priorite'
go

/*==============================================================*/
/* Index : MDL_MODELE_COMPORTE_MESSAGE_FK                       */
/*==============================================================*/
create index MDL_MODELE_COMPORTE_MESSAGE_FK on mz_mdl_message (
id_modele_version ASC
)
go

/*==============================================================*/
/* Index : MDL_TYPAGE_MESSAGE_FK                                */
/*==============================================================*/
create index MDL_TYPAGE_MESSAGE_FK on mz_mdl_message (
c_type_lien ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_modele                                        */
/*==============================================================*/
create table mz_mdl_modele (
   id_modele            int                  identity,
   id_metier            int                  not null,
   in_actif             bit                  not null,
   id_utilisateur_crea  int                  not null,
   d_dateheure_crea     datetime             not null,
   constraint PK_MZ_MDL_MODELE primary key nonclustered (id_modele)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Table contenant les diff�rents mod�les pour le m�tier',
   'user', @CurrentUser, 'table', 'mz_mdl_modele'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_mdl_modele', 'column', 'id_modele'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Indicateur d''activit� (1 = actif ; 0 = inactif). Utilis� pour supprimer logiquement l''objet',
   'user', @CurrentUser, 'table', 'mz_mdl_modele', 'column', 'in_actif'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''utilisateur cr�ateur de l''objet',
   'user', @CurrentUser, 'table', 'mz_mdl_modele', 'column', 'id_utilisateur_crea'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Date/heure de cr�ation de l''objet',
   'user', @CurrentUser, 'table', 'mz_mdl_modele', 'column', 'd_dateheure_crea'
go

/*==============================================================*/
/* Table : mz_mdl_modele_version                                */
/*==============================================================*/
create table mz_mdl_modele_version (
   id_modele_version    int                  identity,
   id_modele            int                  not null,
   id_utilisateur_dmaj  int                  not null,
   d_dateheure_dmaj     datetime             not null,
   in_actif             bit                  not null,
   constraint PK_MZ_MDL_MODELE_VERSION primary key nonclustered (id_modele_version)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Objet de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_mdl_modele_version', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_modele_version', 'column', 'id_modele'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Date/heure de la derni�re modification de l''objet',
   'user', @CurrentUser, 'table', 'mz_mdl_modele_version', 'column', 'd_dateheure_dmaj'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Indicateur d''activit� (1 = actif ; 0 = inactif). Utilis� pour supprimer logiquement l''objet',
   'user', @CurrentUser, 'table', 'mz_mdl_modele_version', 'column', 'in_actif'
go

/*==============================================================*/
/* Index : MODELE_EST_VERSIONNE_FK                              */
/*==============================================================*/
create index MODELE_EST_VERSIONNE_FK on mz_mdl_modele_version (
id_modele ASC
)
go

/*==============================================================*/
/* Index : HORODATE_FK                                          */
/*==============================================================*/
create index HORODATE_FK on mz_mdl_modele_version (
id_utilisateur_dmaj ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_reference                                     */
/*==============================================================*/
create table mz_mdl_reference (
   id_reference         int                  identity,
   id_modele_version    int                  not null,
   id_sous_modele       int                  null,
   n_rang               int                  not null,
   l_libelle_long       LIBELLE_LONG         not null,
   l_commentaire        varchar(2000)        null,
   in_sous_reference    bit                  not null,
   in_ssref_maj_reference bit                  null,
   constraint PK_MZ_MDL_REFERENCE primary key nonclustered (id_reference),
   constraint uk_mz_mdl_reference1 unique (id_modele_version, id_reference)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'R�f�rence du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_mdl_reference', 'column', 'id_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_reference', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto permettant de faire le lien entre cette sous-r�f�rence et le sous-mod�le pour lequel elle a �t� cr��e (utilis� pour l''import/export, seule la r�f�rence ayant les champs id_reference_parent et id_sous_modele � NULL est � utiliser c�t� applicatif dans le mod�lisateur et le compositeur).
   Ce champ est li� au champ id_reference_parent',
   'user', @CurrentUser, 'table', 'mz_mdl_reference', 'column', 'id_sous_modele'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Num�ro de rang de la r�f�rence (permet d''ordonner l''affichage des r�f�rences)',
   'user', @CurrentUser, 'table', 'mz_mdl_reference', 'column', 'n_rang'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Indicateur "Sous-r�f�rence". Ce bool�en indique si cette r�f�rence est li�e � une sous-r�f�rence',
   'user', @CurrentUser, 'table', 'mz_mdl_reference', 'column', 'in_sous_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Donn�e permettant d''indiquer que la r�f�rence courante, li�e � une ou plusieurs sous-r�f�rences, a �t� mise � jour manuellement.
   Ce champ vaut NULL si la r�f�rence n''est pas li�e � une sous-r�f�rence',
   'user', @CurrentUser, 'table', 'mz_mdl_reference', 'column', 'in_ssref_maj_reference'
go

/*==============================================================*/
/* Index : MDL_MODELE_COMPORTE_REFERENCE_FK                     */
/*==============================================================*/
create index MDL_MODELE_COMPORTE_REFERENCE_FK on mz_mdl_reference (
id_modele_version ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_reference_element                             */
/*==============================================================*/
create table mz_mdl_reference_element (
   id_element           int                  not null,
   id_reference         int                  not null,
   id_modele_version    int                  not null,
   n_quantite           smallint             not null,
   n_rang               smallint             null,
   constraint PK_MZ_MDL_REFERENCE_ELEMENT primary key (id_element, id_reference, id_modele_version)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Association d''un �l�ment � une r�f�rence (ou une sous-r�f�rence)',
   'user', @CurrentUser, 'table', 'mz_mdl_reference_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto d''un �l�ment de composition',
   'user', @CurrentUser, 'table', 'mz_mdl_reference_element', 'column', 'id_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto d''une r�f�rence du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_reference_element', 'column', 'id_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_reference_element', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Quantit� du nombre d''�l�ments pour la r�f�rence',
   'user', @CurrentUser, 'table', 'mz_mdl_reference_element', 'column', 'n_quantite'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Num�ro de rang de l''�l�ment dans la r�f�rence (permet d''ordonner les �l�ments dans la r�f�rence, concerne uniquement les �l�ments ne provenant pas de r�gle)',
   'user', @CurrentUser, 'table', 'mz_mdl_reference_element', 'column', 'n_rang'
go

/*==============================================================*/
/* Index : REFERENCE_ELEMENT_FK                                 */
/*==============================================================*/
create index REFERENCE_ELEMENT_FK on mz_mdl_reference_element (
id_element ASC
)
go

/*==============================================================*/
/* Index : REFERENCE_ELEMENT2_FK                                */
/*==============================================================*/
create index REFERENCE_ELEMENT2_FK on mz_mdl_reference_element (
id_modele_version ASC,
id_reference ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_reference_sous_modele                         */
/*==============================================================*/
create table mz_mdl_reference_sous_modele (
   id_sous_modele       int                  identity,
   id_modele_version    int                  not null,
   l_libelle_long       LIBELLE_LONG         not null,
   constraint PK_MZ_MDL_REFERENCE_SOUS_MODEL primary key nonclustered (id_sous_modele),
   constraint uk_mz_mdl_reference_sous_modele1 unique (id_sous_modele, id_modele_version)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Sous mod�le de r�f�rence.
   Cette table contient le libell� du sous-mod�le pour lequel des sous-r�f�rences ont �t� cr��es
   Cette table n''est utilis�e que pour le syst�me d''import/export des r�f�rences',
   'user', @CurrentUser, 'table', 'mz_mdl_reference_sous_modele'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_mdl_reference_sous_modele', 'column', 'id_sous_modele'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_reference_sous_modele', 'column', 'id_modele_version'
go

/*==============================================================*/
/* Index : MDL_MODELE_COMPORTE_REFERENCE_FK                     */
/*==============================================================*/
create index MDL_MODELE_COMPORTE_REFERENCE_FK on mz_mdl_reference_sous_modele (
id_modele_version ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_regle                                         */
/*==============================================================*/
create table mz_mdl_regle (
   id_regle             int                  identity,
   id_modele_version    int                  not null,
   id_source_lien_commun int                  not null,
   id_cible_lien_commun int                  not null,
   c_type_regle         char(1)              not null,
   n_quantite           smallint             not null,
   n_priorite           smallint             not null,
   constraint PK_MZ_MDL_REGLE primary key nonclustered (id_regle)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'D�finition des r�gles pour le mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_regle'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_mdl_regle', 'column', 'id_regle'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_regle', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du lien commun source de cette r�gle (doit respecter le type de r�gle �tabli)',
   'user', @CurrentUser, 'table', 'mz_mdl_regle', 'column', 'id_source_lien_commun'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du lien commun cible de cette r�gle (doit respecter le type de r�gle �tabli)',
   'user', @CurrentUser, 'table', 'mz_mdl_regle', 'column', 'id_cible_lien_commun'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du type de la r�gle',
   'user', @CurrentUser, 'table', 'mz_mdl_regle', 'column', 'c_type_regle'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Quantit� �tablie pour cette r�gle',
   'user', @CurrentUser, 'table', 'mz_mdl_regle', 'column', 'n_quantite'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Priorit� de cette r�gle
   Valeur pr�d�finie : interdite (=1), conseill�e (=2), indispensable (=3)
   Si la valeur est n�gative, alors il s''agit d''une annulation de r�gle interdite (=-1), conseill�e (=-2), indispensable (=-3)
   ',
   'user', @CurrentUser, 'table', 'mz_mdl_regle', 'column', 'n_priorite'
go

/*==============================================================*/
/* Index : REGLE_EST_DU_TYPE_FK                                 */
/*==============================================================*/
create index REGLE_EST_DU_TYPE_FK on mz_mdl_regle (
c_type_regle ASC
)
go

/*==============================================================*/
/* Index : MDL_MODELE_COMPORTE_REGLE_FK                         */
/*==============================================================*/
create index MDL_MODELE_COMPORTE_REGLE_FK on mz_mdl_regle (
id_modele_version ASC
)
go

/*==============================================================*/
/* Index : SOURCE_FK                                            */
/*==============================================================*/
create index SOURCE_FK on mz_mdl_regle (
id_source_lien_commun ASC,
id_modele_version ASC
)
go

/*==============================================================*/
/* Index : ASSOCIATION_42_FK                                    */
/*==============================================================*/
create index ASSOCIATION_42_FK on mz_mdl_regle (
id_cible_lien_commun ASC,
id_modele_version ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_sousreference_reference                       */
/*==============================================================*/
create table mz_mdl_sousreference_reference (
   id_reference         int                  not null,
   id_modele_version    int                  not null,
   id_sousreference     int                  not null,
   constraint PK_MZ_MDL_SOUSREFERENCE_REFERE primary key (id_modele_version, id_reference, id_sousreference)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Une r�f�rence peut �ventuellement se composer d''une ou plusieurs sous-r�f�rences
   La r�f�rence est alors li�es aux �l�ments des sous-r�f�rences et aux attributs �tendus des sous-r�f�rences
   ',
   'user', @CurrentUser, 'table', 'mz_mdl_sousreference_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de la r�f�rence li�e au(x) sous-r�f�rence(s)',
   'user', @CurrentUser, 'table', 'mz_mdl_sousreference_reference', 'column', 'id_reference'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de la version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_sousreference_reference', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de la sous-r�f�rence li�e au(x) r�f�rence(s)',
   'user', @CurrentUser, 'table', 'mz_mdl_sousreference_reference', 'column', 'id_sousreference'
go

/*==============================================================*/
/* Index : MDL_SOUSREFERENCE_REFERENCE_FK                       */
/*==============================================================*/
create index MDL_SOUSREFERENCE_REFERENCE_FK on mz_mdl_sousreference_reference (
id_modele_version ASC,
id_reference ASC
)
go

/*==============================================================*/
/* Index : MDL_SOUSREFERENCE_REFERENCE2_FK                      */
/*==============================================================*/
create index MDL_SOUSREFERENCE_REFERENCE2_FK on mz_mdl_sousreference_reference (
id_modele_version ASC,
id_sousreference ASC
)
go

/*==============================================================*/
/* Table : mz_mdl_type_lien                                     */
/*==============================================================*/
create table mz_mdl_type_lien (
   c_type_lien          char(1)              not null,
   l_libelle            varchar(50)          not null,
   constraint PK_MZ_MDL_TYPE_LIEN primary key nonclustered (c_type_lien)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Type de lien commun
   Valeurs pr�d�finies :
    - C : Lien sur caract�ristique
    - R : Lien sur r�f�rence
    - E : Lien sur �l�ment',
   'user', @CurrentUser, 'table', 'mz_mdl_type_lien'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du type de lien commun',
   'user', @CurrentUser, 'table', 'mz_mdl_type_lien', 'column', 'c_type_lien'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� du type de lien commun',
   'user', @CurrentUser, 'table', 'mz_mdl_type_lien', 'column', 'l_libelle'
go

/*==============================================================*/
/* Table : mz_mdl_type_regle                                    */
/*==============================================================*/
create table mz_mdl_type_regle (
   c_source_type_lien   char(1)              not null,
   c_cible_type_lien    char(1)              not null,
   c_type_regle         char(1)              not null,
   constraint PK_MZ_MDL_TYPE_REGLE primary key nonclustered (c_type_regle),
   constraint uk_mz_mdl_type_regle1 unique (c_source_type_lien, c_cible_type_lien, c_type_regle)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Type de r�gle (d�finition type noeud source vers type noeud cible)
   Valeurs pr�d�finies :
    - ''M'' : caract�ristique vers caract�ristique
    - ''O'' : caract�ristique vers r�f�rence
    - ''Z'' : caract�ristique vers �l�ment
    - ''A'' : r�f�rence vers caract�ristique
    - ''R'' : r�f�rence vers r�f�rence
    - ''T'' : r�f�rence vers �l�ment',
   'user', @CurrentUser, 'table', 'mz_mdl_type_regle'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code de type de lien source de la r�gle (caract�ristique ou r�f�rence)',
   'user', @CurrentUser, 'table', 'mz_mdl_type_regle', 'column', 'c_source_type_lien'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code de type de lien cible de la r�gle (caract�ristique ou r�f�rence ou �l�ment)',
   'user', @CurrentUser, 'table', 'mz_mdl_type_regle', 'column', 'c_cible_type_lien'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du type de r�gle',
   'user', @CurrentUser, 'table', 'mz_mdl_type_regle', 'column', 'c_type_regle'
go

/*==============================================================*/
/* Table : mz_mdl_version                                       */
/*==============================================================*/
create table mz_mdl_version (
   n_version            smallint             not null,
   id_modele            int                  not null,
   id_modele_version    int                  not null,
   constraint PK_MZ_MDL_VERSION primary key nonclustered (n_version, id_modele)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Num�ro de version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Num�ro de version du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_version', 'column', 'n_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du mod�le',
   'user', @CurrentUser, 'table', 'mz_mdl_version', 'column', 'id_modele'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''objet "version du mod�le" (table mz_mdl_modele_version)',
   'user', @CurrentUser, 'table', 'mz_mdl_version', 'column', 'id_modele_version'
go

/*==============================================================*/
/* Table : mz_metier                                            */
/*==============================================================*/
create table mz_metier (
   id_metier            int                  identity,
   c_metier             varchar(10)          not null,
   l_libelle            LIBELLE_COURT        not null,
   in_actif             bit                  not null,
   constraint PK_MZ_METIER primary key nonclustered (id_metier)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'M�tier de l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_metier'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du m�tier',
   'user', @CurrentUser, 'table', 'mz_metier', 'column', 'c_metier'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� du m�tier',
   'user', @CurrentUser, 'table', 'mz_metier', 'column', 'l_libelle'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Indicateur d''activit� (1 = actif ; 0 = inactif). Utilis� pour supprimer logiquement l''objet.',
   'user', @CurrentUser, 'table', 'mz_metier', 'column', 'in_actif'
go

/*==============================================================*/
/* Table : mz_metier_lien_pegaz                                 */
/*==============================================================*/
create table mz_metier_lien_pegaz (
   id_metier_pegaz      int                  not null,
   id_metier            int                  not null,
   constraint PK_MZ_METIER_LIEN_PEGAZ primary key (id_metier_pegaz, id_metier)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Rapprochement du m�tier Mozarto avec le m�tier PEGAZ
   Info : Cardinalit� volontairement d�finies en (0,n) pour d�coupler les 2 tables associ�es, et avoir une table de lien',
   'user', @CurrentUser, 'table', 'mz_metier_lien_pegaz'
go

/*==============================================================*/
/* Index : METIER_LIEN_PEGAZ_FK                                 */
/*==============================================================*/
create index METIER_LIEN_PEGAZ_FK on mz_metier_lien_pegaz (
id_metier_pegaz ASC
)
go

/*==============================================================*/
/* Index : METIER_LIEN_PEGAZ2_FK                                */
/*==============================================================*/
create index METIER_LIEN_PEGAZ2_FK on mz_metier_lien_pegaz (
id_metier ASC
)
go

/*==============================================================*/
/* Table : mz_preference_graphique                              */
/*==============================================================*/
create table mz_preference_graphique (
   c_preference_graphique varchar(10)          not null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_PREFERENCE_GRAPHIQUE primary key nonclustered (c_preference_graphique)
)
go

/*==============================================================*/
/* Table : mz_preference_graphique_utilisateur                  */
/*==============================================================*/
create table mz_preference_graphique_utilisateur (
   id_preference_utilisateur int                  not null,
   c_preference_graphique varchar(10)          not null,
   l_valeur_pref        LIBELLE_LONG         not null,
   constraint PK_MZ_PREFERENCE_GRAPHIQUE_UTI primary key (c_preference_graphique, id_preference_utilisateur)
)
go

/*==============================================================*/
/* Index : PREFERENCE_GRAPHIQUE_UTILISATEUR_FK                  */
/*==============================================================*/
create index PREFERENCE_GRAPHIQUE_UTILISATEUR_FK on mz_preference_graphique_utilisateur (
c_preference_graphique ASC
)
go

/*==============================================================*/
/* Index : PREFERENCE_GRAPHIQUE_UTILISATEUR2_FK                 */
/*==============================================================*/
create index PREFERENCE_GRAPHIQUE_UTILISATEUR2_FK on mz_preference_graphique_utilisateur (
id_preference_utilisateur ASC
)
go

/*==============================================================*/
/* Table : mz_preference_utilisateur                            */
/*==============================================================*/
create table mz_preference_utilisateur (
   id_preference_utilisateur int                  identity,
   id_utilisateur       int                  not null,
   c_langue             char(3)              null,
   constraint PK_MZ_PREFERENCE_UTILISATEUR primary key nonclustered (id_preference_utilisateur)
)
go

/*==============================================================*/
/* Index : UTILISATEUR_A_POUR_PREFERENCE_FK                     */
/*==============================================================*/
create index UTILISATEUR_A_POUR_PREFERENCE_FK on mz_preference_utilisateur (
id_utilisateur ASC
)
go

/*==============================================================*/
/* Index : LANGUE_PAR_DEFAUT_FK                                 */
/*==============================================================*/
create index LANGUE_PAR_DEFAUT_FK on mz_preference_utilisateur (
c_langue ASC
)
go

/*==============================================================*/
/* Table : mz_role_utilisateur                                  */
/*==============================================================*/
create table mz_role_utilisateur (
   c_role               varchar(10)          not null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_ROLE_UTILISATEUR primary key nonclustered (c_role)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'R�le utilisateur
   Liste pr�d�finie: 
   - ADMIN-GEN: Administrateur g�n�ral
   - ADMIN-MET: Administrateur m�tier
   - UTIL-MET: Utilisateur m�tier
   - INVIT-MET: Invit� m�tier',
   'user', @CurrentUser, 'table', 'mz_role_utilisateur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code identifiant le r�le utilisateur',
   'user', @CurrentUser, 'table', 'mz_role_utilisateur', 'column', 'c_role'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� du r�le de l''utilisateur',
   'user', @CurrentUser, 'table', 'mz_role_utilisateur', 'column', 'l_libelle'
go

/*==============================================================*/
/* Table : mz_sas_import                                        */
/*==============================================================*/
create table mz_sas_import (
   id_import            int                  identity,
   id_modele_version    int                  null,
   c_type_import        char(3)              not null,
   c_etat_import        char(3)              not null,
   id_metier            int                  not null,
   id_utilisateur_crea  int                  not null,
   d_dateheure_crea     datetime             not null,
   constraint PK_MZ_SAS_IMPORT primary key nonclustered (id_import)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Table contenant les imports
   ',
   'user', @CurrentUser, 'table', 'mz_sas_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''import dans Mozarto',
   'user', @CurrentUser, 'table', 'mz_sas_import', 'column', 'id_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto du mod�le pour lequel l''import est fait',
   'user', @CurrentUser, 'table', 'mz_sas_import', 'column', 'id_modele_version'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code identifiant le type d''import',
   'user', @CurrentUser, 'table', 'mz_sas_import', 'column', 'c_type_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code de l''�tat indiquant l''avancement de l''import',
   'user', @CurrentUser, 'table', 'mz_sas_import', 'column', 'c_etat_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''utilisateur qui a ordonn� l''import',
   'user', @CurrentUser, 'table', 'mz_sas_import', 'column', 'id_utilisateur_crea'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Date/heure de l''ordre d''import',
   'user', @CurrentUser, 'table', 'mz_sas_import', 'column', 'd_dateheure_crea'
go

/*==============================================================*/
/* Index : IMPORT_SUR_MODELE_FK                                 */
/*==============================================================*/
create index IMPORT_SUR_MODELE_FK on mz_sas_import (
id_modele_version ASC
)
go

/*==============================================================*/
/* Index : IMPORT_A_POUR_TYPE_FK                                */
/*==============================================================*/
create index IMPORT_A_POUR_TYPE_FK on mz_sas_import (
c_type_import ASC
)
go

/*==============================================================*/
/* Index : ETAT_D_AVANCEMENT_DE_L_IMPORT_FK                     */
/*==============================================================*/
create index ETAT_D_AVANCEMENT_DE_L_IMPORT_FK on mz_sas_import (
c_etat_import ASC
)
go

/*==============================================================*/
/* Index : IMPORT_SUR_METIER_FK                                 */
/*==============================================================*/
create index IMPORT_SUR_METIER_FK on mz_sas_import (
id_metier ASC
)
go

/*==============================================================*/
/* Table : mz_sas_import_element                                */
/*==============================================================*/
create table mz_sas_import_element (
   id_element_import    int                  identity,
   c_type_element_import char(3)              not null,
   id_import            int                  not null,
   n_ligne              int                  not null,
   n_colonne            int                  not null,
   l_valeur             varchar(8000)        not null,
   constraint PK_MZ_SAS_IMPORT_ELEMENT primary key nonclustered (id_element_import)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'El�ment d''import (donn�e constituant l''import)
   On peut consid�rer qu''un �l�ment d''import repr�sente une cellule de fichier Excel import�',
   'user', @CurrentUser, 'table', 'mz_sas_import_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet dans Mozarto',
   'user', @CurrentUser, 'table', 'mz_sas_import_element', 'column', 'id_element_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du type de l''�l�ment import�',
   'user', @CurrentUser, 'table', 'mz_sas_import_element', 'column', 'c_type_element_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant de l''import pour lequel cet �l�ment est import�',
   'user', @CurrentUser, 'table', 'mz_sas_import_element', 'column', 'id_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Num�ro de la ligne du fichier d''import',
   'user', @CurrentUser, 'table', 'mz_sas_import_element', 'column', 'n_ligne'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Num�ro de la colonne du fichier d''import',
   'user', @CurrentUser, 'table', 'mz_sas_import_element', 'column', 'n_colonne'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Valeur de l''�l�ment import� (contenu de la cellule)',
   'user', @CurrentUser, 'table', 'mz_sas_import_element', 'column', 'l_valeur'
go

/*==============================================================*/
/* Index : ASSOCIATION_50_FK                                    */
/*==============================================================*/
create index ASSOCIATION_50_FK on mz_sas_import_element (
id_import ASC
)
go

/*==============================================================*/
/* Index : ELEMENT_D_IMPORT_A_POUR_TYPE_FK                      */
/*==============================================================*/
create index ELEMENT_D_IMPORT_A_POUR_TYPE_FK on mz_sas_import_element (
c_type_element_import ASC
)
go

/*==============================================================*/
/* Table : mz_sas_import_element_erreur                         */
/*==============================================================*/
create table mz_sas_import_element_erreur (
   id_erreur_import     int                  identity,
   id_element_import    int                  not null,
   l_libelle_long       varchar(3000)        not null,
   constraint PK_MZ_SAS_IMPORT_ELEMENT_ERREU primary key nonclustered (id_erreur_import)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Table visant les �l�ment d''import qui sont en erreur',
   'user', @CurrentUser, 'table', 'mz_sas_import_element_erreur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de cet objet dans Mozarto',
   'user', @CurrentUser, 'table', 'mz_sas_import_element_erreur', 'column', 'id_erreur_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant Mozarto de l''�l�ment d''import cibl� par cette erreur',
   'user', @CurrentUser, 'table', 'mz_sas_import_element_erreur', 'column', 'id_element_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� de l''erreur visant l''�l�ment d''import',
   'user', @CurrentUser, 'table', 'mz_sas_import_element_erreur', 'column', 'l_libelle_long'
go

/*==============================================================*/
/* Index : ERREUR_TROUVEE_SUR_ELEMENT_D_IMPORT_FK               */
/*==============================================================*/
create index ERREUR_TROUVEE_SUR_ELEMENT_D_IMPORT_FK on mz_sas_import_element_erreur (
id_element_import ASC
)
go

/*==============================================================*/
/* Table : mz_sas_import_element_type                           */
/*==============================================================*/
create table mz_sas_import_element_type (
   c_type_element_import char(3)              not null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_SAS_IMPORT_ELEMENT_TYPE primary key nonclustered (c_type_element_import)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Type d''�l�ment d''import
   Valeurs pr�d�finies
   ''CAR'' : Libell� d''une caract�ristique
   ''REF'' : Libell� d''une r�f�rence
   ''ELT'' : Libell� d''un �l�ment composition
   ''SMD'' : Libell� d''un sous-mod�le
   ''QTE'' : Quantit� d''un �l�ment composition
   ''NAT'' : Nom d�un Attribut �tendu
   ''VAT'' : Valeur d�un Attribut �tendu
   ''FAM'' : Libell� famille �l�ment composition
   ''SFA'' : Libell� sous-famille �l�ment composition
   ''GRP'' : Libell� groupe �l�ment composition
   ''SGR'' : Libell� sous-groupe �l�ment composition
   ''TEL'' : Type d''un �l�ment de composition
   ''CEL'' : Code d''un �l�ment composition
   ''NFO'' : Code nomenclature fournisseur
   ''ACT'' : Indicateur activit� d''un �l�ment de composition',
   'user', @CurrentUser, 'table', 'mz_sas_import_element_type'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code identifiant le type d''�l�ment import�',
   'user', @CurrentUser, 'table', 'mz_sas_import_element_type', 'column', 'c_type_element_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� d�crivant le type d''�l�ment import�',
   'user', @CurrentUser, 'table', 'mz_sas_import_element_type', 'column', 'l_libelle'
go

/*==============================================================*/
/* Table : mz_sas_import_etat                                   */
/*==============================================================*/
create table mz_sas_import_etat (
   c_etat_import        char(3)              not null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_SAS_IMPORT_ETAT primary key nonclustered (c_etat_import)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Table r�pertoriant les diff�rents �tats d''import
   Donn�es pr�d�finies :
    - ''OKI'' : OK, import effectu�
    - ''SAV'' : Donn�es dans le SAS, � v�rifier
    - ''SEC'' : Donn�es dans le SAS, en cours de v�rification
    - ''SOK'' : Donn�es dans le sas, v�rifi�es + � importer
    - ''KOD'' : KO, donn�es non valid�es
    - ''KOF'' : KO, donn�es valid�es mais erreur fonctionnelle durant l''import
    - ''KOT'' : KO, donn�es valid�es mais erreur technique durant l''import',
   'user', @CurrentUser, 'table', 'mz_sas_import_etat'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'code identifiant l''�tat de l''import',
   'user', @CurrentUser, 'table', 'mz_sas_import_etat', 'column', 'c_etat_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� d�crivant l''�tat de l''import',
   'user', @CurrentUser, 'table', 'mz_sas_import_etat', 'column', 'l_libelle'
go

/*==============================================================*/
/* Table : mz_sas_import_type                                   */
/*==============================================================*/
create table mz_sas_import_type (
   c_type_import        char(3)              not null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_SAS_IMPORT_TYPE primary key nonclustered (c_type_import)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Table r�pertoriant les diff�rents types d''import
   Donn�es pr�d�finies :
    - ''ELT'' : Import d''�l�ments de composition
    - ''CAR'' : Import des caract�ristiques
    - ''REF'' : Import des r�f�rences et des liaisons caract�ristiques
    - ''REL'' : Import des liaisons r�f�rence / �l�ment de composition
    - ''RCE'' : Import des r�f�rences, des liaisons caract�ristiques et des liaisons r�f�rence / �l�ment de composition
    - ''SRE'' : Import des r�f�rences par sous-r�f�rence',
   'user', @CurrentUser, 'table', 'mz_sas_import_type'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du type d''import',
   'user', @CurrentUser, 'table', 'mz_sas_import_type', 'column', 'c_type_import'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� du type d''import',
   'user', @CurrentUser, 'table', 'mz_sas_import_type', 'column', 'l_libelle'
go

/*==============================================================*/
/* Table : mz_type_attribut_etendu                              */
/*==============================================================*/
create table mz_type_attribut_etendu (
   c_type_attribut_etendu char(1)              not null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_TYPE_ATTRIBUT_ETENDU primary key nonclustered (c_type_attribut_etendu)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Type d''attribut �tendu : indique s''il s''agit d''un attribut �tendu sur r�f�rence ou sur �l�ment
   Donn�es pr�d�finies :
    - ''E'' : Attribut sur �l�ment
    - ''R'' : Attribut sur r�f�rence',
   'user', @CurrentUser, 'table', 'mz_type_attribut_etendu'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du type d''attribut �tendu',
   'user', @CurrentUser, 'table', 'mz_type_attribut_etendu', 'column', 'c_type_attribut_etendu'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� du type d''attribut �tendu',
   'user', @CurrentUser, 'table', 'mz_type_attribut_etendu', 'column', 'l_libelle'
go

/*==============================================================*/
/* Table : mz_type_element                                      */
/*==============================================================*/
create table mz_type_element (
   c_type_element       char(3)              not null,
   l_libelle            LIBELLE_COURT        not null,
   constraint PK_MZ_TYPE_ELEMENT primary key nonclustered (c_type_element)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Type d''�l�ment de composition
   Valeurs pr�d�finies :
    - ''ART'' : Article
    - ''PRE'' : Prestation',
   'user', @CurrentUser, 'table', 'mz_type_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code identifiant le type de l''�l�ment de composition',
   'user', @CurrentUser, 'table', 'mz_type_element', 'column', 'c_type_element'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� du type d''�l�ment de composition',
   'user', @CurrentUser, 'table', 'mz_type_element', 'column', 'l_libelle'
go

/*==============================================================*/
/* Table : mz_utilisateur                                       */
/*==============================================================*/
create table mz_utilisateur (
   id_utilisateur       int                  identity,
   c_utilisateur        LIBELLE_COURT        not null,
   l_nom                LIBELLE_COURT        not null,
   l_prenom             LIBELLE_COURT        not null,
   l_mail               MAIL                 not null,
   in_actif             bit                  not null,
   l_motdepasse         varchar(10)          not null,
   constraint PK_MZ_UTILISATEUR primary key nonclustered (id_utilisateur)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Utilisateur de l''application Mozarto et compte associ�',
   'user', @CurrentUser, 'table', 'mz_utilisateur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''utilisateur pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'mz_utilisateur', 'column', 'id_utilisateur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code de l''utilisateur, par exemple "j.truchot"
   Ce champ sert de login de connexion � Mozarto
   Il ne peut pas y avoir deux codes d''utilisateur identique dans cette table',
   'user', @CurrentUser, 'table', 'mz_utilisateur', 'column', 'c_utilisateur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Nom de l''utilisateur',
   'user', @CurrentUser, 'table', 'mz_utilisateur', 'column', 'l_nom'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Pr�nom de l''utilisateur',
   'user', @CurrentUser, 'table', 'mz_utilisateur', 'column', 'l_prenom'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Adresse email de l''utilisateur',
   'user', @CurrentUser, 'table', 'mz_utilisateur', 'column', 'l_mail'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Indicateur d''activit� (1 = actif ; 0 = inactif). Utilis� pour supprimer logiquement l''objet.',
   'user', @CurrentUser, 'table', 'mz_utilisateur', 'column', 'in_actif'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Mot de passe de l''utilisateur
   Ce champ sert de mot de passe de connexion � Mozarto',
   'user', @CurrentUser, 'table', 'mz_utilisateur', 'column', 'l_motdepasse'
go

/*==============================================================*/
/* Table : mz_utilisateur_lien_pegaz                            */
/*==============================================================*/
create table mz_utilisateur_lien_pegaz (
   id_utilisateur       int                  not null,
   idUtilisateurPegaz   int                  not null,
   constraint PK_MZ_UTILISATEUR_LIEN_PEGAZ primary key (id_utilisateur, idUtilisateurPegaz)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Rapprochement de l''utilisateur Mozarto avec l''utilisateur PEGAZ
   Info : Cardinalit� volontairement d�finies en (0,n) pour d�coupler les 2 tables associ�es, et avoir une table de lien',
   'user', @CurrentUser, 'table', 'mz_utilisateur_lien_pegaz'
go

/*==============================================================*/
/* Index : UTILISATEUR_LIEN_PEGAZ_FK                            */
/*==============================================================*/
create index UTILISATEUR_LIEN_PEGAZ_FK on mz_utilisateur_lien_pegaz (
id_utilisateur ASC
)
go

/*==============================================================*/
/* Index : UTILISATEUR_LIEN_PEGAZ2_FK                           */
/*==============================================================*/
create index UTILISATEUR_LIEN_PEGAZ2_FK on mz_utilisateur_lien_pegaz (
idUtilisateurPegaz ASC
)
go

/*==============================================================*/
/* Table : pz_metier                                            */
/*==============================================================*/
create table pz_metier (
   id_metierpegaz       int                  identity,
   c_societe_sm         char(3)              not null,
   c_metierPegaz        char(3)              not null,
   l_libelle            LIBELLE_COURT        null,
   constraint PK_PZ_METIER primary key nonclustered (id_metierpegaz)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'M�tier d�fini dans PEGAZ',
   'user', @CurrentUser, 'table', 'pz_metier'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'pz_metier', 'column', 'id_metierpegaz'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code soci�t� du service mat�riel PEGAZ (identifiant le m�tier dans PEGAZ)',
   'user', @CurrentUser, 'table', 'pz_metier', 'column', 'c_societe_sm'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code du m�tier PEGAZ (identifiant le m�tier dans PEGAZ)',
   'user', @CurrentUser, 'table', 'pz_metier', 'column', 'c_metierPegaz'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Libell� du m�tier PEGAZ',
   'user', @CurrentUser, 'table', 'pz_metier', 'column', 'l_libelle'
go

/*==============================================================*/
/* Table : pz_utilisateur                                       */
/*==============================================================*/
create table pz_utilisateur (
   idUtilisateurPegaz   int                  identity,
   c_utilisateur_pegaz  char(5)              not null,
   l_nom                LIBELLE_COURT        null,
   constraint PK_PZ_UTILISATEUR primary key nonclustered (idUtilisateurPegaz)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Utilisateur d�fini dans Pegaz
   User defined in Pegaz application',
   'user', @CurrentUser, 'table', 'pz_utilisateur'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Identifiant unique de l''objet pour l''application Mozarto',
   'user', @CurrentUser, 'table', 'pz_utilisateur', 'column', 'idUtilisateurPegaz'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Code de l''utilisateur c�t� PEGAZ (utilis� pour le rapprochement)',
   'user', @CurrentUser, 'table', 'pz_utilisateur', 'column', 'c_utilisateur_pegaz'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Nom de l''utilisateur c�t� PEGAZ',
   'user', @CurrentUser, 'table', 'pz_utilisateur', 'column', 'l_nom'
go

alter table mz_attribut_etendu
   add constraint FK_MZ_ATTRI_ATTRIBUT__MZ_TYPE_ foreign key (c_type_attribut_etendu)
      references mz_type_attribut_etendu (c_type_attribut_etendu)
go

alter table mz_attribut_etendu
   add constraint FK_MZ_ATTRI_PERSONNAL_MZ_METIE foreign key (id_metier)
      references mz_metier (id_metier)
go

alter table mz_attribut_etendu_element
   add constraint FK_MZ_ATTRI_ATTRIBUT__MZ_ELEME foreign key (id_element)
      references mz_element (id_element)
go

alter table mz_attribut_etendu_element
   add constraint FK_MZ_ATTRI_ATTRIBUT__MZ_ATTRI foreign key (id_attribut_etendu)
      references mz_attribut_etendu (id_attribut_etendu)
go

alter table mz_cmp_attribut_etendu_reference
   add constraint FK_MZ_CMP_A_CMP_ATTRI_MZ_ATTRI foreign key (id_attribut_etendu)
      references mz_attribut_etendu (id_attribut_etendu)
go

alter table mz_cmp_attribut_etendu_reference
   add constraint FK_MZ_CMP_A_MDL_ATTRI_MZ_CMP_R foreign key (id_modele_version, id_composition, id_reference)
      references mz_cmp_reference (id_modele_version, id_composition, id_reference)
go

alter table mz_cmp_caracteristique_select
   add constraint FK_MZ_CMP_C_CMP_CARAC_MZ_CMP_C foreign key (id_modele_version, id_composition)
      references mz_cmp_composition (id_modele_version, id_composition)
go

alter table mz_cmp_caracteristique_select
   add constraint FK_MZ_CMP_C_CMP_CARAC_MZ_MDL_C foreign key (id_modele_version, id_caracteristique)
      references mz_mdl_caracteristique (id_modele_version, id_caracteristique)
go

alter table mz_cmp_composition
   add constraint FK_MZ_CMP_C_CMP_MODEL_MZ_MDL_M foreign key (id_modele_version)
      references mz_mdl_modele_version (id_modele_version)
go

alter table mz_cmp_composition
   add constraint FK_MZ_CMP_C_MZ_CMP_UT_MZ_UTILI foreign key (id_utilisateur_crea)
      references mz_utilisateur (id_utilisateur)
go

alter table mz_cmp_composition
   add constraint FK_MZ_CMP_C_MZ_CMP_UT_MZ_UTILI2 foreign key (id_utilisateur_dmaj)
      references mz_utilisateur (id_utilisateur)
go

alter table mz_cmp_element_select
   add constraint FK_MZ_CMP_E_CMP_ELEME_MZ_CMP_C foreign key (id_modele_version, id_composition)
      references mz_cmp_composition (id_modele_version, id_composition)
go

alter table mz_cmp_element_select
   add constraint FK_MZ_CMP_E_CMP_ELEME_MZ_ELEME foreign key (id_element)
      references mz_element (id_element)
go

alter table mz_cmp_reference
   add constraint FK_MZ_CMP_R_CMP_MODEL_MZ_MDL_R foreign key (id_modele_version, id_reference)
      references mz_mdl_reference (id_modele_version, id_reference)
go

alter table mz_cmp_reference
   add constraint FK_MZ_CMP_R_CMP_REFER_MZ_CMP_C foreign key (id_modele_version, id_composition)
      references mz_cmp_composition (id_modele_version, id_composition)
go

alter table mz_cmp_reference_element
   add constraint FK_MZ_CMP_R_CMP_REFER_MZ_CMP_R foreign key (id_modele_version, id_composition, id_reference)
      references mz_cmp_reference (id_modele_version, id_composition, id_reference)
go

alter table mz_cmp_reference_element
   add constraint FK_MZ_CMP_R_CMP_REFER_MZ_ELEME foreign key (id_element)
      references mz_element (id_element)
go

alter table mz_element
   add constraint FK_MZ_ELEME_ELEMENT_R_MZ_FAMIL foreign key (id_famille, id_metier)
      references mz_famille (id_famille, id_metier)
go

alter table mz_element
   add constraint FK_MZ_ELEME_ELEMENT_R_MZ_METIE foreign key (id_metier)
      references mz_metier (id_metier)
go

alter table mz_famille
   add constraint FK_MZ_FAMIL_FAMILLEPA_MZ_FAMIL foreign key (id_famille_parent, id_metier)
      references mz_famille (id_famille, id_metier)
go

alter table mz_famille
   add constraint FK_MZ_FAMIL_FAMILLE_E_MZ_FAMIL foreign key (c_type_famille, c_type_element)
      references mz_famille_type (c_type_famille, c_type_element)
go

alter table mz_habilitation_utilisateur
   add constraint FK_MZ_HABIL_HABILITAT_MZ_UTILI foreign key (id_utilisateur)
      references mz_utilisateur (id_utilisateur)
go

alter table mz_habilitation_utilisateur
   add constraint FK_MZ_HABIL_HABILITAT_MZ_ROLE_ foreign key (c_role)
      references mz_role_utilisateur (c_role)
go

alter table mz_habilitation_utilisateur
   add constraint FK_MZ_HABIL_HABILITAT_MZ_METIE foreign key (id_metier)
      references mz_metier (id_metier)
go

alter table mz_mdl_attribut_etendu_reference
   add constraint FK_MZ_MDL_A_MDL_ATTRI_MZ_MDL_R foreign key (id_modele_version, id_reference)
      references mz_mdl_reference (id_modele_version, id_reference)
go

alter table mz_mdl_attribut_etendu_reference
   add constraint FK_MZ_MDL_A_MDL_ATTRI_MZ_ATTRI foreign key (id_attribut_etendu)
      references mz_attribut_etendu (id_attribut_etendu)
go

alter table mz_mdl_caracteristique
   add constraint FK_MZ_MDL_C_MDL_CARAC_MZ_MDL_C foreign key (id_modele_version, id_caracteristique_parent)
      references mz_mdl_caracteristique (id_modele_version, id_caracteristique)
go

alter table mz_mdl_caracteristique
   add constraint FK_MZ_MDL_C_MDL_MODEL_MZ_MDL_M foreign key (id_modele_version)
      references mz_mdl_modele_version (id_modele_version)
go

alter table mz_mdl_carateristique_reference
   add constraint FK_MZ_MDL_C_MDL_CARAT_MZ_MDL_C foreign key (id_modele_version, id_caracteristique)
      references mz_mdl_caracteristique (id_modele_version, id_caracteristique)
go

alter table mz_mdl_carateristique_reference
   add constraint FK_MZ_MDL_C_MDL_CARAT_MZ_MDL_R foreign key (id_modele_version, id_reference)
      references mz_mdl_reference (id_modele_version, id_reference)
go

alter table mz_mdl_message
   add constraint FK_MZ_MDL_M_MDL_MESSA_MZ_MDL_L foreign key (id_source_lien_commun, id_modele_version)
      references mz_mdl_lien_commun (id_lien_commun, id_modele_version)
go

alter table mz_mdl_message
   add constraint FK_MZ_MDL_M_MDL_SOURC_MZ_MDL_L foreign key (id_source_lien_commun, id_modele_version)
      references mz_mdl_lien_commun (id_lien_commun, id_modele_version)
go

alter table mz_mdl_modele
   add constraint FK_MZ_MDL_M_MODELE_LI_MZ_METIE foreign key (id_metier)
      references mz_metier (id_metier)
go

alter table mz_mdl_modele
   add constraint FK_MZ_MDL_M_MZ_MDL_UT_MZ_UTILI foreign key (id_utilisateur_crea)
      references mz_utilisateur (id_utilisateur)
go

alter table mz_mdl_modele_version
   add constraint FK_MZ_MDL_M_HORODATE_MZ_UTILI foreign key (id_utilisateur_dmaj)
      references mz_utilisateur (id_utilisateur)
go

alter table mz_mdl_modele_version
   add constraint FK_MZ_MDL_M_MDL_EXEMP_MZ_MDL_M foreign key (id_modele)
      references mz_mdl_modele (id_modele)
go

alter table mz_mdl_reference
   add constraint FK_MZ_MDL_R_REFERENCE_MZ_MDL_R foreign key (id_sous_modele, id_modele_version)
      references mz_mdl_reference_sous_modele (id_sous_modele, id_modele_version)
go

alter table mz_mdl_reference_element
   add constraint FK_MZ_MDL_R_MDL_REFER_MZ_ELEME foreign key (id_element)
      references mz_element (id_element)
go

alter table mz_mdl_reference_element
   add constraint FK_MZ_MDL_R_MDL_REFER_MZ_MDL_R foreign key (id_modele_version, id_reference)
      references mz_mdl_reference (id_modele_version, id_reference)
go

alter table mz_mdl_regle
   add constraint FK_MZ_MDL_R_MDL_TYPAG_MZ_MDL_T foreign key (c_type_regle)
      references mz_mdl_type_regle (c_type_regle)
go

alter table mz_mdl_type_regle
   add constraint FK_MZ_MDL_T_MDL_TYPE__MZ_MDL_S foreign key (c_cible_type_lien)
      references mz_mdl_type_lien (c_type_lien)
go

alter table mz_mdl_type_regle
   add constraint FK_MZ_MDL_T_MDL_SOURC_MZ_MDL_T foreign key (c_source_type_lien)
      references mz_mdl_type_lien (c_type_lien)
go

alter table mz_metier_lien_pegaz
   add constraint FK_MZ_METIE_METIER_LI_PZ_METIE foreign key (id_metier_pegaz)
      references pz_metier (id_metierpegaz)
go

alter table mz_metier_lien_pegaz
   add constraint FK_MZ_METIE_METIER_LI_MZ_METIE foreign key (id_metier)
      references mz_metier (id_metier)
go

alter table mz_preference_graphique_utilisateur
   add constraint FK_MZ_PREF_GRAPHIQUE1 foreign key (c_preference_graphique)
      references mz_preference_graphique (c_preference_graphique)
go

alter table mz_preference_graphique_utilisateur
   add constraint FK_MZ_PREF_UTIL1 foreign key (id_preference_utilisateur)
      references mz_preference_utilisateur (id_preference_utilisateur)
go

alter table mz_preference_utilisateur
   add constraint FK_MZ_PREFE_LANGUE_PA_MZ_LANGU foreign key (c_langue)
      references mz_langue (c_langue)
go

alter table mz_preference_utilisateur
   add constraint FK_MZ_PREFE_UTILISATE_MZ_UTILI foreign key (id_utilisateur)
      references mz_utilisateur (id_utilisateur)
go

alter table mz_sas_import
   add constraint FK_MZ_SAS_I_REFERENCE_MZ_UTILI foreign key (id_utilisateur_crea)
      references mz_utilisateur (id_utilisateur)
go

alter table mz_utilisateur_lien_pegaz
   add constraint FK_MZ_UTILI_UTILISATE_MZ_UTILI foreign key (id_utilisateur)
      references mz_utilisateur (id_utilisateur)
go

alter table mz_utilisateur_lien_pegaz
   add constraint FK_MZ_UTILI_UTILISATE_PZ_UTILI foreign key (idUtilisateurPegaz)
      references pz_utilisateur (idUtilisateurPegaz)
go

