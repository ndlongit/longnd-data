begin tran

-- Attention : le script "mozarto_remplissage_data.sql" doit etre applique avant l'application de ce script
-- Attention : la base de données ne doit pas contenir d'autres métiers et d'autres utilisateurs excepté ceux générés par le script "mozarto_remplissage_data.sql" avant d'insérer les données de ce script

declare
    @id_utilisateur as int,
    @id_utilisateur_admin_general as int,
    @id_metier as int,
    @id_metier_admin as int,
    @c_role as char(3),
    @id_famille_vide_article as int,
    @id_famille_vide_prestation as int


select @c_role = c_role from mz_role_utilisateur where l_libelle = 'Administrateur métier'
select @id_utilisateur_admin_general = id_utilisateur from mz_utilisateur where c_utilisateur = 'admin.mozarto'
select @id_utilisateur = id_utilisateur from mz_utilisateur where c_utilisateur = 'j.truchot'
select @id_metier_admin = id_metier from mz_metier where c_metier = 'ADG'
select @id_metier = id_metier from mz_metier where c_metier = 'JTR'


-- Creation des metiers
insert into mz_metier (c_metier, l_libelle, in_actif) 
          select 'LEV', 'Levage', 1
union all select 'CSE', 'Coffrage', 1
union all select 'ETA', 'Etaiement', 1


-- Création des utilisateurs
insert into mz_utilisateur (c_utilisateur, l_nom, l_prenom, l_mail, in_actif, l_motdepasse)
          select 's.nguyen', 'Nguyen', 'Suong', 'suong.nguyen@vsl.com', 1, 'suong'
union all select 'd.chemin', 'Chemin', 'Dominique', 'dominique.chemin@bouygues-construction.com', 1, 'dominique'
union all select 'f.himdi', 'Himdi', 'Fatine', 'f.himdi@bouygues-construction.com', 1, 'fatine'
union all select 'm.choudy', 'Choudy', 'Myriam', 'm.choudy@bouygues-construction.com', 1, 'myriam'


-- Association des quatre utilisateurs aux trois métiers créés
-- (on ignore le métier 'JTR' et l'utilisateur 'j.truchot')
insert into mz_habilitation_utilisateur (id_utilisateur, id_metier, c_role, in_defaut)
select id_utilisateur, id_metier, @c_role, 0
from mz_utilisateur cross join mz_metier
    where id_metier <> @id_metier
        and id_metier <> @id_metier_admin
        and id_utilisateur <> @id_utilisateur
        and id_utilisateur <> @id_utilisateur_admin_general


insert into mz_famille (id_metier, c_type_element, c_type_famille, id_famille_parent, l_libelle)
select id_metier, 'ART', 'FAM', NULL, '' from mz_metier where id_metier <> @id_metier and id_metier <> @id_metier_admin
insert into mz_famille (id_metier, c_type_element, c_type_famille, id_famille_parent, l_libelle)
select id_metier, 'PRE', 'TPR', NULL, '' from mz_metier where id_metier <> @id_metier and id_metier <> @id_metier_admin


select uti.c_utilisateur, uti.l_motdepasse, met.c_metier, met.l_libelle, hab.c_role
from mz_habilitation_utilisateur hab
    inner join mz_utilisateur uti
        on hab.id_utilisateur = uti.id_utilisateur
    inner join mz_metier met
        on met.id_metier = hab.id_metier

/*
select * from mz_metier
select * from mz_role_utilisateur
select * from mz_utilisateur
select * from mz_habilitation_utilisateur
select * from mz_famille
*/

-------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
/*

declare
    @id_metier_lev as int,
    @id_famille_vide_article_lev as int,
    @id_famille_vide_prestation_lev as int,
    @id_metier_cse as int,
    @id_famille_vide_article_cse as int,
    @id_famille_vide_prestation_cse as int,
    @id_metier_eta as int,
    @id_famille_vide_article_eta as int,
    @id_famille_vide_prestation_eta as int

select @id_metier_lev = id_metier from mz_metier where c_metier = 'LEV'
select @id_famille_vide_article_lev = id_famille from mz_famille
    where c_type_element = 'ART' and c_type_famille = 'FAM' and id_metier = @id_metier_lev
select @id_famille_vide_prestation_lev = id_famille from mz_famille
    where c_type_element = 'PRE' and c_type_famille = 'TPR' and id_metier = @id_metier_lev

select @id_metier_cse = id_metier from mz_metier where c_metier = 'CSE'
select @id_famille_vide_article_lev = id_famille from mz_famille
    where c_type_element = 'ART' and c_type_famille = 'FAM' and id_metier = @id_metier_cse
select @id_famille_vide_prestation_lev = id_famille from mz_famille
    where c_type_element = 'PRE' and c_type_famille = 'TPR' and id_metier = @id_metier_cse

select @id_metier_eta = id_metier from mz_metier where c_metier = 'ETA'
select @id_famille_vide_article_lev = id_famille from mz_famille
    where c_type_element = 'ART' and c_type_famille = 'FAM' and id_metier = @id_metier_eta
select @id_famille_vide_prestation_lev = id_famille from mz_famille
    where c_type_element = 'PRE' and c_type_famille = 'TPR' and id_metier = @id_metier_eta

select
    @id_metier_lev as mtr_lev,
    @id_famille_vide_article_lev as fam_art_lev,
    @id_famille_vide_prestation_lev as fam_pre_lev,
    @id_metier_cse as mtr_cse,
    @id_famille_vide_article_cse as fam_art_cse,
    @id_famille_vide_prestation_cse as fam_pre_cse,
    @id_metier_eta as mtr_eta,
    @id_famille_vide_article_eta as fam_art_eta,
    @id_famille_vide_prestation_eta as fam_pre_eta

--------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- Eléments de composition pour le métier Levage

-- Création des éléments pour le métier Levage
-- 1000 articles dont 100 accessoires
declare
    @id_premier_article_lev as int,
    @id_premiere_prestation_lev as int,
    @id_dernier_article_lev as int,
    @id_derniere_prestation_lev as int,
    @i_art_lev as int,
    @c_art_lev as varchar(10)
    
    
select @i_art_lev = 0
while @i_art_lev < 1000
begin
    select @c_art_lev = 'AL' + right('000'+convert(varchar,@i_art_lev),3)
    insert into mz_element (id_metier, c_type_element, id_famille, c_element, in_actif, l_nomenclature_fournisseur, l_libelle_long)
    values (@id_metier_lev, 'ART', @id_famille_vide_article_lev, @c_art_lev, 1, 'REF-' + @c_art_lev, case when @i_art_lev <= 900 then 'Article ' + @c_art_lev else 'Accessoire ' + @c_art_lev end)
    select @id_dernier_article_lev = @@identity
    if @i_art_lev = 0
        select @id_premier_article_lev = @id_dernier_article_lev
    select @i_art_lev = @i_art_lev + 1
end

-- 200 prestation
declare
    @i_pre_lev as int,
    @c_pre_lev as varchar(10)

select @i_pre_lev = 0
while @i_pre_lev < 200
begin
    select @c_pre_lev = 'PL' + right('000'+convert(varchar,@i_pre_lev),3)
    insert into mz_element (id_metier, c_type_element, id_famille, c_element, in_actif, l_nomenclature_fournisseur, l_libelle_long)
    values (@id_metier_lev, 'PRE', @id_famille_vide_prestation_lev, @c_pre_lev, 1, NULL, 'Prestation ' + @c_pre_lev)
    select @id_derniere_prestation_lev = @@identity
    if @i_pre_lev = 0
        select @id_premiere_prestation_lev = @id_derniere_prestation_lev
    select @i_pre_lev = @i_pre_lev + 1
end





-- *******************************************************
-- ** Affichage des éléments pour le métier
-- select * from mz_element where id_metier = @id_metier
select convert(varchar,@i_art_lev) + ' articles/accessoires insérés' as INFO, @id_premier_article_lev as id_premier_art, @id_dernier_article_lev as id_dernier_art
select convert(varchar,@i_pre_lev) + ' prestations insérées' as INFO, @id_premiere_prestation_lev as id_premier_pre, @id_derniere_prestation_lev as id_dernier_pre

-------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------

*/
fin:

commit tran
