begin tran

-------------------------------------------------------------------------------------------
-- Rôles & Métier

declare
    @id_utilisateur as int,
    @id_metier as int,
    @c_role as char(3)

-- Création des rôles
insert into mz_role_utilisateur (c_role, l_libelle) 
          select 'ADM', 'Administrateur métier'
union all select 'ADG', 'Administrateur général'
union all select 'UTM', 'Utilisateur métier'
union all select 'UTI', 'Utilisateur invité'


-- Création du métier "Administration"
insert into mz_metier (c_metier, l_libelle, in_actif) 
    values ('ADG', 'Administration', 1)
select @id_metier = @@identity

-- Récupération du code du rôle "Administrateur général"
select @c_role = c_role from mz_role_utilisateur where l_libelle = 'Administrateur général'

-- Création d'un utilisateur "admin.mozarto" ayant le rôle d' "Administrateur général" pour le métier "Administration"
-- Mot de passe : "admin"
insert into mz_utilisateur (c_utilisateur, l_nom, l_prenom, l_mail, in_actif, l_motdepasse)
    values('admin.mozarto', 'Mozarto', 'Administrateur', 'j.truchot@bouygues-construction.com', 1, 'admin')
select @id_utilisateur = @@identity
insert into mz_habilitation_utilisateur (id_utilisateur, id_metier, c_role, in_defaut)
    values (@id_utilisateur, @id_metier, @c_role, 1)


--------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- Référentiel
insert into mz_type_attribut_etendu (c_type_attribut_etendu, l_libelle)
          select 'E', 'Elément'
union all select 'R', 'Référence'


insert into mz_application_origine (c_application_origine, l_libelle)
          select 'M', 'Mozarto'
union all select 'P', 'PEGAZ'


insert into mz_type_element (c_type_element, l_libelle)
          select 'ART', 'Article'
union all select 'PRE', 'Prestation'


insert into mz_famille_type (c_type_famille, c_type_element, l_libelle)
          select 'FAM', 'ART', 'Famille'
union all select 'SFA', 'ART', 'Sous-famille'
union all select 'GRP', 'ART', 'Groupe'
union all select 'SGR', 'ART', 'Sous-groupe'
union all select 'TPR', 'PRE', 'Type-Prestation'



insert into mz_mdl_type_lien (c_type_lien, l_libelle)
          select 'C', 'Caractéristique'
union all select 'R', 'Référence'
union all select 'E', 'Elément'


insert into mz_mdl_type_regle (c_source_type_lien, c_cible_type_lien, c_type_regle)
          select 'C', 'C', 'M'
union all select 'C', 'R', 'O'
union all select 'C', 'E', 'Z'
union all select 'R', 'C', 'A'
union all select 'R', 'R', 'R'
union all select 'R', 'E', 'T'


insert into mz_sas_import_type (c_type_import, l_libelle)
	      select 'ELT','Import d''éléments de composition'
union all select 'CAR','Import des caractéristiques'
union all select 'REF','Import des références caractéristiques'
union all select 'REL','Import des liaisons référence/composition'
union all select 'RCE' ,'Import des références et leurs liaisons'
union all select 'SRE' ,'Import des références par sous-référence'


insert into mz_sas_import_etat (c_etat_import, l_libelle)
		  select 'OKI',' OK, import effectué'
union all select 'SAV','Données dans le SAS, à vérifier'
union all select 'SEC' ,'Données dans le SAS, en cours de vérification'
union all select 'SOK' ,'Données dans le SAS, vérifiées + à importer'
union all select 'KOD','KO, données non validées'
union all select 'KOF' ,'Données validées fonctionnelle durant l''import'
union all select 'KOT' ,'Données validées  technique durant l''import'


insert into mz_sas_import_element_type (c_type_element_import, l_libelle)
		  select 'CAR' ,'Libellé d''une caractéristique'
union all select 'REF' ,'Libellé d''une référence'
union all select 'ELT' ,'Libellé d''un élément composition'
union all select 'SMD' ,'Libellé d''un sous-modèle'
union all select 'QTE' ,'Quantité d''un élément composition'
union all select 'NAT' ,'Nom d''un Attribut étendu'
union all select 'VAT' ,'Valeur d''un Attribut étendu'
union all select 'FAM' ,'Libellé famille élément composition'
union all select 'SFA' ,'Libellé sous-famille élément composition'
union all select 'GRP' ,'Libellé groupe élément composition'
union all select 'SGR' ,'Libellé sous-groupe élément composition'
union all select 'TEL' ,'Type d''un élément de composition'
union all select 'CEL' ,'Code d''un élément composition'
union all select 'NFO' ,'Code nomenclature fournisseur'
union all select 'ACT' ,'Indicateur activité d''un élément de composition'
union all select 'CIN' ,'Colonne incorrecte'

-------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------



commit tran

