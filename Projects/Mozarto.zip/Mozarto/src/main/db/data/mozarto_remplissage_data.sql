begin tran


declare
    @id_utilisateur as int,
    @id_metier as int,
    @c_role as char(3),
    @id_famille_vide_article as int,
    @id_famille_vide_prestation as int


-- Cr�ation d'un m�tier
insert into mz_metier (c_metier, l_libelle, in_actif) 
    values ('JTR', 'Metier-test-julien', 1)
select @id_metier = @@identity

-- Cr�ation d'un r�le
select @c_role = c_role from mz_role_utilisateur where l_libelle = 'Administrateur m�tier'

-- Cr�ation d'un utilisateur avec son r�le pour le m�tier
insert into mz_utilisateur (c_utilisateur, l_nom, l_prenom, l_mail, in_actif, l_motdepasse)
    values('j.truchot', 'Truchot', 'Julien', 'j.truchot@bouygues-construction.com', 1, 'trunel')
select @id_utilisateur = @@identity
insert into mz_habilitation_utilisateur (id_utilisateur, id_metier, c_role, in_defaut)
    values (@id_utilisateur, @id_metier, @c_role, 1)


insert into mz_famille (id_metier, c_type_element, c_type_famille, id_famille_parent, l_libelle)
    values (@id_metier, 'ART', 'FAM', NULL, '')
select @id_famille_vide_article = @@identity
insert into mz_famille (id_metier, c_type_element, c_type_famille, id_famille_parent, l_libelle)
    values (@id_metier, 'PRE', 'TPR', NULL, '')
select @id_famille_vide_prestation = @@identity


declare
    @c_type_attr_element as char(1),
    @c_type_attr_reference as char(1)
select @c_type_attr_element = 'E', @c_type_attr_reference = 'R'

insert into mz_attribut_etendu(c_type_attribut_etendu, id_metier, n_rang, c_label_attribut_etendu, l_libelle, in_utilisation_compositeur, l_commentaire)
          select @c_type_attr_element, @id_metier, 01, 'pds-elt', 'Poids-elt', 0, 'Tonne'
union all select @c_type_attr_element, @id_metier, 02, 'haut-elt', 'Hauteur-elt', 0, 'M�tre'
union all select @c_type_attr_element, @id_metier, 03, 'long-elt', 'Longueur-elt', 0, 'M�tre'
union all select @c_type_attr_element, @id_metier, 04, 'larg-elt', 'Largeur-elt', 0, 'M�tre'
union all select @c_type_attr_element, @id_metier, 05, 'coul-elt', 'Couleur-elt', 0, null
union all select @c_type_attr_reference, @id_metier, 01, 'pds-ref', 'Poids-ref', 0, 'Tonne'
union all select @c_type_attr_reference, @id_metier, 02, 'vol-ref', 'Volume-ref', 0, 'M�tre cube'
union all select @c_type_attr_reference, @id_metier, 03, 'haut-ref', 'Hauteur-ref', 0, 'M�tre'
union all select @c_type_attr_reference, @id_metier, 04, 'long-ref', 'Longueur-ref', 0, 'M�tre'
union all select @c_type_attr_reference, @id_metier, 05, 'larg-ref', 'Largeur-ref', 0, 'M�tre'


-- select * from mz_metier
-- select * from mz_role_utilisateur
-- select * from mz_utilisateur
-- select * from mz_famille

-------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------






--------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- El�ments de composition pour le m�tier

-- Cr�ation des �l�ments pour le m�tier
-- 1000 articles dont 100 accessoires
declare
    @id_premier_article as int,
    @id_premiere_prestation as int,
    @id_dernier_article as int,
    @id_derniere_prestation as int,
    @i_art as int,
    @c_art as varchar(10)
    
    
select @i_art = 0
while @i_art < 1000
begin
    select @c_art = 'A1' + right('000'+convert(varchar,@i_art),3)
    insert into mz_element (id_metier, c_type_element, id_famille, c_element, in_actif, l_nomenclature_fournisseur, l_libelle_long)
    values (@id_metier, 'ART', @id_famille_vide_article, @c_art, 1, 'REF-' + @c_art, case when @i_art <= 900 then 'Article ' + @c_art else 'Accessoire ' + @c_art end)
    select @id_dernier_article = @@identity
    if @i_art = 0
        select @id_premier_article = @id_dernier_article
    select @i_art = @i_art + 1
end

-- 200 prestation
declare @i_pre as int
declare @c_pre as varchar(10)
select @i_pre = 0
while @i_pre < 200
begin
    select @c_pre = 'P3' + right('000'+convert(varchar,@i_pre),3)
    insert into mz_element (id_metier, c_type_element, id_famille, c_element, in_actif, l_nomenclature_fournisseur, l_libelle_long)
    values (@id_metier, 'PRE', @id_famille_vide_prestation, @c_pre, 1, NULL, 'Prestation ' + @c_pre)
    select @id_derniere_prestation = @@identity
    if @i_pre = 0
        select @id_premiere_prestation = @id_derniere_prestation
    select @i_pre = @i_pre + 1
end





-- *******************************************************
-- ** Affichage des �l�ments pour le m�tier
-- select * from mz_element where id_metier = @id_metier
select convert(varchar,@i_art) + ' articles/accessoires ins�r�s' as INFO, @id_premier_article as id_premier_art, @id_dernier_article as id_dernier_art
select convert(varchar,@i_pre) + ' prestations ins�r�es' as INFO, @id_premiere_prestation as id_premier_pre, @id_derniere_prestation as id_dernier_pre

-------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------







--------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------

-- Mod�lisation simple

/**
 * Dans un premier temps, on d�finit l'arbre des caract�ristiques.
 * Puis les r�f�rences sont g�n�r�es automatiquement � partir des caract�ristiques existantes
 * sous les noeuds "Hauteur", "Longueur", "Poids".
 * Puis les �l�ments de composition sont li�s de mani�res al�atoire avec des quantit�s al�atoires
 * aux r�f�rences g�n�r�es.
 * Si on veut faire un autre noeud de niveau 1, il faut mettre � jour la requ�te qui cr�e les
 * r�f�rence dans la table #temp_reference
 *      (cf. code comment� [-> Ajout d'une caract�ristique 'Mati�re'])
 * [!!] Attention [!!]
 *    -> La mod�lisation complexe est g�n�r�e sur des noeuds d�finies, donc si le mod�le g�n�r�
 *       est mis � jour, il faut reporter les donn�es mises � jour dans les r�gles et messages
 */

declare
    @id_modele as int,
    @id_modele_version as int,
    @id_caracteristique_niv0 as int,
    @id_caracteristique_niv1 as int,
    @d_maintenant as datetime

select @d_maintenant = getdate()


-- L'enveloppe du mod�le
insert into mz_mdl_modele (id_metier, in_actif, id_utilisateur_crea, d_dateheure_crea)
    values (@id_metier, 1, @id_utilisateur, @d_maintenant)
select @id_modele = @@identity
insert into mz_mdl_modele_version (id_modele, id_utilisateur_dmaj, d_dateheure_dmaj, in_actif)
    values (@id_modele, @id_utilisateur, @d_maintenant, 1)
select @id_modele_version = @@identity
insert into mz_mdl_version (n_version, id_modele, id_modele_version)
    values (0, @id_modele, @id_modele_version)


-- Les caract�ristiques
--      (on choisit volontairement de mettre un rang > 10 pour les caract�ristique de niveau 2,
--       pour les retrouver facilement pour rapprocher avec les r�f�rences)
-- Niveau 0
insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
    values (@id_modele_version, NULL, 1, 'Mod�le de test', 'La racine du mod�le')
select @id_caracteristique_niv0 = @@identity
        -- Niveau 1
        insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
            values (@id_modele_version, @id_caracteristique_niv0, 1, 'Hauteur', 'La premi�re branche sous la racine "Mod�le de test"')
        select @id_caracteristique_niv1 = @@identity
                -- Niveau 2
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 11, 'H200', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 12, 'H250', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 13, 'H300', NULL)
        /*
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 14, 'H350', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 15, 'H400', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 16, 'H450', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 17, 'H500', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 18, 'H550', NULL)
        */
        -- Niveau 1
        insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
            values (@id_modele_version, @id_caracteristique_niv0, 2, 'Largeur', 'La seconde branche sous la racine "Mod�le de test"')
        select @id_caracteristique_niv1 = @@identity
                -- Niveau 2
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 21, 'L180', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 22, 'L200', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 23, 'L220', NULL)
        /*
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 24, 'L240', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 25, 'L260', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 26, 'L280', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 27, 'L300', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 28, 'L320', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 29, 'L340', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 30, 'L360', NULL)
        */
        -- Niveau 1
        insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
            values (@id_modele_version, @id_caracteristique_niv0, 3, 'Poids', 'La troisi�me branche sous la racine "Mod�le de test"')
        select @id_caracteristique_niv1 = @@identity
                -- Niveau 2
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 31, 'P2.2', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 32, 'P2.5', NULL)
        /*
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 33, 'P2.8', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 34, 'P3.0', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 35, 'P3.5', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 36, 'P4.0', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 37, 'P4.5', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 38, 'P5.0', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 39, 'P5.5', NULL)
        */
        /*
        -- Niveau 1
        insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
            values (@id_modele_version, @id_caracteristique_niv0, 4, 'Mati�re', 'La quatri�me branche sous la racine "Mod�le de test"')
        select @id_caracteristique_niv1 = @@identity
                -- Niveau 2
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 41, 'CUIVRE', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 42, 'FER', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 43, 'BRONZE', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 44, 'ALUMINIUM', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 45, 'OR', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 46, 'ARGENT', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 47, 'ETAIN', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 48, 'PLOMB', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 49, 'ZINC', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 50, 'TITANE', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 51, 'MERCURE', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 52, 'CHROME', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 53, 'COBALT', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 54, 'PLATINE', NULL)
        -- Niveau 1
        insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
            values (@id_modele_version, @id_caracteristique_niv0, 6, 'Couleur', 'La cinqui�me branche sous la racine "Mod�le de test"')
        select @id_caracteristique_niv1 = @@identity
                -- Niveau 2
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 61, 'VERT', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 62, 'BLEU', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 63, 'ROUGE', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 64, 'JAUNE', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 65, 'NOIR', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 66, 'BLANC', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 67, 'ORANGE', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 68, 'ROSE', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 69, 'MARRON', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 70, 'GRIS', NULL)
        */

/** -> Ajout d'une caract�ristique 'Mati�re'
        -- Niveau 1
        insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
            values (@id_modele_version, @id_caracteristique_niv0, 4, 'Mati�re', 'La quatri�me branche sous la racine "Mod�le de test"')
        select @id_caracteristique_niv1 = @@identity
                -- Niveau 2
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 41, 'CUIVRE', NULL)
                insert into mz_mdl_caracteristique (id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire)
                    values (@id_modele_version, @id_caracteristique_niv1, 42, 'FER', NULL)
*/


-- *******************************************************
-- ** Affichage des niveaux 0, 1, 2 de l'arbre
select niv0.l_libelle as carac_niv0, niv1.l_libelle as carac_niv1, niv2.l_libelle as carac_niv2
from mz_mdl_caracteristique niv0
    inner join mz_mdl_caracteristique niv1
        on niv0.id_caracteristique = niv1.id_caracteristique_parent
            and niv0.id_modele_version = niv1.id_modele_version
    inner join mz_mdl_caracteristique niv2
        on niv1.id_caracteristique = niv2.id_caracteristique_parent
            and niv1.id_modele_version = niv2.id_modele_version
where niv0.id_modele_version = @id_modele_version
order by niv2.n_rang asc




-- Les r�f�rences
create table #temp_reference ( l_reference varchar(500) not null, n_rang int not null identity )

insert into #temp_reference(l_reference)
select car_1.l_libelle
    + ' ' + car_2.l_libelle
    + ' ' + car_3.l_libelle
    /*
    + ' ' + car_4.l_libelle
    + ' ' + car_5.l_libelle
    */
/** -> Ajout d'une caract�ristique 'Mati�re'
    + ' ' + car_4.l_libelle
*/
from mz_mdl_caracteristique car1
    inner join mz_mdl_caracteristique car_1
        on car1.id_caracteristique = car_1.id_caracteristique_parent
    inner join mz_mdl_caracteristique car2
        on car2.n_rang = 2
    inner join mz_mdl_caracteristique car_2
        on car2.id_caracteristique = car_2.id_caracteristique_parent
    inner join mz_mdl_caracteristique car3
        on car3.n_rang = 3
    inner join mz_mdl_caracteristique car_3
        on car3.id_caracteristique = car_3.id_caracteristique_parent
    /*
    inner join mz_mdl_caracteristique car4
        on car4.n_rang = 4
    inner join mz_mdl_caracteristique car_4
        on car4.id_caracteristique = car_4.id_caracteristique_parent
    inner join mz_mdl_caracteristique car5
        on car5.n_rang = 6
    inner join mz_mdl_caracteristique car_5
        on car5.id_caracteristique = car_5.id_caracteristique_parent
    */
/** ->
    inner join mz_mdl_caracteristique car4
        on car4.n_rang = 4
    inner join mz_mdl_caracteristique car_4
        on car4.id_caracteristique = car_4.id_caracteristique_parent
*/
where car1.n_rang = 1
    and car1.id_modele_version = @id_modele_version 
    and car1.id_caracteristique_parent is not null
    and car2.id_modele_version = car1.id_modele_version
    and car2.id_caracteristique_parent is not null
    and car3.id_modele_version = car1.id_modele_version
    and car3.id_caracteristique_parent is not null
    /*
    and car4.id_modele_version = car1.id_modele_version
    and car4.id_caracteristique_parent is not null
    and car5.id_modele_version = car1.id_modele_version
    and car5.id_caracteristique_parent is not null
    */
/** -> Ajout d'une caract�ristique 'Mati�re'
    and car4.id_modele_version = car1.id_modele_version
    and car4.id_caracteristique_parent is not null
*/

insert into mz_mdl_reference (id_modele_version, n_rang, l_libelle_long, in_sous_reference)
    select @id_modele_version, n_rang, l_reference, 0 from #temp_reference

drop table #temp_reference


-- *******************************************************
-- ** Affichage des r�f�rences cr��es
select ref.l_libelle_long as reference
from mz_mdl_reference ref
where ref.id_modele_version = @id_modele_version
order by ref.l_libelle_long




-- Les relations r�f�rences / caract�ristiques
declare
    @id_caracteristique as int,
    @l_caracteristique as varchar(500)

declare cursor_relation_reference_caracteristique cursor for
select id_caracteristique, l_libelle from mz_mdl_caracteristique where n_rang > 10 and id_modele_version = @id_modele_version
open cursor_relation_reference_caracteristique
while 0 = 0
begin
    fetch next from cursor_relation_reference_caracteristique into @id_caracteristique, @l_caracteristique
    if @@fetch_status <> 0
        break
    
    -- On recherche toute les r�f�rences dont le libell� contient le libell� de la caract�ristique
    insert into mz_mdl_carateristique_reference(id_caracteristique, id_reference, id_modele_version)
    select @id_caracteristique, id_reference, @id_modele_version
        from mz_mdl_reference
        where l_libelle_long like ('%' + @l_caracteristique + '%')
            and id_modele_version = @id_modele_version

end 
close cursor_relation_reference_caracteristique
deallocate cursor_relation_reference_caracteristique



-- *******************************************************
-- ** Affichage des liens r�f�rences / caract�ristiques
select ref.l_libelle_long as reference, car.l_libelle as caracteristique
from mz_mdl_reference ref 
    inner join mz_mdl_carateristique_reference mcr
        on mcr.id_reference = ref.id_reference and mcr.id_modele_version = ref.id_modele_version
    inner join mz_mdl_caracteristique car
        on mcr.id_caracteristique = car.id_caracteristique and mcr.id_modele_version = car.id_modele_version
where ref.id_modele_version = @id_modele_version
order by ref.l_libelle_long


declare
    @nb_element_min as int,
    @nb_element_suppl as int

select
    @nb_element_min = 5,
    @nb_element_suppl = 30


-- Les relations r�f�rences / �l�ments (+qt�)
declare
    @id_reference as int


create table #temp_element ( id_element int not null, n_qte int not null, n_rang int not null )

declare cursor_relation_reference_element cursor for
select id_reference from mz_mdl_reference where id_modele_version = @id_modele_version
open cursor_relation_reference_element
while 0 = 0
begin
    fetch next from cursor_relation_reference_element into @id_reference
    if @@fetch_status <> 0
        break
    
    declare
        @i_elt as int,
        @id_element as int,
        @nb_element as int
        
    select @i_elt = 0, @nb_element = @nb_element_min + (cast((rand()*10000) as int)%@nb_element_suppl)
    
    while @i_elt < @nb_element
    begin
        select @i_elt = @i_elt + 1
        
        if cast((rand()*10000) as int)%10 > 0 -- 10% de prestations
            select @id_element = @id_premier_article + (cast((rand()*10000) as int)%(@id_dernier_article-@id_premier_article))
        else
            select @id_element = @id_premiere_prestation + (cast((rand()*10000) as int)%(@id_derniere_prestation-@id_premiere_prestation))
        insert into #temp_element(id_element, n_qte, n_rang)
            values(@id_element, (1+(cast((rand()*10000) as int)%4)), @i_elt)
    end
    
    insert into mz_mdl_reference_element(id_element, id_reference, id_modele_version, n_quantite, n_rang)
    select distinct id_element, @id_reference, @id_modele_version, sum(n_qte), min(n_rang)
        from #temp_element
        group by id_element

    delete from #temp_element
end 
close cursor_relation_reference_element
deallocate cursor_relation_reference_element

drop table #temp_element




-- *******************************************************
-- ** Affichage des liens r�f�rences / �l�ments

select ref.l_libelle_long as reference, count(mre.id_element) as nb_element
from mz_mdl_reference ref 
    inner join mz_mdl_reference_element mre
        on mre.id_reference = ref.id_reference
            and mre.id_modele_version = ref.id_modele_version
group by ref.l_libelle_long

/*
select ref.l_libelle_long as reference, elt.c_element, mre.n_quantite
from mz_mdl_reference ref 
    inner join mz_mdl_reference_element mre
        on mre.id_reference = ref.id_reference
            and mre.id_modele_version = ref.id_modele_version
    inner join mz_element elt
        on mre.id_element = elt.id_element
order by ref.l_libelle_long
*/

-------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------







--------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------

-- Mod�lisation complexe


-- Les r�gles :
--   - Sur "H200" : cible A1001, priorit� obligatoire (=3), quantit� 5
--   - Sur "L200" : cible P3001, priorit� interdite (=1), quantit� 0
--   - Sur "P2.5" : cible A1111, priorit� conseill�e (=2), quantit� 4
--   - Sur 20% des r�f�rences, une r�gle de priorit� conseill�e (=2), visant un �l�ment al�atoire, pour une quantit� de 1 sera mise en place

------------
-- R�gle sur "H200" : cible A1001, priorit� obligatoire, quantit� 5
declare
    @id_carac_h200 as int,
    @id_elem_a1001 as int,
    @id_lien_carac_h200 as int,
    @id_lien_elem_a1001 as int

-- Lien sur caract�ristique H200
select @id_carac_h200 = id_caracteristique
    from mz_mdl_caracteristique
    where l_libelle = 'H200' and id_modele_version = @id_modele_version
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('C', @id_modele_version)
select @id_lien_carac_h200 = @@identity
insert into mz_mdl_lien_caracteristique (id_lien_commun, id_caracteristique, id_modele_version)
    values(@id_lien_carac_h200, @id_carac_h200, @id_modele_version)

-- Lien sur �l�ment A1001
select @id_elem_a1001 = id_element
    from mz_element
    where c_element = 'A1001' and id_metier = @id_metier
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('E', @id_modele_version)
select @id_lien_elem_a1001 = @@identity
insert into mz_mdl_lien_element (id_lien_commun, id_element, id_modele_version)
    values(@id_lien_elem_a1001, @id_elem_a1001, @id_modele_version)

insert into mz_mdl_regle (id_modele_version, id_source_lien_commun, id_cible_lien_commun, c_type_regle, n_quantite, n_priorite)
    values (@id_modele_version, @id_lien_carac_h200, @id_lien_elem_a1001, 'Z', 5, 3)


------------
-- R�gle sur "L200" : cible P3001, priorit� interdite, quantit� 0
declare
    @id_carac_l200 as int,
    @id_elem_p3001 as int,
    @id_lien_carac_l200 as int,
    @id_lien_elem_p3001 as int,
    @nb_suppr_elem_p3001 as int

-- Lien sur caract�ristique L200
select @id_carac_l200 = id_caracteristique
    from mz_mdl_caracteristique
    where l_libelle = 'L200' and id_modele_version = @id_modele_version
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('C', @id_modele_version)
select @id_lien_carac_l200 = @@identity
insert into mz_mdl_lien_caracteristique (id_lien_commun, id_caracteristique, id_modele_version)
    values(@id_lien_carac_l200, @id_carac_l200, @id_modele_version)

-- Lien sur �l�ment P3001
select @id_elem_p3001 = id_element
    from mz_element
    where c_element = 'P3001' and id_metier = @id_metier
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('E', @id_modele_version)
select @id_lien_elem_p3001 = @@identity
insert into mz_mdl_lien_element (id_lien_commun, id_element, id_modele_version)
    values(@id_lien_elem_p3001, @id_elem_p3001, @id_modele_version)

-- Recherche d'une �ventuelle incoh�rence avec le mod�le :
--    - l'�l�ment interdit par la r�gle ne doit en aucun cas exister sur la (les) branche de la r�gle
-- Remarque : on ne fait la recherche que dans la mod�lisation simple puisque l'�l�ment ne peut pas
-- exister dans les r�gles � ce moment de la proc�dure
if exists( select mre.id_element
    from mz_mdl_reference_element mre
        inner join mz_mdl_carateristique_reference mcr
            on mre.id_reference = mcr.id_reference
                and id_caracteristique = @id_carac_l200
    where mre.id_element = @id_elem_p3001 )
begin
    -- Si on a trouv� quelque chose, on le supprime
    delete mre
    from mz_mdl_reference_element mre
        inner join mz_mdl_carateristique_reference mcr
            on mre.id_reference = mcr.id_reference
                and id_caracteristique = @id_carac_l200
    where mre.id_element = @id_elem_p3001
    select @nb_suppr_elem_p3001 = @@rowcount
    select 'Suppression de l''�l�ment P3001' as INFO, @nb_suppr_elem_p3001 as NB_SUPPR
end

-- Et on ins�re la r�gle
insert into mz_mdl_regle (id_modele_version, id_source_lien_commun, id_cible_lien_commun, c_type_regle, n_quantite, n_priorite)
    values (@id_modele_version, @id_lien_carac_l200, @id_lien_elem_p3001, 'Z', 0, 1)

------------
-- R�gle sur "P2.5" : cible A1111, priorit� conseill�e, quantit� 4
declare
    @id_carac_p25 as int,
    @id_elem_a1111 as int,
    @id_lien_carac_p25 as int,
    @id_lien_elem_a1111 as int

-- Lien sur caract�ristique P2.5
select @id_carac_p25 = id_caracteristique
    from mz_mdl_caracteristique
    where l_libelle = 'P2.5' and id_modele_version = @id_modele_version
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('C', @id_modele_version)
select @id_lien_carac_p25 = @@identity
insert into mz_mdl_lien_caracteristique (id_lien_commun, id_caracteristique, id_modele_version)
    values(@id_lien_carac_p25, @id_carac_p25, @id_modele_version)

-- Lien sur �l�ment A1111
select @id_elem_a1111 = id_element
    from mz_element
    where c_element = 'A1111' and id_metier = @id_metier
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('E', @id_modele_version)
select @id_lien_elem_a1111 = @@identity
insert into mz_mdl_lien_element (id_lien_commun, id_element, id_modele_version)
    values(@id_lien_elem_a1111, @id_elem_a1111, @id_modele_version)

insert into mz_mdl_regle (id_modele_version, id_source_lien_commun, id_cible_lien_commun, c_type_regle, n_quantite, n_priorite)
    values (@id_modele_version, @id_lien_carac_p25, @id_lien_elem_a1111, 'Z', 4, 2)


------------
-- R�gle sur 20% des r�f�rences, une r�gle de priorit� conseill�e, visant un �l�ment al�atoire, pour une quantit� de 1 sera mise en place
-- Remarque : on s'assure qu'aucun �l�ment cible soit l'�l�ment qui a �t� interdit ('P3001'), c'est plus simple
declare
    @id_premiere_reference as int,
    @id_derniere_reference as int,
    @nb_regle as int

select @id_premiere_reference = min(id_reference), @id_derniere_reference = max(id_reference)
    from mz_mdl_reference
select @nb_regle = (@id_derniere_reference-@id_premiere_reference)*2/10 -- 20% des r�f�rences


declare
    @id_ref_regle as int,  -- id de la r�f�rence source
    @id_elem_regle as int, -- id de l'�l�ment cible
    @id_lien_ref_regle as int,  -- lien commun sur la r�f�rence
    @id_lien_elem_regle as int, -- lien commun sur l'�l�ment
    @i_regle as int,  -- donn�e incr�ment�e pour faire les tours de la boucle de cr�ation des r�gles
    @in_existe as bit -- indicateur permettant de v�rifier qu'une r�gle ne sera pas cr��e deux fois

select @i_regle = 0

while @i_regle < @nb_regle
begin
    -- Selection al�atoire de l'�l�ment de composition
    select @id_elem_regle = @id_premier_article + (cast((rand()*10000) as int)%(@id_derniere_prestation-@id_premier_article))
    -- On n'accepte pas l'�l�ment de composition P3001
    if @id_elem_regle = @id_elem_p3001
        continue
    -- Selection al�atoire de la r�f�rence
    select @id_ref_regle = @id_premiere_reference + (cast((rand()*10000) as int)%(@id_derniere_reference-@id_premiere_reference))

    -- On cr�e ou on r�cup�re les liens communs
    if not exists( select id_lien_commun from mz_mdl_lien_reference where id_reference = @id_ref_regle and id_modele_version = @id_modele_version )
    begin
        insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
            values('R', @id_modele_version)
        select @id_lien_ref_regle = @@identity
        insert into mz_mdl_lien_reference (id_lien_commun, id_reference, id_modele_version)
            values(@id_lien_ref_regle, @id_ref_regle, @id_modele_version)
        select @in_existe = 0
    end
    else
    begin
        select @id_lien_ref_regle = id_lien_commun from mz_mdl_lien_reference where id_reference = @id_ref_regle and id_modele_version = @id_modele_version
        select @in_existe = 1
    end
    
    if not exists( select id_lien_commun from mz_mdl_lien_element where id_element = @id_elem_regle and id_modele_version = @id_modele_version )
    begin
        insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
            values('E', @id_modele_version)
        select @id_lien_elem_regle = @@identity
        insert into mz_mdl_lien_element (id_lien_commun, id_element, id_modele_version)
            values(@id_lien_elem_regle, @id_elem_regle, @id_modele_version)
    end
    else
    begin
        if @in_existe = 1
            continue -- on ne peut pas cr�er deux fois la m�me r�gle
        select @id_lien_elem_regle = id_lien_commun from mz_mdl_lien_element where id_element = @id_elem_regle and id_modele_version = @id_modele_version
    end

    -- Et on ins�re la r�gle
    insert into mz_mdl_regle (id_modele_version, id_source_lien_commun, id_cible_lien_commun, c_type_regle, n_quantite, n_priorite)
        values (@id_modele_version, @id_lien_ref_regle, @id_lien_elem_regle, 'T', 1, 2)

    select @i_regle += 1
end



-- Les messages :
--   - Sur la racine : "Bonjour et bienvenue dans le mod�le de test", information
--   - Sur "H300" : "Attention � la hauteur, car c'est tr�s haut !", alerte
--   - Sur "L180" : "Message d'information sur la longueur L180", information
--   - Sur "P2.2" : "Le poids le plus bas ne doit pas �tre associ� aux hauteurs hautes et aux longueurs longues (sauf cas tr�s sp�cifiques)", avertissement
--   - Sur 10% des r�f�rences, un message de priorit� al�atoire sera affich� : "Ce message sur la r�f�rence xxx a pour priorit� yyy"

------------
-- Message sur la racine : "Bonjour et bienvenue dans le mod�le de test", information
declare
    @id_carac_racine as int,
    @id_lien_carac_racine as int

select @id_carac_racine = id_caracteristique
    from mz_mdl_caracteristique
    where id_caracteristique_parent is null and id_modele_version = @id_modele_version
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('C', @id_modele_version)
select @id_lien_carac_racine = @@identity
insert into mz_mdl_lien_caracteristique (id_lien_commun, id_caracteristique, id_modele_version)
    values(@id_lien_carac_racine, @id_carac_racine, @id_modele_version)

insert into mz_mdl_message (id_modele_version, id_source_lien_commun, c_type_lien, l_libelle_long, n_priorite)
    values (@id_modele_version, @id_lien_carac_racine, 'C', 'Bonjour et bienvenue dans le mod�le de test', 4)

------------
-- Message sur "H300" : "Attention � la hauteur, car c'est tr�s haut !", alerte
declare
    @id_carac_h300 as int,
    @id_lien_carac_h300 as int

select @id_carac_h300 = id_caracteristique
    from mz_mdl_caracteristique
    where l_libelle = 'H300' and id_modele_version = @id_modele_version
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('C', @id_modele_version)
select @id_lien_carac_h300 = @@identity
insert into mz_mdl_lien_caracteristique (id_lien_commun, id_caracteristique, id_modele_version)
    values(@id_lien_carac_h300, @id_carac_h300, @id_modele_version)

insert into mz_mdl_message (id_modele_version, id_source_lien_commun, c_type_lien, l_libelle_long, n_priorite)
    values (@id_modele_version, @id_lien_carac_h300, 'C', 'Attention � la hauteur, car c''est tr�s haut !', 6)

------------
-- Message sur "L180" : "Message d'information sur la longueur L180", information
declare
    @id_carac_l180 as int,
    @id_lien_carac_l180 as int

select @id_carac_l180 = id_caracteristique
    from mz_mdl_caracteristique
    where l_libelle = 'L180' and id_modele_version = @id_modele_version
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('C', @id_modele_version)
select @id_lien_carac_l180 = @@identity
insert into mz_mdl_lien_caracteristique (id_lien_commun, id_caracteristique, id_modele_version)
    values(@id_lien_carac_l180, @id_carac_l180, @id_modele_version)

insert into mz_mdl_message (id_modele_version, id_source_lien_commun, c_type_lien, l_libelle_long, n_priorite)
    values (@id_modele_version, @id_lien_carac_l180, 'C', 'Message d''information sur la longueur L180', 4)

------------
-- Message sur "P2.2" : "Le poids le plus bas ne doit pas �tre associ� aux hauteurs hautes et aux longueurs longues (sauf cas tr�s sp�cifiques)", avertissement
declare
    @id_carac_p22 as int,
    @id_lien_carac_p22 as int

select @id_carac_p22 = id_caracteristique
    from mz_mdl_caracteristique
    where l_libelle = 'P2.2' and id_modele_version = @id_modele_version
insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
    values('C', @id_modele_version)
select @id_lien_carac_p22 = @@identity
insert into mz_mdl_lien_caracteristique (id_lien_commun, id_caracteristique, id_modele_version)
    values(@id_lien_carac_p22, @id_carac_p22, @id_modele_version)

insert into mz_mdl_message (id_modele_version, id_source_lien_commun, c_type_lien, l_libelle_long, n_priorite)
    values (@id_modele_version, @id_lien_carac_p22, 'C', 'Le poids le plus bas ne doit pas �tre associ� aux hauteurs hautes et aux longueurs longues (sauf cas tr�s sp�cifiques)', 5)

------------
-- Message sur 10% des r�f�rences, un message de priorit� al�atoire sera affich� : "Ce message sur la r�f�rence xxx a pour priorit� yyy"
declare
    @nb_msg as int

select @nb_msg = (@id_derniere_reference-@id_premiere_reference)*1/10 -- 10% des r�f�rences


declare
    @id_ref_msg as int,  -- id de la r�f�rence source
    @id_lien_ref_msg as int,  -- lien commun sur la r�f�rence
    @n_priorite as tinyint,  -- priorit�
    @i_msg as int  -- donn�e incr�ment�e pour faire les tours de la boucle de cr�ation des messages

select @i_msg = 0

while @i_msg < @nb_msg
begin
    -- Selection al�atoire de la r�f�rence
    select @id_ref_msg = @id_premiere_reference + (cast((rand()*10000) as int)%(@id_derniere_reference-@id_premiere_reference))
    
    -- D�finition al�atoire de la quantit�
    select @n_priorite = 4 + cast((rand()*10000) as int)%3

    -- On cr�e le lien commun
	insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
		values('R', @id_modele_version)
	select @id_lien_ref_msg = @@identity
	insert into mz_mdl_lien_reference (id_lien_commun, id_reference, id_modele_version)
		values(@id_lien_ref_msg, @id_ref_msg, @id_modele_version)
    
    if not exists( select id_lien_commun from mz_mdl_lien_reference where id_reference = @id_ref_msg and id_modele_version = @id_modele_version )
    begin
        insert into mz_mdl_lien_commun (c_type_lien, id_modele_version)
            values('R', @id_modele_version)
        select @id_lien_ref_msg = @@identity
        insert into mz_mdl_lien_element (id_lien_commun, id_element, id_modele_version)
            values(@id_lien_ref_msg, @id_ref_msg, @id_modele_version)
    end
    else
    begin
        if @in_existe = 1
            continue -- on ne peut pas cr�er deux fois la m�me r�gle
        select @id_lien_ref_msg = id_lien_commun from mz_mdl_lien_reference where id_reference = @id_ref_msg and id_modele_version = @id_modele_version
    end

    -- Et on ins�re le message
    insert into mz_mdl_message (id_modele_version, id_source_lien_commun, c_type_lien, n_priorite, l_libelle_long)
    select @id_modele_version, @id_lien_ref_msg, 'R', @n_priorite,
        'Ce message sur la r�f�rence [' + l_libelle_long + '] a pour priorit� '
        + case when @n_priorite = 4 then '-INFORMATION-'
               when @n_priorite = 5 then '!AVERTISSEMENT!'
               when @n_priorite = 6 then '#*^!ALERTE!^*#'
               else '???' end
        from mz_mdl_reference
        where id_reference = @id_ref_msg and id_modele_version = @id_modele_version
        

    select @i_msg += 1
end



-- *******************************************************
-- ** Affichage des r�gles et des messages

select
    case when reg.c_type_regle = 'Z' then car.l_libelle
         when reg.c_type_regle = 'T' then ref.l_libelle_long
         else '???'
         end as source,
    elt.c_element as cible, reg.c_type_regle as type, reg.n_quantite as qte, reg.n_priorite as priorite
from mz_mdl_regle reg
    left outer join mz_mdl_lien_caracteristique mlc
        on reg.id_source_lien_commun = mlc.id_lien_commun
    left outer join mz_mdl_caracteristique car
        on mlc.id_caracteristique = car.id_caracteristique
    left outer join mz_mdl_lien_reference mlr
        on reg.id_source_lien_commun = mlr.id_lien_commun
    left outer join mz_mdl_reference ref
        on mlr.id_reference = ref.id_reference
    inner join mz_mdl_lien_element mle
        on reg.id_cible_lien_commun = mle.id_lien_commun
    inner join mz_element elt
        on mle.id_element = elt.id_element
where reg.id_modele_version = @id_modele_version

select
    case when msg.c_type_lien = 'C' then car.l_libelle
         when msg.c_type_lien = 'R' then ref.l_libelle_long
         else '???'
         end as source,
    msg.c_type_lien as type, msg.l_libelle_long as msg, msg.n_priorite as priorite
from mz_mdl_message msg
    left outer join mz_mdl_lien_caracteristique mlc
        on msg.id_source_lien_commun = mlc.id_lien_commun
    left outer join mz_mdl_caracteristique car
        on mlc.id_caracteristique = car.id_caracteristique
    left outer join mz_mdl_lien_reference mlr
        on msg.id_source_lien_commun = mlr.id_lien_commun
    left outer join mz_mdl_reference ref
        on mlr.id_reference = ref.id_reference
where msg.id_modele_version = @id_modele_version

-------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------

fin:

commit tran
