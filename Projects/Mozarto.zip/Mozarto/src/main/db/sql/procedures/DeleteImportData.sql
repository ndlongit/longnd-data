
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteImportData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DeleteImportData]
GO


CREATE PROCEDURE [dbo].[DeleteImportData] 
	@IdImport INT
AS
BEGIN
--delete delete from mz_sas_import_element_erreur
delete from mz_sas_import_element_erreur 
where id_element_import in (select id_element_import from mz_sas_import_element where id_import in (select id_import from mz_sas_import where id_import = @IdImport));

--delete mz_sas_import_element
delete from mz_sas_import_element where id_import in (select id_import from mz_sas_import where id_import = @IdImport)

--delete mz_sas_import
delete from mz_sas_import where id_import = @IdImport
	
END

GO


