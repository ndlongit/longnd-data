
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ShowGetParent_Caracteristique]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ShowGetParent_Caracteristique]
GO


CREATE PROC [dbo].[ShowGetParent_Caracteristique]
(
	@Root Nvarchar(4000)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @EmpID Nvarchar(4000)
	
	INSERT #table (id_caracteristique,id_caracteristique_parent,n_rang,l_libelle)
	SELECT id_caracteristique,id_caracteristique_parent,n_rang,l_libelle FROM mz_mdl_caracteristique WHERE id_caracteristique = @Root
	
	SET @EmpID = (SELECT  ISNULL(MIN(id_caracteristique_parent),0) FROM mz_mdl_caracteristique WHERE  id_caracteristique = @Root)

	WHILE @EmpID > 0
	BEGIN
		EXEC dbo.ShowGetParent_Caracteristique @EmpID
		SET @EmpID = (SELECT ISNULL(MIN(id_caracteristique_parent),0) FROM mz_mdl_caracteristique WHERE id_caracteristique = @Root AND id_caracteristique_parent > @EmpID)
	END
	
END



GO


