
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ShowGetChildren_Caracteristique]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ShowGetChildren_Caracteristique]
GO



CREATE PROC [dbo].[ShowGetChildren_Caracteristique]
(
	@Root Nvarchar(4000)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @EmpID Nvarchar(4000)
	
	INSERT #table (id_caracteristique,id_caracteristique_parent,l_libelle,n_rang)
	SELECT id_caracteristique,id_caracteristique_parent,l_libelle,n_rang FROM mz_mdl_caracteristique WHERE id_caracteristique = @Root
	
	SET @EmpID = (SELECT MIN(id_caracteristique) FROM mz_mdl_caracteristique WHERE id_caracteristique_parent = @Root)

	WHILE @EmpID IS NOT NULL
	BEGIN
		EXEC dbo.ShowGetChildren_Caracteristique @EmpID
		SET @EmpID = (SELECT MIN(id_caracteristique) FROM mz_mdl_caracteristique WHERE id_caracteristique_parent = @Root AND id_caracteristique > @EmpID)
	END
	
END
GO


