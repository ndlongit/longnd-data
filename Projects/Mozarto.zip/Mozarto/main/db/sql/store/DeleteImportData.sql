USE [DEV_CP1_CI_AI]
GO

/****** Object:  StoredProcedure [dbo].[DeleteImportData]    Script Date: 10/08/2012 16:18:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[DeleteImportData] 
	@IdImport INT
AS
BEGIN
--delete delete from mz_sas_import_element_erreur
delete from mz_sas_import_element_erreur 
where id_element_import in (select id_element_import from mz_sas_import_element where id_import in (select id_import from mz_sas_import where id_import = @IdImport));

--delete mz_sas_import_element
delete from mz_sas_import_element where id_import in (select id_import from mz_sas_import where id_import = @IdImport)

--delete mz_sas_import
delete from mz_sas_import where id_import = @IdImport
	
END

GO

