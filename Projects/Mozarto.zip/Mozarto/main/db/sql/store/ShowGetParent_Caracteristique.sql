USE [DEV_CP1_CI_AI]
GO

/****** Object:  StoredProcedure [dbo].[ShowGetParent_Caracteristique]    Script Date: 10/08/2012 16:17:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create PROC [dbo].[ShowGetParent_Caracteristique]
(
	@Root Nvarchar(4000)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @EmpID Nvarchar(4000)
	
	INSERT #table (id_caracteristique,id_caracteristique_parent,n_rang,l_libelle)
	SELECT id_caracteristique,id_caracteristique_parent,n_rang,l_libelle FROM mz_mdl_caracteristique WHERE id_caracteristique = @Root
	
	SET @EmpID = (SELECT  ISNULL(MIN(id_caracteristique_parent),0) FROM mz_mdl_caracteristique WHERE  id_caracteristique = @Root)

	WHILE @EmpID > 0
	BEGIN
		EXEC dbo.ShowGetParent_Caracteristique @EmpID
		SET @EmpID = (SELECT ISNULL(MIN(id_caracteristique_parent),0) FROM mz_mdl_caracteristique WHERE id_caracteristique = @Root AND id_caracteristique_parent > @EmpID)
	END
	
END



GO

