USE [DEV_CP1_CI_AI]
GO

/****** Object:  StoredProcedure [dbo].[GetChildren_Caracteristique]    Script Date: 10/08/2012 16:18:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[GetChildren_Caracteristique]
(
      @List_id nvarchar(max),
      @Type nvarchar(3)
)
AS
BEGIN
 DECLARE @row int,@total int,@l_libelle varchar(50),@List varchar(2000)=@List_id
	CREATE TABLE #List (ID  int identity(1,1), item nvarchar(2000))
	CREATE TABLE #table (id_caracteristique INT,id_caracteristique_parent INT,l_libelle varchar (50),n_rang smallint)
	INSERT INTO #List (item)
	SELECT * FROM [dbo].[ufn_Split] (@List,',')
	SELECT @row=MIN(ID),@total=MAX(ID)FROM #List
 WHILE @row <=@total
	BEGIN
		SELECT @l_libelle=item	FROM #List
								WHERE ID=@row
		EXEC dbo.ShowGetChildren_Caracteristique @l_libelle
		SET @row=@row+1
	END
IF @Type='All'
  BEGIN
      SELECT * FROM #table ORDER BY id_caracteristique_parent, n_rang
  END
ELSE IF @Type='ID'
  BEGIN
     SELECT id_caracteristique FROM #table
  END
      DROP TABLE #table
END

GO

