USE [DEV_CP1_CI_AI]
GO

/****** Object:  StoredProcedure [dbo].[ShowGetChildren_Caracteristique]    Script Date: 10/08/2012 16:17:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create PROC [dbo].[ShowGetChildren_Caracteristique]
(
	@Root Nvarchar(4000)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @EmpID Nvarchar(4000)
	
	INSERT #table (id_caracteristique,id_caracteristique_parent,l_libelle,n_rang)
	SELECT id_caracteristique,id_caracteristique_parent,l_libelle,n_rang FROM mz_mdl_caracteristique WHERE id_caracteristique = @Root
	
	SET @EmpID = (SELECT MIN(id_caracteristique) FROM mz_mdl_caracteristique WHERE id_caracteristique_parent = @Root)

	WHILE @EmpID IS NOT NULL
	BEGIN
		EXEC dbo.ShowGetChildren_Caracteristique @EmpID
		SET @EmpID = (SELECT MIN(id_caracteristique) FROM mz_mdl_caracteristique WHERE id_caracteristique_parent = @Root AND id_caracteristique > @EmpID)
	END
	
END
GO

