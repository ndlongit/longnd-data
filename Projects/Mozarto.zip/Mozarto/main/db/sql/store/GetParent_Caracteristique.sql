USE [DEV_CP1_CI_AI]
GO

/****** Object:  StoredProcedure [dbo].[GetParent_Caracteristique]    Script Date: 10/08/2012 16:17:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create PROC [dbo].[GetParent_Caracteristique]
(
      @List_id nvarchar(max),
      @Type nvarchar(3)
)
AS
BEGIN
 DECLARE @row int,@total int,@l_libelle varchar(50),@List varchar(2000)=@List_id
	CREATE TABLE #List (ID  int identity(1,1), item nvarchar(2000))
	CREATE TABLE #table (id_caracteristique INT,id_caracteristique_parent INT,n_rang SMALLINT,l_libelle VARCHAR (250))
	INSERT INTO #List (item)
	 SELECT * FROM [dbo].[ufn_Split] (@List,',')
	 SELECT @row=MIN(ID),@total=MAX(ID)FROM #List
 WHILE @row <=@total
	BEGIN
		SELECT @l_libelle=item	FROM #List
								WHERE ID=@row
		EXEC dbo.ShowGetParent_Caracteristique @l_libelle
		SET @row=@row+1
	END
IF @Type='All' 
BEGIN
      SELECT DISTINCT  * FROM #table
      WHERE id_caracteristique NOT IN (  SELECT * FROM [dbo].[ufn_Split] (@List,','))
END
 ELSE IF @Type='ID'
BEGIN
    SELECT DISTINCT  id_caracteristique FROM #table
    WHERE id_caracteristique NOT IN (  SELECT * FROM [dbo].[ufn_Split] (@List,','))
END
      DROP TABLE #table
END

GO

