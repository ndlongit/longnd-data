USE [DEV_CP1_CI_AI]
GO

/****** Object:  StoredProcedure [dbo].[GetModele_Version_old]    Script Date: 10/08/2012 16:17:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[GetModele_Version_old]
(
    @ID_Metier INT,
    @SortOrder VARCHAR(50),
    @TypeSort VARCHAR(4),
    @ParameterType varchar(10)
 )
AS
CREATE TABLE #Temple (n_version smallint,id_modele int ,id_metier int,c_utilisateur varchar(50),d_dateheure_dmaj datetime,in_actif bit,l_libelle varchar(50),Max_n_version int, id_modele_version int)
INSERT INTO #Temple
SELECT * FROM 
--Get n_version =0
	(SELECT V.n_version,V.Modele_Id,M.id_metier,U.c_utilisateur AS C_utilisateur  , MV.d_dateheure_dmaj AS D_dateheure_dmaj, MV.in_actif, C.l_libelle AS L_libelle,A.Max_n_version, Modele_Version_Id 
	 FROM (SELECT n_version, id_modele AS Modele_Id,id_modele_version AS Modele_Version_Id 
			  FROM dbo.mz_mdl_version
		      GROUP BY id_modele,id_modele_version,n_version ) V 
	 INNER JOIN dbo.mz_mdl_modele M ON M.id_modele = V.Modele_Id
	 INNER JOIN dbo.mz_mdl_modele_version MV ON V.Modele_Version_Id = MV.id_modele_version 
	 INNER JOIN dbo.mz_mdl_caracteristique C ON C.id_modele_version = V.Modele_Version_Id 
	 INNER JOIN dbo.mz_utilisateur U ON U.id_utilisateur = MV.id_utilisateur_dmaj
	 INNER JOIN (
					SELECT V2.n_version, V2.Max_n_version, V2.Modele_Id, M2.id_metier
					FROM (SELECT MIN(n_version)AS n_version,MAX(n_version)AS Max_n_version, id_modele AS Modele_Id
						  FROM dbo.mz_mdl_version
						  GROUP BY id_modele) V2 
					INNER JOIN dbo.mz_mdl_modele M2 ON M2.id_modele = V2.Modele_Id		
					WHERE M2.id_metier = @ID_Metier 
					GROUP BY V2.n_version, V2.Max_n_version, V2.Modele_Id, M2.id_metier
				) AS A ON A.Modele_Id = M.id_modele
WHERE M.id_metier = @ID_Metier and C.id_caracteristique_parent is null AND V.n_version =0
GROUP BY   MV.in_actif, V.n_version,A.Max_n_version,V.Modele_Id,M.id_metier,U.c_utilisateur, MV.d_dateheure_dmaj ,C.l_libelle, V.Modele_Version_Id
UNION
--Get n_version <>0
SELECT V.n_version ,M.id_modele AS Modele_Id, M.id_metier, U.c_utilisateur AS C_utilisateur, MV.d_dateheure_dmaj AS D_dateheure_dmaj, MV.in_actif, C.l_libelle AS L_libelle,n_version AS Max_n_version, V.id_modele_version
FROM dbo.mz_mdl_version AS V
		INNER JOIN dbo.mz_mdl_modele AS M ON M.id_modele = V.id_modele
		INNER JOIN dbo.mz_mdl_modele_version AS MV ON V.id_modele_version = MV.id_modele_version 
		INNER JOIN dbo.mz_mdl_caracteristique AS C ON C.id_modele_version = V.id_modele_version 
		INNER JOIN dbo.mz_utilisateur AS U ON U.id_utilisateur = MV.id_utilisateur_dmaj
WHERE M.id_metier = @ID_Metier AND  C.id_caracteristique_parent IS NULL AND V.n_version <>0
GROUP BY MV.in_actif, M.id_modele,V.n_version, M.id_metier, U.c_utilisateur, MV.d_dateheure_dmaj, C.l_libelle, V.id_modele_version) AS T	
	
-- Process order of n_version 0 and n to 1 (ex: 0, 5, 4, 3, 2, 1)
CREATE TABLE #Final_Temple (n_version smallint,id_modele int ,id_metier int,c_utilisateur varchar(50),d_dateheure_dmaj datetime,in_actif bit,l_libelle varchar(50),Max_n_version int, id_modele_version int)
CREATE TABLE #Final_Temple1 (n_version smallint,id_modele int ,id_metier int,c_utilisateur varchar(50),d_dateheure_dmaj datetime,in_actif bit,l_libelle varchar(50),Max_n_version int, id_modele_version int)
CREATE TABLE #Final_Temple2 (n_version smallint,id_modele int ,id_metier int,c_utilisateur varchar(50),d_dateheure_dmaj datetime,in_actif bit,l_libelle varchar(50),Max_n_version int, id_modele_version int)
--Get in_actif=1 for order by with n_version =0 and <>0 innsert into table @Temple_Model_Id1
DECLARE @Temple_Model_Id1 int
DECLARE cursor_Temple_Model_Id1 CURSOR FOR 
	SELECT id_modele FROM #Temple 
	WHERE in_actif = 1 AND n_version = 0
	ORDER BY CASE WHEN @SortOrder='lLibelle' AND @TypeSort='DESC' 
			           THEN l_libelle + CONVERT(NVARCHAR,d_dateheure_dmaj, 112) + CONVERT(NVARCHAR(30),Max_n_version)	   
			           
		          WHEN @SortOrder='dDateheureCrea' AND @TypeSort='DESC' 
			           THEN CONVERT(NVARCHAR,d_dateheure_dmaj, 112) + L_libelle + CONVERT(NVARCHAR(30),Max_n_version)   
			           
		          WHEN @SortOrder='pubVersion' AND @TypeSort='DESC' 
			           THEN CONVERT(NVARCHAR(30),Max_n_version) + L_libelle + CONVERT(NVARCHAR,d_dateheure_dmaj, 112)  
			             
		          WHEN @SortOrder='cUtilisateur' AND @TypeSort='DESC' 
			           THEN C_utilisateur + L_libelle + CONVERT(NVARCHAR,d_dateheure_dmaj, 112) + CONVERT(NVARCHAR(30),Max_n_version) END DESC, 
				  
			CASE WHEN @SortOrder='lLibelle' AND @TypeSort='ASC' 
				  THEN l_libelle + CONVERT(NVARCHAR, d_dateheure_dmaj, 112) END ASC,
				  
			--CASE WHEN @SortOrder='dDateheureCrea' AND @TypeSort='ASC' 
			----	  THEN  Max_n_version END DESC,
			CASE WHEN @SortOrder='dDateheureCrea' AND @TypeSort='ASC' 
				  THEN  CONVERT(NVARCHAR,d_dateheure_dmaj, 112) + L_libelle END ASC,
			CASE WHEN @SortOrder='pubVersion' AND @TypeSort='ASC' 
				  THEN  Max_n_version END DESC,	
			CASE WHEN @SortOrder='pubVersion' AND @TypeSort='ASC' 
				  THEN  CONVERT(NVARCHAR(30),Max_n_version) + L_libelle END ASC,
			CASE WHEN @SortOrder='cUtilisateur' AND @TypeSort='ASC'
				  THEN Max_n_version END DESC,
			CASE WHEN @SortOrder='cUtilisateur' AND @TypeSort='ASC' 
				  THEN  C_utilisateur + L_libelle + CONVERT(NVARCHAR,d_dateheure_dmaj, 112)END ASC
	
OPEN cursor_Temple_Model_Id1
FETCH NEXT FROM cursor_Temple_Model_Id1 INTO @Temple_Model_Id1
WHILE @@FETCH_STATUS = 0
BEGIN
	IF NOT EXISTS(SELECT * FROM #Final_Temple1 WHERE id_modele = @Temple_Model_Id1)
	BEGIN
		INSERT INTO #Final_Temple1     
		SELECT n_version, id_modele, id_metier, c_utilisateur, d_dateheure_dmaj, in_actif,
				(
				--Get libelle of max_n_version innsert into n_version=0 group by id_modele
				SELECT  TOP(1) C2.l_libelle  
				FROM dbo.mz_mdl_caracteristique AS C2 
				INNER JOIN dbo.mz_mdl_version AS V2 ON V2.id_modele_version = C2.id_modele_version
				WHERE V2.n_version = (
										SELECT MAX(V3.n_version)
										FROM dbo.mz_mdl_version AS V3 
										WHERE V3.id_modele = @Temple_Model_Id1 GROUP BY V3.id_modele
									 )
				AND C2.id_caracteristique_parent IS NULL AND V2.id_modele = @Temple_Model_Id1),
				Max_n_version, id_modele_version 
		FROM #Temple
		WHERE id_modele = @Temple_Model_Id1 AND n_version = 0 AND in_actif = 1				

		INSERT INTO #Final_Temple1	 
		SELECT * FROM #Temple AS T4
		WHERE T4.id_modele = @Temple_Model_Id1 AND T4.n_version <> 0 AND in_actif = 1
		ORDER BY T4.n_version DESC
	END	

	FETCH NEXT FROM cursor_Temple_Model_Id1 INTO @Temple_Model_Id1	
END
CLOSE cursor_Temple_Model_Id1
DEALLOCATE cursor_Temple_Model_Id1
--Get in_actif=0 for order by with n_version =0 and <>0 innsert into table @Temple_Model_Id2
DECLARE @Temple_Model_Id2 int
DECLARE cursor_Temple_Model_Id2 CURSOR FOR 
	SELECT id_modele FROM #Temple WHERE in_actif = 0 AND n_version = 0
	ORDER BY CASE WHEN @SortOrder='lLibelle' AND @TypeSort='DESC' 
			           THEN L_libelle + CONVERT(NVARCHAR,d_dateheure_dmaj, 112) + CONVERT(NVARCHAR(30),Max_n_version)
			           	   
				  WHEN @SortOrder='dDateheureCrea' AND @TypeSort='DESC' 
			         THEN  CONVERT(NVARCHAR,d_dateheure_dmaj, 112) + L_libelle + CONVERT(NVARCHAR(30),Max_n_version)  
			         
		          WHEN @SortOrder='pubVersion' AND @TypeSort='DESC' 
			          THEN  CONVERT(NVARCHAR(30),Max_n_version) + L_libelle + CONVERT(NVARCHAR,d_dateheure_dmaj, 112)   
			          
		          WHEN  @SortOrder='cUtilisateur' AND @TypeSort='DESC' 
			          THEN C_utilisateur + L_libelle + CONVERT(NVARCHAR,d_dateheure_dmaj, 112) + CONVERT(NVARCHAR(30),Max_n_version) END DESC,		
			          	  
			CASE WHEN @SortOrder='lLibelle' AND @TypeSort='ASC' 
				  THEN l_libelle + CONVERT(NVARCHAR, d_dateheure_dmaj, 112) END ASC,
				  
			--CASE WHEN @SortOrder='dDateheureCrea' AND @TypeSort='ASC' 
				  --THEN  Max_n_version END DESC,
			CASE WHEN @SortOrder='dDateheureCrea' AND @TypeSort='ASC' 
				  THEN  CONVERT(NVARCHAR,d_dateheure_dmaj, 112) + L_libelle END ASC,
				  
			CASE WHEN @SortOrder='pubVersion' AND @TypeSort='ASC' 
				  THEN  Max_n_version END DESC,
			CASE WHEN @SortOrder='pubVersion' AND @TypeSort='ASC' 
				  THEN  CONVERT(NVARCHAR(30),Max_n_version) + L_libelle END ASC,
				  
			CASE WHEN @SortOrder='cUtilisateur' AND @TypeSort='ASC'
				  THEN Max_n_version END DESC,
			CASE WHEN @SortOrder='cUtilisateur' AND @TypeSort='ASC' 
				  THEN  C_utilisateur + L_libelle + CONVERT(NVARCHAR,d_dateheure_dmaj, 112)END ASC
				  
OPEN cursor_Temple_Model_Id2
FETCH NEXT FROM cursor_Temple_Model_Id2 INTO @Temple_Model_Id2
WHILE @@FETCH_STATUS = 0
BEGIN
	IF NOT EXISTS(SELECT * FROM #Final_Temple2 WHERE id_modele = @Temple_Model_Id1)
	BEGIN		
		INSERT INTO #Final_Temple2     
		SELECT n_version, id_modele, id_metier, c_utilisateur, d_dateheure_dmaj, in_actif,
				(SELECT  TOP(1) C2.l_libelle --Get libelle of max_n_version innsert into n_version=0 group by id_modele
				FROM dbo.mz_mdl_caracteristique AS C2 
				INNER JOIN dbo.mz_mdl_version AS V2 ON V2.id_modele_version = C2.id_modele_version
				WHERE V2.n_version = (
										SELECT MAX(V3.n_version)
										FROM dbo.mz_mdl_version AS V3 
										WHERE V3.id_modele = @Temple_Model_Id2 GROUP BY V3.id_modele
									 )
				AND C2.id_caracteristique_parent IS NULL AND V2.id_modele = @Temple_Model_Id2),
				Max_n_version, id_modele_version 
		FROM #Temple
		WHERE id_modele = @Temple_Model_Id2 AND n_version = 0 AND in_actif = 0

		INSERT INTO #Final_Temple2	 
		SELECT * FROM #Temple AS T4
		WHERE T4.id_modele = @Temple_Model_Id2 AND T4.n_version <> 0 AND in_actif = 0
		ORDER BY T4.n_version DESC	
	END

	FETCH NEXT FROM cursor_Temple_Model_Id2 INTO @Temple_Model_Id2	
END
CLOSE cursor_Temple_Model_Id2
DEALLOCATE cursor_Temple_Model_Id2
--Innsert into table #Final_Temple 
IF @ParameterType='All'
	BEGIN
	
		 INSERT INTO #Final_Temple
		 SELECT * FROM #Final_Temple1
		 WHERE n_version=0			  
		 INSERT INTO #Final_Temple	   
		 SELECT * FROM #Final_Temple2
		 WHERE n_version=0
	END
ELSE
	BEGIN	
	
	     INSERT INTO #Final_Temple
		 SELECT * FROM #Final_Temple1
		 WHERE n_version=0 OR id_modele=@ParameterType		  
	     INSERT INTO #Final_Temple	   
		 SELECT * FROM #Final_Temple2
		 WHERE n_version=0 OR id_modele=@ParameterType	
		 
	END	
SELECT * FROM #Final_Temple

DROP TABLE #Temple
DROP TABLE #Final_Temple
DROP TABLE #Final_Temple1
DROP TABLE #Final_Temple2



GO

