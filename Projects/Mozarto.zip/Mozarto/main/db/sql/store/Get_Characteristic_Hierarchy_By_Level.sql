USE [DEV_CP1_CI_AI]
GO

/****** Object:  StoredProcedure [dbo].[Get_Characteristic_Hierarchy_By_Level]    Script Date: 10/08/2012 16:18:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Long.Nguyen
-- Create date: 
-- Description:	Get Characteristic Hierarchy by ParantId + Level + Label
-- =============================================
CREATE PROCEDURE [dbo].[Get_Characteristic_Hierarchy_By_Level] 
	-- Add the parameters for the stored procedure here
	@ModelVersion INT,
	@Level INT,
	@Label VARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    
	with DataTree (id_caracteristique, id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire, level) as (
    -- get root of the tree
    select
        id_caracteristique, id_modele_version, id_caracteristique_parent, n_rang, l_libelle, l_commentaire, 0
    from
        mz_mdl_caracteristique
    where
        id_caracteristique_parent is null
        and id_modele_version = @ModelVersion
    union all
    -- do a recursive lookup
    select
        child.id_caracteristique, child.id_modele_version, child.id_caracteristique_parent, child.n_rang, child.l_libelle, child.l_commentaire, level + 1
    from
        mz_mdl_caracteristique as child
            inner join
        DataTree
            on
        DataTree.id_caracteristique = child.id_caracteristique_parent
)
select * from DataTree
WHERE level = @Level
AND UPPER(l_libelle) = UPPER(@Label)
ORDER BY Level        
    
END

GO

