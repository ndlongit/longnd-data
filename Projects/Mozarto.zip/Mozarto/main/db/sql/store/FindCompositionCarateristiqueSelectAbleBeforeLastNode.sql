USE [DEV_CP1_CI_AI]
GO

/****** Object:  StoredProcedure [dbo].[FindCompositionCarateristiqueSelectAbleBeforeLastNode]    Script Date: 10/08/2012 16:18:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 CREATE  PROC [dbo].[FindCompositionCarateristiqueSelectAbleBeforeLastNode]
(
      @id_modele_version INT
)
AS
BEGIN
	SELECT C1.id_caracteristique,C1.id_caracteristique_parent,C1.id_modele_version,C1.l_libelle,C1.n_rang,
		   C2.id_caracteristique AS c_id_caracteristique,C2.id_modele_version AS c_id_modele_version,C2.l_libelle AS c_l_libelle,C2.n_rang AS c_n_rang 
    FROM mz_mdl_caracteristique   AS  C1 INNER JOIN mz_mdl_caracteristique AS C2 
    ON C1.id_caracteristique = C2.id_caracteristique_parent
    AND C2.id_caracteristique  IN (SELECT DISTINCT id_caracteristique 
								   FROM mz_mdl_caracteristique 
								   WHERE id_modele_versiON = @id_modele_version 
								   AND id_caracteristique NOT IN (SELECT DISTINCT id_caracteristique_parent 
													              FROM mz_mdl_caracteristique 
											                      WHERE id_modele_version = @id_modele_version AND id_caracteristique_parent IS NOT NULL))
    WHERE  C1.id_modele_version = @id_modele_version
	       AND C1.id_caracteristique IN (SELECT DISTINCT id_caracteristique_parent 
	                                     FROM mz_mdl_caracteristique 
	                                     WHERE id_modele_version = @id_modele_version AND id_caracteristique_parent IS NOT NULL)
	ORDER BY C1.n_rang
END
GO

