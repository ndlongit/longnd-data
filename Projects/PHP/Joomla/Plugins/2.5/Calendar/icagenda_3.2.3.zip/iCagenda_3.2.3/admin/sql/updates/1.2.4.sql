UPDATE `#__icagenda` SET version='1.2.4' WHERE id=1;
