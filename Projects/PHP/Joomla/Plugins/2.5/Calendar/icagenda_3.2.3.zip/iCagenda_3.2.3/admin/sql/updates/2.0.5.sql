UPDATE `#__icagenda` SET version='2.0.5', releasedate='2013-02-01' WHERE id=1;
