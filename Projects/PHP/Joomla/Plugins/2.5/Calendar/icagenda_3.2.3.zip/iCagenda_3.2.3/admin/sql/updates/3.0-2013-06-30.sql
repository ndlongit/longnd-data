UPDATE `#__icagenda` SET version='3.0 RC', releasedate='2013-06-30' WHERE id=2;
