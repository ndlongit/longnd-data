UPDATE `#__icagenda` SET version='3.2.0 RC4', releasedate='2013-10-04' WHERE id=2;
