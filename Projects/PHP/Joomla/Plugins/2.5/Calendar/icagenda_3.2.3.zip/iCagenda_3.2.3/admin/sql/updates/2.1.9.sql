UPDATE `#__icagenda` SET version='2.1.9', releasedate='2013-05-03' WHERE id=1;
