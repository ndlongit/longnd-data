UPDATE `#__icagenda` SET version='3.0 Alpha', releasedate='2013-06-04' WHERE id=1;
