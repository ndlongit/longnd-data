UPDATE `#__icagenda` SET version='1.2.6 beta1', releasedate='2012-10-09' WHERE id=1;


