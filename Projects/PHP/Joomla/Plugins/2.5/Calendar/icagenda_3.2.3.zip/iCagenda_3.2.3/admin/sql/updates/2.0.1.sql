UPDATE `#__icagenda` SET version='2.0.1 RC', releasedate='2013-01-01' WHERE id=1;
