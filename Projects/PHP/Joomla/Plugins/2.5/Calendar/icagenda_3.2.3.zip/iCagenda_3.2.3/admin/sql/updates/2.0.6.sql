UPDATE `#__icagenda` SET version='2.0.6', releasedate='2013-02-07' WHERE id=1;
