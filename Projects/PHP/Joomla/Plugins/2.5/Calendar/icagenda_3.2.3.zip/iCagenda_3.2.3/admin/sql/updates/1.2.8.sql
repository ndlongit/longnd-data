UPDATE `#__icagenda` SET version='1.2.8', releasedate='2012-10-22' WHERE id=1;


