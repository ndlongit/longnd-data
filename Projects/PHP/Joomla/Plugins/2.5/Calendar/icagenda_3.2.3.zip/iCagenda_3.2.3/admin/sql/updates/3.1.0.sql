UPDATE `#__icagenda` SET version='3.1.0', releasedate='2013-07-26' WHERE id=2;
