DROP TABLE IF EXISTS `#__icagenda_category`;
DROP TABLE IF EXISTS `#__icagenda_events`;
DROP TABLE IF EXISTS `#__icagenda_registration`;
DROP TABLE IF EXISTS `#__icagenda_location`;
DROP TABLE IF EXISTS `#__icagenda`;