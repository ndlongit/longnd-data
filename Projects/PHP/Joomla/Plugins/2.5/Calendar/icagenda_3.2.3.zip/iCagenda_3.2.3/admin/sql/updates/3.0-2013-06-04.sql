UPDATE `#__icagenda` SET version='3.0 Alpha 1', releasedate='2013-06-04' WHERE id=1;
