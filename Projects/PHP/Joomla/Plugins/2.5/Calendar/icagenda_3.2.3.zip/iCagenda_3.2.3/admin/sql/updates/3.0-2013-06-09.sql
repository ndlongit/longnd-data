INSERT INTO `#__icagenda` (id,version,releasedate) VALUES (2,'3.0 Beta 1','2013-06-09');
