UPDATE `#__icagenda` SET version='3.1.2', releasedate='2013-08-05' WHERE id=2;
