UPDATE `#__icagenda` SET version='1.3 beta2', releasedate='2012-12-15' WHERE id=1;
