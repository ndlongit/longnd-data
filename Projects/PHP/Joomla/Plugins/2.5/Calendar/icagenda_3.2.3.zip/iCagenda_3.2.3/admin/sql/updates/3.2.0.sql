UPDATE `#__icagenda` SET version='3.2.0 RC', releasedate='2013-09-20' WHERE id=2;
