UPDATE `#__icagenda` SET version='1.2.6 beta3', releasedate='2012-10-13' WHERE id=1;


