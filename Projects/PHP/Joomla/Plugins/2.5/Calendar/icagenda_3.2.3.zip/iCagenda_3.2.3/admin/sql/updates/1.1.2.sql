UPDATE `#__icagenda` SET version='1.1.2' WHERE id=1;
