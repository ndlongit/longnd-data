<?php
defined('_JEXEC') or die;

require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'functions.php';

// Create alias for $this object reference:
$document = & $this;

// Shortcut for template base url:
$templateUrl = $document->baseurl . '/templates/' . $document->template;

// Initialize $view:
$view = $this->artx = new ArtxPage($this);

$view->componentWrapper();

$app                = JFactory::getApplication();
$templateparams     = $app->getTemplate(true)->params;
// logo text var

$show_header                = ($this->params->get("showHeader", 1)  == 0)?"false":"true";
$show_logo                  = ($this->params->get("showLogo", 1)  == 0)?"false":"true";
$logoText = (trim($this->params->get('textoflogo'))=='') ? $config->sitename :  $this->params->get('textoflogo');
$sloganText = (trim($this->params->get('textofslogan'))=='') ? $config->sitename :  $this->params->get('textofslogan');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $document->language; ?>" lang="<?php echo $document->language; ?>" dir="ltr">
<head>
<jdoc:include type="head" />
<link rel="stylesheet" href="<?php echo $document->baseurl; ?>/templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $document->baseurl; ?>/templates/system/css/general.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo $templateUrl; ?>/css/template.css" media="screen" />
<!--[if IE 6]><link rel="stylesheet" href="<?php echo $templateUrl; ?>/css/template.ie6.css" type="text/css" media="screen" /><![endif]-->
<!--[if IE 7]><link rel="stylesheet" href="<?php echo $templateUrl; ?>/css/template.ie7.css" type="text/css" media="screen" /><![endif]-->
<script type="text/javascript">if ('undefined' != typeof jQuery) document._artxJQueryBackup = jQuery;</script>
<script type="text/javascript" src="<?php echo $templateUrl; ?>/jquery.js"></script>
<script type="text/javascript">jQuery.noConflict();</script>
<script type="text/javascript" src="<?php echo $templateUrl; ?>/script.js"></script>
<script type="text/javascript">if (document._artxJQueryBackup) jQuery = document._artxJQueryBackup;</script>
</head>
<body>
<div id="td-main">
<div class="cleared reset-box"></div>
<?php if ($view->containsModules('mainmenu', 'extra1', 'extra2')) : ?>
<div class="td-bar td-nav">
<div class="td-nav-outer">
<div class="td-nav-wrapper">
<div class="td-nav-inner">
<?php if ($view->containsModules('extra1')) : ?>
<div class="td-hmenu-extra1"><?php echo $view->position('extra1'); ?></div>
<?php endif; ?>
<?php if ($view->containsModules('extra2')) : ?>
<div class="td-hmenu-extra2"><?php echo $view->position('extra2'); ?></div>
<?php endif; ?>
<?php echo $view->position('mainmenu'); ?>
</div>
</div>
</div>
</div>
<div class="cleared reset-box"></div>
<?php endif; ?>

<?php if($templateparams->get('show-header',1)) : ?>
<?php if (JRequest::getVar('view') == 'featured') : ?>
<div class="td-header">
<object type="application/x-shockwave-flash" data="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/header/header.swf" width="100%" height="250">
<param name="wmode" value="transparent" />
<param name="movie" value="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/header/header.swf" />
</object>
<!-- BEGIN: LOGO -->
<?php if($templateparams->get('logoType')=='image'): ?>
<div id="logo"><a href="index.php"><img src="<?php echo $templateUrl; ?>/images/logo.png" alt="" /></a></div>
<?php else: ?>
<div class="td-logo">
<h1 class="td-logo-name"><a href="<?php echo $document->baseurl; ?>/"><?php echo $this->params->get('textoflogo'); ?></a></h1>
<h2 class="td-logo-text"><?php echo $this->params->get('textofslogan'); ?></h2>
</div>
<?php endif; ?>
<!-- END: LOGO -->
</div>
<?php else: ?>
<div class="td-header1">
<!-- BEGIN: LOGO -->
<?php if($show_logo == "true") : ?>
<div id="logo">
<a href="<?php echo $mosConfig_live_site;?>">
<img src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/images/logo.png" alt="" />
</a>
</div>
<?php endif; ?>
<!-- END: LOGO -->
</div>
<?php endif; ?>
<?php else: ?>
<div class="td-header">
<object type="application/x-shockwave-flash" data="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/header/header.swf" width="100%" height="250">
<param name="wmode" value="transparent" />
<param name="movie" value="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/header/header.swf" />
</object>
<!-- BEGIN: LOGO -->
<?php if($templateparams->get('logoType')=='image'): ?>
<div id="logo"><a href="index.php"><img src="<?php echo $templateUrl; ?>/images/logo.png" alt="" /></a></div>
<?php else: ?>
<div class="td-logo">
<h1 class="td-logo-name"><a href="<?php echo $document->baseurl; ?>/"><?php echo $this->params->get('textoflogo'); ?></a></h1>
<h2 class="td-logo-text"><?php echo $this->params->get('textofslogan'); ?></h2>
</div>
<?php endif; ?>
<!-- END: LOGO -->
</div>
<?php endif; ?>
<div class="cleared reset-box"></div>
<div class="td-box td-sheet">
<div class="td-box-body td-sheet-body">
<?php echo $view->position('banner1', 'td-nostyle'); ?>
<?php echo $view->positions(array('top1' => 33, 'top2' => 33, 'top3' => 34), 'td-block'); ?>
<div class="td-layout-wrapper">
<div class="td-content-layout">
<div class="td-content-layout-row">
<div class="td-layout-cell td-content">

<?php
echo $view->position('banner2', 'td-nostyle');
if ($view->containsModules('breadcrumb'))
echo artxPost($view->position('breadcrumb'));
echo $view->positions(array('user1' => 50, 'user2' => 50), 'td-article');
echo $view->position('banner3', 'td-nostyle');
if ($view->hasMessages())
echo artxPost('<jdoc:include type="message" />');
echo '<jdoc:include type="component" />';
echo $view->position('user3', 'td-block');
echo $view->positions(array('user4' => 50, 'user5' => 50), 'td-article');
echo $view->position('banner5', 'td-nostyle');
?>

<div class="cleared"></div>
</div>
<?php if ($view->containsModules('right')) : ?>
<div class="td-layout-cell td-sidebar1">
<?php echo $view->position('right', 'td-block'); ?>

<div class="cleared"></div>
</div>
<?php endif; ?>

</div>
</div>
</div>
<div class="cleared"></div>


<?php echo $view->positions(array('user7' => 33, 'user8' => 33, 'user9' => 34), 'td-block'); ?>
<?php echo $view->position('banner6', 'td-nostyle'); ?>
<div class="td-footer">
<div class="td-footer-body">
<?php echo $view->position('syndicate'); ?>
<div class="td-footer-text">
<?php if ($view->containsModules('copyright')): ?>
<?php echo $view->position('copyright', 'td-nostyle'); ?>
<?php else: ?>
<?php ob_start(); ?>

<p><?php include (dirname(__FILE__).DS.'/footer.php');?></p>

<?php echo str_replace('%YEAR%', date('Y'), ob_get_clean()); ?>
<?php endif; ?>
</div>
<div class="cleared"></div>
</div>
</div>

<div class="cleared"></div>
</div>
</div>
<div class="cleared"></div>
<p class="td-page-footer"></p>

<div class="cleared"></div>
</div>

<?php echo $view->position('debug'); ?>
</body>
</html>