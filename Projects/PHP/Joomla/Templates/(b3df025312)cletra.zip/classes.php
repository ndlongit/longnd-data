<?php
defined('_JEXEC') or die;

require_once dirname(__FILE__) . '/classes/ArtxPage.php';
require_once dirname(__FILE__) . '/classes/ArtxContent.php';
require_once dirname(__FILE__) . '/classes/ArtxContentArticleBase.php';
require_once dirname(__FILE__) . '/classes/ArtxContentArchivedArticle.php';
require_once dirname(__FILE__) . '/classes/ArtxContentItem.php';
require_once dirname(__FILE__) . '/classes/ArtxContentSingleArticle.php';
require_once dirname(__FILE__) . '/classes/ArtxContentListItem.php';
require_once dirname(__FILE__) . '/classes/ArtxContentCategoryArticle.php';
require_once dirname(__FILE__) . '/classes/ArtxContentFeaturedArticle.php';
