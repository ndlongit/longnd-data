//JS script for Joomla template
window.addEvent('load', function(){

	var StyleCookie = new Hash.Cookie('JVMiraStyleCookieSite');
	var settings = { colors: '' };
	var style_1, style_2, style_3;
	//new Asset.css(StyleCookie.get('colors'));

	/* Style 1 */
	if($('jvcolor1')){$('jvcolor1').addEvent('click', function(e) {
		e = new Event(e).stop();
		if (style_1) style_1.remove();
		new Asset.css(jvpathcolor + 'brown.css', {id: 'brown'});
		style_1 = $('brown');
		settings['colors'] = jvpathcolor + 'brown.css';
		StyleCookie.empty();
		StyleCookie.extend(settings);
	});}

	/* Style 2 */
	if($('jvcolor2')){$('jvcolor2').addEvent('click', function(e) {
		e = new Event(e).stop();
		if (style_2) style_2.remove();
		new Asset.css(jvpathcolor + 'blue.css', {id: 'blue'});
		style_2 = $('blue');
		settings['blue'] = jvpathcolor + 'blue.css';
		StyleCookie.empty();
		StyleCookie.extend(settings);
	});}

	/* Style 3 */
	if($('jvcolor3')){$('jvcolor3').addEvent('click', function(e) {
		e = new Event(e).stop();
		if (style_3) style_3.remove();
		new Asset.css(jvpathcolor + 'orange.css', {id: 'orange'});
		style_3 = $('orange');
		settings['colors'] = jvpathcolor + 'orange.css';
		StyleCookie.empty();
		StyleCookie.extend(settings);
	});}

});

function JV_FullHeight() {
	if($('jv-left')) {
		var left_col = $('jv-left');
		var content_col = $('jv-middle');
		var left_height = left_col.getCoordinates().height;
		var content_height = content_col.getCoordinates().height;
		var maxheight = content_height;
		if(content_height < left_height) {
			maxheight = left_height
			$('jv-middle-inner2').setStyle('height',maxheight);
		}
	}
}

window.addEvent ('load', function() {
	setInterval (JV_FullHeight,1000);
});