<?php
/**
 * @copyright	Copyright (C) 2008 - 2009 JoomVision.com. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
include_once (dirname(__FILE__).DS.'libs'.DS.'jv_tools.php');
include_once (dirname(__FILE__).DS.'jv_menus'.DS.'jv.common.php');
include_once (dirname(__FILE__).DS.'libs'.DS.'jv_vars.php');
unset($this->_scripts[$this->baseurl . '/media/system/js/caption.js']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>">
<head>
<jdoc:include type="head" />
<?php JHTML::_('behavior.mootools'); ?>
<link rel="stylesheet" href="<?php echo $jvTools->baseurl() ; ?>templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $jvTools->baseurl() ; ?>templates/system/css/general.css" type="text/css" />

	<?php if($jvTools->getParam('jv_google_fonts')) : ?>
	<link href="http://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet" type="text/css" />
	<link href='http://fonts.googleapis.com/css?family=OFL+Sorts+Mill+Goudy+TT&amp;subset=latin' rel='stylesheet' type='text/css' />
	<link href='http://fonts.googleapis.com/css?family=Vollkorn&amp;subset=latin' rel='stylesheet' type='text/css' />
	<?php endif; ?>

	<?php if($gzip == "true") : ?>
		<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/template.css.php?rtl=<?php if($jvrtl == 'rtl'){echo '1';}else{echo '0';}; ?>&googlefont=<?php if($jvTools->getParam('jv_google_fonts')){echo '1';}else{echo '0';} ?>" type="text/css" />
	<?php else: ?>
		<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/default.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/template.css" type="text/css" />

		<?php if($jvrtl == 'rtl') : ?>
		<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/template_rtl.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/typo_rtl.css" type="text/css" />
		<?php else : ?>
		<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/typo.css" type="text/css" />
		<?php endif; ?>

		<?php if($jvTools->getParam('jv_google_fonts')) : ?>
		<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/googlefonts.css" type="text/css" />
		<?php endif; ?>
	<?php endif; ?>
	<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/css3.php?url=<?php echo $jvTools->templateurl(); ?>" type="text/css" />
	<link href="<?php echo $jvTools->parse_jvcolor_cookie($jvcolorstyle); ?>" rel="stylesheet" type="text/css" />
	<script type="text/javascript">
		var baseurl = "<?php echo $jvTools->baseurl() ; ?>";
		var jvpathcolor = '<?php echo $jvTools->templateurl(); ?>css/colors/';
		var tmplurl = '<?php echo $jvTools->templateurl();?>';
		var CurrentFontSize = parseInt('<?php echo $jvTools->getParam('jv_font');?>');
	</script>
	<script type="text/javascript" src="<?php echo $jvTools->templateurl() ?>js/jv.script.js"></script>
	<!--[if lte IE 6]>
	<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/ie6.css" type="text/css" />
	<script type="text/javascript" src="<?php echo $jvTools->templateurl() ?>js/ie_png.js"></script>
	<script type="text/javascript">
	window.addEvent ('load', function() {
	   ie_png.fix('.png');
	});
	</script>
	<![endif]-->
	<!--[if lte IE 7]>
	<link rel="stylesheet" href="<?php echo $jvTools->templateurl(); ?>css/ie7.css" type="text/css" />
	<![endif]-->
</head>
<body id="bd" class="fs<?php echo $jvTools->getParam('jv_font'); ?> <?php echo $jvTools->getParam('jv_display'); ?> <?php echo $jvTools->getParam('jv_display_style'); ?> <?php echo $jvrtl; ?>">
<div id="jv-wrapper">
	<div id="jv-wrapper-inner">

		<?php if($this->countModules('topmenu') || $this->countModules('search') || $jvTools->getParam('jv_time')) : ?>
		<div id="jv-userwrap1" class="clearfix">
			<div class="jv-wrapper">
				<div id="jv-userwrap1-inner">
					<?php if($jvTools->getParam('jv_time')) : ?>
					<div id="jv-time"><?php echo @date('l, F d, Y'); ?></div>
					<?php endif; ?>
					<?php if($this->countModules('search')) : ?>
					<div id="jv-search">
						<jdoc:include type="modules" name="search" />
					</div>
					<?php endif; ?>
					<?php if($this->countModules('topmenu')) : ?>
					<div id="jv-topmenu">
						<jdoc:include type="modules" name="topmenu" />
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php endif; ?>
		
		<!-- HEADER -->
		<div id="jv-header" class="clearfix">
		<div id="jv-header2">
			<div class="jv-wrapper">	
				<div id="jv-header-inner">
					<div id="jv-logo">
						<h1 id="logo"><a class="png" href="<?php echo $jvTools->baseurl() ; ?>" title="<?php echo $jvTools->sitename() ; ?>">
							<span><?php echo $jvTools->sitename() ; ?></span></a>
						</h1>
					</div>
					<?php if($this->countModules('login')) : ?>
					<div id="jv-login"><jdoc:include type="modules" name="login" /></div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		</div>
		<!-- END HEADER -->
		
		<div id="jv-mainmenu" class="clearfix">
			<div class="jv-wrapper">
				<div id="jv-mainmenu-inner">
					<?php $menu->show(); ?>
				</div>
			</div>
		</div>	

		<div id="jv-mainframe" class="clearfix">
		<div id="jv-mainframe-inner">

			<?php if($this->countModules('breadcrumb')) : ?>
			<div id="jv-breadcrumb" class="clearfix">
				<div class="jv-wrapper">
					<div id="jv-breadcrumb-inner">
						<strong><?php echo JText::_('YOU ARE HERE')?></strong> <jdoc:include type="modules" name="breadcrumb" />
					</div>
				</div>
			</div>
			<?php endif; ?>

			<?php if($this->countModules('slideshow')) : ?>							
			<div id="jv-slideshow" class="clearfix">
				<div class="jv-wrapper">
					<div id="jv-slideshow-inner">
					<div id="jv-slideshow-inner2">
						<jdoc:include type="modules" name="slideshow" />
					</div>
					</div>
				</div>
			</div>
			<?php endif; ?>

			<?php
			$spotlight = array ('user1','user2','user3','user4');
			$consl = $jvTools->calSpotlight($spotlight,$jvTools->isOP()?100:100,'%');
			if( $consl) :
			?>	
			<div id="jv-userwrap2" class="clearfix">
				<div class="jv-wrapper">
					<div id="jv-userwrap2-inner">
					
						<?php if($this->countModules('user1')) : ?>
						<div id="jv-user1" class="jv-user jv-box<?php echo $consl['user1']['class']; ?>" style="width: <?php echo $consl['user1']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user1" style="jvxhtml2" />
							</div>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('user2')) : ?>
						<div id="jv-user2" class="jv-user jv-box<?php echo $consl['user2']['class']; ?>" style="width: <?php echo $consl['user2']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user2" style="jvxhtml2" />
							</div>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('user3')) : ?>
						<div id="jv-user3" class="jv-user jv-box<?php echo $consl['user3']['class']; ?>" style="width: <?php echo $consl['user3']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user3" style="jvxhtml2" />
							</div>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('user4')) : ?>
						<div id="jv-user4" class="jv-user jv-box<?php echo $consl['user4']['class']; ?>" style="width: <?php echo $consl['user4']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user4" style="jvxhtml2" />
							</div>
						</div>
						<?php endif; ?>
						
					</div>
				</div>
			</div>
			<?php endif; ?>
			
			<!-- MAINBODY -->
			<div id="jv-mainbody" class="clearfix">
				<div class="jv-wrapper">
					<div id="jv-mainbody-inner">
					
						<!-- CONTAINER -->
						<div id="jv-container<?php echo $jv_width; ?>" class="clearfix">
							<div id="jv-content">
								
								<?php if($this->countModules('left')) : ?>
								<div id="jv-left">
									<div id="jv-left-inner">
										<jdoc:include type="modules" name="left" style="jvxhtml" />
									</div>
								</div>
								<?php endif; ?>

								<div id="jv-middle">
									<div id="jv-shadow-l"></div>
									<div id="jv-shadow-r"></div>
								<div id="jv-middle-inner">
								<div id="jv-middle-inner2">

									<?php if($this->countModules('top')) : ?>
									<div id="jv-top">
										<div id="jv-top-inner">
											<jdoc:include type="modules" name="top" />
										</div>
									</div>
									<?php endif; ?>

									<div id="jv-contentright" class="clearfix">

										<div id="jv-maincontent">
										<div id="jv-maincontent-inner">
										
											<?php if($this->countModules('user5')) : ?>
												<div id="jv-user5" class="clearfix">
													<jdoc:include type="modules" name="user5" style="jvxhtml2" />
												</div>
											<?php endif; ?>
												
											<div id="jv-component" class="clearfix">
												<jdoc:include type="message" />
												<jdoc:include type="component" />
											</div>

										   <?php if($this->countModules('user6')) : ?>
											   <div id="jv-user6" class="clearfix">
													<jdoc:include type="modules" name="user6" style="jvxhtml2" />
											   </div>
											<?php endif; ?>
											
											<?php
											$spotlight = array ('col1','col2','col3');
											$botsl1 = $jvTools->calSpotlight($spotlight,$jvTools->isOP()?100:99,'%');
											if( $botsl1 ) :
											?>
											<div id="jv-col" class="clearfix">
													
												<?php if($this->countModules('col1')) : ?>
													<div id="jv-col1" class="jv-user jv-box<?php echo $botsl1['col1']['class']; ?>" style="width: <?php echo $botsl1['col1']['width']; ?>;">
														<div class="jv-box-inside">
															<jdoc:include type="modules" name="col1" style="jvxhtml" />
														</div>
													</div>
												<?php endif; ?>
												
												<?php if($this->countModules('col2')) : ?>
													<div id="jv-col2" class="jv-user jv-box<?php echo $botsl1['col2']['class']; ?>" style="width: <?php echo $botsl1['col2']['width']; ?>;">
														<div class="jv-box-inside">
															<jdoc:include type="modules" name="col2" style="jvxhtml" />
														</div>
													</div>
												<?php endif; ?>
												
												<?php if($this->countModules('col3')) : ?>
													<div id="jv-col3" class="jv-user jv-box<?php echo $botsl1['col3']['class']; ?>" style="width: <?php echo $botsl1['col3']['width']; ?>;">
														<div class="jv-box-inside">
															<jdoc:include type="modules" name="col3" style="jvxhtml" />
														</div>
													</div>
												<?php endif; ?>
												
											</div>		
											<?php endif; ?>
											
										</div>
										</div>

										<?php if($this->countModules('right')) : ?>
										<div id="jv-right">
											<div id="jv-right-inner">
												<jdoc:include type="modules" name="right" style="jvxhtml" />
											</div>
										</div>
										<?php endif; ?>

									</div>

									<?php if($this->countModules('inset')) : ?>
									<div id="jv-inset" class="clearfix">
										<div id="jv-inset-inner">
											<jdoc:include type="modules" name="inset" style="jvxhtml"/>
										</div>
									</div>
									<?php endif; ?>

									<?php
									$spotlight = array ('user7','user8','user9','user10');
									$botsl2 = $jvTools->calSpotlight($spotlight,$jvTools->isOP()?100:100, '%');
									if( $botsl2 ) :
									?>	
									<div id="jv-userwrap3" class="clearfix spotlight<?php echo $jvTools->countSpotlight($spotlight); ?>">
										<div id="jv-userwrap3-inner">

											<?php if($this->countModules('user7')): ?>
												<div id="jv-user7" class="jv-user jv-box<?php echo $botsl2['user7']['class']; ?>" style="width:<?php echo $botsl2['user7']['width']; ?>;">
													<div class="jv-box-inside">
														<jdoc:include type="modules" name="user7" style="jvxhtml" />
													</div>
												</div>
											<?php endif; ?>
												
											<?php if($this->countModules('user8')) : ?>
												<div id="jv-user8" class="jv-user jv-box<?php echo $botsl2['user8']['class']; ?>" style="width:<?php echo $botsl2['user8']['width']; ?>;">
													<div class="jv-box-inside">
														<jdoc:include type="modules" name="user8" style="jvxhtml" />
													</div>
												</div>
											<?php endif; ?>
												
											<?php if($this->countModules('user9')) : ?>
												<div id="jv-user9" class="jv-user jv-box<?php echo $botsl2['user9']['class']; ?>" style="width:<?php echo $botsl2['user9']['width']; ?>;">
													<div class="jv-box-inside">
														<jdoc:include type="modules" name="user9" style="jvxhtml" />
													</div>
												</div>
											<?php endif; ?>
												
											<?php if($this->countModules('user10')) : ?>
												<div id="jv-user10" class="jv-user jv-box<?php echo $botsl2['user10']['class']; ?>" style="width:<?php echo $botsl2['user10']['width']; ?>;">
													<div class="jv-box-inside">
														<jdoc:include type="modules" name="user10" style="jvxhtml" />
													</div>
												</div>
											<?php endif; ?>
												
										</div>
									</div>
									<?php endif; ?>

								</div>
								</div>
								</div>
									
							</div>	
						</div>
						<!-- END CONTAINER -->
						
					</div>
				</div>		
			</div>

		</div>
		</div>
		<!-- END MAINBODY -->

		<?php
		$spotlight = array ('user11','user12','user13','user14');
		$botsl3 = $jvTools->calSpotlight ($spotlight,$jvTools->isOP()?99:100,'%');
		if( $botsl3 ) :
		?>

		<div id="jv-userwrap4" class="clearfix">
		<div id="jv-userwrap4-2">
			<div class="jv-wrapper">
				<div id="jv-userwrap4-inner">
				
					<?php if($this->countModules('user11')) : ?>
						<div id="jv-user11" class="jv-user jv-box<?php echo $botsl3['user11']['class']; ?>" style="width: <?php echo $botsl3['user11']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user11" style="jvxhtml" />
							</div>
						</div>
					<?php endif; ?>

					<?php if($this->countModules('user12')) : ?>
						<div id="jv-user12" class="jv-user jv-box<?php echo $botsl3['user12']['class']; ?>" style="width: <?php echo $botsl3['user12']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user12" style="jvxhtml" />
							</div>
						</div>
					<?php endif; ?>

					<?php if($this->countModules('user13')) : ?>
						<div id="jv-user13" class="jv-user jv-box<?php echo $botsl3['user13']['class']; ?>" style="width: <?php echo $botsl3['user13']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user13" style="jvxhtml" />
							</div>
						</div>
					<?php endif; ?>

					<?php if($this->countModules('user14')) : ?>
						<div id="jv-user14" class="jv-user " style="width: <?php echo $botsl3['user14']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user14" style="jvxhtml" />
							</div>
						</div>
					<?php endif; ?>

				</div>
			</div>
		</div>
		</div>
		<?php endif; ?>
		

		<?php
		$spotlight = array ('user15','user16','user17','user18');
		$botsl2 = $jvTools->calSpotlight($spotlight,$jvTools->isOP()?100:100, '%');
		if( $botsl2 ) :
		?>
		<div id="jv-userwrap5" class="clearfix">
			<div class="jv-wrapper">
				<div id="jv-userwrap5-inner">	

					<?php if($this->countModules('user15')) : ?>
						<div id="jv-user15" class="jv-user jv-box<?php echo $botsl2['user15']['class']; ?>" style="width:<?php echo $botsl2['user15']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user15" style="jvxhtml2" />
							</div>
						</div>
					<?php endif; ?>

					<?php if($this->countModules('user16')): ?>
						<div id="jv-user16" class="jv-user jv-box<?php echo $botsl2['user16']['class']; ?> " style="width:<?php echo $botsl2['user16']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user16" style="jvxhtml2" />
							</div>
						</div>
					<?php endif; ?>
						
					<?php if($this->countModules('user17')) : ?>
						<div id="jv-user17" class="jv-user jv-box<?php echo $botsl2['user17']['class']; ?>" style="width:<?php echo $botsl2['user17']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user17" style="jvxhtml2" />
							</div>
						</div>
					<?php endif; ?>
						
					<?php if($this->countModules('user18')) : ?>
						<div id="jv-user18" class="jv-user jv-box<?php echo $botsl2['user18']['class']; ?>" style="width:<?php echo $botsl2['user18']['width']; ?>;">
							<div class="jv-box-inside">
								<jdoc:include type="modules" name="user18" style="jvxhtml2" />
							</div>
						</div>
					<?php endif; ?>
						
				</div>
			</div>
		</div>
		<?php endif; ?>

		<div id="jv-bottom" class="clearfix">
			<div class="jv-wrapper">
				<div id="jv-bottom-inner">

					<?php if($this->countModules('footer')) : ?>
					<div id="jv-footer">
						<div id="jv-footer-inner"><jdoc:include type="modules" name="footer" /></div>
					</div>
					<?php endif; ?>
					<?php if($jvTools->getParam('jv_function')) : ?>
					<div id="jv-tool"><?php echo $changecolor; ?></div>
					<?php endif; ?>
					<div id="jv-copyright">
						<div id="jv-copyright-inner">
							<?php if($jvTools->getParam('jv_footer')) : ?>
							<?php echo $jvTools->getParam('jv_footer_text'); ?>
							<?php else : ?>
							Copyright &copy; 2008 - 2010 <a href="http://www.joomlavision.com" title="Joomla Templates">Joomla Templates</a>  by <a href="http://www.joomlavision.com" title="JoomlaVision">JoomlaVision.Com</a>. All rights reserved.
							<?php endif; ?>
						</div>
					</div>

				</div>
			</div>
		</div>

	</div>
</div>


</body>
</html>

