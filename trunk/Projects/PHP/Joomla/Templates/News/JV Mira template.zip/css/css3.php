<?php 
/*---------------------------------------------------------------- 
  Copyright:
  Copyright (C) 2008 JoomVision. All Rights Reserved
  
  License:
  Copyrighted Commercial Software 
  
  Author:
  JoomVision - http://wwww.joomvision.com
---------------------------------------------------------------- */
header('Content-type: text/css; charset: UTF-8');
header('Cache-Control: must-revalidate');
header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 3600) . ' GMT');
$url = $_REQUEST['url'];
?>
#menusys_moo li ul {
	-webkit-box-shadow: #838383 0px 5px 10px;
	-moz-box-shadow: #838383 0px 5px 10px;
	box-shadow: #838383 0px 5px 10px;
	behavior: url(<?php echo $url; ?>/css/css3.htc);
}
#jv-userwrap3 {
	-webkit-border-radius: 0 0 8px 8px;
	-moz-border-radius: 0 0 8px 8px;
	border-radius: 0 0 8px 8px;
	behavior: url(<?php echo $url; ?>/css/css3.htc);
}
#jv-slideshow-inner2 {
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	border-radius: 8px;
	-webkit-box-shadow: #c7cccc 0px 0px 7px;
	-moz-box-shadow: #c7cccc 0px 0px 7px;
	box-shadow: #c7cccc 0px 0px 7px;
	behavior: url(<?php echo $url; ?>/css/css3.htc);
}
#jv-middle-inner {
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	border-radius: 8px;
	-webkit-box-shadow: #838383 0px 0px 7px;
	-moz-box-shadow: #838383 0px 0px 7px;
	box-shadow: #838383 0px 0px 7px;
	behavior: url(<?php echo $url; ?>/css/css3.htc);
}
#jv-middle-inner2 {
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	border-radius: 8px;
	behavior: url(<?php echo $url; ?>/css/css3.htc);
}
#jv-top {
	-webkit-border-radius: 8px 8px 0 0;
	-moz-border-radius: 8px 8px 0 0;
	border-radius: 8px 8px 0 0;
	behavior: url(<?php echo $url; ?>/css/css3.htc);
}
#jv-login div.jv-field-submit .button,
#jv-userwrap4 div.jv-field .button,
#jv-userwrap4 div.jv-field .button_white {
	-webkit-box-shadow: none;
	-moz-box-shadow: none;
	box-shadow: none;
}
.inputbox {
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
	/*behavior: url(<?php echo $url; ?>/css/css3.htc);*/
}
.button,
.button2 {
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
	-webkit-box-shadow: #888c8c 0px 0px 3px;
	-moz-box-shadow: #888c8c 0px 0px 3px;
	box-shadow: #888c8c 0px 0px 3px;
	/*behavior: url(<?php echo $url; ?>/css/css3.htc);*/
}
#jv-left div.moduletable,
#jv-left div.moduletable_menu,
#jv-left div.moduletable_contact,
#jv-left div.moduletable_text {
	-webkit-border-radius: 10px;
	-moz-border-radius: 10px;
	border-radius: 10px;
	-webkit-box-shadow: #838383 0px 0px 7px;
	-moz-box-shadow: #838383 0px 0px 7px;
	box-shadow: #838383 0px 0px 7px;
	behavior: url(<?php echo $url; ?>/css/css3.htc);
}