<?php // no direct access
defined('_JEXEC') or die('Restricted access'); 
$i = 0;
$count_list = count($list);
?>
<div class="latestnews  clearfix" >
<?php foreach ($list as $item) :  ?>
	<?php $i++; ?>
	<?php if($i == $count_list) : ?>
	<div class="latestnewsitems last-item" >
	<?php else : ?>
	<div class="latestnewsitems" >
	<?php endif; ?>	
		
		<?php if($params->get('thumb')==1 && $item->thumb) : ?>
		<a href="<?php echo $item->link; ?>" class="latestnews<?php echo $params->get('moduleclass_sfx'); ?>"><img src="<?php echo $item->thumb; ?>" border="0" alt="<?php echo $item->title; ?>" /></a>
		<?php endif; ?>
		<?php if($params->get('articletitle')==1) : ?>
		<h4><a href="<?php echo $item->link; ?>" class="latestnews<?php echo $params->get('moduleclass_sfx'); ?>"><?php echo $item->title; ?></a></h4>
		<?php endif; ?>
		
		<span class="hidden "><?php if($params->get('showintro')==1) echo $item->introtext; ?></span>
		<br/>
		<?php if($params->get('readmore')==1) : ?><a href="<?php echo $item->link; ?>" class="readone"><?php echo JText::sprintf('Read more '); ?></a><?php endif; ?>
	</div>
<?php endforeach; ?>
</div>
<div style="display: none;"><a href="http://www.joomlavision.com" title="Joomla Templates">Joomla Templates</a> and Joomla Extensions by JoomlaVision.Com</div>