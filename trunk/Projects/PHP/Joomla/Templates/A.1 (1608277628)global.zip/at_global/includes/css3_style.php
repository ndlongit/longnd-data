<?php defined( '_JEXEC' ) or die( 'Restricted index access' ); ?>
<style type="text/css">

#container_inner
{
border-radius: 10px 10px 0 0;
}
.footer .container
{
border-radius: 0 0 10px 10px;
}
.nav-child.unstyled.small
{
border-radius: 0 0 3px 3px;
}
.well
{
border-radius: 0;
}
#hor_nav li, #hor_nav li.active a, #hor_nav a:hover
{
border-radius: 0 0 0 0;
}
#hor_nav .menu ul li
{
border-radius: 0 0 0 0;
}
#page_header_h3
{
border-radius: 2px;
}
.well
{
border-radius: 4px;
}

</style>