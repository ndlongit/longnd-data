<?php
/*
*All for Web Template
*Alexander Kroker
*info@all-for-web.de
*
*/
defined( '_JEXEC' ) or die( 'Restricted access' ); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="<?php echo $this->language; ?>" xml:lang="<?php echo $this->language; ?>">
<head>
<jdoc:include type="head" />
<link rel="stylesheet" type="text/css" href="<?php echo $this->baseurl ?>/templates/afw-3d/css/template.css" />
<link rel="stylesheet" type="text/css" href="<?php echo $this->baseurl ?>/templates/afw-3d/css/slide.css" />
<link rel="stylesheet" type="text/css" href="<?php echo $this->baseurl ?>/templates/afw-3d/css/slimbox2.css" />
<link rel="stylesheet" type="text/css" href="<?php echo $this->baseurl ?>/templates/system/css/system.css" />
<link rel="stylesheet" type="text/css" href="<?php echo $this->baseurl ?>/templates/system/css/general.css" />
<script type="text/javascript" src="templates/<?php echo $this->template ?>/js/jquery.js"></script>
<script type="text/javascript" src="templates/<?php echo $this->template ?>/js/script.js"></script>
<!--[if IE 8]>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/afw-3d/css/ie8.css" type="text/css" />
<![endif]--> 
<!--[if IE 7]>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/afw-3d/css/ie7.css" type="text/css" />
<![endif]--> 
</head>
<body>
<div id="background">
<div id="container">
	<div id="website">
    	<a href="<?php echo $baseurl; ?>"><div id="logo">
        </div></a>
        <div id="search">
        	<jdoc:include type="modules" name="search" style="none" />
        </div>
        <div id="user3">
        	<jdoc:include type="modules" name="user3" style="none" />
        </div>
        <div id="content">
        	<?php if($this->countModules('top')) : ?>
            	<div id="top">
                	<jdoc:include type="modules" name="top" style="xhtml" />
                </div>
            <?php endif; ?>
            <?php if($this->countModules('user1')) : ?>
            	<div id="user1">
                	<jdoc:include type="modules" name="user1" style="xhtml" />
                </div>
            <?php endif; ?>
            <?php if($this->countModules('user2')) : ?>
            	<div id="user2">
                	<jdoc:include type="modules" name="user2" style="xhtml" />
                </div>
            <?php endif; ?>
            <div id="content_line">
            </div>
            <?php if($this->countModules('left')) : ?>
            	<div id="left">
                	<jdoc:include type="modules" name="left" style="xhtml" />
                </div>
                <div id="component_left">
                	<jdoc:include type="message" />
                    <jdoc:include type="component" />
                </div>
            <?php else : ?>
            	 <div id="component">
                	<jdoc:include type="message" />
                    <jdoc:include type="component" />
                </div>
            <?php endif; ?>
        </div>
        <div id="footer">
        	<div id="links">
            	<a href="http://www.geschenkideen-in.de" target="_blank">Geschenkideen</a> | <a href="http://www.all-for-web.de" target="_blank">Webdesign Agentur</a>
            </div>
            <div id="copyright">
            	<jdoc:include type="modules" name="copy" style="none" />
            </div>
        </div>
    </div>
</div>
</div>
</body>
</html>