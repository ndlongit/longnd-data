<?php
/**
 */
 
class awesInstallerEvents extends JPlugin {
 	public function onExtensionAfterInstall($installer, $eid)
	{
        $lang = JFactory::getLanguage();
        $lang->load('install_override',dirname(__FILE__), $lang->getTag(), true);
	}
}
